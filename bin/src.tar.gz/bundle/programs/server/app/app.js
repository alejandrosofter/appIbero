var require = meteorInstall({"lib":{"collections.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 0);
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 1);
Settings = new Mongo.Collection('settings');
Anclajes = new Mongo.Collection('anclajes');
AnclajesEquipos = new Mongo.Collection('anclajesEquipos');
Personal = new Mongo.Collection('personal');
PersonalLiquidaciones = new Mongo.Collection('personalLiquidaciones');
TipoPerfiles = new Mongo.Collection('tipoPerfiles');
Archivos = new FilesCollection({
  collectionName: 'Archivos'
}); // export default Archivos; 
// Archivos = new FS.Collection("archivos", {
//   stores: [new FS.Store.FileSystem("archivos", {path: "/var/www/uploads"})]
// });
// Archivos.allow({
//  insert: function(){
//  return true;
//  },
//  update: function(){
//  return true;
//  },
//  remove: function(){
//  return true;
//  },
//  download: function(){
//  return true;
//  }
// });

TipoPerfiles.attachSchema(new SimpleSchema({
  nombrePerfil: {
    type: String,
    label: "Nombre Perfil"
  },
  esAdministrador: {
    type: Boolean,
    label: "Es administrador?",
    autoform: {
      type: "boolean-checkbox"
    }
  },
  modulosAcceso: {
    type: Array,
    label: 'Modulos de Acceso',
    optional: true
  },
  "modulosAcceso.$": {
    type: Object
  },
  "modulosAcceso.$._id": {
    type: String,
    autoform: {
      type: "hidden"
    },
    autoValue: function () {
      return Random.id();
    }
  },
  "modulosAcceso.$.soloVerMios": {
    type: Boolean,
    autoform: {
      type: "boolean-checkbox"
    },
    optional: true
  },
  "modulosAcceso.$.nombre": {
    type: String,
    label: "Nombre Modulo [acciones]"
  }
}));
PersonalLiquidaciones.attachSchema(new SimpleSchema({
  horas: {
    type: Array,
    label: 'Horas',
    optional: true
  },
  "horas.$": {
    type: Object
  },
  "horas.$._id": {
    type: String,
    autoValue: function () {
      return Random.id();
    }
  },
  "horas.$.dia": {
    type: Number,
    optional: true,
    label: "Día",
    autoform: {
      style: "width:60px"
    }
  },
  "horas.$.viandas": {
    type: Number,
    optional: true,
    autoform: {
      style: "width:60px"
    }
  },
  "horas.$.cantidad": {
    type: Number,
    optional: false,
    autoform: {
      style: "width:60px"
    }
  },
  "horas.$.idPersonal": {
    type: String,
    optional: false,
    label: "Personal",
    autoform: {
      type: "hidden",
      style: "width:60px"
    }
  },
  "horas.$.tipoHora": {
    type: String,
    optional: true,
    label: "Tipo de Hora",
    autoform: {
      type: "select2",
      placeholder: 'Seleccione...',
      style: "width:120px",
      options: [{
        label: "NORMAL",
        value: "NORMAL"
      }, {
        label: "AL 50%",
        value: "AL 50%"
      }, {
        label: "AL 100%",
        value: "AL 100%"
      }, {
        label: "50% NOCT.",
        value: "50% NOCT."
      }, {
        label: "100% NOCT",
        value: "100% NOCT"
      }, {
        label: "FERIADO",
        value: "FERIADO"
      }, {
        label: "ESPECIAL",
        value: "ESPECIAL"
      }]
    }
  },
  fechaDesde: {
    type: Date,
    label: "Desde"
  },
  fechaHasta: {
    type: Date,
    label: "Hasta"
  },
  tipoPersonal: {
    type: String,
    label: "Tipo Personal",
    autoform: {
      type: "select2",
      placeholder: 'TIPO PERSONAL',
      style: "width:220px",
      options: [{
        label: "UOCRA",
        value: "UOCRA"
      }, {
        label: "FUERA CONVENIO",
        value: "FUERA CONVENIO"
      }]
    }
  },
  estado: {
    type: String,
    label: "Estado",
    autoform: {
      type: "select2",
      placeholder: 'Estado',
      style: "width:220px",
      options: [{
        label: "PENDIENTE",
        value: "PENDIENTE"
      }, {
        label: "CANCELADO",
        value: "CANCELADO"
      }]
    }
  }
}));
Personal.attachSchema(new SimpleSchema({
  accidentes: {
    type: Array,
    label: 'Accidentes',
    optional: true
  },
  "accidentes.$": {
    type: Object
  },
  "accidentes.$._id": {
    type: String,
    autoValue: function () {
      return Random.id();
    }
  },
  "accidentes.$.fechaAccidente": {
    type: Date,
    label: "Fecha Accidente",
    autoform: {
      style: "font-size:9px;text-indent:0.5px"
    }
  },
  "accidentes.$.fechaDenuncua": {
    type: Date,
    label: "Fecha Denuncia",
    autoform: {
      style: "font-size:9px;text-indent:0.5px"
    }
  },
  "accidentes.$.fechaAlta": {
    type: Date,
    label: "Fecha Alta",
    autoform: {
      style: "font-size:9px;text-indent:0.5px"
    }
  },
  "accidentes.$.comentario": {
    type: String,
    optional: true,
    label: "Comentarios",
    autoform: {
      type: "textarea"
    }
  },
  apellido: {
    type: String,
    label: "Apellido"
  },
  nombre: {
    type: String,
    label: "Nombre"
  },
  nroLegajo: {
    type: Number,
    unique: true,
    label: "Nro Legajo"
  },
  cuil: {
    type: String,
    label: "CUIL"
  },
  tipoPersonal: {
    type: String,
    label: "Tipo Personal",
    autoform: {
      type: "select2",
      placeholder: 'TIPO PERSONAL',
      style: "width:140px",
      options: [{
        label: "UOCRA",
        value: "UOCRA"
      }, {
        label: "FUERA CONVENIO",
        value: "FUERA CONVENIO"
      }]
    }
  },
  obraSocial: {
    type: String,
    label: "Obra Social"
  },
  sueldo: {
    type: String,
    label: "Sueldo"
  },
  centroCosto: {
    type: String,
    label: "CC",
    autoform: {
      type: "select2",
      placeholder: 'CC',
      style: "width:80px",
      options: [{
        label: "100",
        value: "100"
      }, {
        label: "101",
        value: "101"
      }, {
        label: "200",
        value: "200"
      }, {
        label: "300",
        value: "300"
      }, {
        label: "500",
        value: "500"
      }, {
        label: "600",
        value: "600"
      }, {
        label: "601",
        value: "601"
      }, {
        label: "603",
        value: "603"
      }, {
        label: "700",
        value: "700"
      }, {
        label: "701",
        value: "701"
      }]
    }
  },
  categoria: {
    type: String,
    label: "Cactegoria",
    autoform: {
      type: "select2",
      placeholder: 'Categoria',
      style: "width:160px",
      options: [{
        label: "AYUDANTE",
        value: "AYUDANTE"
      }, {
        label: "MEDIO OFICIAL",
        value: "MEDIO OFICIAL"
      }, {
        label: "OFICIAL",
        value: "OFICIAL"
      }, {
        label: "OFICIAL ESPECIAL",
        value: "OFICIAL ESPECIAL"
      }, {
        label: "SERENO",
        value: "SERENO"
      }]
    }
  },
  fechaExamen: {
    type: Date,
    label: "Exámen Preoc.",
    optional: true
  },
  estado: {
    type: String,
    label: "Estado",
    autoform: {
      type: "select2",
      placeholder: 'Estado',
      style: "width:160px",
      options: [{
        label: "ALTA",
        value: "ALTA"
      }, {
        label: "BAJA",
        value: "BAJA"
      }, {
        label: "SUSPENDIDO",
        value: "SUSPENDIDO"
      }]
    }
  }
}));
AnclajesEquipos.attachSchema(new SimpleSchema({
  nombreEquipo: {
    type: String,
    label: "Nombre Equipo"
  },
  detalle: {
    type: String,
    label: 'Detalle',
    optional: true,
    autoform: {
      type: "textarea",
      placeholder: 'Detalle para el equipo de ensayo'
    }
  },
  idUsuario: {
    type: String,
    label: 'Usuario',
    optional: true,
    autoform: {
      type: "select2",
      options: function () {
        if (Meteor.isClient) return _.map(Session.get("usuarios"), function (c, i) {
          return {
            label: c.username,
            value: c._id
          };
        });
      },
      style: "width:250px"
    }
  },
  created: {
    type: Date,
    optional: true,
    autoValue: function () {
      if (this.isInsert) {
        return new Date();
      } else if (this.isUpsert) {
        return {
          $setOnInsert: new Date()
        };
      } else {
        this.unset();
      }
    }
  },
  updated: {
    type: Date,
    optional: true,
    autoValue: function () {
      if (this.isUpdate) {
        return new Date();
      }
    }
  }
}));
Anclajes.attachSchema(new SimpleSchema({
  // zona: {
  //   type: String,
  //   label: 'Zona',
  //   autoform: {
  //      type: "select2",
  //     placeholder: 'Seleccione Zona',
  //     style: "width:80px",
  //     options: [
  //       {label: "AH", value: "AH"},
  //           {label: "BV", value: "BV"},
  //           {label: "CL", value: "CL"},
  //           {label: "CM", value: "CM"},
  //           {label: "COV", value: "COV"},
  //           {label: "CS", value: "CS"},
  //           {label: "CW", value: "CW"},
  //           {label: "EC", value: "EC"},
  //           {label: "EH", value: "EH"},
  //           {label: "HT", value: "ET"},
  //           {label: "KK", value: "KK"},
  //           {label: "LH", value: "LH"},
  //           {label: "ME", value: "ME"},
  //           {label: "MS", value: "MS"},
  //           {label: "MSA", value: "MSA"},
  //           {label: "PC", value: "PC"},
  //           {label: "PCX", value: "PCX"},
  //           {label: "SPC", value: "SPC"},
  //           {label: "TP", value: "TP"},
  //     ]
  //   },
  //   max: 200
  // },
  certificado: {
    type: String,
    optional: true,
    label: "Certificado",
    autoform: {
      placeholder: "Click para seleccionar el archivo del CERTIFICADO (puede arrastrar aquí tambien)...",
      // afFieldInput: {
      //   type: "cfs-file",
      //   collection: "archivos"
      // }
      afFieldInput: {
        type: 'fileUpload',
        collection: 'Archivos' // uploadTemplate: 'uploadField' // <- Optional
        // previewTemplate: 'uploadPreview' // <- Optional

      }
    }
  },
  pozo: {
    type: String,
    label: 'Pozo'
  },
  bateria: {
    type: String,
    label: 'Bateria',
    optional: true
  },
  idUsuario: {
    type: String,
    label: 'Usuario',
    optional: true
  },
  certificacion: {
    type: String,
    label: 'Nro Cert.'
  },
  equipoEnsayo: {
    type: String,
    optional: true,
    label: "Equipo Ensayo",
    autoform: {
      type: "select2",
      select2Options: {
        placeholder: 'Seleccione...',
        width: "200px",
        allowClear: true
      },
      options: function () {
        return _.map(AnclajesEquipos.find().fetch(), function (c, i) {
          return {
            label: c.nombreEquipo,
            value: c._id
          };
        });
      },
      style: "width:250px"
    }
  },
  equipoIngresante: {
    type: String,
    label: 'Equipo Ingresante',
    autoform: {
      type: "select2",
      placeholder: 'Equipo Ingresante',
      style: "width:120px",
      options: [{
        label: "PULLING",
        value: "PULLING"
      }, {
        label: "DRILLING",
        value: "DRILLING"
      }, {
        label: "WORK OVER",
        value: "WORK OVER"
      }]
    }
  },
  fechaEnsayo: {
    type: Date,
    label: 'Fecha Construccion',
    optional: true
  },
  fechaConstruccion: {
    type: Date,
    label: 'Fecha Ensayo',
    optional: true
  },
  horaEnsayo: {
    type: String,
    label: 'Hora Ensayo',
    optional: true
  },
  numeroAFE: {
    type: String,
    label: 'Nro AFE',
    optional: true
  },
  cantidadAnclajes: {
    type: Number,
    label: 'Cant. Construidos',
    optional: true
  },
  tipoAnclajesConstruidos: {
    type: Number,
    label: 'Tipo Anclaje Construido',
    autoform: {
      type: "select2",
      placeholder: 'Tipo Anclaje Construido',
      style: "width:300px",
      options: [{
        label: "PERFORACIÓN",
        value: "PERFORACIÓN"
      }, {
        label: "TERMINACIÓN",
        value: "TERMINACIÓN"
      }]
    },
    optional: true
  },
  numeroFactura: {
    type: String,
    label: 'Nro Factura',
    optional: true
  },
  archivo: {
    type: String,
    label: 'Archivo',
    optional: true
  },
  constEnsayo: {
    type: String,
    label: 'constEnsayo',
    optional: true
  },
  cantidadAnclaje: {
    type: String,
    label: 'cantidadAnclaje',
    optional: true
  },
  constConstruido: {
    type: String,
    label: 'constConstruido',
    optional: true
  },
  estadoNO: {
    type: String,
    label: 'NO',
    optional: true,
    autoform: {
      type: "select",
      firstOption: "",
      options: [{
        label: "A",
        value: "A"
      }, {
        label: "R",
        value: "R"
      }, {
        label: "",
        value: ""
      }]
    }
  },
  estadoNE: {
    type: String,
    label: 'NE',
    optional: true,
    autoform: {
      type: "select",
      firstOption: "",
      options: [{
        label: "A",
        value: "A"
      }, {
        label: "R",
        value: "R"
      }, {
        label: "",
        value: ""
      }]
    }
  },
  estadoSO: {
    type: String,
    label: 'SO',
    optional: true,
    autoform: {
      type: "select",
      firstOption: "",
      options: [{
        label: "A",
        value: "A"
      }, {
        label: "R",
        value: "R"
      }, {
        label: "",
        value: ""
      }]
    }
  },
  estadoSE: {
    type: String,
    label: 'SE',
    optional: true,
    autoform: {
      type: "select",
      firstOption: "",
      options: [{
        label: "A",
        value: "A"
      }, {
        label: "R",
        value: "R"
      }, {
        label: "",
        value: ""
      }]
    }
  },
  nroReporte: {
    type: String,
    label: 'Nro Reporte',
    optional: true
  },
  observaciones: {
    type: Array,
    label: 'Observaciones',
    optional: true
  },
  "observaciones.$": {
    type: Object
  },
  "observaciones.$._id": {
    type: String,
    autoValue: function () {
      return Random.id();
    }
  },
  "observaciones.$.fecha": {
    type: Date,
    optional: true,
    autoform: {
      type: "hidden"
    }
  },
  "observaciones.$.usuario": {
    type: String,
    optional: true,
    autoform: {
      type: "hidden"
    }
  },
  "observaciones.$.detalle": {
    type: String,
    label: "Observacion",
    // optional:true,
    autoform: {
      // type:"textarea",
      // style:"width:450px",
      placeholder: "Describa la observación..."
    }
  },
  estado: {
    type: String,
    label: 'Estado',
    optional: true
  }
}));
Settings.attachSchema(new SimpleSchema({
  clave: {
    type: String,
    label: "Clave"
  },
  valor: {
    type: String,
    label: 'Valor'
  },
  fecha: {
    type: Date,
    label: 'Fecha',
    optional: true
  },
  created: {
    type: Date,
    optional: true,
    autoValue: function () {
      if (this.isInsert) {
        return new Date();
      } else if (this.isUpsert) {
        return {
          $setOnInsert: new Date()
        };
      } else {
        this.unset();
      }
    }
  },
  updated: {
    type: Date,
    optional: true,
    autoValue: function () {
      if (this.isUpdate) {
        return new Date();
      }
    }
  }
}));
TipoPerfiles.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
Anclajes.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
AnclajesEquipos.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
PersonalLiquidaciones.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
PersonalLiquidaciones.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
TipoPerfiles.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/router.js                                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
applicationController = RouteController.extend({
  layoutTemplate: 'layoutApp',
  loadingTemplate: 'loaderGral',
  notFoundTemlplate: 'notFound',
  // 	  yieldTemplates: {
  // 		'applicationHeader': {to: 'header'},
  // 		'projectSwitcher': {to: 'projectSwitcher'},
  // 		'applicationMainNav': {to: 'mainNav'},
  // 		'applicationFooter': {to: 'footer'}
  // 	  },
  waitOn: function () {
    return [];
  },
  onBeforeAction: function (pause) {
    this.render('loaderGral');

    if (!Meteor.user()) {
      this.render('login');
    } // 		if (!!this.ready() && Projects.find().count() === 0)
    else {
        this.next();
      }
  },
  action: function () {
    if (!this.ready()) {
      this.render('loaderGral');
    } else {
      UIBlock.unblock();
      this.render();
    }
  }
});
Router.route('/inicio', {
  path: '/inicio',
  // layoutTemplate: 'layoutVacio',
  template: "inicio",
  controller: applicationController
});
Router.route('descargaCertificado', {
  where: 'server',
  path: '/descargaCertificado/:id',
  action: function () {
    var a = Settings.findOne({
      clave: "folderUploads"
    });
    var pathUploads = a ? a.valor : "/var/www/??";
    var archivo = Archivos.findOne({
      _id: this.params.id
    });

    if (archivo) {
      var filename = archivo.path;
      var path = pathUploads + filename;
      var serv = this;
      fs = Npm.require('fs');

      if (!fs.existsSync(path)) {
        this.response.writeHead(200, {
          'Content-Disposition': "attachment; filename=notFound.pdf"
        });
        return this.response.end(false);
      }

      var data = fs.readFileSync(path);
      this.response.writeHead(200, {
        'Content-Disposition': "attachment; filename=" + filename
      });
      return this.response.end(data);
    } // return this.response.end("No encuentro archivo!");

  }
});
Router.route('/personalLiquidaciones', {
  path: '/personalLiquidaciones',
  // layoutTemplate: 'layoutVacio',
  template: "personalLiquidaciones",
  controller: applicationController
});
Router.route('/tipoPerfiles', {
  path: '/tipoPerfiles',
  // layoutTemplate: 'layoutVacio',
  template: "tipoPerfiles",
  controller: applicationController
});
Router.route('/horasLiquidacion/:_id', {
  template: 'horasLiquidacion',
  controller: applicationController
});
Router.route('/personal', {
  path: '/personal',
  // layoutTemplate: 'layoutVacio',
  template: "personal",
  controller: applicationController
});
Router.route('/', {
  path: '/',
  // layoutTemplate: 'layoutVacio',
  template: "inicio",
  controller: applicationController
});
Router.route('/anclajes', {
  path: '/anclajes',
  // layoutTemplate: 'layoutVacio',
  template: "anclajes",
  controller: applicationController
});
Router.route('/anclajesEquipos', {
  path: '/anclajesEquipos',
  // layoutTemplate: 'layoutVacio',
  template: "anclajesEquipos",
  controller: applicationController
});
Router.route('/datosSistema', {
  path: '/datosSistema',
  // layoutTemplate: 'layoutVacio',
  template: "datosSistema",
  controller: applicationController
});
Router.route('/modificarDatosSistema/:_id', {
  template: 'modificarDatosSistema',
  controller: applicationController,
  data: function () {
    var sal = Settings.findOne({
      _id: this.params._id
    });
    return sal;
  }
});
Router.route('/usuarios', {
  path: '/usuarios',
  // layoutTemplate: 'layoutVacio',
  template: "usuarios",
  controller: applicationController
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tabular.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/tabular.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Tabular;
module.link("meteor/aldeed:tabular", {
  default(v) {
    Tabular = v;
  }

}, 0);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 1);
so__ = new Tabular.Table({
  name: "Anclajes",
  language: {
    processing: "<img src='/images/loading.gif'>"
  },
  processing: true,
  stateSave: true,
  collection: Anclajes,
  filters: ['filtro_equipoEnsayo'],

  createdRow(row, data, dataIndex) {
    if (data.estado == "BAJA") {
      var fila = $(row);
      var dias = getDiasVto(row.fechaEnsayo);
      if (dias < 90) fila.attr("class", "warning"); //danger, success,info
    }
  },

  extraFields: ['equipoEnsayo', 'horaEnsayo', "certificado", "observaciones", "equipoIngresante"],
  buttons: ['copy', 'excel', 'csv', 'colvis'],
  autoWidth: false,
  // puse esto por que cuando eliminaba un socio y volvia a socios queda la tabla por la mitad
  //classname:"compact",
  columns: [{
    title: 'Vto.',
    width: '80px',
    data: "fechaEnsayo",
    render: function (value, type, object) {
      var dias = getDiasVto(value);
      if (dias < 90) return "Muy Vencido";
      return dias + " dias";
    }
  }, {
    title: 'Pozo',
    width: '100px',
    data: "pozo"
  }, {
    title: 'Bateria',
    width: '70px',
    data: "bateria",
    render: function (value, type, object) {
      if (value) return value;
      return "-";
    }
  }, {
    title: 'Cert.',
    width: '70px',
    data: "certificacion"
  }, {
    title: 'Equipo',
    width: '100px',
    data: "equipoEnsayo",
    render: function (value, type, object) {
      var aux = AnclajesEquipos.findOne(value);
      if (aux) return aux.nombreEquipo;
      return "-";
    },
    visible: true
  }, {
    title: 'Ensayado..',
    width: '100px',
    data: "fechaEnsayo",
    render: function (value, type, object) {
      var d = new Date(value);
      var hora = object.horaAnclaje ? object.horaAnclaje : "";
      if (value) return d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear() + " " + hora;
      return "-";
    }
  }, {
    title: 'Construido..',
    width: '100px',
    data: "fechaConstruccion",
    render: function (value, type, object) {
      var d = new Date(value);
      if (value) return d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
      return "-";
    }
  }, {
    title: 'NO',
    width: '30px',
    data: "estadoNO",
    render: function (value, type, object) {
      return new Spacebars.SafeString(colorearEstado(value));
    }
  }, {
    title: 'NE',
    width: '30px',
    data: "estadoNE",
    render: function (value, type, object) {
      return new Spacebars.SafeString(colorearEstado(value));
    }
  }, {
    title: 'SO',
    width: '30px',
    data: "estadoSO",
    render: function (value, type, object) {
      return new Spacebars.SafeString(colorearEstado(value));
    }
  }, {
    title: 'SE',
    width: '30px',
    data: "estadoSE",
    render: function (value, type, object) {
      return new Spacebars.SafeString(colorearEstado(value));
    }
  }, {
    width: '160px',
    tmpl: Meteor.isClient && Template.accionesAnclajes
  }]
});

function colorearEstado(estado) {
  if (estado == "A") return "<b style='color:green'>" + estado + "</b>";
  if (estado == "R") return "<b style='color:red'>" + estado + "</b>";
  return "<b style='color:grey'> - </b>";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/utils.js                                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
!function (module1) {
  /*eslint-disable no-unreachable, no-extend-native, no-undef, semi*/
  String.prototype.lpad = function (padString, length) {
    var str = this;

    while (str.length < length) str = padString + str;

    return str;
  };

  Date.prototype.addHours = function (h) {
    this.setTime(this.getTime() + h * 60 * 60 * 1000);
    return this;
  };

  Date.prototype.addDays = function (num) {
    var value = this.valueOf();
    value += 86400000 * num;
    return new Date(value);
  };

  String.prototype.lpad = function (padString, length) {
    var str = this;

    while (str.length < length) str = padString + str;

    return str;
  };

  String.prototype.capitalizar = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
  };

  String.prototype.rpad = function (padString, length) {
    var str = this;

    while (str.length < length) str = str + padString;

    return str;
  };

  Date.prototype.getFecha = function () {
    var value = this.valueOf();
    value += 86400000 * 1;
    var d = new Date(value);
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
  };

  Date.prototype.getFecha2 = function () {
    var value = this.valueOf();
    value += 86400000 * 1;
    var d = new Date(value);
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
  };

  Date.prototype.getMes = function () {
    var value = this.valueOf();
    value += 86400000 * 1;
    var d = new Date(value);
    return d.getMonth() + 1;
  };

  Date.prototype.getDia = function () {
    var value = this.valueOf();
    value += 86400000 * 1;
    var d = new Date(value);
    return d.getDate();
  };

  Date.prototype.getAno = function () {
    var value = this.valueOf();
    value += 86400000 * 1;
    var d = new Date(value);
    return d.getFullYear();
  };

  Number.prototype.formatMoney = function (n, x, s, c) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
        num = this.toFixed(Math.max(0, ~~n));
    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
  };

  function validarLargoCBU(cbu) {
    if (cbu.length != 22) {
      return false;
    }

    return true;
  }

  var validarCodigoBanco = function (codigo) {
    if (codigo.length != 8) {
      return false;
    }

    var banco = codigo.substr(0, 3);
    var digitoVerificador1 = codigo[3];
    var sucursal = codigo.substr(4, 3);
    var digitoVerificador2 = codigo[7];
    var suma = banco[0] * 7 + banco[1] * 1 + banco[2] * 3 + digitoVerificador1 * 9 + sucursal[0] * 7 + sucursal[1] * 1 + sucursal[2] * 3;
    var diferencia = 10 - suma % 10;
    return diferencia == digitoVerificador2;
  };

  mesLetras = function (mes) {
    if (mes == 1) return "ENERO";
    if (mes == 2) return "FEBRERO";
    if (mes == 3) return "MARZO";
    if (mes == 4) return "ABRIL";
    if (mes == 5) return "MAYO";
    if (mes == 6) return "JUNIO";
    if (mes == 7) return "JULIO";
    if (mes == 8) return "AGOSTO";
    if (mes == 9) return "SEPTEMBRE";
    if (mes == 10) return "OCTUBRE";
    if (mes == 11) return "NOVIEMBRE";
    if (mes == 12) return "DICIEMBRE";
    return "s/a";
  };

  mesNumeros = function (mes) {
    if (mes == "ENERO") return 1;
    if (mes == "FEBRERO") return 2;
    if (mes == "MARZO") return 3;
    if (mes == "ABRIL") return 4;
    if (mes == "MAYO") return 5;
    if (mes == "JUNIO") return 6;
    if (mes == "JULIO") return 7;
    if (mes == "AGOSTO") return 8;
    if (mes == "SEPTEMBRE") return 9;
    if (mes == "OCTUBRE") return 10;
    if (mes == "NOVIEMBRE") return 11;
    if (mes == "DICIEMBRE") return 12;
    return null;
  };

  getMeses = function () {
    return ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
  };

  ripFechaArchivo = function (fechaDate) {
    var st = fechaDate.toLocaleDateString();
    var arr = st.split("/");
    return arr[0].lpad("0", 2) + arr[1].lpad("0", 2) + arr[2].lpad("0", 2);
  };

  getImporteTotalSocios = function (arr) {
    var sum = 0;

    for (var i = 0; i < arr.length; i++) sum += arr[i].importe * 1;

    return sum;
  };

  ripImporteArchivo = function (importe) {
    importe = importe + "";
    var arr = importe.split(".");
    if (arr.length > 1) return arr[0].lpad("0", 8) + arr[1].lpad("0", 2);
    return arr[0].lpad("0", 8) + "00";
  };

  var validarCuenta = function (cuenta) {
    if (cuenta.length != 14) {
      return false;
    }

    var digitoVerificador = cuenta[13];
    var suma = cuenta[0] * 3 + cuenta[1] * 9 + cuenta[2] * 7 + cuenta[3] * 1 + cuenta[4] * 3 + cuenta[5] * 9 + cuenta[6] * 7 + cuenta[7] * 1 + cuenta[8] * 3 + cuenta[9] * 9 + cuenta[10] * 7 + cuenta[11] * 1 + cuenta[12] * 3;
    var diferencia = 10 - suma % 10;
    return diferencia == digitoVerificador;
  };

  validarCBU = function (cbu) {
    return validarLargoCBU(cbu) && validarCodigoBanco(cbu.substr(0, 8)) && validarCuenta(cbu.substr(8, 14));
  };

  getClaseTipoSocio = function (fechaNac, esActivo, estado) {
    var tipo = getTipoSocio(fechaNac, esActivo);
    if (estado == "BAJA") return "bajaSocio";
    var clase = tipo === "PARTICIPANTE" ? "text-warning" : "text-info";
    if (tipo === "ACTIVO") clase = "text-danger";
    return clase;
  };

  geTipoSocioEdad = function (edad, activo) {
    var edadAdherente = parseFloat(Settings.findOne({
      clave: "edadAdherente"
    }).valor);
    if (activo) return "ACTIVO";
    if (edad >= edadAdherente) return "ADHERENTE";
    return "PARTICIPANTE";
  };

  getImporteSocioEdad = function (edad, activo) {
    var edadAdherente = parseFloat(Settings.findOne({
      clave: "edadAdherente"
    }).valor);
    if (activo) return parseFloat(Settings.findOne({
      clave: "importeActivos"
    }).valor);
    if (edad >= edadAdherente) return parseFloat(Settings.findOne({
      clave: "imprteAdherentes"
    }).valor);
    return parseFloat(Settings.findOne({
      clave: "importeParticipantes"
    }).valor);
  };

  getEdadSocio = function (fechaNac) {
    var hoy = new Date();
    var cumpleanos = new Date(fechaNac);
    var edad = hoy.getAno() - cumpleanos.getAno();
    var m = hoy.getMes() - cumpleanos.getMes();

    if (m < 0 || m === 0 && hoy.getDia() < cumpleanos.getDia()) {
      edad--;
    }

    return edad;
  };

  getTipoSocio = function (fechaNac, esActivo) {
    var edadAdherente = parseFloat(Settings.findOne({
      clave: "edadAdherente"
    }).valor);
    var anos = getEdadSocio(fechaNac);
    if (esActivo) return "ACTIVO";
    return anos < edadAdherente ? "PARTICIPANTE" : "ADHERENTE";
  };

  getImporteSocio = function (idSocio) {
    var dataParticipantes = Settings.findOne({
      clave: "importeParticipantes"
    });
    var dataAdherentes = Settings.findOne({
      clave: "importeAdherentes"
    });
    var dataActivos = Settings.findOne({
      clave: "importeActivos"
    });
    var edadAdherente = parseFloat(Settings.findOne({
      clave: "edadAdherente"
    }).valor);
    var socio = Socios.findOne({
      _id: idSocio
    });
    var anos = getEdadSocio(socio.fechaNacimiento);
    if (socio.esActivo) return dataActivos.valor;
    if (anos < edadAdherente) return dataParticipantes.valor;
    return dataAdherentes.valor;
  };

  getImporteSocioDatos = function (fechaNacimiento, esActivo) {
    var dataParticipantes = Settings.findOne({
      clave: "importeParticipantes"
    });
    var dataAdherentes = Settings.findOne({
      clave: "importeAdherentes"
    });
    var dataActivos = Settings.findOne({
      clave: "importeActivos"
    });
    var edadAdherente = parseFloat(Settings.findOne({
      clave: "edadAdherente"
    }).valor);
    var anos = getEdadSocio(fechaNacimiento);
    if (esActivo) return dataActivos.valor;
    if (anos < edadAdherente) return dataParticipantes.valor;
    return dataAdherentes.valor;
  };

  module.exports = getTipoSocio;
}.call(this, module);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utilsUsuarios.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/utilsUsuarios.js                                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
getModulo = function (nombreModulo, modulos) {
  if (modulos) for (var i = 0; i < modulos.length; i++) if (String(modulos[i].nombre).toLocaleLowerCase() == String(nombreModulo).toLowerCase()) return modulos[i];
  return false;
};

getModulo2 = function (nombreModulo) {
  var tipoPerfil = TipoPerfiles.findOne({
    _id: Meteor.user().profile
  });
  console.log(Meteor.user().profile);

  if (tipoPerfil) {
    var modulos = tipoPerfil.modulosAcceso;
    if (tipoPerfil.esAdministrador) return true;

    for (var i = 0; i < modulos.length; i++) if (String(modulos[i].nombre).toLocaleLowerCase() == String(nombreModulo).toLowerCase()) return modulos[i];
  }

  return false;
};

getColeccionAcceso = function (tipoPerfil, user, nombreColeccion) {
  var Coleccion = eval(nombreColeccion);
  var modulo = getModulo("anclajes", tipoPerfil.modulosAcceso);
  if (tipoPerfil.esAdministrador) return Coleccion.find();

  if (modulo) {
    if (modulo.soloVerMios) {
      return Coleccion.find({
        idUsuario: user._id
      });
    }

    return Coleccion.find();
  }
};

getColeccionPerfil = function (nombreColeccion) {
  var usuario = Meteor.user();

  if (usuario) {
    var tipoPerfil = TipoPerfiles.findOne({
      _id: usuario.profile
    });
    if (tipoPerfil) return getColeccionAcceso(tipoPerfil, usuario, nombreColeccion);
  }

  return [];
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"DeudaSocios.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/DeudaSocios.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var getImporteSocio = function (idSocio) {
  var dataParticipantes = Settings.findOne({
    clave: "importeParticipantes"
  });
  var dataAdherentes = Settings.findOne({
    clave: "importeAdherentes"
  });
  var dataActivos = Settings.findOne({
    clave: "importeActivos"
  });
  var socio = Socios.findOne({
    _id: idSocio
  });
  var nacimiento = new Date(socio.fechaNacimiento);
  var ahora = new Date();
  var anos = ahora.getFullYear() - nacimiento.getFullYear();
  if (socio.esActivo) return dataActivos.valor;
  if (anos <= 18) return dataParticipantes.valor;
  return dataAdherentes.valor;
};

function DeudaSocios(detalle, fecha, esCuotaSocial, excluido) {} // var de=new DeudaSocios("CUOTA SOCIAL", new Date(),true, []);
//var excluir = doc.actividadesExcluir ? doc.actividadesExcluir : [];
//     de.cargarDeudaSocios();


getImporteSocio = function (idSocio) {
  var dataParticipantes = Settings.findOne({
    clave: "importeParticipantes"
  });
  var dataAdherentes = Settings.findOne({
    clave: "importeAdherentes"
  });
  var dataActivos = Settings.findOne({
    clave: "importeActivos"
  });
  var socio = Socios.findOne({
    _id: idSocio
  });
  var nacimiento = new Date(socio.fechaNacimiento);
  var ahora = new Date();
  var anos = ahora.getFullYear() - nacimiento.getFullYear();
  if (socio.esActivo) return dataActivos.valor;
  if (anos <= 18) return dataParticipantes.valor;
  return dataAdherentes.valor;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"funciones.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/funciones.js                                                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Funciones: () => Funciones
});
let Auxiliares;
module.link("./funciones_aux.js", {
  Auxiliares(v) {
    Auxiliares = v;
  }

}, 0);
let PythonShell;
module.link("python-shell", {
  PythonShell(v) {
    PythonShell = v;
  }

}, 1);

var _AUX = new Auxiliares();

Future = Npm.require('fibers/future');

var fs = Npm.require('fs');

class Funciones {
  getArchivos() {
    return Promise.asyncApply(() => {
      Archivos.remove({}); // console.log(Archivos.find().fetch())

      _AUX.cargarImagenes();
    });
  }

  eliminarAnclajes() {
    Anclajes.remove({});
    Archivos.remove({});
  }

  importarAnclajes() {
    var fut1 = new Future(); // var PythonShell = require('python-shell');

    var archi = './importarAnclajes.py';
    var path = process.cwd() + '/../web.browser/app/shellPython';
    var options = {
      mode: 'text',
      pythonPath: '/usr/bin/python2',
      scriptPath: path,
      args: []
    };
    PythonShell.run(archi, options, function (err, res) {
      if (err) throw err;
      return _AUX.cargarImagenes(fut1);
    });
    return fut1.wait();
  }

  generarVariables() {
    //Settings.remove({});
    if (!Settings.findOne({
      clave: "dbInyeccion"
    })) Settings.insert({
      clave: "dbInyeccion",
      valor: "utesa"
    });
    if (!Settings.findOne({
      clave: "claveInyeccion"
    })) Settings.insert({
      clave: "claveInyeccion",
      valor: "peterete"
    });
    if (!Settings.findOne({
      clave: "usuarioInyeccion"
    })) Settings.insert({
      clave: "usuarioInyeccion",
      valor: "alejandro"
    });
    if (!Settings.findOne({
      clave: "hostInyeccion"
    })) Settings.insert({
      clave: "hostInyeccion",
      valor: "134.209.175.156"
    });
    if (!Settings.findOne({
      clave: "cuitEmpresa"
    })) Settings.insert({
      clave: "cuitEmpresa",
      valor: "30670251140001"
    });
    if (!Settings.findOne({
      clave: "datosContacto"
    })) Settings.insert({
      clave: "datosContacto",
      valor: "email:su email, domicilio:suDomicilio otros datos"
    });
    if (!Settings.findOne({
      clave: "cadenaConexionMail"
    })) Settings.insert({
      clave: "cadenaConexionMail",
      valor: "smtp://USUARIO%40gmail.com:CLAVE@smtp.gmail.com:465/"
    });
    if (!Settings.findOne({
      clave: "puntoVentaDeudas"
    })) Settings.insert({
      clave: "puntoVentaDeudas",
      valor: "3"
    });
    if (!Settings.findOne({
      clave: "folderUploads"
    })) Settings.insert({
      clave: "folderUploads",
      valor: "/var/www/uploads/"
    });
    if (!Settings.findOne({
      clave: "desdeHastaImportaAnclaje"
    })) Settings.insert({
      clave: "desdeHastaImportaAnclaje",
      valor: "1,1000"
    });
    if (!Settings.findOne({
      clave: "modoServidor"
    })) Settings.insert({
      clave: "modoServidor",
      valor: "PRODUCCION"
    });
    if (!Settings.findOne({
      clave: "nombreEmpresa"
    })) Settings.insert({
      clave: "nombreEmpresa",
      valor: "Nombre Fantasia"
    });
    if (!Settings.findOne({
      clave: "proxNroRecivoDeudas"
    })) Settings.insert({
      clave: "proxNroRecivoDeudas",
      valor: "1"
    });
  }

  getHorasPersonal(idLiquidacion, idPersonal) {
    var unw = {
      $unwind: {
        path: "$horas"
      }
    };
    var proy = {
      $project: {
        _id: "$horas._id",
        idLiquidacion: "$_id",
        dia: "$horas.dia",
        tipoHora: "$horas.tipoHora",
        cantidad: "$horas.cantidad",
        viandas: "$horas.viandas",
        idPersonal: "$horas.idPersonal",
        idHora: "$horas._id"
      }
    };
    var match = {
      $match: {
        idLiquidacion: idLiquidacion,
        idPersonal: idPersonal
      }
    };
    var raw = PersonalLiquidaciones.rawCollection();
    var q = Meteor.wrapAsync(raw.aggregate, raw);
    return q([unw, proy, match]).toArray();
  }

  getDataSeleccion(coleccion, id) {
    var Coleccion = module.runSetters(eval(coleccion));
    return Coleccion.findOne({
      _id: id
    });
  }

  getPersonalLiquidacion(idLiquidacion) {
    var liqu = PersonalLiquidaciones.findOne({
      _id: idLiquidacion
    });

    if (liqu) {
      return Personal.find({
        tipoPersonal: liqu.tipoPersonal,
        estado: "ALTA"
      }).fetch();
    }

    return [];
  }

  buscarPersonalAccidentes(idPersonal) {
    var data = Personal.findOne({
      _id: idPersonal
    });
    if (data) if (data.accidentes) return data.accidentes;
    return [];
  }

  quitarItemGenerico(coleccion, id, subcoleccion, idSubColeccion) {
    var Coleccion = module.runSetters(eval(coleccion));

    if (subcoleccion) {
      var res = Coleccion.update({
        _id: id
      }, {
        $pull: {
          [subcoleccion]: {
            "_id": idSubColeccion
          }
        }
      }, {
        getAutoValues: false
      } // SIN ESTE PARAMETRO NO QUITA!!
      );
    } else {}

    var aux = Coleccion.findOne({
      _id: id
    });
    console.log(aux[subcoleccion]);
    return aux[subcoleccion];
  }

  "buscarObservacionesAnclaje"(idAnclaje) {
    var data = Anclajes.findOne({
      _id: idAnclaje
    });
    console.log(data, idAnclaje);
    if (data) if (data.observaciones) return data.observaciones;
    return [];
  }

  loginUser(data) {
    // Meteor.call('loginUser',{email: "vxxxxx@xxxx.com",password: "123456"}, function(error, result){
    //      if(!error) Meteor.loginWithToken(result.token);
    // });
    console.log(data);
    var user = Meteor.users.findOne({
      'emails.address': data.email
    });

    if (user) {
      var password = data.password;

      var result = Accounts._checkPassword(user, password);

      console.log(result);

      if (result.error) {
        return result.error;
      } else {
        return result;
      }
    } else {
      return {
        error: "user not found"
      };
    }
  }

  userUpdate(doc) {
    console.log(doc);
    Meteor.users.update({
      _id: doc._id
    }, {
      $set: doc
    });
    console.log(Meteor.users.find().fetch());
    return id;
  }

  userInsert(doc) {
    console.log(doc);
    id = Accounts.createUser({
      username: doc.username,
      password: doc.password,
      profile: doc.profile
    });
    console.log(Meteor.users.find().fetch());
    return id;
  }

  usuarios() {
    var res = Meteor.users.find().fetch();
    console.log(res);
    return res;
  }

  modificarClave(id, clave) {
    var res = Accounts.setPassword(id, clave, {
      logout: false
    });
    console.log(res);
    console.log(id);
    console.log(clave);
  }

  userRemove(id) {
    Meteor.users.remove(id);
    return id;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"funciones_aux.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/funciones_aux.js                                                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Auxiliares: () => Auxiliares
});
module.link("../lib/utils.js");

var exec = Npm.require('child_process').exec;

var Fiber = Npm.require('fibers');

var Future = Npm.require('fibers/future');

var fs = Npm.require('fs');

const fetch = Npm.require('node-fetch');

class Auxiliares {
  cargaImagen(archivo, id) {
    return Promise.asyncApply(() => {
      const http = require("http");

      var path = "http://appibero.yavu.com.ar/javier/archivos/" + id + "/" + archivo;
      const file = fs.createWriteStream(archivo);
      const response = Promise.await(fetch(path));
      const data = Promise.await(response.buffer());
      Archivos.write(data, {
        fileName: archivo,
        fielId: id //optional

      }, function (writeError, fileRef) {
        if (writeError) {
          throw writeError;
        } else {
          Anclajes.update({
            _id: id
          }, {
            $set: {
              certificado: fileRef._id
            }
          });
          console.log(fileRef.name + ' is successfully saved to FS. _id: ' + fileRef._id);
        }
      }); // try{
      // await http.get(, response => {
      //   response.pipe(file);
      //   var data= fs.readFileSync(archivo)
      //   fs.readFile(archivo, function (error, data) {
      //   if (error) {
      //     throw error;
      //   } else {
      //  Archivos.write(data, {
      //   fileName: archivo,
      //   fielId: id, //optional
      // }, function (writeError, fileRef) {
      //   if (writeError) {
      //     throw writeError;
      //   } else {
      //     console.log(fileRef.name + ' is successfully saved to FS. _id: ' + fileRef._id);
      //   }
      // });
      //   }
      // });
      // });
      // }catch (err){
      // 	console.log("no encuentro")
      // }
    });
  }

  cargarImagenes(fut1) {
    return Promise.asyncApply(() => {
      var path = "http://appibero.yavu.com.ar/javier/archivos/"; // Archivos.remove({})
      // return;

      var a = Settings.findOne({
        clave: "desdeHastaImportaAnclaje"
      }).valor.split(",");
      var desde = a[0] * 1;
      var hasta = a[1] * 1;
      var cantidadImagenes = 0;
      console.log("DESDE: " + desde + " HSTA: " + hasta);

      for (var i = desde; i < hasta; i++) {
        var aux = Promise.await(Anclajes.findOne({
          _id: i + ""
        }));

        if (aux) {
          cantidadImagenes++;
          var archivo = i + "_1.pdf";
          Promise.await(this.cargaImagen(archivo, i + ""));
        }
      }

      fut1.return(cantidadImagenes + "imagenes cargadas"); // console.log(Archivos.find().fetch())
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/publish.js                                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
Meteor.publishComposite("anclajesPublish", function (tableName, ids, fields) {
  // check(tableName, String);
  // check(ids, Array);
  // check(fields, Match.Optional(Object));
  // this.unblock(); // requires meteorhacks:unblock package
  return {
    find: function () {
      // this.unblock(); // requires meteorhacks:unblock package
      // check for admin role with alanning:roles package
      // if (!Roles.userIsInRole(this.userId, 'admin')) {
      //   return [];
      // }
      var mod = getModulo2("Anclajes");

      if (mod) {
        if (mod.hasOwnProperty("soloVerMios")) {
          if (mod.soloVerMios) {
            console.log(Meteor.user()._id);
            return Anclajes.find({
              _id: {
                $in: ids
              }
            }, {
              idUsuario: "2ga37rdx57sGGLD7f"
            });
          }
        }

        return [];
      }

      return [];
    },
    children: [{
      find: function (feedback) {
        // this.unblock(); // requires meteorhacks:unblock package
        // Publish the related user
        return Meteor.users.find({
          _id: feedback.userId
        }, {
          limit: 1,
          fields: {
            emails: 1
          },
          sort: {
            _id: 1
          }
        });
      }
    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utilidades.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/utilidades.js                                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
!function (module1) {
  String.prototype.lpad = function (padString, length) {
    var str = this;

    while (str.length < length) str = padString + str;

    return str;
  };

  EDAD_ADHERENTE = 20;

  getClaseTipoSocio = function (fechaNac, esActivo) {
    var tipo = getTipoSocio(fechaNac, esActivo);
    var clase = tipo === "PARTICIPANTE" ? "text-warning" : "text-info";
    if (tipo === "ACTIVO") clase = "text-danger";
    return clase;
  };

  getEdadSocio = function (fechaNac) {
    var nacimiento = new Date(fechaNac);
    var ahora = new Date();
    var anos = ahora.getFullYear() - nacimiento.getFullYear();
    return anos;
  };

  getTipoSocio = function (fechaNac, esActivo) {
    var nacimiento = new Date(fechaNac);
    var ahora = new Date();
    var anos = ahora.getFullYear() - nacimiento.getFullYear();
    if (esActivo) return "ACTIVO";
    return anos < EDAD_ADHERENTE ? "PARTICIPANTE" : "ADHERENTE";
  };

  getImporteSocio = function (idSocio) {
    var dataParticipantes = Settings.findOne({
      clave: "importeParticipantes"
    });
    var dataAdherentes = Settings.findOne({
      clave: "importeAdherentes"
    });
    var dataActivos = Settings.findOne({
      clave: "importeActivos"
    });
    var socio = Socios.findOne({
      _id: idSocio
    });
    var nacimiento = new Date(socio.fechaNacimiento);
    var ahora = new Date();
    var anos = ahora.getFullYear() - nacimiento.getFullYear();
    if (socio.esActivo) return dataActivos.valor;
    if (anos < EDAD_ADHERENTE) return dataParticipantes.valor;
    return dataAdherentes.valor;
  };

  module.exports = getTipoSocio;
}.call(this, module);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.link("./funciones.js");
let Funciones;
module.link("./funciones.js", {
  Funciones(v) {
    Funciones = v;
  }

}, 1);

const bodyParser = require('body-parser'); // WebApp.connectHandlers.use(bodyParser.urlencoded({extended: false}))
// WebApp.connectHandlers.use('/setFotoPerfil', bodyParser.urlencoded());


var seting = Settings.findOne({
  clave: "cadenaConexionMail"
});
var valorMail = seting ? seting.valor : "";
process.env.MAIL_URL = valorMail; //DATOS DE LA BASE DE DATOS!!!!//////////////////////////////////////////////////////////////////////////

nombreBase = "appCai";
puertoBase = "27017"; //DATOS DE LA BASE DE DATOS!!!!//////////////////////////////////////////////////////////////////////////

mesLetras = function (mes) {
  if (mes == 1) return "ENERO";
  if (mes == 2) return "FEBRERO";
  if (mes == 3) return "MARZO";
  if (mes == 4) return "ABRIL";
  if (mes == 5) return "MAYO";
  if (mes == 6) return "JUNIO";
  if (mes == 7) return "JULIO";
  if (mes == 8) return "AGOSTO";
  if (mes == 9) return "SEPTEMBRE";
  if (mes == 10) return "OCTUBRE";
  if (mes == 11) return "NOVIEMBRE";
  if (mes == 12) return "DICIEMBRE";
  return "s/a";
};

var f = new Funciones();
Meteor.methods({
  "eliminarAnclajes": f.eliminarAnclajes,
  "importarAnclajes": f.importarAnclajes,
  "getHorasPersonal": f.getHorasPersonal,
  "getArchivos": f.getArchivos,
  "getDataSeleccion": f.getDataSeleccion,
  "getPersonalLiquidacion": f.getPersonalLiquidacion,
  "quitarItemGenerico": f.quitarItemGenerico,
  "buscarPersonalAccidentes": f.buscarPersonalAccidentes,
  "buscarObservacionesAnclaje": f.buscarObservacionesAnclaje,
  "loginUser": f.loginUser,
  "userInsert": f.userInsert,
  "userUpdate": f.userUpdate,
  "usuarios": f.usuarios,
  "modificarClave": f.modificarClave,
  "userRemove": f.userRemove,
  "generarVariables": f.generarVariables
});
Meteor.startup(() => {
  Meteor.publish('Settings', function () {
    return Settings.find();
  });
  Meteor.publish('Anclajes', function () {
    return getColeccionPerfil("Anclajes");
  });
  Meteor.publish('AnclajesEquipos', function () {
    return getColeccionPerfil("AnclajesEquipos");
  });
  Meteor.publish('Archivos', function () {
    return Archivos.find();
  });
  Meteor.publish('Personal', function () {
    return getColeccionPerfil("Personal");
  });
  Meteor.publish('PersonalLiquidaciones', function () {
    return getColeccionPerfil("PersonalLiquidaciones");
  });
  Meteor.publish('TipoPerfiles', function () {
    return TipoPerfiles.find();
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

require("/lib/collections.js");
require("/lib/router.js");
require("/lib/tabular.js");
require("/lib/utils.js");
require("/lib/utilsUsuarios.js");
require("/server/DeudaSocios.js");
require("/server/funciones.js");
require("/server/funciones_aux.js");
require("/server/publish.js");
require("/server/utilidades.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvcm91dGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvdGFidWxhci5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL3V0aWxzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvdXRpbHNVc3Vhcmlvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL0RldWRhU29jaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZnVuY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZnVuY2lvbmVzX2F1eC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2guanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci91dGlsaWRhZGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJSYW5kb20iLCJtb2R1bGUiLCJsaW5rIiwidiIsIkZpbGVzQ29sbGVjdGlvbiIsIlNldHRpbmdzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiQW5jbGFqZXMiLCJBbmNsYWplc0VxdWlwb3MiLCJQZXJzb25hbCIsIlBlcnNvbmFsTGlxdWlkYWNpb25lcyIsIlRpcG9QZXJmaWxlcyIsIkFyY2hpdm9zIiwiY29sbGVjdGlvbk5hbWUiLCJhdHRhY2hTY2hlbWEiLCJTaW1wbGVTY2hlbWEiLCJub21icmVQZXJmaWwiLCJ0eXBlIiwiU3RyaW5nIiwibGFiZWwiLCJlc0FkbWluaXN0cmFkb3IiLCJCb29sZWFuIiwiYXV0b2Zvcm0iLCJtb2R1bG9zQWNjZXNvIiwiQXJyYXkiLCJvcHRpb25hbCIsIk9iamVjdCIsImF1dG9WYWx1ZSIsImlkIiwiaG9yYXMiLCJOdW1iZXIiLCJzdHlsZSIsInBsYWNlaG9sZGVyIiwib3B0aW9ucyIsInZhbHVlIiwiZmVjaGFEZXNkZSIsIkRhdGUiLCJmZWNoYUhhc3RhIiwidGlwb1BlcnNvbmFsIiwiZXN0YWRvIiwiYWNjaWRlbnRlcyIsImFwZWxsaWRvIiwibm9tYnJlIiwibnJvTGVnYWpvIiwidW5pcXVlIiwiY3VpbCIsIm9icmFTb2NpYWwiLCJzdWVsZG8iLCJjZW50cm9Db3N0byIsImNhdGVnb3JpYSIsImZlY2hhRXhhbWVuIiwibm9tYnJlRXF1aXBvIiwiZGV0YWxsZSIsImlkVXN1YXJpbyIsIk1ldGVvciIsImlzQ2xpZW50IiwiXyIsIm1hcCIsIlNlc3Npb24iLCJnZXQiLCJjIiwiaSIsInVzZXJuYW1lIiwiX2lkIiwiY3JlYXRlZCIsImlzSW5zZXJ0IiwiaXNVcHNlcnQiLCIkc2V0T25JbnNlcnQiLCJ1bnNldCIsInVwZGF0ZWQiLCJpc1VwZGF0ZSIsImNlcnRpZmljYWRvIiwiYWZGaWVsZElucHV0IiwiY29sbGVjdGlvbiIsInBvem8iLCJiYXRlcmlhIiwiY2VydGlmaWNhY2lvbiIsImVxdWlwb0Vuc2F5byIsInNlbGVjdDJPcHRpb25zIiwid2lkdGgiLCJhbGxvd0NsZWFyIiwiZmluZCIsImZldGNoIiwiZXF1aXBvSW5ncmVzYW50ZSIsImZlY2hhRW5zYXlvIiwiZmVjaGFDb25zdHJ1Y2Npb24iLCJob3JhRW5zYXlvIiwibnVtZXJvQUZFIiwiY2FudGlkYWRBbmNsYWplcyIsInRpcG9BbmNsYWplc0NvbnN0cnVpZG9zIiwibnVtZXJvRmFjdHVyYSIsImFyY2hpdm8iLCJjb25zdEVuc2F5byIsImNhbnRpZGFkQW5jbGFqZSIsImNvbnN0Q29uc3RydWlkbyIsImVzdGFkb05PIiwiZmlyc3RPcHRpb24iLCJlc3RhZG9ORSIsImVzdGFkb1NPIiwiZXN0YWRvU0UiLCJucm9SZXBvcnRlIiwib2JzZXJ2YWNpb25lcyIsImNsYXZlIiwidmFsb3IiLCJmZWNoYSIsImFsbG93IiwiaW5zZXJ0IiwidXBkYXRlIiwiYXBwbGljYXRpb25Db250cm9sbGVyIiwiUm91dGVDb250cm9sbGVyIiwiZXh0ZW5kIiwibGF5b3V0VGVtcGxhdGUiLCJsb2FkaW5nVGVtcGxhdGUiLCJub3RGb3VuZFRlbWxwbGF0ZSIsIndhaXRPbiIsIm9uQmVmb3JlQWN0aW9uIiwicGF1c2UiLCJyZW5kZXIiLCJ1c2VyIiwibmV4dCIsImFjdGlvbiIsInJlYWR5IiwiVUlCbG9jayIsInVuYmxvY2siLCJSb3V0ZXIiLCJyb3V0ZSIsInBhdGgiLCJ0ZW1wbGF0ZSIsImNvbnRyb2xsZXIiLCJ3aGVyZSIsImEiLCJmaW5kT25lIiwicGF0aFVwbG9hZHMiLCJwYXJhbXMiLCJmaWxlbmFtZSIsInNlcnYiLCJmcyIsIk5wbSIsInJlcXVpcmUiLCJleGlzdHNTeW5jIiwicmVzcG9uc2UiLCJ3cml0ZUhlYWQiLCJlbmQiLCJkYXRhIiwicmVhZEZpbGVTeW5jIiwic2FsIiwiVGFidWxhciIsImRlZmF1bHQiLCJtb21lbnQiLCJzb19fIiwiVGFibGUiLCJuYW1lIiwibGFuZ3VhZ2UiLCJwcm9jZXNzaW5nIiwic3RhdGVTYXZlIiwiZmlsdGVycyIsImNyZWF0ZWRSb3ciLCJyb3ciLCJkYXRhSW5kZXgiLCJmaWxhIiwiJCIsImRpYXMiLCJnZXREaWFzVnRvIiwiYXR0ciIsImV4dHJhRmllbGRzIiwiYnV0dG9ucyIsImF1dG9XaWR0aCIsImNvbHVtbnMiLCJ0aXRsZSIsIm9iamVjdCIsImF1eCIsInZpc2libGUiLCJkIiwiaG9yYSIsImhvcmFBbmNsYWplIiwiZ2V0RGF0ZSIsImdldE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJTcGFjZWJhcnMiLCJTYWZlU3RyaW5nIiwiY29sb3JlYXJFc3RhZG8iLCJ0bXBsIiwiVGVtcGxhdGUiLCJhY2Npb25lc0FuY2xhamVzIiwicHJvdG90eXBlIiwibHBhZCIsInBhZFN0cmluZyIsImxlbmd0aCIsInN0ciIsImFkZEhvdXJzIiwiaCIsInNldFRpbWUiLCJnZXRUaW1lIiwiYWRkRGF5cyIsIm51bSIsInZhbHVlT2YiLCJjYXBpdGFsaXphciIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJycGFkIiwiZ2V0RmVjaGEiLCJnZXRGZWNoYTIiLCJnZXRNZXMiLCJnZXREaWEiLCJnZXRBbm8iLCJmb3JtYXRNb25leSIsIm4iLCJ4IiwicyIsInJlIiwidG9GaXhlZCIsIk1hdGgiLCJtYXgiLCJyZXBsYWNlIiwiUmVnRXhwIiwidmFsaWRhckxhcmdvQ0JVIiwiY2J1IiwidmFsaWRhckNvZGlnb0JhbmNvIiwiY29kaWdvIiwiYmFuY28iLCJzdWJzdHIiLCJkaWdpdG9WZXJpZmljYWRvcjEiLCJzdWN1cnNhbCIsImRpZ2l0b1ZlcmlmaWNhZG9yMiIsInN1bWEiLCJkaWZlcmVuY2lhIiwibWVzTGV0cmFzIiwibWVzIiwibWVzTnVtZXJvcyIsImdldE1lc2VzIiwicmlwRmVjaGFBcmNoaXZvIiwiZmVjaGFEYXRlIiwic3QiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJhcnIiLCJzcGxpdCIsImdldEltcG9ydGVUb3RhbFNvY2lvcyIsInN1bSIsImltcG9ydGUiLCJyaXBJbXBvcnRlQXJjaGl2byIsInZhbGlkYXJDdWVudGEiLCJjdWVudGEiLCJkaWdpdG9WZXJpZmljYWRvciIsInZhbGlkYXJDQlUiLCJnZXRDbGFzZVRpcG9Tb2NpbyIsImZlY2hhTmFjIiwiZXNBY3Rpdm8iLCJ0aXBvIiwiZ2V0VGlwb1NvY2lvIiwiY2xhc2UiLCJnZVRpcG9Tb2Npb0VkYWQiLCJlZGFkIiwiYWN0aXZvIiwiZWRhZEFkaGVyZW50ZSIsInBhcnNlRmxvYXQiLCJnZXRJbXBvcnRlU29jaW9FZGFkIiwiZ2V0RWRhZFNvY2lvIiwiaG95IiwiY3VtcGxlYW5vcyIsIm0iLCJhbm9zIiwiZ2V0SW1wb3J0ZVNvY2lvIiwiaWRTb2NpbyIsImRhdGFQYXJ0aWNpcGFudGVzIiwiZGF0YUFkaGVyZW50ZXMiLCJkYXRhQWN0aXZvcyIsInNvY2lvIiwiU29jaW9zIiwiZmVjaGFOYWNpbWllbnRvIiwiZ2V0SW1wb3J0ZVNvY2lvRGF0b3MiLCJleHBvcnRzIiwiZ2V0TW9kdWxvIiwibm9tYnJlTW9kdWxvIiwibW9kdWxvcyIsInRvTG9jYWxlTG93ZXJDYXNlIiwidG9Mb3dlckNhc2UiLCJnZXRNb2R1bG8yIiwidGlwb1BlcmZpbCIsInByb2ZpbGUiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q29sZWNjaW9uQWNjZXNvIiwibm9tYnJlQ29sZWNjaW9uIiwiQ29sZWNjaW9uIiwiZXZhbCIsIm1vZHVsbyIsInNvbG9WZXJNaW9zIiwiZ2V0Q29sZWNjaW9uUGVyZmlsIiwidXN1YXJpbyIsIm5hY2ltaWVudG8iLCJhaG9yYSIsIkRldWRhU29jaW9zIiwiZXNDdW90YVNvY2lhbCIsImV4Y2x1aWRvIiwiZXhwb3J0IiwiRnVuY2lvbmVzIiwiQXV4aWxpYXJlcyIsIlB5dGhvblNoZWxsIiwiX0FVWCIsIkZ1dHVyZSIsImdldEFyY2hpdm9zIiwicmVtb3ZlIiwiY2FyZ2FySW1hZ2VuZXMiLCJlbGltaW5hckFuY2xhamVzIiwiaW1wb3J0YXJBbmNsYWplcyIsImZ1dDEiLCJhcmNoaSIsInByb2Nlc3MiLCJjd2QiLCJtb2RlIiwicHl0aG9uUGF0aCIsInNjcmlwdFBhdGgiLCJhcmdzIiwicnVuIiwiZXJyIiwicmVzIiwid2FpdCIsImdlbmVyYXJWYXJpYWJsZXMiLCJnZXRIb3Jhc1BlcnNvbmFsIiwiaWRMaXF1aWRhY2lvbiIsImlkUGVyc29uYWwiLCJ1bnciLCIkdW53aW5kIiwicHJveSIsIiRwcm9qZWN0IiwiZGlhIiwidGlwb0hvcmEiLCJjYW50aWRhZCIsInZpYW5kYXMiLCJpZEhvcmEiLCJtYXRjaCIsIiRtYXRjaCIsInJhdyIsInJhd0NvbGxlY3Rpb24iLCJxIiwid3JhcEFzeW5jIiwiYWdncmVnYXRlIiwidG9BcnJheSIsImdldERhdGFTZWxlY2Npb24iLCJjb2xlY2Npb24iLCJnZXRQZXJzb25hbExpcXVpZGFjaW9uIiwibGlxdSIsImJ1c2NhclBlcnNvbmFsQWNjaWRlbnRlcyIsInF1aXRhckl0ZW1HZW5lcmljbyIsInN1YmNvbGVjY2lvbiIsImlkU3ViQ29sZWNjaW9uIiwiJHB1bGwiLCJnZXRBdXRvVmFsdWVzIiwiaWRBbmNsYWplIiwibG9naW5Vc2VyIiwidXNlcnMiLCJlbWFpbCIsInBhc3N3b3JkIiwicmVzdWx0IiwiQWNjb3VudHMiLCJfY2hlY2tQYXNzd29yZCIsImVycm9yIiwidXNlclVwZGF0ZSIsImRvYyIsIiRzZXQiLCJ1c2VySW5zZXJ0IiwiY3JlYXRlVXNlciIsInVzdWFyaW9zIiwibW9kaWZpY2FyQ2xhdmUiLCJzZXRQYXNzd29yZCIsImxvZ291dCIsInVzZXJSZW1vdmUiLCJleGVjIiwiRmliZXIiLCJjYXJnYUltYWdlbiIsImh0dHAiLCJmaWxlIiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJidWZmZXIiLCJ3cml0ZSIsImZpbGVOYW1lIiwiZmllbElkIiwid3JpdGVFcnJvciIsImZpbGVSZWYiLCJkZXNkZSIsImhhc3RhIiwiY2FudGlkYWRJbWFnZW5lcyIsInJldHVybiIsInB1Ymxpc2hDb21wb3NpdGUiLCJ0YWJsZU5hbWUiLCJpZHMiLCJmaWVsZHMiLCJtb2QiLCJoYXNPd25Qcm9wZXJ0eSIsIiRpbiIsImNoaWxkcmVuIiwiZmVlZGJhY2siLCJ1c2VySWQiLCJsaW1pdCIsImVtYWlscyIsInNvcnQiLCJFREFEX0FESEVSRU5URSIsImJvZHlQYXJzZXIiLCJzZXRpbmciLCJ2YWxvck1haWwiLCJlbnYiLCJNQUlMX1VSTCIsIm5vbWJyZUJhc2UiLCJwdWVydG9CYXNlIiwiZiIsIm1ldGhvZHMiLCJidXNjYXJPYnNlcnZhY2lvbmVzQW5jbGFqZSIsInN0YXJ0dXAiLCJwdWJsaXNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsZUFBSjtBQUFvQkgsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0UsaUJBQWUsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLG1CQUFlLEdBQUNELENBQWhCO0FBQWtCOztBQUF0QyxDQUFsQyxFQUEwRSxDQUExRTtBQUdwRkUsUUFBUSxHQUFHLElBQUlDLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixDQUFYO0FBQ0FDLFFBQVEsR0FBRyxJQUFJRixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsVUFBckIsQ0FBWDtBQUNBRSxlQUFlLEdBQUcsSUFBSUgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGlCQUFyQixDQUFsQjtBQUNBRyxRQUFRLEdBQUcsSUFBSUosS0FBSyxDQUFDQyxVQUFWLENBQXFCLFVBQXJCLENBQVg7QUFDQUkscUJBQXFCLEdBQUcsSUFBSUwsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHVCQUFyQixDQUF4QjtBQUNBSyxZQUFZLEdBQUcsSUFBSU4sS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQWY7QUFDQU0sUUFBUSxHQUFHLElBQUlULGVBQUosQ0FBb0I7QUFBQ1UsZ0JBQWMsRUFBRTtBQUFqQixDQUFwQixDQUFYLEMsQ0FDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FGLFlBQVksQ0FBQ0csWUFBYixDQUEwQixJQUFJQyxZQUFKLENBQWlCO0FBQ3pDQyxjQUFZLEVBQUU7QUFDWkMsUUFBSSxFQUFFQyxNQURNO0FBRVpDLFNBQUssRUFBRTtBQUZLLEdBRDJCO0FBS3hDQyxpQkFBZSxFQUFFO0FBQ2hCSCxRQUFJLEVBQUVJLE9BRFU7QUFFaEJGLFNBQUssRUFBRSxtQkFGUztBQUdoQkcsWUFBUSxFQUFDO0FBQUVMLFVBQUksRUFBQztBQUFQO0FBSE8sR0FMdUI7QUFXekNNLGVBQWEsRUFBRTtBQUNiTixRQUFJLEVBQUVPLEtBRE87QUFFYkwsU0FBSyxFQUFFLG1CQUZNO0FBR2JNLFlBQVEsRUFBRTtBQUhHLEdBWDBCO0FBZ0J6QyxxQkFBa0I7QUFDaEJSLFFBQUksRUFBQ1M7QUFEVyxHQWhCdUI7QUFtQnhDLHlCQUFzQjtBQUVyQlQsUUFBSSxFQUFFQyxNQUZlO0FBR3JCSSxZQUFRLEVBQUM7QUFDUEwsVUFBSSxFQUFDO0FBREUsS0FIWTtBQU1yQlUsYUFBUyxFQUFFLFlBQVc7QUFDcEIsYUFBTzVCLE1BQU0sQ0FBQzZCLEVBQVAsRUFBUDtBQUNEO0FBUm9CLEdBbkJrQjtBQThCeEMsaUNBQThCO0FBRTdCWCxRQUFJLEVBQUVJLE9BRnVCO0FBRzdCQyxZQUFRLEVBQUM7QUFDUEwsVUFBSSxFQUFDO0FBREUsS0FIb0I7QUFNN0JRLFlBQVEsRUFBQztBQU5vQixHQTlCVTtBQXVDekMsNEJBQXlCO0FBRXZCUixRQUFJLEVBQUVDLE1BRmlCO0FBR3ZCQyxTQUFLLEVBQUM7QUFIaUI7QUF2Q2dCLENBQWpCLENBQTFCO0FBb0RBVCxxQkFBcUIsQ0FBQ0ksWUFBdEIsQ0FBbUMsSUFBSUMsWUFBSixDQUFpQjtBQUNqRGMsT0FBSyxFQUFFO0FBQ05aLFFBQUksRUFBRU8sS0FEQTtBQUVOTCxTQUFLLEVBQUUsT0FGRDtBQUdOTSxZQUFRLEVBQUU7QUFISixHQUQwQztBQU1sRCxhQUFVO0FBQ1JSLFFBQUksRUFBQ1M7QUFERyxHQU53QztBQVNqRCxpQkFBYztBQUViVCxRQUFJLEVBQUVDLE1BRk87QUFHYlMsYUFBUyxFQUFFLFlBQVc7QUFDcEIsYUFBTzVCLE1BQU0sQ0FBQzZCLEVBQVAsRUFBUDtBQUNEO0FBTFksR0FUbUM7QUFpQmpELGlCQUFjO0FBQ2JYLFFBQUksRUFBRWEsTUFETztBQUViTCxZQUFRLEVBQUMsSUFGSTtBQUdiTixTQUFLLEVBQUMsS0FITztBQUliRyxZQUFRLEVBQUU7QUFDUlMsV0FBSyxFQUFDO0FBREU7QUFKRyxHQWpCbUM7QUEwQmxELHFCQUFrQjtBQUNoQmQsUUFBSSxFQUFFYSxNQURVO0FBRWhCTCxZQUFRLEVBQUMsSUFGTztBQUdoQkgsWUFBUSxFQUFFO0FBQ1JTLFdBQUssRUFBQztBQURFO0FBSE0sR0ExQmdDO0FBa0NsRCxzQkFBbUI7QUFDakJkLFFBQUksRUFBRWEsTUFEVztBQUVqQkwsWUFBUSxFQUFDLEtBRlE7QUFHakJILFlBQVEsRUFBRTtBQUNSUyxXQUFLLEVBQUM7QUFERTtBQUhPLEdBbEMrQjtBQTBDbEQsd0JBQXFCO0FBQ25CZCxRQUFJLEVBQUVDLE1BRGE7QUFFbkJPLFlBQVEsRUFBQyxLQUZVO0FBR25CTixTQUFLLEVBQUMsVUFIYTtBQUluQkcsWUFBUSxFQUFFO0FBQ1JMLFVBQUksRUFBQyxRQURHO0FBRVJjLFdBQUssRUFBQztBQUZFO0FBSlMsR0ExQzZCO0FBb0RqRCxzQkFBbUI7QUFDbEJkLFFBQUksRUFBRUMsTUFEWTtBQUVsQk8sWUFBUSxFQUFDLElBRlM7QUFHbEJOLFNBQUssRUFBQyxjQUhZO0FBSWxCRyxZQUFRLEVBQUU7QUFDUEwsVUFBSSxFQUFFLFNBREM7QUFFTmUsaUJBQVcsRUFBRSxlQUZQO0FBR05ELFdBQUssRUFBRSxhQUhEO0FBSU5FLGFBQU8sRUFBRSxDQUVMO0FBQUNkLGFBQUssRUFBRSxRQUFSO0FBQWtCZSxhQUFLLEVBQUU7QUFBekIsT0FGSyxFQUdMO0FBQUNmLGFBQUssRUFBRSxRQUFSO0FBQWtCZSxhQUFLLEVBQUU7QUFBekIsT0FISyxFQUlMO0FBQUNmLGFBQUssRUFBRSxTQUFSO0FBQW1CZSxhQUFLLEVBQUU7QUFBMUIsT0FKSyxFQUtMO0FBQUNmLGFBQUssRUFBRSxXQUFSO0FBQXFCZSxhQUFLLEVBQUU7QUFBNUIsT0FMSyxFQU1MO0FBQUNmLGFBQUssRUFBRSxXQUFSO0FBQXFCZSxhQUFLLEVBQUU7QUFBNUIsT0FOSyxFQU9MO0FBQUNmLGFBQUssRUFBRSxTQUFSO0FBQW1CZSxhQUFLLEVBQUU7QUFBMUIsT0FQSyxFQVFMO0FBQUNmLGFBQUssRUFBRSxVQUFSO0FBQW9CZSxhQUFLLEVBQUU7QUFBM0IsT0FSSztBQUpIO0FBSlEsR0FwRDhCO0FBMkVsREMsWUFBVSxFQUFFO0FBQ1ZsQixRQUFJLEVBQUVtQixJQURJO0FBRVZqQixTQUFLLEVBQUU7QUFGRyxHQTNFc0M7QUErRWxEa0IsWUFBVSxFQUFFO0FBQ1ZwQixRQUFJLEVBQUVtQixJQURJO0FBRVZqQixTQUFLLEVBQUU7QUFGRyxHQS9Fc0M7QUFtRmxEbUIsY0FBWSxFQUFFO0FBQ1pyQixRQUFJLEVBQUVDLE1BRE07QUFFWkMsU0FBSyxFQUFFLGVBRks7QUFHWkcsWUFBUSxFQUFFO0FBQ1BMLFVBQUksRUFBRSxTQURDO0FBRU5lLGlCQUFXLEVBQUUsZUFGUDtBQUdORCxXQUFLLEVBQUUsYUFIRDtBQUlORSxhQUFPLEVBQUUsQ0FFTDtBQUFDZCxhQUFLLEVBQUUsT0FBUjtBQUFpQmUsYUFBSyxFQUFFO0FBQXhCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsZ0JBQVI7QUFBMEJlLGFBQUssRUFBRTtBQUFqQyxPQUhLO0FBSkg7QUFIRSxHQW5Gb0M7QUFpR2pESyxRQUFNLEVBQUU7QUFDUHRCLFFBQUksRUFBRUMsTUFEQztBQUVQQyxTQUFLLEVBQUUsUUFGQTtBQUdQRyxZQUFRLEVBQUU7QUFDUEwsVUFBSSxFQUFFLFNBREM7QUFFTmUsaUJBQVcsRUFBRSxRQUZQO0FBR05ELFdBQUssRUFBRSxhQUhEO0FBSU5FLGFBQU8sRUFBRSxDQUVMO0FBQUNkLGFBQUssRUFBRSxXQUFSO0FBQXFCZSxhQUFLLEVBQUU7QUFBNUIsT0FGSyxFQUdMO0FBQUNmLGFBQUssRUFBRSxXQUFSO0FBQXFCZSxhQUFLLEVBQUU7QUFBNUIsT0FISztBQUpIO0FBSEg7QUFqR3lDLENBQWpCLENBQW5DO0FBaUhBekIsUUFBUSxDQUFDSyxZQUFULENBQXNCLElBQUlDLFlBQUosQ0FBaUI7QUFDckN5QixZQUFVLEVBQUU7QUFDVnZCLFFBQUksRUFBRU8sS0FESTtBQUVWTCxTQUFLLEVBQUUsWUFGRztBQUdWTSxZQUFRLEVBQUU7QUFIQSxHQUR5QjtBQU1yQyxrQkFBZTtBQUNiUixRQUFJLEVBQUNTO0FBRFEsR0FOc0I7QUFTcEMsc0JBQW1CO0FBRWxCVCxRQUFJLEVBQUVDLE1BRlk7QUFHbEJTLGFBQVMsRUFBRSxZQUFXO0FBQ3BCLGFBQU81QixNQUFNLENBQUM2QixFQUFQLEVBQVA7QUFDRDtBQUxpQixHQVRpQjtBQWlCckMsaUNBQStCO0FBQzdCWCxRQUFJLEVBQUVtQixJQUR1QjtBQUU3QmpCLFNBQUssRUFBRSxpQkFGc0I7QUFHN0JHLFlBQVEsRUFBQztBQUNOUyxXQUFLLEVBQUM7QUFEQTtBQUhvQixHQWpCTTtBQXdCckMsZ0NBQThCO0FBQzVCZCxRQUFJLEVBQUVtQixJQURzQjtBQUU1QmpCLFNBQUssRUFBRSxnQkFGcUI7QUFHM0JHLFlBQVEsRUFBQztBQUNSUyxXQUFLLEVBQUM7QUFERTtBQUhrQixHQXhCTztBQWdDckMsNEJBQTBCO0FBQ3hCZCxRQUFJLEVBQUVtQixJQURrQjtBQUV4QmpCLFNBQUssRUFBRSxZQUZpQjtBQUd2QkcsWUFBUSxFQUFDO0FBQ1BTLFdBQUssRUFBQztBQURDO0FBSGMsR0FoQ1c7QUF1Q3JDLDZCQUEyQjtBQUN6QmQsUUFBSSxFQUFFQyxNQURtQjtBQUV6Qk8sWUFBUSxFQUFDLElBRmdCO0FBR3pCTixTQUFLLEVBQUUsYUFIa0I7QUFJeEJHLFlBQVEsRUFBRTtBQUNSTCxVQUFJLEVBQUU7QUFERTtBQUpjLEdBdkNVO0FBK0NyQ3dCLFVBQVEsRUFBRTtBQUNSeEIsUUFBSSxFQUFFQyxNQURFO0FBRVJDLFNBQUssRUFBRTtBQUZDLEdBL0MyQjtBQW1EckN1QixRQUFNLEVBQUU7QUFDTnpCLFFBQUksRUFBRUMsTUFEQTtBQUVOQyxTQUFLLEVBQUU7QUFGRCxHQW5ENkI7QUF1RHJDd0IsV0FBUyxFQUFFO0FBQ1QxQixRQUFJLEVBQUVhLE1BREc7QUFFVGMsVUFBTSxFQUFDLElBRkU7QUFHVHpCLFNBQUssRUFBRTtBQUhFLEdBdkQwQjtBQTREckMwQixNQUFJLEVBQUU7QUFDSjVCLFFBQUksRUFBRUMsTUFERjtBQUVKQyxTQUFLLEVBQUU7QUFGSCxHQTVEK0I7QUFnRXJDbUIsY0FBWSxFQUFFO0FBQ1pyQixRQUFJLEVBQUVDLE1BRE07QUFFWkMsU0FBSyxFQUFFLGVBRks7QUFHWkcsWUFBUSxFQUFFO0FBQ1BMLFVBQUksRUFBRSxTQURDO0FBRU5lLGlCQUFXLEVBQUUsZUFGUDtBQUdORCxXQUFLLEVBQUUsYUFIRDtBQUlORSxhQUFPLEVBQUUsQ0FFTDtBQUFDZCxhQUFLLEVBQUUsT0FBUjtBQUFpQmUsYUFBSyxFQUFFO0FBQXhCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsZ0JBQVI7QUFBMEJlLGFBQUssRUFBRTtBQUFqQyxPQUhLO0FBSkg7QUFIRSxHQWhFdUI7QUErRXJDWSxZQUFVLEVBQUU7QUFDVjdCLFFBQUksRUFBRUMsTUFESTtBQUVWQyxTQUFLLEVBQUU7QUFGRyxHQS9FeUI7QUFtRnJDNEIsUUFBTSxFQUFFO0FBQ045QixRQUFJLEVBQUVDLE1BREE7QUFFTkMsU0FBSyxFQUFFO0FBRkQsR0FuRjZCO0FBdUZyQzZCLGFBQVcsRUFBRTtBQUNYL0IsUUFBSSxFQUFFQyxNQURLO0FBRVhDLFNBQUssRUFBRSxJQUZJO0FBR1hHLFlBQVEsRUFBRTtBQUNQTCxVQUFJLEVBQUUsU0FEQztBQUVOZSxpQkFBVyxFQUFFLElBRlA7QUFHTkQsV0FBSyxFQUFFLFlBSEQ7QUFJTkUsYUFBTyxFQUFFLENBRUw7QUFBQ2QsYUFBSyxFQUFFLEtBQVI7QUFBZWUsYUFBSyxFQUFFO0FBQXRCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsS0FBUjtBQUFlZSxhQUFLLEVBQUU7QUFBdEIsT0FISyxFQUlMO0FBQUNmLGFBQUssRUFBRSxLQUFSO0FBQWVlLGFBQUssRUFBRTtBQUF0QixPQUpLLEVBS0w7QUFBQ2YsYUFBSyxFQUFFLEtBQVI7QUFBZWUsYUFBSyxFQUFFO0FBQXRCLE9BTEssRUFNTDtBQUFDZixhQUFLLEVBQUUsS0FBUjtBQUFlZSxhQUFLLEVBQUU7QUFBdEIsT0FOSyxFQU9MO0FBQUNmLGFBQUssRUFBRSxLQUFSO0FBQWVlLGFBQUssRUFBRTtBQUF0QixPQVBLLEVBUUw7QUFBQ2YsYUFBSyxFQUFFLEtBQVI7QUFBZWUsYUFBSyxFQUFFO0FBQXRCLE9BUkssRUFTTDtBQUFDZixhQUFLLEVBQUUsS0FBUjtBQUFlZSxhQUFLLEVBQUU7QUFBdEIsT0FUSyxFQVVMO0FBQUNmLGFBQUssRUFBRSxLQUFSO0FBQWVlLGFBQUssRUFBRTtBQUF0QixPQVZLLEVBV0w7QUFBQ2YsYUFBSyxFQUFFLEtBQVI7QUFBZWUsYUFBSyxFQUFFO0FBQXRCLE9BWEs7QUFKSDtBQUhDLEdBdkZ3QjtBQTZHckNlLFdBQVMsRUFBRTtBQUNUaEMsUUFBSSxFQUFFQyxNQURHO0FBRVRDLFNBQUssRUFBRSxZQUZFO0FBR1RHLFlBQVEsRUFBRTtBQUNQTCxVQUFJLEVBQUUsU0FEQztBQUVOZSxpQkFBVyxFQUFFLFdBRlA7QUFHTkQsV0FBSyxFQUFFLGFBSEQ7QUFJTkUsYUFBTyxFQUFFLENBRUw7QUFBQ2QsYUFBSyxFQUFFLFVBQVI7QUFBb0JlLGFBQUssRUFBRTtBQUEzQixPQUZLLEVBR0w7QUFBQ2YsYUFBSyxFQUFFLGVBQVI7QUFBeUJlLGFBQUssRUFBRTtBQUFoQyxPQUhLLEVBSUw7QUFBQ2YsYUFBSyxFQUFFLFNBQVI7QUFBbUJlLGFBQUssRUFBRTtBQUExQixPQUpLLEVBS0w7QUFBQ2YsYUFBSyxFQUFFLGtCQUFSO0FBQTRCZSxhQUFLLEVBQUU7QUFBbkMsT0FMSyxFQU1MO0FBQUNmLGFBQUssRUFBRSxRQUFSO0FBQWtCZSxhQUFLLEVBQUU7QUFBekIsT0FOSztBQUpIO0FBSEQsR0E3RzBCO0FBOEhyQ2dCLGFBQVcsRUFBRTtBQUNYakMsUUFBSSxFQUFFbUIsSUFESztBQUVYakIsU0FBSyxFQUFFLGVBRkk7QUFHWE0sWUFBUSxFQUFDO0FBSEUsR0E5SHdCO0FBbUlyQ2MsUUFBTSxFQUFFO0FBQ050QixRQUFJLEVBQUVDLE1BREE7QUFFTkMsU0FBSyxFQUFFLFFBRkQ7QUFHTkcsWUFBUSxFQUFFO0FBQ1BMLFVBQUksRUFBRSxTQURDO0FBRU5lLGlCQUFXLEVBQUUsUUFGUDtBQUdORCxXQUFLLEVBQUUsYUFIRDtBQUlORSxhQUFPLEVBQUUsQ0FFTDtBQUFDZCxhQUFLLEVBQUUsTUFBUjtBQUFnQmUsYUFBSyxFQUFFO0FBQXZCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsTUFBUjtBQUFnQmUsYUFBSyxFQUFFO0FBQXZCLE9BSEssRUFJTDtBQUFDZixhQUFLLEVBQUUsWUFBUjtBQUFzQmUsYUFBSyxFQUFFO0FBQTdCLE9BSks7QUFKSDtBQUhKO0FBbkk2QixDQUFqQixDQUF0QjtBQW9KQTFCLGVBQWUsQ0FBQ00sWUFBaEIsQ0FBNkIsSUFBSUMsWUFBSixDQUFpQjtBQUM1Q29DLGNBQVksRUFBRTtBQUNabEMsUUFBSSxFQUFFQyxNQURNO0FBRVpDLFNBQUssRUFBRTtBQUZLLEdBRDhCO0FBSzVDaUMsU0FBTyxFQUFFO0FBQ1BuQyxRQUFJLEVBQUVDLE1BREM7QUFFUEMsU0FBSyxFQUFFLFNBRkE7QUFHUE0sWUFBUSxFQUFDLElBSEY7QUFJTkgsWUFBUSxFQUFFO0FBQ1JMLFVBQUksRUFBRSxVQURFO0FBRVBlLGlCQUFXLEVBQUU7QUFGTjtBQUpKLEdBTG1DO0FBZTVDcUIsV0FBUyxFQUFFO0FBQ1RwQyxRQUFJLEVBQUVDLE1BREc7QUFFVEMsU0FBSyxFQUFFLFNBRkU7QUFHVE0sWUFBUSxFQUFDLElBSEE7QUFJUEgsWUFBUSxFQUFFO0FBQ1RMLFVBQUksRUFBRSxTQURHO0FBRVRnQixhQUFPLEVBQUUsWUFBWTtBQUNwQixZQUFHcUIsTUFBTSxDQUFDQyxRQUFWLEVBQ0EsT0FBT0MsQ0FBQyxDQUFDQyxHQUFGLENBQU1DLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosQ0FBTixFQUErQixVQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDcEQsaUJBQU87QUFBQzFDLGlCQUFLLEVBQUV5QyxDQUFDLENBQUNFLFFBQVY7QUFBb0I1QixpQkFBSyxFQUFFMEIsQ0FBQyxDQUFDRztBQUE3QixXQUFQO0FBQ0QsU0FGTSxDQUFQO0FBRUcsT0FOSztBQU9SaEMsV0FBSyxFQUFFO0FBUEM7QUFKSCxHQWZpQztBQTZCNUNpQyxTQUFPLEVBQUU7QUFDUC9DLFFBQUksRUFBRW1CLElBREM7QUFFUFgsWUFBUSxFQUFFLElBRkg7QUFHUEUsYUFBUyxFQUFFLFlBQVc7QUFDcEIsVUFBSSxLQUFLc0MsUUFBVCxFQUFtQjtBQUNqQixlQUFPLElBQUk3QixJQUFKLEVBQVA7QUFDRCxPQUZELE1BRU8sSUFBSSxLQUFLOEIsUUFBVCxFQUFtQjtBQUN4QixlQUFPO0FBQ0xDLHNCQUFZLEVBQUUsSUFBSS9CLElBQUo7QUFEVCxTQUFQO0FBR0QsT0FKTSxNQUlBO0FBQ0wsYUFBS2dDLEtBQUw7QUFDRDtBQUNGO0FBYk0sR0E3Qm1DO0FBNEM1Q0MsU0FBTyxFQUFFO0FBQ1BwRCxRQUFJLEVBQUVtQixJQURDO0FBRVBYLFlBQVEsRUFBRSxJQUZIO0FBR1BFLGFBQVMsRUFBRSxZQUFXO0FBQ3BCLFVBQUksS0FBSzJDLFFBQVQsRUFBbUI7QUFDakIsZUFBTyxJQUFJbEMsSUFBSixFQUFQO0FBQ0Q7QUFDRjtBQVBNO0FBNUNtQyxDQUFqQixDQUE3QjtBQXdEQTdCLFFBQVEsQ0FBQ08sWUFBVCxDQUF1QixJQUFJQyxZQUFKLENBQWlCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0F3RCxhQUFXLEVBQUU7QUFDWHRELFFBQUksRUFBRUMsTUFESztBQUVYTyxZQUFRLEVBQUMsSUFGRTtBQUdYTixTQUFLLEVBQUMsYUFISztBQUtYRyxZQUFRLEVBQUU7QUFDUlUsaUJBQVcsRUFBQyxxRkFESjtBQUVSO0FBQ0E7QUFDQTtBQUNBO0FBQ0N3QyxrQkFBWSxFQUFFO0FBQ2J2RCxZQUFJLEVBQUUsWUFETztBQUVid0Qsa0JBQVUsRUFBRSxVQUZDLENBR2I7QUFDQTs7QUFKYTtBQU5QO0FBTEMsR0FoQ3lCO0FBb0RyQ0MsTUFBSSxFQUFFO0FBQ0x6RCxRQUFJLEVBQUVDLE1BREQ7QUFFTEMsU0FBSyxFQUFFO0FBRkYsR0FwRCtCO0FBd0R0Q3dELFNBQU8sRUFBRTtBQUNQMUQsUUFBSSxFQUFFQyxNQURDO0FBRVBDLFNBQUssRUFBRSxTQUZBO0FBR05NLFlBQVEsRUFBRTtBQUhKLEdBeEQ2QjtBQTZEdEM0QixXQUFTLEVBQUU7QUFDVHBDLFFBQUksRUFBRUMsTUFERztBQUVUQyxTQUFLLEVBQUUsU0FGRTtBQUdUTSxZQUFRLEVBQUU7QUFIRCxHQTdEMkI7QUFrRXRDbUQsZUFBYSxFQUFFO0FBQ2IzRCxRQUFJLEVBQUVDLE1BRE87QUFFYkMsU0FBSyxFQUFFO0FBRk0sR0FsRXVCO0FBc0V0QzBELGNBQVksRUFBQztBQUNWNUQsUUFBSSxFQUFFQyxNQURJO0FBRVhPLFlBQVEsRUFBQyxJQUZFO0FBR1hOLFNBQUssRUFBQyxlQUhLO0FBSVhHLFlBQVEsRUFBRTtBQUNQTCxVQUFJLEVBQUUsU0FEQztBQUVQNkQsb0JBQWMsRUFBQztBQUNYOUMsbUJBQVcsRUFBRSxlQURGO0FBRWIrQyxhQUFLLEVBQUMsT0FGTztBQUdiQyxrQkFBVSxFQUFDO0FBSEUsT0FGUjtBQU9QL0MsYUFBTyxFQUFFLFlBQVk7QUFDcEIsZUFBT3VCLENBQUMsQ0FBQ0MsR0FBRixDQUFNakQsZUFBZSxDQUFDeUUsSUFBaEIsR0FBdUJDLEtBQXZCLEVBQU4sRUFBc0MsVUFBVXRCLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUMzRCxpQkFBTztBQUFDMUMsaUJBQUssRUFBRXlDLENBQUMsQ0FBQ1QsWUFBVjtBQUF3QmpCLGlCQUFLLEVBQUUwQixDQUFDLENBQUNHO0FBQWpDLFdBQVA7QUFDRCxTQUZNLENBQVA7QUFFRyxPQVZHO0FBV05oQyxXQUFLLEVBQUU7QUFYRDtBQUpDLEdBdEV5QjtBQXdGckNvRCxrQkFBZ0IsRUFBRTtBQUNqQmxFLFFBQUksRUFBRUMsTUFEVztBQUVqQkMsU0FBSyxFQUFFLG1CQUZVO0FBR2hCRyxZQUFRLEVBQUU7QUFDUkwsVUFBSSxFQUFFLFNBREU7QUFFUGUsaUJBQVcsRUFBRSxtQkFGTjtBQUdQRCxXQUFLLEVBQUUsYUFIQTtBQUlQRSxhQUFPLEVBQUUsQ0FFTDtBQUFDZCxhQUFLLEVBQUUsU0FBUjtBQUFtQmUsYUFBSyxFQUFFO0FBQTFCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsVUFBUjtBQUFvQmUsYUFBSyxFQUFFO0FBQTNCLE9BSEssRUFJTDtBQUFDZixhQUFLLEVBQUUsV0FBUjtBQUFxQmUsYUFBSyxFQUFFO0FBQTVCLE9BSks7QUFKRjtBQUhNLEdBeEZtQjtBQXVHdENrRCxhQUFXLEVBQUM7QUFDVm5FLFFBQUksRUFBRW1CLElBREk7QUFFVmpCLFNBQUssRUFBRSxvQkFGRztBQUdWTSxZQUFRLEVBQUM7QUFIQyxHQXZHMEI7QUE0R3JDNEQsbUJBQWlCLEVBQUM7QUFDakJwRSxRQUFJLEVBQUVtQixJQURXO0FBRWpCakIsU0FBSyxFQUFFLGNBRlU7QUFHakJNLFlBQVEsRUFBQztBQUhRLEdBNUdtQjtBQWlIckM2RCxZQUFVLEVBQUU7QUFDWHJFLFFBQUksRUFBRUMsTUFESztBQUVYQyxTQUFLLEVBQUUsYUFGSTtBQUdYTSxZQUFRLEVBQUU7QUFIQyxHQWpIeUI7QUFzSHRDOEQsV0FBUyxFQUFFO0FBQ1R0RSxRQUFJLEVBQUVDLE1BREc7QUFFVEMsU0FBSyxFQUFFLFNBRkU7QUFHVE0sWUFBUSxFQUFFO0FBSEQsR0F0SDJCO0FBMkh0QytELGtCQUFnQixFQUFFO0FBQ2hCdkUsUUFBSSxFQUFFYSxNQURVO0FBRWhCWCxTQUFLLEVBQUUsbUJBRlM7QUFHaEJNLFlBQVEsRUFBRTtBQUhNLEdBM0hvQjtBQWdJdENnRSx5QkFBdUIsRUFBRTtBQUN2QnhFLFFBQUksRUFBRWEsTUFEaUI7QUFFdkJYLFNBQUssRUFBRSx5QkFGZ0I7QUFHdEJHLFlBQVEsRUFBRTtBQUNSTCxVQUFJLEVBQUUsU0FERTtBQUVQZSxpQkFBVyxFQUFFLHlCQUZOO0FBR1BELFdBQUssRUFBQyxhQUhDO0FBSVBFLGFBQU8sRUFBRSxDQUVMO0FBQUNkLGFBQUssRUFBRSxhQUFSO0FBQXVCZSxhQUFLLEVBQUU7QUFBOUIsT0FGSyxFQUdMO0FBQUNmLGFBQUssRUFBRSxhQUFSO0FBQXVCZSxhQUFLLEVBQUU7QUFBOUIsT0FISztBQUpGLEtBSFk7QUFhdkJULFlBQVEsRUFBRTtBQWJhLEdBaElhO0FBK0l0Q2lFLGVBQWEsRUFBRTtBQUNiekUsUUFBSSxFQUFFQyxNQURPO0FBRWJDLFNBQUssRUFBRSxhQUZNO0FBR2JNLFlBQVEsRUFBRTtBQUhHLEdBL0l1QjtBQW9KdENrRSxTQUFPLEVBQUU7QUFDUDFFLFFBQUksRUFBRUMsTUFEQztBQUVQQyxTQUFLLEVBQUUsU0FGQTtBQUdQTSxZQUFRLEVBQUU7QUFISCxHQXBKNkI7QUEwSnRDbUUsYUFBVyxFQUFFO0FBQ1gzRSxRQUFJLEVBQUVDLE1BREs7QUFFWEMsU0FBSyxFQUFFLGFBRkk7QUFHWE0sWUFBUSxFQUFFO0FBSEMsR0ExSnlCO0FBZ0t0Q29FLGlCQUFlLEVBQUU7QUFDZjVFLFFBQUksRUFBRUMsTUFEUztBQUVmQyxTQUFLLEVBQUUsaUJBRlE7QUFHZk0sWUFBUSxFQUFFO0FBSEssR0FoS3FCO0FBc0t0Q3FFLGlCQUFlLEVBQUU7QUFDZjdFLFFBQUksRUFBRUMsTUFEUztBQUVmQyxTQUFLLEVBQUUsaUJBRlE7QUFHZk0sWUFBUSxFQUFFO0FBSEssR0F0S3FCO0FBNEt0Q3NFLFVBQVEsRUFBRTtBQUNSOUUsUUFBSSxFQUFFQyxNQURFO0FBRVJDLFNBQUssRUFBRSxJQUZDO0FBR1JNLFlBQVEsRUFBRSxJQUhGO0FBSVJILFlBQVEsRUFBRTtBQUNQTCxVQUFJLEVBQUUsUUFEQztBQUVQK0UsaUJBQVcsRUFBQyxFQUZMO0FBR04vRCxhQUFPLEVBQUUsQ0FDTDtBQUFDZCxhQUFLLEVBQUUsR0FBUjtBQUFhZSxhQUFLLEVBQUU7QUFBcEIsT0FESyxFQUVMO0FBQUNmLGFBQUssRUFBRSxHQUFSO0FBQWFlLGFBQUssRUFBRTtBQUFwQixPQUZLLEVBR0w7QUFBQ2YsYUFBSyxFQUFFLEVBQVI7QUFBWWUsYUFBSyxFQUFFO0FBQW5CLE9BSEs7QUFISDtBQUpGLEdBNUs0QjtBQTJMdEMrRCxVQUFRLEVBQUU7QUFDUmhGLFFBQUksRUFBRUMsTUFERTtBQUVSQyxTQUFLLEVBQUUsSUFGQztBQUdSTSxZQUFRLEVBQUUsSUFIRjtBQUlSSCxZQUFRLEVBQUU7QUFDUEwsVUFBSSxFQUFFLFFBREM7QUFFUCtFLGlCQUFXLEVBQUMsRUFGTDtBQUdOL0QsYUFBTyxFQUFFLENBQ0w7QUFBQ2QsYUFBSyxFQUFFLEdBQVI7QUFBYWUsYUFBSyxFQUFFO0FBQXBCLE9BREssRUFFTDtBQUFDZixhQUFLLEVBQUUsR0FBUjtBQUFhZSxhQUFLLEVBQUU7QUFBcEIsT0FGSyxFQUdMO0FBQUNmLGFBQUssRUFBRSxFQUFSO0FBQVllLGFBQUssRUFBRTtBQUFuQixPQUhLO0FBSEg7QUFKRixHQTNMNEI7QUF5TXRDZ0UsVUFBUSxFQUFFO0FBQ1JqRixRQUFJLEVBQUVDLE1BREU7QUFFUkMsU0FBSyxFQUFFLElBRkM7QUFHUk0sWUFBUSxFQUFFLElBSEY7QUFJUkgsWUFBUSxFQUFFO0FBQ1BMLFVBQUksRUFBRSxRQURDO0FBRVArRSxpQkFBVyxFQUFDLEVBRkw7QUFHTi9ELGFBQU8sRUFBRSxDQUNMO0FBQUNkLGFBQUssRUFBRSxHQUFSO0FBQWFlLGFBQUssRUFBRTtBQUFwQixPQURLLEVBRUw7QUFBQ2YsYUFBSyxFQUFFLEdBQVI7QUFBYWUsYUFBSyxFQUFFO0FBQXBCLE9BRkssRUFHTDtBQUFDZixhQUFLLEVBQUUsRUFBUjtBQUFZZSxhQUFLLEVBQUU7QUFBbkIsT0FISztBQUhIO0FBSkYsR0F6TTRCO0FBdU50Q2lFLFVBQVEsRUFBRTtBQUNSbEYsUUFBSSxFQUFFQyxNQURFO0FBRVJDLFNBQUssRUFBRSxJQUZDO0FBR1JNLFlBQVEsRUFBRSxJQUhGO0FBSVJILFlBQVEsRUFBRTtBQUNQTCxVQUFJLEVBQUUsUUFEQztBQUVUK0UsaUJBQVcsRUFBQyxFQUZIO0FBR04vRCxhQUFPLEVBQUUsQ0FDTDtBQUFDZCxhQUFLLEVBQUUsR0FBUjtBQUFhZSxhQUFLLEVBQUU7QUFBcEIsT0FESyxFQUVMO0FBQUNmLGFBQUssRUFBRSxHQUFSO0FBQWFlLGFBQUssRUFBRTtBQUFwQixPQUZLLEVBR0w7QUFBQ2YsYUFBSyxFQUFFLEVBQVI7QUFBWWUsYUFBSyxFQUFFO0FBQW5CLE9BSEs7QUFISDtBQUpGLEdBdk40QjtBQXFPckNrRSxZQUFVLEVBQUU7QUFDWG5GLFFBQUksRUFBRUMsTUFESztBQUVYQyxTQUFLLEVBQUUsYUFGSTtBQUdWTSxZQUFRLEVBQUU7QUFIQSxHQXJPeUI7QUEyT3RDNEUsZUFBYSxFQUFFO0FBQ2JwRixRQUFJLEVBQUVPLEtBRE87QUFFYkwsU0FBSyxFQUFFLGVBRk07QUFHYk0sWUFBUSxFQUFFO0FBSEcsR0EzT3VCO0FBZ1B0QyxxQkFBa0I7QUFDaEJSLFFBQUksRUFBQ1M7QUFEVyxHQWhQb0I7QUFtUHJDLHlCQUFzQjtBQUVyQlQsUUFBSSxFQUFFQyxNQUZlO0FBR3JCUyxhQUFTLEVBQUUsWUFBVztBQUNwQixhQUFPNUIsTUFBTSxDQUFDNkIsRUFBUCxFQUFQO0FBQ0Q7QUFMb0IsR0FuUGU7QUEyUHJDLDJCQUF3QjtBQUN2QlgsUUFBSSxFQUFFbUIsSUFEaUI7QUFFdkJYLFlBQVEsRUFBQyxJQUZjO0FBR3ZCSCxZQUFRLEVBQUU7QUFDUkwsVUFBSSxFQUFDO0FBREc7QUFIYSxHQTNQYTtBQW1RdEMsNkJBQTBCO0FBQ3hCQSxRQUFJLEVBQUVDLE1BRGtCO0FBRXhCTyxZQUFRLEVBQUMsSUFGZTtBQUd4QkgsWUFBUSxFQUFFO0FBQ1JMLFVBQUksRUFBQztBQURHO0FBSGMsR0FuUVk7QUEyUXRDLDZCQUEwQjtBQUN4QkEsUUFBSSxFQUFFQyxNQURrQjtBQUV4QkMsU0FBSyxFQUFDLGFBRmtCO0FBR3hCO0FBQ0FHLFlBQVEsRUFBRTtBQUNSO0FBQ0E7QUFDQVUsaUJBQVcsRUFBQztBQUhKO0FBSmMsR0EzUVk7QUFzUnRDTyxRQUFNLEVBQUU7QUFDTnRCLFFBQUksRUFBRUMsTUFEQTtBQUVOQyxTQUFLLEVBQUUsUUFGRDtBQUdOTSxZQUFRLEVBQUU7QUFISjtBQXRSOEIsQ0FBakIsQ0FBdkI7QUE2UkFyQixRQUFRLENBQUNVLFlBQVQsQ0FBc0IsSUFBSUMsWUFBSixDQUFpQjtBQUNyQ3VGLE9BQUssRUFBRTtBQUNMckYsUUFBSSxFQUFFQyxNQUREO0FBRUxDLFNBQUssRUFBRTtBQUZGLEdBRDhCO0FBS3JDb0YsT0FBSyxFQUFFO0FBQ0x0RixRQUFJLEVBQUVDLE1BREQ7QUFFTEMsU0FBSyxFQUFFO0FBRkYsR0FMOEI7QUFTckNxRixPQUFLLEVBQUU7QUFDTHZGLFFBQUksRUFBRW1CLElBREQ7QUFFSmpCLFNBQUssRUFBRSxPQUZIO0FBR0xNLFlBQVEsRUFBRTtBQUhMLEdBVDhCO0FBZXJDdUMsU0FBTyxFQUFFO0FBQ1AvQyxRQUFJLEVBQUVtQixJQURDO0FBRVBYLFlBQVEsRUFBRSxJQUZIO0FBR1BFLGFBQVMsRUFBRSxZQUFXO0FBQ3BCLFVBQUksS0FBS3NDLFFBQVQsRUFBbUI7QUFDakIsZUFBTyxJQUFJN0IsSUFBSixFQUFQO0FBQ0QsT0FGRCxNQUVPLElBQUksS0FBSzhCLFFBQVQsRUFBbUI7QUFDeEIsZUFBTztBQUNMQyxzQkFBWSxFQUFFLElBQUkvQixJQUFKO0FBRFQsU0FBUDtBQUdELE9BSk0sTUFJQTtBQUNMLGFBQUtnQyxLQUFMO0FBQ0Q7QUFDRjtBQWJNLEdBZjRCO0FBOEJyQ0MsU0FBTyxFQUFFO0FBQ1BwRCxRQUFJLEVBQUVtQixJQURDO0FBRVBYLFlBQVEsRUFBRSxJQUZIO0FBR1BFLGFBQVMsRUFBRSxZQUFXO0FBQ3BCLFVBQUksS0FBSzJDLFFBQVQsRUFBbUI7QUFDakIsZUFBTyxJQUFJbEMsSUFBSixFQUFQO0FBQ0Q7QUFDRjtBQVBNO0FBOUI0QixDQUFqQixDQUF0QjtBQTBDQXpCLFlBQVksQ0FBQzhGLEtBQWIsQ0FBbUI7QUFDakJDLFFBQU0sRUFBRSxZQUFZO0FBQ2xCLFdBQU8sSUFBUDtBQUNELEdBSGdCO0FBSWpCQyxRQUFNLEVBQUUsWUFBWTtBQUNsQixXQUFPLElBQVA7QUFDRDtBQU5nQixDQUFuQjtBQVFBcEcsUUFBUSxDQUFDa0csS0FBVCxDQUFlO0FBQ2JDLFFBQU0sRUFBRSxZQUFZO0FBQ2xCLFdBQU8sSUFBUDtBQUNELEdBSFk7QUFJYkMsUUFBTSxFQUFFLFlBQVk7QUFDbEIsV0FBTyxJQUFQO0FBQ0Q7QUFOWSxDQUFmO0FBU0FuRyxlQUFlLENBQUNpRyxLQUFoQixDQUFzQjtBQUNwQkMsUUFBTSxFQUFFLFlBQVk7QUFDbEIsV0FBTyxJQUFQO0FBQ0QsR0FIbUI7QUFJcEJDLFFBQU0sRUFBRSxZQUFZO0FBQ2xCLFdBQU8sSUFBUDtBQUNEO0FBTm1CLENBQXRCO0FBUUFqRyxxQkFBcUIsQ0FBQytGLEtBQXRCLENBQTRCO0FBQzFCQyxRQUFNLEVBQUUsWUFBWTtBQUNsQixXQUFPLElBQVA7QUFDRCxHQUh5QjtBQUkxQkMsUUFBTSxFQUFFLFlBQVk7QUFDbEIsV0FBTyxJQUFQO0FBQ0Q7QUFOeUIsQ0FBNUI7QUFRQWpHLHFCQUFxQixDQUFDK0YsS0FBdEIsQ0FBNEI7QUFDMUJDLFFBQU0sRUFBRSxZQUFZO0FBQ2xCLFdBQU8sSUFBUDtBQUNELEdBSHlCO0FBSTFCQyxRQUFNLEVBQUUsWUFBWTtBQUNsQixXQUFPLElBQVA7QUFDRDtBQU55QixDQUE1QjtBQVFBaEcsWUFBWSxDQUFDOEYsS0FBYixDQUFtQjtBQUNqQkMsUUFBTSxFQUFFLFlBQVk7QUFDbEIsV0FBTyxJQUFQO0FBQ0QsR0FIZ0I7QUFJakJDLFFBQU0sRUFBRSxZQUFZO0FBQ2xCLFdBQU8sSUFBUDtBQUNEO0FBTmdCLENBQW5CLEU7Ozs7Ozs7Ozs7O0FDNXZCQ0MscUJBQXFCLEdBQUdDLGVBQWUsQ0FBQ0MsTUFBaEIsQ0FBdUI7QUFDOUNDLGdCQUFjLEVBQUUsV0FEOEI7QUFFN0NDLGlCQUFlLEVBQUUsWUFGNEI7QUFHN0NDLG1CQUFpQixFQUFFLFVBSDBCO0FBSWhEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNHQyxRQUFNLEVBQUUsWUFBVztBQUNwQixXQUFPLEVBQVA7QUFJRSxHQWY0QztBQWdCN0NDLGdCQUFjLEVBQUUsVUFBU0MsS0FBVCxFQUFnQjtBQUNqQyxTQUFLQyxNQUFMLENBQVksWUFBWjs7QUFFQSxRQUFLLENBQUMvRCxNQUFNLENBQUNnRSxJQUFQLEVBQU4sRUFDQztBQUFDLFdBQUtELE1BQUwsQ0FBWSxPQUFaO0FBQXNCLEtBRHhCLENBRUY7QUFGRSxTQUdNO0FBQUMsYUFBS0UsSUFBTDtBQUFhO0FBQ2xCLEdBdkI0QztBQXdCN0NDLFFBQU0sRUFBRSxZQUFZO0FBQ3JCLFFBQUksQ0FBQyxLQUFLQyxLQUFMLEVBQUwsRUFBbUI7QUFFakIsV0FBS0osTUFBTCxDQUFZLFlBQVo7QUFDRCxLQUhELE1BSUs7QUFDSkssYUFBTyxDQUFDQyxPQUFSO0FBQ0MsV0FBS04sTUFBTDtBQUVEO0FBQ0M7QUFsQzRDLENBQXZCLENBQXhCO0FBcUNETyxNQUFNLENBQUNDLEtBQVAsQ0FBYSxTQUFiLEVBQXdCO0FBQ3ZCQyxNQUFJLEVBQUUsU0FEaUI7QUFFdkI7QUFDR0MsVUFBUSxFQUFDLFFBSFc7QUFJdEJDLFlBQVUsRUFBRXBCO0FBSlUsQ0FBeEI7QUFNQWdCLE1BQU0sQ0FBQ0MsS0FBUCxDQUFhLHFCQUFiLEVBQW9DO0FBQ2hDSSxPQUFLLEVBQUUsUUFEeUI7QUFFaENILE1BQUksRUFBRSwwQkFGMEI7QUFHaENOLFFBQU0sRUFBRSxZQUFXO0FBQ2xCLFFBQUlVLENBQUMsR0FBQzlILFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQU47QUFDQSxRQUFJOEIsV0FBVyxHQUFDRixDQUFDLEdBQUNBLENBQUMsQ0FBQzNCLEtBQUgsR0FBUyxhQUExQjtBQUNBLFFBQUlaLE9BQU8sR0FBQy9FLFFBQVEsQ0FBQ3VILE9BQVQsQ0FBaUI7QUFBQ3BFLFNBQUcsRUFBQyxLQUFLc0UsTUFBTCxDQUFZekc7QUFBakIsS0FBakIsQ0FBWjs7QUFDQSxRQUFHK0QsT0FBSCxFQUFXO0FBRVQsVUFBSTJDLFFBQVEsR0FBRzNDLE9BQU8sQ0FBQ21DLElBQXZCO0FBRUQsVUFBSUEsSUFBSSxHQUFHTSxXQUFXLEdBQUNFLFFBQXZCO0FBRUEsVUFBSUMsSUFBSSxHQUFDLElBQVQ7QUFDREMsUUFBRSxHQUFHQyxHQUFHLENBQUNDLE9BQUosQ0FBWSxJQUFaLENBQUw7O0FBQ0EsVUFBRyxDQUFDRixFQUFFLENBQUNHLFVBQUgsQ0FBY2IsSUFBZCxDQUFKLEVBQXlCO0FBQ3ZCLGFBQUtjLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QixHQUF4QixFQUE2QjtBQUFFLGlDQUF1QjtBQUF6QixTQUE3QjtBQUNELGVBQU8sS0FBS0QsUUFBTCxDQUFjRSxHQUFkLENBQWtCLEtBQWxCLENBQVA7QUFDTDs7QUFDQyxVQUFJQyxJQUFJLEdBQUdQLEVBQUUsQ0FBQ1EsWUFBSCxDQUFnQmxCLElBQWhCLENBQVg7QUFDRSxXQUFLYyxRQUFMLENBQWNDLFNBQWQsQ0FBd0IsR0FBeEIsRUFBNkI7QUFBRSwrQkFBdUIsMEJBQXdCUDtBQUFqRCxPQUE3QjtBQUVFLGFBQU8sS0FBS00sUUFBTCxDQUFjRSxHQUFkLENBQWtCQyxJQUFsQixDQUFQO0FBRUEsS0FyQmlCLENBc0JsQjs7QUFJQTtBQTdCK0IsQ0FBcEM7QUErQkFuQixNQUFNLENBQUNDLEtBQVAsQ0FBYSx3QkFBYixFQUF1QztBQUN0Q0MsTUFBSSxFQUFFLHdCQURnQztBQUV0QztBQUNHQyxVQUFRLEVBQUMsdUJBSDBCO0FBSXJDQyxZQUFVLEVBQUVwQjtBQUp5QixDQUF2QztBQU1BZ0IsTUFBTSxDQUFDQyxLQUFQLENBQWEsZUFBYixFQUE4QjtBQUM3QkMsTUFBSSxFQUFFLGVBRHVCO0FBRTdCO0FBQ0dDLFVBQVEsRUFBQyxjQUhpQjtBQUk1QkMsWUFBVSxFQUFFcEI7QUFKZ0IsQ0FBOUI7QUFNQWdCLE1BQU0sQ0FBQ0MsS0FBUCxDQUFhLHdCQUFiLEVBQXVDO0FBQ25DRSxVQUFRLEVBQUUsa0JBRHlCO0FBRW5DQyxZQUFVLEVBQUVwQjtBQUZ1QixDQUF2QztBQUlBZ0IsTUFBTSxDQUFDQyxLQUFQLENBQWEsV0FBYixFQUEwQjtBQUN6QkMsTUFBSSxFQUFFLFdBRG1CO0FBRXpCO0FBQ0dDLFVBQVEsRUFBQyxVQUhhO0FBSXhCQyxZQUFVLEVBQUVwQjtBQUpZLENBQTFCO0FBTUFnQixNQUFNLENBQUNDLEtBQVAsQ0FBYSxHQUFiLEVBQWtCO0FBQ2pCQyxNQUFJLEVBQUUsR0FEVztBQUVqQjtBQUNHQyxVQUFRLEVBQUMsUUFISztBQUloQkMsWUFBVSxFQUFFcEI7QUFKSSxDQUFsQjtBQU1BZ0IsTUFBTSxDQUFDQyxLQUFQLENBQWEsV0FBYixFQUEwQjtBQUN6QkMsTUFBSSxFQUFFLFdBRG1CO0FBRXpCO0FBQ0dDLFVBQVEsRUFBQyxVQUhhO0FBSXhCQyxZQUFVLEVBQUVwQjtBQUpZLENBQTFCO0FBTUFnQixNQUFNLENBQUNDLEtBQVAsQ0FBYSxrQkFBYixFQUFpQztBQUNoQ0MsTUFBSSxFQUFFLGtCQUQwQjtBQUVoQztBQUNHQyxVQUFRLEVBQUMsaUJBSG9CO0FBSS9CQyxZQUFVLEVBQUVwQjtBQUptQixDQUFqQztBQU1BZ0IsTUFBTSxDQUFDQyxLQUFQLENBQWEsZUFBYixFQUE4QjtBQUM3QkMsTUFBSSxFQUFFLGVBRHVCO0FBRTdCO0FBQ0dDLFVBQVEsRUFBQyxjQUhpQjtBQUk1QkMsWUFBVSxFQUFFcEI7QUFKZ0IsQ0FBOUI7QUFNQWdCLE1BQU0sQ0FBQ0MsS0FBUCxDQUFhLDZCQUFiLEVBQTRDO0FBQ3hDRSxVQUFRLEVBQUUsdUJBRDhCO0FBRXhDQyxZQUFVLEVBQUVwQixxQkFGNEI7QUFHeENtQyxNQUFJLEVBQUUsWUFBVTtBQUNYLFFBQUlFLEdBQUcsR0FBQzdJLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQ3BFLFNBQUcsRUFBRSxLQUFLc0UsTUFBTCxDQUFZdEU7QUFBbEIsS0FBakIsQ0FBUjtBQUNBLFdBQU9rRixHQUFQO0FBQ0o7QUFOdUMsQ0FBNUM7QUFRQXJCLE1BQU0sQ0FBQ0MsS0FBUCxDQUFhLFdBQWIsRUFBMEI7QUFDekJDLE1BQUksRUFBRSxXQURtQjtBQUV6QjtBQUNHQyxVQUFRLEVBQUMsVUFIYTtBQUl4QkMsWUFBVSxFQUFFcEI7QUFKWSxDQUExQixFOzs7Ozs7Ozs7OztBQ2pJQSxJQUFJc0MsT0FBSjtBQUFZbEosTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ2tKLFNBQU8sQ0FBQ2pKLENBQUQsRUFBRztBQUFDZ0osV0FBTyxHQUFDaEosQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJa0osTUFBSjtBQUFXcEosTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDa0osU0FBTyxDQUFDakosQ0FBRCxFQUFHO0FBQUNrSixVQUFNLEdBQUNsSixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBR3JGbUosSUFBSSxHQUFDLElBQUlILE9BQU8sQ0FBQ0ksS0FBWixDQUFrQjtBQUN0QkMsTUFBSSxFQUFFLFVBRGdCO0FBRXJCQyxVQUFRLEVBQUU7QUFDUkMsY0FBVSxFQUFFO0FBREosR0FGVztBQUtyQkEsWUFBVSxFQUFFLElBTFM7QUFNckJDLFdBQVMsRUFBRSxJQU5VO0FBT3RCakYsWUFBVSxFQUFFbEUsUUFQVTtBQVF0Qm9KLFNBQU8sRUFBRSxDQUFDLHFCQUFELENBUmE7O0FBU3JCQyxZQUFVLENBQUVDLEdBQUYsRUFBT2QsSUFBUCxFQUFhZSxTQUFiLEVBQXlCO0FBQ2xDLFFBQUdmLElBQUksQ0FBQ3hHLE1BQUwsSUFBYSxNQUFoQixFQUF1QjtBQUNyQixVQUFJd0gsSUFBSSxHQUFDQyxDQUFDLENBQUNILEdBQUQsQ0FBVjtBQUVBLFVBQUlJLElBQUksR0FBQ0MsVUFBVSxDQUFDTCxHQUFHLENBQUN6RSxXQUFMLENBQW5CO0FBQ0UsVUFBRzZFLElBQUksR0FBQyxFQUFSLEVBQVlGLElBQUksQ0FBQ0ksSUFBTCxDQUFVLE9BQVYsRUFBa0IsU0FBbEIsRUFKTyxDQUl1QjtBQUU3QztBQUNGLEdBakJxQjs7QUFrQnJCQyxhQUFXLEVBQUUsQ0FBQyxjQUFELEVBQWlCLFlBQWpCLEVBQThCLGFBQTlCLEVBQTRDLGVBQTVDLEVBQTRELGtCQUE1RCxDQWxCUTtBQW1CcEJDLFNBQU8sRUFBRSxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLEtBQWxCLEVBQXlCLFFBQXpCLENBbkJXO0FBb0JyQkMsV0FBUyxFQUFFLEtBcEJVO0FBb0JIO0FBQ3JCO0FBQ0VDLFNBQU8sRUFBRSxDQUNOO0FBQ0dDLFNBQUssRUFBRSxNQURWO0FBRUV6RixTQUFLLEVBQUUsTUFGVDtBQUdFZ0UsUUFBSSxFQUFDLGFBSFA7QUFJQzFCLFVBQU0sRUFBQyxVQUFVbkYsS0FBVixFQUFpQmpCLElBQWpCLEVBQXVCd0osTUFBdkIsRUFBK0I7QUFDbkMsVUFBSVIsSUFBSSxHQUFDQyxVQUFVLENBQUNoSSxLQUFELENBQW5CO0FBQ0QsVUFBRytILElBQUksR0FBQyxFQUFSLEVBQVksT0FBTyxhQUFQO0FBQ1osYUFBT0EsSUFBSSxHQUFDLE9BQVo7QUFDRTtBQVJMLEdBRE0sRUFXTDtBQUNFTyxTQUFLLEVBQUUsTUFEVDtBQUVFekYsU0FBSyxFQUFFLE9BRlQ7QUFHRWdFLFFBQUksRUFBQztBQUhQLEdBWEssRUFpQkw7QUFDRXlCLFNBQUssRUFBRSxTQURUO0FBRUV6RixTQUFLLEVBQUUsTUFGVDtBQUdDZ0UsUUFBSSxFQUFDLFNBSE47QUFJRTFCLFVBQU0sRUFBQyxVQUFVbkYsS0FBVixFQUFpQmpCLElBQWpCLEVBQXVCd0osTUFBdkIsRUFBK0I7QUFDckMsVUFBR3ZJLEtBQUgsRUFBUyxPQUFPQSxLQUFQO0FBQ1QsYUFBTyxHQUFQO0FBQ0M7QUFQSixHQWpCSyxFQTBCTDtBQUNFc0ksU0FBSyxFQUFFLE9BRFQ7QUFFRXpGLFNBQUssRUFBRSxNQUZUO0FBR0NnRSxRQUFJLEVBQUM7QUFITixHQTFCSyxFQStCTDtBQUNFeUIsU0FBSyxFQUFFLFFBRFQ7QUFFRXpGLFNBQUssRUFBRSxPQUZUO0FBR0NnRSxRQUFJLEVBQUMsY0FITjtBQUlFMUIsVUFBTSxFQUFDLFVBQVVuRixLQUFWLEVBQWlCakIsSUFBakIsRUFBdUJ3SixNQUF2QixFQUErQjtBQUNyQyxVQUFJQyxHQUFHLEdBQUNsSyxlQUFlLENBQUMySCxPQUFoQixDQUF3QmpHLEtBQXhCLENBQVI7QUFDQSxVQUFHd0ksR0FBSCxFQUFPLE9BQU9BLEdBQUcsQ0FBQ3ZILFlBQVg7QUFDUCxhQUFPLEdBQVA7QUFDQyxLQVJKO0FBU0d3SCxXQUFPLEVBQUM7QUFUWCxHQS9CSyxFQTBDTDtBQUNFSCxTQUFLLEVBQUUsWUFEVDtBQUVFekYsU0FBSyxFQUFFLE9BRlQ7QUFHRWdFLFFBQUksRUFBQyxhQUhQO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ3BDLFVBQUlHLENBQUMsR0FBRyxJQUFJeEksSUFBSixDQUFTRixLQUFULENBQVI7QUFDRCxVQUFJMkksSUFBSSxHQUFDSixNQUFNLENBQUNLLFdBQVAsR0FBbUJMLE1BQU0sQ0FBQ0ssV0FBMUIsR0FBc0MsRUFBL0M7QUFDRyxVQUFHNUksS0FBSCxFQUFVLE9BQU8wSSxDQUFDLENBQUNHLE9BQUYsS0FBWSxHQUFaLEdBQWdCSCxDQUFDLENBQUNJLFFBQUYsRUFBaEIsR0FBNkIsR0FBN0IsR0FBaUNKLENBQUMsQ0FBQ0ssV0FBRixFQUFqQyxHQUFpRCxHQUFqRCxHQUFxREosSUFBNUQ7QUFDVixhQUFPLEdBQVA7QUFDRDtBQVRKLEdBMUNLLEVBcURMO0FBQ0VMLFNBQUssRUFBRSxjQURUO0FBRUV6RixTQUFLLEVBQUUsT0FGVDtBQUdFZ0UsUUFBSSxFQUFDLG1CQUhQO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ3BDLFVBQUlHLENBQUMsR0FBRyxJQUFJeEksSUFBSixDQUFTRixLQUFULENBQVI7QUFDRCxVQUFHQSxLQUFILEVBQVcsT0FBTzBJLENBQUMsQ0FBQ0csT0FBRixLQUFZLEdBQVosR0FBZ0JILENBQUMsQ0FBQ0ksUUFBRixFQUFoQixHQUE2QixHQUE3QixHQUFpQ0osQ0FBQyxDQUFDSyxXQUFGLEVBQXhDO0FBQ1gsYUFBTyxHQUFQO0FBQ0U7QUFSSixHQXJESyxFQStETDtBQUNFVCxTQUFLLEVBQUUsSUFEVDtBQUVFekYsU0FBSyxFQUFFLE1BRlQ7QUFHQ2dFLFFBQUksRUFBQyxVQUhOO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ25DLGFBQVEsSUFBSVMsU0FBUyxDQUFDQyxVQUFkLENBQXlCQyxjQUFjLENBQUNsSixLQUFELENBQXZDLENBQVI7QUFDQTtBQU5KLEdBL0RLLEVBd0VMO0FBQ0VzSSxTQUFLLEVBQUUsSUFEVDtBQUVFekYsU0FBSyxFQUFFLE1BRlQ7QUFHQ2dFLFFBQUksRUFBQyxVQUhOO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ25DLGFBQVEsSUFBSVMsU0FBUyxDQUFDQyxVQUFkLENBQXlCQyxjQUFjLENBQUNsSixLQUFELENBQXZDLENBQVI7QUFDQTtBQU5KLEdBeEVLLEVBaUZMO0FBQ0VzSSxTQUFLLEVBQUUsSUFEVDtBQUVFekYsU0FBSyxFQUFFLE1BRlQ7QUFHQ2dFLFFBQUksRUFBQyxVQUhOO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ25DLGFBQVEsSUFBSVMsU0FBUyxDQUFDQyxVQUFkLENBQXlCQyxjQUFjLENBQUNsSixLQUFELENBQXZDLENBQVI7QUFDQTtBQU5KLEdBakZLLEVBMEZMO0FBQ0VzSSxTQUFLLEVBQUUsSUFEVDtBQUVFekYsU0FBSyxFQUFFLE1BRlQ7QUFHQ2dFLFFBQUksRUFBQyxVQUhOO0FBSUMxQixVQUFNLEVBQUMsVUFBVW5GLEtBQVYsRUFBaUJqQixJQUFqQixFQUF1QndKLE1BQXZCLEVBQStCO0FBQ25DLGFBQVEsSUFBSVMsU0FBUyxDQUFDQyxVQUFkLENBQXlCQyxjQUFjLENBQUNsSixLQUFELENBQXZDLENBQVI7QUFDQTtBQU5KLEdBMUZLLEVBbUdMO0FBQ0M2QyxTQUFLLEVBQUUsT0FEUjtBQUVBc0csUUFBSSxFQUFFL0gsTUFBTSxDQUFDQyxRQUFQLElBQW1CK0gsUUFBUSxDQUFDQztBQUZsQyxHQW5HSztBQXRCYSxDQUFsQixDQUFMOztBQWdJQSxTQUFTSCxjQUFULENBQXdCN0ksTUFBeEIsRUFDRDtBQUNFLE1BQUdBLE1BQU0sSUFBRSxHQUFYLEVBQWUsT0FBTyw0QkFBMEJBLE1BQTFCLEdBQWlDLE1BQXhDO0FBQ2YsTUFBR0EsTUFBTSxJQUFFLEdBQVgsRUFBZSxPQUFPLDBCQUF3QkEsTUFBeEIsR0FBK0IsTUFBdEM7QUFDZixTQUFPLCtCQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7O0FDeElEO0FBQ0FyQixRQUFNLENBQUNzSyxTQUFQLENBQWlCQyxJQUFqQixHQUF3QixVQUFTQyxTQUFULEVBQW9CQyxNQUFwQixFQUE0QjtBQUNoRCxRQUFJQyxHQUFHLEdBQUcsSUFBVjs7QUFDQSxXQUFPQSxHQUFHLENBQUNELE1BQUosR0FBYUEsTUFBcEIsRUFDSUMsR0FBRyxHQUFHRixTQUFTLEdBQUdFLEdBQWxCOztBQUNKLFdBQU9BLEdBQVA7QUFDSCxHQUxEOztBQU1BeEosTUFBSSxDQUFDb0osU0FBTCxDQUFlSyxRQUFmLEdBQTBCLFVBQVNDLENBQVQsRUFBWTtBQUNuQyxTQUFLQyxPQUFMLENBQWEsS0FBS0MsT0FBTCxLQUFrQkYsQ0FBQyxHQUFDLEVBQUYsR0FBSyxFQUFMLEdBQVEsSUFBdkM7QUFDQSxXQUFPLElBQVA7QUFDRixHQUhEOztBQUlBMUosTUFBSSxDQUFDb0osU0FBTCxDQUFlUyxPQUFmLEdBQXlCLFVBQVVDLEdBQVYsRUFBZTtBQUNwQyxRQUFJaEssS0FBSyxHQUFHLEtBQUtpSyxPQUFMLEVBQVo7QUFDQWpLLFNBQUssSUFBSSxXQUFXZ0ssR0FBcEI7QUFDQSxXQUFPLElBQUk5SixJQUFKLENBQVNGLEtBQVQsQ0FBUDtBQUNILEdBSkQ7O0FBS0FoQixRQUFNLENBQUNzSyxTQUFQLENBQWlCQyxJQUFqQixHQUF3QixVQUFTQyxTQUFULEVBQW9CQyxNQUFwQixFQUE0QjtBQUNoRCxRQUFJQyxHQUFHLEdBQUcsSUFBVjs7QUFDQSxXQUFPQSxHQUFHLENBQUNELE1BQUosR0FBYUEsTUFBcEIsRUFDSUMsR0FBRyxHQUFHRixTQUFTLEdBQUdFLEdBQWxCOztBQUNKLFdBQU9BLEdBQVA7QUFDSCxHQUxEOztBQU1BMUssUUFBTSxDQUFDc0ssU0FBUCxDQUFpQlksV0FBakIsR0FBK0IsWUFBVztBQUN0QyxXQUFPLEtBQUtDLE1BQUwsQ0FBWSxDQUFaLEVBQWVDLFdBQWYsS0FBK0IsS0FBS0MsS0FBTCxDQUFXLENBQVgsQ0FBdEM7QUFDSCxHQUZEOztBQUdBckwsUUFBTSxDQUFDc0ssU0FBUCxDQUFpQmdCLElBQWpCLEdBQXdCLFVBQVNkLFNBQVQsRUFBb0JDLE1BQXBCLEVBQTRCO0FBQ2hELFFBQUlDLEdBQUcsR0FBRyxJQUFWOztBQUNBLFdBQU9BLEdBQUcsQ0FBQ0QsTUFBSixHQUFhQSxNQUFwQixFQUNJQyxHQUFHLEdBQUdBLEdBQUcsR0FBRUYsU0FBWDs7QUFDSixXQUFPRSxHQUFQO0FBQ0gsR0FMRDs7QUFNQXhKLE1BQUksQ0FBQ29KLFNBQUwsQ0FBZWlCLFFBQWYsR0FBMEIsWUFBWTtBQUNsQyxRQUFJdkssS0FBSyxHQUFHLEtBQUtpSyxPQUFMLEVBQVo7QUFDQWpLLFNBQUssSUFBSSxXQUFXLENBQXBCO0FBQ0EsUUFBSTBJLENBQUMsR0FBRSxJQUFJeEksSUFBSixDQUFTRixLQUFULENBQVA7QUFDRixXQUFPMEksQ0FBQyxDQUFDRyxPQUFGLEtBQVksR0FBWixJQUFpQkgsQ0FBQyxDQUFDSSxRQUFGLEtBQWEsQ0FBOUIsSUFBaUMsR0FBakMsR0FBcUNKLENBQUMsQ0FBQ0ssV0FBRixFQUE1QztBQUNELEdBTEQ7O0FBTUE3SSxNQUFJLENBQUNvSixTQUFMLENBQWVrQixTQUFmLEdBQTJCLFlBQVk7QUFDbkMsUUFBSXhLLEtBQUssR0FBRyxLQUFLaUssT0FBTCxFQUFaO0FBQ0FqSyxTQUFLLElBQUksV0FBVyxDQUFwQjtBQUNBLFFBQUkwSSxDQUFDLEdBQUUsSUFBSXhJLElBQUosQ0FBU0YsS0FBVCxDQUFQO0FBQ0YsV0FBTzBJLENBQUMsQ0FBQ0csT0FBRixLQUFZLEdBQVosSUFBaUJILENBQUMsQ0FBQ0ksUUFBRixLQUFhLENBQTlCLElBQWlDLEdBQWpDLEdBQXFDSixDQUFDLENBQUNLLFdBQUYsRUFBNUM7QUFDRCxHQUxEOztBQU1BN0ksTUFBSSxDQUFDb0osU0FBTCxDQUFlbUIsTUFBZixHQUF3QixZQUFZO0FBQ2hDLFFBQUl6SyxLQUFLLEdBQUcsS0FBS2lLLE9BQUwsRUFBWjtBQUNBakssU0FBSyxJQUFJLFdBQVcsQ0FBcEI7QUFDQSxRQUFJMEksQ0FBQyxHQUFFLElBQUl4SSxJQUFKLENBQVNGLEtBQVQsQ0FBUDtBQUNGLFdBQU8wSSxDQUFDLENBQUNJLFFBQUYsS0FBYSxDQUFwQjtBQUNELEdBTEQ7O0FBTUE1SSxNQUFJLENBQUNvSixTQUFMLENBQWVvQixNQUFmLEdBQXVCLFlBQVk7QUFDL0IsUUFBSTFLLEtBQUssR0FBRyxLQUFLaUssT0FBTCxFQUFaO0FBQ0FqSyxTQUFLLElBQUksV0FBVyxDQUFwQjtBQUNBLFFBQUkwSSxDQUFDLEdBQUUsSUFBSXhJLElBQUosQ0FBU0YsS0FBVCxDQUFQO0FBQ0YsV0FBTzBJLENBQUMsQ0FBQ0csT0FBRixFQUFQO0FBQ0QsR0FMRDs7QUFNQTNJLE1BQUksQ0FBQ29KLFNBQUwsQ0FBZXFCLE1BQWYsR0FBdUIsWUFBWTtBQUMvQixRQUFJM0ssS0FBSyxHQUFHLEtBQUtpSyxPQUFMLEVBQVo7QUFDQWpLLFNBQUssSUFBSSxXQUFXLENBQXBCO0FBQ0EsUUFBSTBJLENBQUMsR0FBRSxJQUFJeEksSUFBSixDQUFTRixLQUFULENBQVA7QUFDRixXQUFPMEksQ0FBQyxDQUFDSyxXQUFGLEVBQVA7QUFDRCxHQUxEOztBQU1BbkosUUFBTSxDQUFDMEosU0FBUCxDQUFpQnNCLFdBQWpCLEdBQStCLFVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlQyxDQUFmLEVBQWtCckosQ0FBbEIsRUFBcUI7QUFDaEQsUUFBSXNKLEVBQUUsR0FBRyxpQkFBaUJGLENBQUMsSUFBSSxDQUF0QixJQUEyQixLQUEzQixJQUFvQ0QsQ0FBQyxHQUFHLENBQUosR0FBUSxLQUFSLEdBQWdCLEdBQXBELElBQTJELEdBQXBFO0FBQUEsUUFDSWIsR0FBRyxHQUFHLEtBQUtpQixPQUFMLENBQWFDLElBQUksQ0FBQ0MsR0FBTCxDQUFTLENBQVQsRUFBWSxDQUFDLENBQUNOLENBQWQsQ0FBYixDQURWO0FBR0EsV0FBTyxDQUFDbkosQ0FBQyxHQUFHc0ksR0FBRyxDQUFDb0IsT0FBSixDQUFZLEdBQVosRUFBaUIxSixDQUFqQixDQUFILEdBQXlCc0ksR0FBM0IsRUFBZ0NvQixPQUFoQyxDQUF3QyxJQUFJQyxNQUFKLENBQVdMLEVBQVgsRUFBZSxHQUFmLENBQXhDLEVBQTZELFFBQVFELENBQUMsSUFBSSxHQUFiLENBQTdELENBQVA7QUFDSCxHQUxEOztBQU1BLFdBQVNPLGVBQVQsQ0FBeUJDLEdBQXpCLEVBQThCO0FBQzVCLFFBQUlBLEdBQUcsQ0FBQzlCLE1BQUosSUFBYyxFQUFsQixFQUFzQjtBQUFFLGFBQU8sS0FBUDtBQUFjOztBQUN2QyxXQUFPLElBQVA7QUFDQTs7QUFFRCxNQUFJK0Isa0JBQWtCLEdBQUMsVUFBU0MsTUFBVCxFQUFpQjtBQUN2QyxRQUFJQSxNQUFNLENBQUNoQyxNQUFQLElBQWlCLENBQXJCLEVBQXdCO0FBQUUsYUFBTyxLQUFQO0FBQWM7O0FBQ3hDLFFBQUlpQyxLQUFLLEdBQUdELE1BQU0sQ0FBQ0UsTUFBUCxDQUFjLENBQWQsRUFBZ0IsQ0FBaEIsQ0FBWjtBQUNBLFFBQUlDLGtCQUFrQixHQUFHSCxNQUFNLENBQUMsQ0FBRCxDQUEvQjtBQUNBLFFBQUlJLFFBQVEsR0FBR0osTUFBTSxDQUFDRSxNQUFQLENBQWMsQ0FBZCxFQUFnQixDQUFoQixDQUFmO0FBQ0EsUUFBSUcsa0JBQWtCLEdBQUdMLE1BQU0sQ0FBQyxDQUFELENBQS9CO0FBRUEsUUFBSU0sSUFBSSxHQUFHTCxLQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsQ0FBWCxHQUFlQSxLQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsQ0FBMUIsR0FBOEJBLEtBQUssQ0FBQyxDQUFELENBQUwsR0FBVyxDQUF6QyxHQUE2Q0Usa0JBQWtCLEdBQUcsQ0FBbEUsR0FBc0VDLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBYyxDQUFwRixHQUF3RkEsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjLENBQXRHLEdBQTBHQSxRQUFRLENBQUMsQ0FBRCxDQUFSLEdBQWMsQ0FBbkk7QUFFQSxRQUFJRyxVQUFVLEdBQUcsS0FBTUQsSUFBSSxHQUFHLEVBQTlCO0FBRUEsV0FBT0MsVUFBVSxJQUFJRixrQkFBckI7QUFDQSxHQVpEOztBQWFBRyxXQUFTLEdBQUMsVUFBU0MsR0FBVCxFQUNWO0FBQ0UsUUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLE9BQVA7QUFDVixRQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sU0FBUDtBQUNWLFFBQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxPQUFQO0FBQ1YsUUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLE9BQVA7QUFDVixRQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sTUFBUDtBQUNWLFFBQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxPQUFQO0FBQ1YsUUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLE9BQVA7QUFDVixRQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sUUFBUDtBQUNWLFFBQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxXQUFQO0FBQ1YsUUFBR0EsR0FBRyxJQUFFLEVBQVIsRUFBVyxPQUFPLFNBQVA7QUFDWCxRQUFHQSxHQUFHLElBQUUsRUFBUixFQUFXLE9BQU8sV0FBUDtBQUNYLFFBQUdBLEdBQUcsSUFBRSxFQUFSLEVBQVcsT0FBTyxXQUFQO0FBQ1gsV0FBTyxLQUFQO0FBQ0QsR0FmRDs7QUFnQkFDLFlBQVUsR0FBQyxVQUFTRCxHQUFULEVBQ1g7QUFDRSxRQUFHQSxHQUFHLElBQUUsT0FBUixFQUFnQixPQUFPLENBQVA7QUFDaEIsUUFBR0EsR0FBRyxJQUFFLFNBQVIsRUFBa0IsT0FBTyxDQUFQO0FBQ2xCLFFBQUdBLEdBQUcsSUFBRSxPQUFSLEVBQWdCLE9BQU8sQ0FBUDtBQUNoQixRQUFHQSxHQUFHLElBQUcsT0FBVCxFQUFpQixPQUFPLENBQVA7QUFDakIsUUFBR0EsR0FBRyxJQUFFLE1BQVIsRUFBZSxPQUFPLENBQVA7QUFDZixRQUFHQSxHQUFHLElBQUUsT0FBUixFQUFnQixPQUFPLENBQVA7QUFDaEIsUUFBR0EsR0FBRyxJQUFHLE9BQVQsRUFBaUIsT0FBTyxDQUFQO0FBQ2pCLFFBQUdBLEdBQUcsSUFBRSxRQUFSLEVBQWlCLE9BQU8sQ0FBUDtBQUNqQixRQUFHQSxHQUFHLElBQUUsV0FBUixFQUFvQixPQUFPLENBQVA7QUFDcEIsUUFBR0EsR0FBRyxJQUFFLFNBQVIsRUFBa0IsT0FBTyxFQUFQO0FBQ2xCLFFBQUdBLEdBQUcsSUFBRSxXQUFSLEVBQW9CLE9BQU8sRUFBUDtBQUNwQixRQUFHQSxHQUFHLElBQUUsV0FBUixFQUFvQixPQUFPLEVBQVA7QUFDcEIsV0FBTyxJQUFQO0FBQ0QsR0FmRDs7QUFnQkFFLFVBQVEsR0FBQyxZQUNUO0FBQ0UsV0FBTyxDQUFDLE9BQUQsRUFBUyxTQUFULEVBQW1CLE9BQW5CLEVBQTJCLE9BQTNCLEVBQW1DLE1BQW5DLEVBQTBDLE9BQTFDLEVBQWtELE9BQWxELEVBQTBELFFBQTFELEVBQW1FLFdBQW5FLEVBQStFLFNBQS9FLEVBQXlGLFdBQXpGLEVBQXFHLFdBQXJHLENBQVA7QUFDRCxHQUhEOztBQUlBQyxpQkFBZSxHQUFDLFVBQVNDLFNBQVQsRUFDaEI7QUFDSSxRQUFJQyxFQUFFLEdBQUNELFNBQVMsQ0FBQ0Usa0JBQVYsRUFBUDtBQUNBLFFBQUlDLEdBQUcsR0FBQ0YsRUFBRSxDQUFDRyxLQUFILENBQVMsR0FBVCxDQUFSO0FBRUEsV0FBT0QsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPbEQsSUFBUCxDQUFZLEdBQVosRUFBZ0IsQ0FBaEIsSUFBbUJrRCxHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9sRCxJQUFQLENBQVksR0FBWixFQUFnQixDQUFoQixDQUFuQixHQUFzQ2tELEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT2xELElBQVAsQ0FBWSxHQUFaLEVBQWdCLENBQWhCLENBQTdDO0FBQ0gsR0FORDs7QUFPQW9ELHVCQUFxQixHQUFDLFVBQVNGLEdBQVQsRUFDdEI7QUFDSSxRQUFJRyxHQUFHLEdBQUMsQ0FBUjs7QUFDQSxTQUFJLElBQUlqTCxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUM4SyxHQUFHLENBQUNoRCxNQUFsQixFQUF5QjlILENBQUMsRUFBMUIsRUFBNkJpTCxHQUFHLElBQUVILEdBQUcsQ0FBQzlLLENBQUQsQ0FBSCxDQUFPa0wsT0FBUCxHQUFlLENBQXBCOztBQUM3QixXQUFPRCxHQUFQO0FBQ0gsR0FMRDs7QUFNQUUsbUJBQWlCLEdBQUMsVUFBU0QsT0FBVCxFQUNsQjtBQUNJQSxXQUFPLEdBQUNBLE9BQU8sR0FBQyxFQUFoQjtBQUNBLFFBQUlKLEdBQUcsR0FBQ0ksT0FBTyxDQUFDSCxLQUFSLENBQWMsR0FBZCxDQUFSO0FBQ0EsUUFBR0QsR0FBRyxDQUFDaEQsTUFBSixHQUFXLENBQWQsRUFBZ0IsT0FBT2dELEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT2xELElBQVAsQ0FBWSxHQUFaLEVBQWdCLENBQWhCLElBQW1Ca0QsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPbEQsSUFBUCxDQUFZLEdBQVosRUFBZ0IsQ0FBaEIsQ0FBMUI7QUFDaEIsV0FBT2tELEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT2xELElBQVAsQ0FBWSxHQUFaLEVBQWdCLENBQWhCLElBQW1CLElBQTFCO0FBQ0gsR0FORDs7QUFPQSxNQUFJd0QsYUFBYSxHQUFDLFVBQVNDLE1BQVQsRUFBaUI7QUFDbEMsUUFBSUEsTUFBTSxDQUFDdkQsTUFBUCxJQUFpQixFQUFyQixFQUF5QjtBQUFFLGFBQU8sS0FBUDtBQUFjOztBQUN6QyxRQUFJd0QsaUJBQWlCLEdBQUdELE1BQU0sQ0FBQyxFQUFELENBQTlCO0FBQ0EsUUFBSWpCLElBQUksR0FBR2lCLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWSxDQUFaLEdBQWdCQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVksQ0FBNUIsR0FBZ0NBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWSxDQUE1QyxHQUFnREEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZLENBQTVELEdBQWdFQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVksQ0FBNUUsR0FBZ0ZBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWSxDQUE1RixHQUFnR0EsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZLENBQTVHLEdBQWdIQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVksQ0FBNUgsR0FBZ0lBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWSxDQUE1SSxHQUFnSkEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZLENBQTVKLEdBQWdLQSxNQUFNLENBQUMsRUFBRCxDQUFOLEdBQWEsQ0FBN0ssR0FBaUxBLE1BQU0sQ0FBQyxFQUFELENBQU4sR0FBYSxDQUE5TCxHQUFrTUEsTUFBTSxDQUFDLEVBQUQsQ0FBTixHQUFhLENBQTFOO0FBQ0EsUUFBSWhCLFVBQVUsR0FBRyxLQUFNRCxJQUFJLEdBQUcsRUFBOUI7QUFDQSxXQUFPQyxVQUFVLElBQUlpQixpQkFBckI7QUFDQSxHQU5EOztBQVFBQyxZQUFVLEdBQUMsVUFBUzNCLEdBQVQsRUFBYztBQUN4QixXQUFPRCxlQUFlLENBQUNDLEdBQUQsQ0FBZixJQUF3QkMsa0JBQWtCLENBQUNELEdBQUcsQ0FBQ0ksTUFBSixDQUFXLENBQVgsRUFBYSxDQUFiLENBQUQsQ0FBMUMsSUFBK0RvQixhQUFhLENBQUN4QixHQUFHLENBQUNJLE1BQUosQ0FBVyxDQUFYLEVBQWEsRUFBYixDQUFELENBQW5GO0FBQ0EsR0FGRDs7QUFHQXdCLG1CQUFpQixHQUFDLFVBQVNDLFFBQVQsRUFBa0JDLFFBQWxCLEVBQTJCaE4sTUFBM0IsRUFBa0M7QUFDbkQsUUFBSWlOLElBQUksR0FBQ0MsWUFBWSxDQUFDSCxRQUFELEVBQVVDLFFBQVYsQ0FBckI7QUFDQSxRQUFHaE4sTUFBTSxJQUFFLE1BQVgsRUFBa0IsT0FBTyxXQUFQO0FBQ2xCLFFBQUltTixLQUFLLEdBQUNGLElBQUksS0FBRyxjQUFQLEdBQXNCLGNBQXRCLEdBQXFDLFdBQS9DO0FBQ0MsUUFBR0EsSUFBSSxLQUFHLFFBQVYsRUFBbUJFLEtBQUssR0FBQyxhQUFOO0FBQ3BCLFdBQU9BLEtBQVA7QUFDQSxHQU5EOztBQU9BQyxpQkFBZSxHQUFDLFVBQVNDLElBQVQsRUFBY0MsTUFBZCxFQUNoQjtBQUNDLFFBQUlDLGFBQWEsR0FBQ0MsVUFBVSxDQUFDM1AsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsRUFBMENDLEtBQTNDLENBQTVCO0FBQ0EsUUFBR3NKLE1BQUgsRUFBVyxPQUFPLFFBQVA7QUFDWCxRQUFHRCxJQUFJLElBQUVFLGFBQVQsRUFBdUIsT0FBTyxXQUFQO0FBRXZCLFdBQU8sY0FBUDtBQUNBLEdBUEQ7O0FBUUFFLHFCQUFtQixHQUFDLFVBQVNKLElBQVQsRUFBY0MsTUFBZCxFQUNwQjtBQUNDLFFBQUlDLGFBQWEsR0FBQ0MsVUFBVSxDQUFDM1AsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsRUFBMENDLEtBQTNDLENBQTVCO0FBQ0EsUUFBR3NKLE1BQUgsRUFBVyxPQUFPRSxVQUFVLENBQUMzUCxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQUM3QixXQUFLLEVBQUM7QUFBUCxLQUFqQixFQUEyQ0MsS0FBNUMsQ0FBakI7QUFDWCxRQUFHcUosSUFBSSxJQUFFRSxhQUFULEVBQXVCLE9BQU9DLFVBQVUsQ0FBQzNQLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLEVBQTZDQyxLQUE5QyxDQUFqQjtBQUV2QixXQUFPd0osVUFBVSxDQUFDM1AsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsRUFBaURDLEtBQWxELENBQWpCO0FBQ0EsR0FQRDs7QUFRQTBKLGNBQVksR0FBQyxVQUFTWCxRQUFULEVBQWtCO0FBQzlCLFFBQUlZLEdBQUcsR0FBRyxJQUFJOU4sSUFBSixFQUFWO0FBQ0csUUFBSStOLFVBQVUsR0FBRyxJQUFJL04sSUFBSixDQUFTa04sUUFBVCxDQUFqQjtBQUNBLFFBQUlNLElBQUksR0FBR00sR0FBRyxDQUFDckQsTUFBSixLQUFlc0QsVUFBVSxDQUFDdEQsTUFBWCxFQUExQjtBQUNBLFFBQUl1RCxDQUFDLEdBQUdGLEdBQUcsQ0FBQ3ZELE1BQUosS0FBZXdELFVBQVUsQ0FBQ3hELE1BQVgsRUFBdkI7O0FBRUEsUUFBSXlELENBQUMsR0FBRyxDQUFKLElBQVVBLENBQUMsS0FBSyxDQUFOLElBQVdGLEdBQUcsQ0FBQ3RELE1BQUosS0FBZXVELFVBQVUsQ0FBQ3ZELE1BQVgsRUFBeEMsRUFBOEQ7QUFDMURnRCxVQUFJO0FBQ1A7O0FBRUQsV0FBT0EsSUFBUDtBQUNILEdBWEQ7O0FBWUFILGNBQVksR0FBQyxVQUFTSCxRQUFULEVBQWtCQyxRQUFsQixFQUEyQjtBQUN2QyxRQUFJTyxhQUFhLEdBQUNDLFVBQVUsQ0FBQzNQLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLEVBQTBDQyxLQUEzQyxDQUE1QjtBQUVDLFFBQUk4SixJQUFJLEdBQUNKLFlBQVksQ0FBQ1gsUUFBRCxDQUFyQjtBQUNELFFBQUdDLFFBQUgsRUFBWSxPQUFPLFFBQVA7QUFDVixXQUFPYyxJQUFJLEdBQUNQLGFBQUwsR0FBbUIsY0FBbkIsR0FBa0MsV0FBekM7QUFDRixHQU5EOztBQU9BUSxpQkFBZSxHQUFDLFVBQVNDLE9BQVQsRUFDaEI7QUFDRSxRQUFJQyxpQkFBaUIsR0FBQ3BRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQXRCO0FBQ0UsUUFBSW1LLGNBQWMsR0FBQ3JRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQW5CO0FBQ0EsUUFBSW9LLFdBQVcsR0FBQ3RRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQWhCO0FBQ0osUUFBSXdKLGFBQWEsR0FBQ0MsVUFBVSxDQUFDM1AsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsRUFBMENDLEtBQTNDLENBQTVCO0FBRUUsUUFBSW9LLEtBQUssR0FBQ0MsTUFBTSxDQUFDekksT0FBUCxDQUFlO0FBQUNwRSxTQUFHLEVBQUN3TTtBQUFMLEtBQWYsQ0FBVjtBQUNBLFFBQUlGLElBQUksR0FBQ0osWUFBWSxDQUFDVSxLQUFLLENBQUNFLGVBQVAsQ0FBckI7QUFFQSxRQUFHRixLQUFLLENBQUNwQixRQUFULEVBQWtCLE9BQU9tQixXQUFXLENBQUNuSyxLQUFuQjtBQUNsQixRQUFHOEosSUFBSSxHQUFDUCxhQUFSLEVBQXVCLE9BQU9VLGlCQUFpQixDQUFDakssS0FBekI7QUFDdkIsV0FBT2tLLGNBQWMsQ0FBQ2xLLEtBQXRCO0FBQ0QsR0FiRDs7QUFjQXVLLHNCQUFvQixHQUFDLFVBQVNELGVBQVQsRUFBeUJ0QixRQUF6QixFQUNyQjtBQUNFLFFBQUlpQixpQkFBaUIsR0FBQ3BRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQXRCO0FBQ0UsUUFBSW1LLGNBQWMsR0FBQ3JRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQW5CO0FBQ0EsUUFBSW9LLFdBQVcsR0FBQ3RRLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLFdBQUssRUFBQztBQUFQLEtBQWpCLENBQWhCO0FBQ0osUUFBSXdKLGFBQWEsR0FBQ0MsVUFBVSxDQUFDM1AsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsRUFBMENDLEtBQTNDLENBQTVCO0FBR0UsUUFBSThKLElBQUksR0FBQ0osWUFBWSxDQUFDWSxlQUFELENBQXJCO0FBRUEsUUFBR3RCLFFBQUgsRUFBWSxPQUFPbUIsV0FBVyxDQUFDbkssS0FBbkI7QUFDWixRQUFHOEosSUFBSSxHQUFDUCxhQUFSLEVBQXVCLE9BQU9VLGlCQUFpQixDQUFDakssS0FBekI7QUFDdkIsV0FBT2tLLGNBQWMsQ0FBQ2xLLEtBQXRCO0FBQ0QsR0FiRDs7QUFlQXZHLFFBQU0sQ0FBQytRLE9BQVAsR0FBZXRCLFlBQWY7Ozs7Ozs7Ozs7OztBQy9OQXVCLFNBQVMsR0FBQyxVQUFTQyxZQUFULEVBQXNCQyxPQUF0QixFQUNWO0FBQ0EsTUFBR0EsT0FBSCxFQUNFLEtBQUssSUFBSXJOLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdxTixPQUFPLENBQUN2RixNQUE1QixFQUFvQzlILENBQUMsRUFBckMsRUFDRSxJQUFHM0MsTUFBTSxDQUFDZ1EsT0FBTyxDQUFDck4sQ0FBRCxDQUFQLENBQVduQixNQUFaLENBQU4sQ0FBMEJ5TyxpQkFBMUIsTUFBK0NqUSxNQUFNLENBQUMrUCxZQUFELENBQU4sQ0FBcUJHLFdBQXJCLEVBQWxELEVBQXFGLE9BQU9GLE9BQU8sQ0FBQ3JOLENBQUQsQ0FBZDtBQUV2RixTQUFPLEtBQVA7QUFDRCxDQVBEOztBQVFBd04sVUFBVSxHQUFDLFVBQVNKLFlBQVQsRUFDWDtBQUNFLE1BQUlLLFVBQVUsR0FBQzNRLFlBQVksQ0FBQ3dILE9BQWIsQ0FBcUI7QUFBQ3BFLE9BQUcsRUFBQ1QsTUFBTSxDQUFDZ0UsSUFBUCxHQUFjaUs7QUFBbkIsR0FBckIsQ0FBZjtBQUNBQyxTQUFPLENBQUNDLEdBQVIsQ0FBWW5PLE1BQU0sQ0FBQ2dFLElBQVAsR0FBY2lLLE9BQTFCOztBQUNBLE1BQUdELFVBQUgsRUFBYztBQUNaLFFBQUlKLE9BQU8sR0FBQ0ksVUFBVSxDQUFDL1AsYUFBdkI7QUFDQSxRQUFHK1AsVUFBVSxDQUFDbFEsZUFBZCxFQUE4QixPQUFPLElBQVA7O0FBQ2hDLFNBQUssSUFBSXlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdxTixPQUFPLENBQUN2RixNQUE1QixFQUFvQzlILENBQUMsRUFBckMsRUFDRSxJQUFHM0MsTUFBTSxDQUFDZ1EsT0FBTyxDQUFDck4sQ0FBRCxDQUFQLENBQVduQixNQUFaLENBQU4sQ0FBMEJ5TyxpQkFBMUIsTUFBK0NqUSxNQUFNLENBQUMrUCxZQUFELENBQU4sQ0FBcUJHLFdBQXJCLEVBQWxELEVBQXFGLE9BQU9GLE9BQU8sQ0FBQ3JOLENBQUQsQ0FBZDtBQUV0Rjs7QUFDRCxTQUFPLEtBQVA7QUFDRCxDQVpEOztBQWNBNk4sa0JBQWtCLEdBQUMsVUFBU0osVUFBVCxFQUFvQmhLLElBQXBCLEVBQTBCcUssZUFBMUIsRUFDbkI7QUFDRSxNQUFJQyxTQUFTLEdBQUNDLElBQUksQ0FBQ0YsZUFBRCxDQUFsQjtBQUNBLE1BQUlHLE1BQU0sR0FBQ2QsU0FBUyxDQUFDLFVBQUQsRUFBWU0sVUFBVSxDQUFDL1AsYUFBdkIsQ0FBcEI7QUFDQSxNQUFHK1AsVUFBVSxDQUFDbFEsZUFBZCxFQUE4QixPQUFPd1EsU0FBUyxDQUFDM00sSUFBVixFQUFQOztBQUM5QixNQUFHNk0sTUFBSCxFQUFVO0FBQ1AsUUFBR0EsTUFBTSxDQUFDQyxXQUFWLEVBQXNCO0FBQ3JCLGFBQU9ILFNBQVMsQ0FBQzNNLElBQVYsQ0FBZTtBQUFDNUIsaUJBQVMsRUFBQ2lFLElBQUksQ0FBQ3ZEO0FBQWhCLE9BQWYsQ0FBUDtBQUNBOztBQUNKLFdBQU82TixTQUFTLENBQUMzTSxJQUFWLEVBQVA7QUFDQztBQUdGLENBYkQ7O0FBY0ErTSxrQkFBa0IsR0FBQyxVQUFTTCxlQUFULEVBQ25CO0FBQ0UsTUFBSU0sT0FBTyxHQUFDM08sTUFBTSxDQUFDZ0UsSUFBUCxFQUFaOztBQUNBLE1BQUcySyxPQUFILEVBQVc7QUFDVCxRQUFJWCxVQUFVLEdBQUMzUSxZQUFZLENBQUN3SCxPQUFiLENBQXFCO0FBQUNwRSxTQUFHLEVBQUNrTyxPQUFPLENBQUNWO0FBQWIsS0FBckIsQ0FBZjtBQUNBLFFBQUdELFVBQUgsRUFBYyxPQUFPSSxrQkFBa0IsQ0FBQ0osVUFBRCxFQUFZVyxPQUFaLEVBQXFCTixlQUFyQixDQUF6QjtBQUNmOztBQUFBLFNBQU8sRUFBUDtBQUVGLENBUkQsQzs7Ozs7Ozs7Ozs7QUNwQ0EsSUFBSXJCLGVBQWUsR0FBQyxVQUFTQyxPQUFULEVBQ3BCO0FBQ0UsTUFBSUMsaUJBQWlCLEdBQUNwUSxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQUM3QixTQUFLLEVBQUM7QUFBUCxHQUFqQixDQUF0QjtBQUNFLE1BQUltSyxjQUFjLEdBQUNyUSxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQUM3QixTQUFLLEVBQUM7QUFBUCxHQUFqQixDQUFuQjtBQUNBLE1BQUlvSyxXQUFXLEdBQUN0USxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQUM3QixTQUFLLEVBQUM7QUFBUCxHQUFqQixDQUFoQjtBQUVGLE1BQUlxSyxLQUFLLEdBQUNDLE1BQU0sQ0FBQ3pJLE9BQVAsQ0FBZTtBQUFDcEUsT0FBRyxFQUFDd007QUFBTCxHQUFmLENBQVY7QUFDQSxNQUFJMkIsVUFBVSxHQUFDLElBQUk5UCxJQUFKLENBQVN1TyxLQUFLLENBQUNFLGVBQWYsQ0FBZjtBQUNBLE1BQUlzQixLQUFLLEdBQUMsSUFBSS9QLElBQUosRUFBVjtBQUNBLE1BQUlpTyxJQUFJLEdBQUM4QixLQUFLLENBQUNsSCxXQUFOLEtBQW9CaUgsVUFBVSxDQUFDakgsV0FBWCxFQUE3QjtBQUVBLE1BQUcwRixLQUFLLENBQUNwQixRQUFULEVBQWtCLE9BQU9tQixXQUFXLENBQUNuSyxLQUFuQjtBQUNsQixNQUFHOEosSUFBSSxJQUFFLEVBQVQsRUFBYSxPQUFPRyxpQkFBaUIsQ0FBQ2pLLEtBQXpCO0FBQ2IsU0FBT2tLLGNBQWMsQ0FBQ2xLLEtBQXRCO0FBQ0QsQ0FkRDs7QUFlQSxTQUFTNkwsV0FBVCxDQUFxQmhQLE9BQXJCLEVBQThCb0QsS0FBOUIsRUFBb0M2TCxhQUFwQyxFQUFtREMsUUFBbkQsRUFBNkQsQ0FRNUQsQyxDQUNEO0FBQ0U7QUFDRjs7O0FBQ0FoQyxlQUFlLEdBQUMsVUFBU0MsT0FBVCxFQUNoQjtBQUNFLE1BQUlDLGlCQUFpQixHQUFDcFEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsU0FBSyxFQUFDO0FBQVAsR0FBakIsQ0FBdEI7QUFDRSxNQUFJbUssY0FBYyxHQUFDclEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsU0FBSyxFQUFDO0FBQVAsR0FBakIsQ0FBbkI7QUFDQSxNQUFJb0ssV0FBVyxHQUFDdFEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsU0FBSyxFQUFDO0FBQVAsR0FBakIsQ0FBaEI7QUFFRixNQUFJcUssS0FBSyxHQUFDQyxNQUFNLENBQUN6SSxPQUFQLENBQWU7QUFBQ3BFLE9BQUcsRUFBQ3dNO0FBQUwsR0FBZixDQUFWO0FBQ0EsTUFBSTJCLFVBQVUsR0FBQyxJQUFJOVAsSUFBSixDQUFTdU8sS0FBSyxDQUFDRSxlQUFmLENBQWY7QUFDQSxNQUFJc0IsS0FBSyxHQUFDLElBQUkvUCxJQUFKLEVBQVY7QUFDQSxNQUFJaU8sSUFBSSxHQUFDOEIsS0FBSyxDQUFDbEgsV0FBTixLQUFvQmlILFVBQVUsQ0FBQ2pILFdBQVgsRUFBN0I7QUFFQSxNQUFHMEYsS0FBSyxDQUFDcEIsUUFBVCxFQUFrQixPQUFPbUIsV0FBVyxDQUFDbkssS0FBbkI7QUFDbEIsTUFBRzhKLElBQUksSUFBRSxFQUFULEVBQWEsT0FBT0csaUJBQWlCLENBQUNqSyxLQUF6QjtBQUNiLFNBQU9rSyxjQUFjLENBQUNsSyxLQUF0QjtBQUNELENBZEQsQzs7Ozs7Ozs7Ozs7QUMzQkF2RyxNQUFNLENBQUN1UyxNQUFQLENBQWM7QUFBQ0MsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJQyxVQUFKO0FBQWV6UyxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDd1MsWUFBVSxDQUFDdlMsQ0FBRCxFQUFHO0FBQUN1UyxjQUFVLEdBQUN2UyxDQUFYO0FBQWE7O0FBQTVCLENBQWpDLEVBQStELENBQS9EO0FBQWtFLElBQUl3UyxXQUFKO0FBQWdCMVMsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeVMsYUFBVyxDQUFDeFMsQ0FBRCxFQUFHO0FBQUN3UyxlQUFXLEdBQUN4UyxDQUFaO0FBQWM7O0FBQTlCLENBQTNCLEVBQTJELENBQTNEOztBQUcxSSxJQUFJeVMsSUFBSSxHQUFFLElBQUlGLFVBQUosRUFBVjs7QUFDQ0csTUFBTSxHQUFHbkssR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixDQUFUOztBQUVBLElBQUlGLEVBQUUsR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksSUFBWixDQUFUOztBQUNNLE1BQU04SixTQUFOLENBQ1A7QUFDT0ssYUFBTjtBQUFBLG9DQUFtQjtBQUNqQmpTLGNBQVEsQ0FBQ2tTLE1BQVQsQ0FBZ0IsRUFBaEIsRUFEaUIsQ0FFbEI7O0FBQ0FILFVBQUksQ0FBQ0ksY0FBTDtBQUdBLEtBTkQ7QUFBQTs7QUFPQUMsa0JBQWdCLEdBQ2hCO0FBQ0N6UyxZQUFRLENBQUN1UyxNQUFULENBQWdCLEVBQWhCO0FBQ0FsUyxZQUFRLENBQUNrUyxNQUFULENBQWdCLEVBQWhCO0FBQ0E7O0FBQ0RHLGtCQUFnQixHQUFFO0FBR2pCLFFBQUlDLElBQUksR0FBRyxJQUFJTixNQUFKLEVBQVgsQ0FIaUIsQ0FJakI7O0FBQ0EsUUFBSU8sS0FBSyxHQUFHLHVCQUFaO0FBQ0EsUUFBSXJMLElBQUksR0FBR3NMLE9BQU8sQ0FBQ0MsR0FBUixLQUFnQixpQ0FBM0I7QUFDQSxRQUFJcFIsT0FBTyxHQUFHO0FBQ2JxUixVQUFJLEVBQUUsTUFETztBQUViQyxnQkFBVSxFQUFFLGtCQUZDO0FBR2JDLGdCQUFVLEVBQUUxTCxJQUhDO0FBSWIyTCxVQUFJLEVBQUU7QUFKTyxLQUFkO0FBTUFmLGVBQVcsQ0FBQ2dCLEdBQVosQ0FBZ0JQLEtBQWhCLEVBQXVCbFIsT0FBdkIsRUFBZ0MsVUFBUzBSLEdBQVQsRUFBY0MsR0FBZCxFQUFtQjtBQUNsRCxVQUFJRCxHQUFKLEVBQVMsTUFBTUEsR0FBTjtBQUNSLGFBQU9oQixJQUFJLENBQUNJLGNBQUwsQ0FBb0JHLElBQXBCLENBQVA7QUFHRCxLQUxEO0FBTUEsV0FBT0EsSUFBSSxDQUFDVyxJQUFMLEVBQVA7QUFDQTs7QUFFREMsa0JBQWdCLEdBQUk7QUFDbkI7QUFDRyxRQUFJLENBQUMxVCxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQ3BCN0IsV0FBSyxFQUFFO0FBRGEsS0FBakIsQ0FBTCxFQUVLbEcsUUFBUSxDQUFDc0csTUFBVCxDQUFnQjtBQUNwQkosV0FBSyxFQUFFLGFBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBSUwsUUFBSSxDQUFDbkcsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUNwQjdCLFdBQUssRUFBRTtBQURhLEtBQWpCLENBQUwsRUFFS2xHLFFBQVEsQ0FBQ3NHLE1BQVQsQ0FBZ0I7QUFDcEJKLFdBQUssRUFBRSxnQkFEYTtBQUVwQkMsV0FBSyxFQUFFO0FBRmEsS0FBaEI7QUFJTCxRQUFJLENBQUNuRyxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQ3BCN0IsV0FBSyxFQUFFO0FBRGEsS0FBakIsQ0FBTCxFQUVLbEcsUUFBUSxDQUFDc0csTUFBVCxDQUFnQjtBQUNwQkosV0FBSyxFQUFFLGtCQURhO0FBRXBCQyxXQUFLLEVBQUU7QUFGYSxLQUFoQjtBQUlMLFFBQUksQ0FBQ25HLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFDcEI3QixXQUFLLEVBQUU7QUFEYSxLQUFqQixDQUFMLEVBRUtsRyxRQUFRLENBQUNzRyxNQUFULENBQWdCO0FBQ3BCSixXQUFLLEVBQUUsZUFEYTtBQUVwQkMsV0FBSyxFQUFFO0FBRmEsS0FBaEI7QUFJTCxRQUFJLENBQUNuRyxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQ3BCN0IsV0FBSyxFQUFFO0FBRGEsS0FBakIsQ0FBTCxFQUVLbEcsUUFBUSxDQUFDc0csTUFBVCxDQUFnQjtBQUNwQkosV0FBSyxFQUFFLGFBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBSVIsUUFBSSxDQUFDbkcsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUNwQjdCLFdBQUssRUFBRTtBQURhLEtBQWpCLENBQUwsRUFFS2xHLFFBQVEsQ0FBQ3NHLE1BQVQsQ0FBZ0I7QUFDcEJKLFdBQUssRUFBRSxlQURhO0FBRXBCQyxXQUFLLEVBQUU7QUFGYSxLQUFoQjtBQUlMLFFBQUksQ0FBQ25HLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFDcEI3QixXQUFLLEVBQUU7QUFEYSxLQUFqQixDQUFMLEVBRUtsRyxRQUFRLENBQUNzRyxNQUFULENBQWdCO0FBQ3BCSixXQUFLLEVBQUUsb0JBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBSUwsUUFBSSxDQUFDbkcsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUNwQjdCLFdBQUssRUFBRTtBQURhLEtBQWpCLENBQUwsRUFFS2xHLFFBQVEsQ0FBQ3NHLE1BQVQsQ0FBZ0I7QUFDcEJKLFdBQUssRUFBRSxrQkFEYTtBQUVwQkMsV0FBSyxFQUFFO0FBRmEsS0FBaEI7QUFJTCxRQUFJLENBQUNuRyxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQ3BCN0IsV0FBSyxFQUFFO0FBRGEsS0FBakIsQ0FBTCxFQUVLbEcsUUFBUSxDQUFDc0csTUFBVCxDQUFnQjtBQUNwQkosV0FBSyxFQUFFLGVBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBSUwsUUFBSSxDQUFDbkcsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUNwQjdCLFdBQUssRUFBRTtBQURhLEtBQWpCLENBQUwsRUFFS2xHLFFBQVEsQ0FBQ3NHLE1BQVQsQ0FBZ0I7QUFDcEJKLFdBQUssRUFBRSwwQkFEYTtBQUVwQkMsV0FBSyxFQUFFO0FBRmEsS0FBaEI7QUFJTCxRQUFJLENBQUNuRyxRQUFRLENBQUMrSCxPQUFULENBQWlCO0FBQ3BCN0IsV0FBSyxFQUFFO0FBRGEsS0FBakIsQ0FBTCxFQUVLbEcsUUFBUSxDQUFDc0csTUFBVCxDQUFnQjtBQUNwQkosV0FBSyxFQUFFLGNBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBSUwsUUFBSSxDQUFDbkcsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUNwQjdCLFdBQUssRUFBRTtBQURhLEtBQWpCLENBQUwsRUFFS2xHLFFBQVEsQ0FBQ3NHLE1BQVQsQ0FBZ0I7QUFDcEJKLFdBQUssRUFBRSxlQURhO0FBRXBCQyxXQUFLLEVBQUU7QUFGYSxLQUFoQjtBQUlMLFFBQUksQ0FBQ25HLFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFDcEI3QixXQUFLLEVBQUU7QUFEYSxLQUFqQixDQUFMLEVBRUtsRyxRQUFRLENBQUNzRyxNQUFULENBQWdCO0FBQ3BCSixXQUFLLEVBQUUscUJBRGE7QUFFcEJDLFdBQUssRUFBRTtBQUZhLEtBQWhCO0FBS0w7O0FBQ0R3TixrQkFBZ0IsQ0FBQ0MsYUFBRCxFQUFlQyxVQUFmLEVBQ2hCO0FBQ0MsUUFBSUMsR0FBRyxHQUFDO0FBQUdDLGFBQU8sRUFBRztBQUFFck0sWUFBSSxFQUFFO0FBQVI7QUFBYixLQUFSO0FBQ0EsUUFBSXNNLElBQUksR0FBQztBQUFHQyxjQUFRLEVBQUU7QUFDcEJ0USxXQUFHLEVBQUUsWUFEZTtBQUVwQmlRLHFCQUFhLEVBQUMsTUFGTTtBQUdwQk0sV0FBRyxFQUFDLFlBSGdCO0FBSXBCQyxnQkFBUSxFQUFDLGlCQUpXO0FBS3BCQyxnQkFBUSxFQUFDLGlCQUxXO0FBTXBCQyxlQUFPLEVBQUMsZ0JBTlk7QUFPcEJSLGtCQUFVLEVBQUMsbUJBUFM7QUFRcEJTLGNBQU0sRUFBQztBQVJhO0FBQWIsS0FBVDtBQVdBLFFBQUlDLEtBQUssR0FBQztBQUNUQyxZQUFNLEVBQUU7QUFDUFoscUJBQWEsRUFBRUEsYUFEUjtBQUVQQyxrQkFBVSxFQUFFQTtBQUZMO0FBREMsS0FBVjtBQU1BLFFBQUlZLEdBQUcsR0FBR25VLHFCQUFxQixDQUFDb1UsYUFBdEIsRUFBVjtBQUNBLFFBQUlDLENBQUMsR0FBR3pSLE1BQU0sQ0FBQzBSLFNBQVAsQ0FBaUJILEdBQUcsQ0FBQ0ksU0FBckIsRUFBZ0NKLEdBQWhDLENBQVI7QUFDQSxXQUFPRSxDQUFDLENBQUMsQ0FBRWIsR0FBRixFQUFPRSxJQUFQLEVBQVlPLEtBQVosQ0FBRCxDQUFELENBQXVCTyxPQUF2QixFQUFQO0FBQ0E7O0FBQ0RDLGtCQUFnQixDQUFDQyxTQUFELEVBQVd4VCxFQUFYLEVBQ2hCO0FBQ0MsUUFBSWdRLFNBQVMscUJBQUNDLElBQUksQ0FBQ3VELFNBQUQsQ0FBTCxDQUFiO0FBQ0EsV0FBT3hELFNBQVMsQ0FBQ3pKLE9BQVYsQ0FBa0I7QUFBQ3BFLFNBQUcsRUFBQ25DO0FBQUwsS0FBbEIsQ0FBUDtBQUNBOztBQUNEeVQsd0JBQXNCLENBQUNyQixhQUFELEVBQ3RCO0FBQ0MsUUFBSXNCLElBQUksR0FBQzVVLHFCQUFxQixDQUFDeUgsT0FBdEIsQ0FBOEI7QUFBQ3BFLFNBQUcsRUFBQ2lRO0FBQUwsS0FBOUIsQ0FBVDs7QUFDQSxRQUFHc0IsSUFBSCxFQUFRO0FBQ1AsYUFBTzdVLFFBQVEsQ0FBQ3dFLElBQVQsQ0FBYztBQUFDM0Msb0JBQVksRUFBQ2dULElBQUksQ0FBQ2hULFlBQW5CO0FBQWdDQyxjQUFNLEVBQUM7QUFBdkMsT0FBZCxFQUE4RDJDLEtBQTlELEVBQVA7QUFDQTs7QUFDRCxXQUFPLEVBQVA7QUFDQTs7QUFDRHFRLDBCQUF3QixDQUFDdEIsVUFBRCxFQUN4QjtBQUNDLFFBQUlsTCxJQUFJLEdBQUN0SSxRQUFRLENBQUMwSCxPQUFULENBQWlCO0FBQUNwRSxTQUFHLEVBQUNrUTtBQUFMLEtBQWpCLENBQVQ7QUFDQSxRQUFHbEwsSUFBSCxFQUNDLElBQUdBLElBQUksQ0FBQ3ZHLFVBQVIsRUFBbUIsT0FBT3VHLElBQUksQ0FBQ3ZHLFVBQVo7QUFDcEIsV0FBTyxFQUFQO0FBQ0E7O0FBQ0RnVCxvQkFBa0IsQ0FBQ0osU0FBRCxFQUFXeFQsRUFBWCxFQUFjNlQsWUFBZCxFQUEyQkMsY0FBM0IsRUFDbEI7QUFFQyxRQUFJOUQsU0FBUyxxQkFBQ0MsSUFBSSxDQUFDdUQsU0FBRCxDQUFMLENBQWI7O0FBQ0EsUUFBR0ssWUFBSCxFQUFnQjtBQUNmLFVBQUk3QixHQUFHLEdBQUdoQyxTQUFTLENBQUNqTCxNQUFWLENBQ1A7QUFBQzVDLFdBQUcsRUFBRW5DO0FBQU4sT0FETyxFQUVQO0FBQUUrVCxhQUFLLEVBQUU7QUFBRSxXQUFDRixZQUFELEdBQWdCO0FBQUUsbUJBQU9DO0FBQVQ7QUFBbEI7QUFBVCxPQUZPLEVBR1A7QUFBRUUscUJBQWEsRUFBRTtBQUFqQixPQUhPLENBR2tCO0FBSGxCLE9BQVY7QUFLQSxLQU5ELE1BTUssQ0FFSjs7QUFDRCxRQUFJbEwsR0FBRyxHQUFFa0gsU0FBUyxDQUFDekosT0FBVixDQUFrQjtBQUFDcEUsU0FBRyxFQUFDbkM7QUFBTCxLQUFsQixDQUFUO0FBQ0E0UCxXQUFPLENBQUNDLEdBQVIsQ0FBWS9HLEdBQUcsQ0FBQytLLFlBQUQsQ0FBZjtBQUNBLFdBQU8vSyxHQUFHLENBQUMrSyxZQUFELENBQVY7QUFDQTs7QUFDRCwrQkFBNkJJLFNBQTdCLEVBQ0E7QUFDQyxRQUFJOU0sSUFBSSxHQUFDeEksUUFBUSxDQUFDNEgsT0FBVCxDQUFpQjtBQUFDcEUsU0FBRyxFQUFDOFI7QUFBTCxLQUFqQixDQUFUO0FBQ0FyRSxXQUFPLENBQUNDLEdBQVIsQ0FBWTFJLElBQVosRUFBaUI4TSxTQUFqQjtBQUNBLFFBQUc5TSxJQUFILEVBQ0MsSUFBR0EsSUFBSSxDQUFDMUMsYUFBUixFQUFzQixPQUFPMEMsSUFBSSxDQUFDMUMsYUFBWjtBQUN2QixXQUFPLEVBQVA7QUFDQTs7QUFDRHlQLFdBQVMsQ0FBRS9NLElBQUYsRUFBUTtBQUNoQjtBQUNBO0FBQ0E7QUFDQXlJLFdBQU8sQ0FBQ0MsR0FBUixDQUFZMUksSUFBWjtBQUNBLFFBQUl6QixJQUFJLEdBQUdoRSxNQUFNLENBQUN5UyxLQUFQLENBQWE1TixPQUFiLENBQXFCO0FBQy9CLHdCQUFrQlksSUFBSSxDQUFDaU47QUFEUSxLQUFyQixDQUFYOztBQUdBLFFBQUkxTyxJQUFKLEVBQVU7QUFDVCxVQUFJMk8sUUFBUSxHQUFHbE4sSUFBSSxDQUFDa04sUUFBcEI7O0FBQ0EsVUFBSUMsTUFBTSxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0I5TyxJQUF4QixFQUE4QjJPLFFBQTlCLENBQWI7O0FBQ0F6RSxhQUFPLENBQUNDLEdBQVIsQ0FBWXlFLE1BQVo7O0FBQ0EsVUFBSUEsTUFBTSxDQUFDRyxLQUFYLEVBQWtCO0FBQ2pCLGVBQU9ILE1BQU0sQ0FBQ0csS0FBZDtBQUNBLE9BRkQsTUFFTztBQUNOLGVBQU9ILE1BQVA7QUFDQTtBQUNELEtBVEQsTUFTTztBQUNOLGFBQU87QUFDTkcsYUFBSyxFQUFFO0FBREQsT0FBUDtBQUdBO0FBQ0Q7O0FBQ0FDLFlBQVUsQ0FBRUMsR0FBRixFQUFPO0FBQ2pCL0UsV0FBTyxDQUFDQyxHQUFSLENBQVk4RSxHQUFaO0FBQ0FqVCxVQUFNLENBQUN5UyxLQUFQLENBQWFwUCxNQUFiLENBQW9CO0FBQUM1QyxTQUFHLEVBQUN3UyxHQUFHLENBQUN4UztBQUFULEtBQXBCLEVBQWtDO0FBQUN5UyxVQUFJLEVBQUNEO0FBQU4sS0FBbEM7QUFDQS9FLFdBQU8sQ0FBQ0MsR0FBUixDQUFZbk8sTUFBTSxDQUFDeVMsS0FBUCxDQUFhOVEsSUFBYixHQUFvQkMsS0FBcEIsRUFBWjtBQUNBLFdBQU90RCxFQUFQO0FBQ0E7O0FBQ0E2VSxZQUFVLENBQUVGLEdBQUYsRUFBTztBQUNqQi9FLFdBQU8sQ0FBQ0MsR0FBUixDQUFZOEUsR0FBWjtBQUNBM1UsTUFBRSxHQUFHdVUsUUFBUSxDQUFDTyxVQUFULENBQW9CO0FBQ3hCNVMsY0FBUSxFQUFFeVMsR0FBRyxDQUFDelMsUUFEVTtBQUV4Qm1TLGNBQVEsRUFBRU0sR0FBRyxDQUFDTixRQUZVO0FBR3hCMUUsYUFBTyxFQUFFZ0YsR0FBRyxDQUFDaEY7QUFIVyxLQUFwQixDQUFMO0FBS0FDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZbk8sTUFBTSxDQUFDeVMsS0FBUCxDQUFhOVEsSUFBYixHQUFvQkMsS0FBcEIsRUFBWjtBQUNBLFdBQU90RCxFQUFQO0FBQ0E7O0FBQ0ErVSxVQUFRLEdBQUk7QUFDWixRQUFJL0MsR0FBRyxHQUFHdFEsTUFBTSxDQUFDeVMsS0FBUCxDQUFhOVEsSUFBYixHQUFvQkMsS0FBcEIsRUFBVjtBQUNBc00sV0FBTyxDQUFDQyxHQUFSLENBQVltQyxHQUFaO0FBQ0EsV0FBT0EsR0FBUDtBQUNBOztBQUNBZ0QsZ0JBQWMsQ0FBRWhWLEVBQUYsRUFBTTBFLEtBQU4sRUFBYTtBQUMzQixRQUFJc04sR0FBRyxHQUFHdUMsUUFBUSxDQUFDVSxXQUFULENBQXFCalYsRUFBckIsRUFBeUIwRSxLQUF6QixFQUFnQztBQUN6Q3dRLFlBQU0sRUFBRTtBQURpQyxLQUFoQyxDQUFWO0FBR0F0RixXQUFPLENBQUNDLEdBQVIsQ0FBWW1DLEdBQVo7QUFDQXBDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZN1AsRUFBWjtBQUNBNFAsV0FBTyxDQUFDQyxHQUFSLENBQVluTCxLQUFaO0FBQ0E7O0FBQ0F5USxZQUFVLENBQUVuVixFQUFGLEVBQU07QUFFaEIwQixVQUFNLENBQUN5UyxLQUFQLENBQWFqRCxNQUFiLENBQW9CbFIsRUFBcEI7QUFFQSxXQUFPQSxFQUFQO0FBQ0E7O0FBblBGLEM7Ozs7Ozs7Ozs7O0FDUkE1QixNQUFNLENBQUN1UyxNQUFQLENBQWM7QUFBQ0UsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkN6UyxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQkFBWjs7QUFHM0MsSUFBSStXLElBQUksR0FBR3ZPLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosRUFBNkJzTyxJQUF4Qzs7QUFDQSxJQUFJQyxLQUFLLEdBQUd4TyxHQUFHLENBQUNDLE9BQUosQ0FBWSxRQUFaLENBQVo7O0FBQ0EsSUFBSWtLLE1BQU0sR0FBR25LLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosQ0FBYjs7QUFDQSxJQUFJRixFQUFFLEdBQUdDLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLElBQVosQ0FBVDs7QUFDQSxNQUFNeEQsS0FBSyxHQUFHdUQsR0FBRyxDQUFDQyxPQUFKLENBQVksWUFBWixDQUFkOztBQUVPLE1BQU0rSixVQUFOLENBQWlCO0FBRWxCeUUsYUFBTixDQUFrQnZSLE9BQWxCLEVBQTBCL0QsRUFBMUI7QUFBQSxvQ0FDQTtBQUNDLFlBQU11VixJQUFJLEdBQUd6TyxPQUFPLENBQUMsTUFBRCxDQUFwQjs7QUFDQSxVQUFJWixJQUFJLEdBQUMsaURBQStDbEcsRUFBL0MsR0FBa0QsR0FBbEQsR0FBc0QrRCxPQUEvRDtBQUNELFlBQU15UixJQUFJLEdBQUc1TyxFQUFFLENBQUM2TyxpQkFBSCxDQUFxQjFSLE9BQXJCLENBQWI7QUFDQSxZQUFNaUQsUUFBUSxpQkFBUzFELEtBQUssQ0FBQzRDLElBQUQsQ0FBZCxDQUFkO0FBQ0UsWUFBTWlCLElBQUksaUJBQVNILFFBQVEsQ0FBQzBPLE1BQVQsRUFBVCxDQUFWO0FBQ0MxVyxjQUFRLENBQUMyVyxLQUFULENBQWV4TyxJQUFmLEVBQXFCO0FBQ2xCeU8sZ0JBQVEsRUFBRTdSLE9BRFE7QUFFbEI4UixjQUFNLEVBQUU3VixFQUZVLENBRU47O0FBRk0sT0FBckIsRUFHSSxVQUFVOFYsVUFBVixFQUFzQkMsT0FBdEIsRUFBK0I7QUFDaEMsWUFBSUQsVUFBSixFQUFnQjtBQUNkLGdCQUFNQSxVQUFOO0FBQ0QsU0FGRCxNQUVPO0FBQ05uWCxrQkFBUSxDQUFDb0csTUFBVCxDQUFnQjtBQUFDNUMsZUFBRyxFQUFDbkM7QUFBTCxXQUFoQixFQUF5QjtBQUFDNFUsZ0JBQUksRUFBQztBQUFDalMseUJBQVcsRUFBQ29ULE9BQU8sQ0FBQzVUO0FBQXJCO0FBQU4sV0FBekI7QUFDQ3lOLGlCQUFPLENBQUNDLEdBQVIsQ0FBWWtHLE9BQU8sQ0FBQ3BPLElBQVIsR0FBZSxxQ0FBZixHQUF1RG9PLE9BQU8sQ0FBQzVULEdBQTNFO0FBQ0Q7QUFDRixPQVZGLEVBTkgsQ0FpQkE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0MsS0E1Q0Q7QUFBQTs7QUE2Q01nUCxnQkFBTixDQUFxQkcsSUFBckI7QUFBQSxvQ0FBMEI7QUFFMUIsVUFBSXBMLElBQUksR0FBQyw4Q0FBVCxDQUYwQixDQUcxQjtBQUNBOztBQUNBLFVBQUlJLENBQUMsR0FBQzlILFFBQVEsQ0FBQytILE9BQVQsQ0FBaUI7QUFBQzdCLGFBQUssRUFBRTtBQUFSLE9BQWpCLEVBQXNEQyxLQUF0RCxDQUE0RHFJLEtBQTVELENBQWtFLEdBQWxFLENBQU47QUFDQSxVQUFJZ0osS0FBSyxHQUFDMVAsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFLLENBQWY7QUFDQSxVQUFJMlAsS0FBSyxHQUFDM1AsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFLLENBQWY7QUFDQSxVQUFJNFAsZ0JBQWdCLEdBQUMsQ0FBckI7QUFDQXRHLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVVtRyxLQUFWLEdBQWdCLFNBQWhCLEdBQTBCQyxLQUF0Qzs7QUFDQSxXQUFLLElBQUloVSxDQUFDLEdBQUcrVCxLQUFiLEVBQW9CL1QsQ0FBQyxHQUFHZ1UsS0FBeEIsRUFBK0JoVSxDQUFDLEVBQWhDLEVBQW9DO0FBQ25DLFlBQUk2RyxHQUFHLGlCQUFPbkssUUFBUSxDQUFDNEgsT0FBVCxDQUFpQjtBQUFDcEUsYUFBRyxFQUFFRixDQUFDLEdBQUM7QUFBUixTQUFqQixDQUFQLENBQVA7O0FBQ0EsWUFBRzZHLEdBQUgsRUFBTztBQUNOb04sMEJBQWdCO0FBQ2hCLGNBQUluUyxPQUFPLEdBQUM5QixDQUFDLEdBQUMsUUFBZDtBQUNBLHdCQUFNLEtBQUtxVCxXQUFMLENBQWlCdlIsT0FBakIsRUFBeUI5QixDQUFDLEdBQUMsRUFBM0IsQ0FBTjtBQUVBO0FBRUQ7O0FBQ0RxUCxVQUFJLENBQUM2RSxNQUFMLENBQVlELGdCQUFnQixHQUFFLG1CQUE5QixFQXBCMEIsQ0FxQnpCO0FBQ0MsS0F0QkY7QUFBQTs7QUEvQ3dCLEM7Ozs7Ozs7Ozs7O0FDVHhCeFUsTUFBTSxDQUFDMFUsZ0JBQVAsQ0FBd0IsaUJBQXhCLEVBQTJDLFVBQVVDLFNBQVYsRUFBcUJDLEdBQXJCLEVBQTBCQyxNQUExQixFQUFrQztBQUMzRTtBQUNBO0FBQ0E7QUFFQTtBQUVBLFNBQU87QUFDTGxULFFBQUksRUFBRSxZQUFZO0FBQ2hCO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFJbVQsR0FBRyxHQUFDL0csVUFBVSxDQUFDLFVBQUQsQ0FBbEI7O0FBRUEsVUFBRytHLEdBQUgsRUFBTztBQUVMLFlBQUdBLEdBQUcsQ0FBQ0MsY0FBSixDQUFtQixhQUFuQixDQUFILEVBQXFDO0FBRW5DLGNBQUdELEdBQUcsQ0FBQ3JHLFdBQVAsRUFBbUI7QUFDakJQLG1CQUFPLENBQUNDLEdBQVIsQ0FBWW5PLE1BQU0sQ0FBQ2dFLElBQVAsR0FBY3ZELEdBQTFCO0FBQ0EsbUJBQU94RCxRQUFRLENBQUMwRSxJQUFULENBQWM7QUFBQ2xCLGlCQUFHLEVBQUU7QUFBQ3VVLG1CQUFHLEVBQUVKO0FBQU47QUFBTixhQUFkLEVBQWlDO0FBQUM3VSx1QkFBUyxFQUFDO0FBQVgsYUFBakMsQ0FBUDtBQUNEO0FBQ0Y7O0FBRUQsZUFBTyxFQUFQO0FBQ0Q7O0FBQ0QsYUFBTyxFQUFQO0FBRUQsS0F4Qkk7QUF5QkxrVixZQUFRLEVBQUUsQ0FDUjtBQUNFdFQsVUFBSSxFQUFFLFVBQVN1VCxRQUFULEVBQW1CO0FBQ3ZCO0FBQ0E7QUFDQSxlQUFPbFYsTUFBTSxDQUFDeVMsS0FBUCxDQUFhOVEsSUFBYixDQUFrQjtBQUFDbEIsYUFBRyxFQUFFeVUsUUFBUSxDQUFDQztBQUFmLFNBQWxCLEVBQTBDO0FBQUNDLGVBQUssRUFBRSxDQUFSO0FBQVdQLGdCQUFNLEVBQUU7QUFBQ1Esa0JBQU0sRUFBRTtBQUFULFdBQW5CO0FBQWdDQyxjQUFJLEVBQUU7QUFBQzdVLGVBQUcsRUFBRTtBQUFOO0FBQXRDLFNBQTFDLENBQVA7QUFDRDtBQUxILEtBRFE7QUF6QkwsR0FBUDtBQW1DRCxDQTFDRCxFOzs7Ozs7Ozs7Ozs7QUNBQTdDLFFBQU0sQ0FBQ3NLLFNBQVAsQ0FBaUJDLElBQWpCLEdBQXdCLFVBQVNDLFNBQVQsRUFBb0JDLE1BQXBCLEVBQTRCO0FBQ2hELFFBQUlDLEdBQUcsR0FBRyxJQUFWOztBQUNBLFdBQU9BLEdBQUcsQ0FBQ0QsTUFBSixHQUFhQSxNQUFwQixFQUNJQyxHQUFHLEdBQUdGLFNBQVMsR0FBR0UsR0FBbEI7O0FBQ0osV0FBT0EsR0FBUDtBQUNILEdBTEQ7O0FBT0FpTixnQkFBYyxHQUFDLEVBQWY7O0FBQ0F4SixtQkFBaUIsR0FBQyxVQUFTQyxRQUFULEVBQWtCQyxRQUFsQixFQUEyQjtBQUM1QyxRQUFJQyxJQUFJLEdBQUNDLFlBQVksQ0FBQ0gsUUFBRCxFQUFVQyxRQUFWLENBQXJCO0FBQ0EsUUFBSUcsS0FBSyxHQUFDRixJQUFJLEtBQUcsY0FBUCxHQUFzQixjQUF0QixHQUFxQyxXQUEvQztBQUNDLFFBQUdBLElBQUksS0FBRyxRQUFWLEVBQW1CRSxLQUFLLEdBQUMsYUFBTjtBQUNwQixXQUFPQSxLQUFQO0FBQ0EsR0FMRDs7QUFNQU8sY0FBWSxHQUFDLFVBQVNYLFFBQVQsRUFBa0I7QUFDOUIsUUFBSTRDLFVBQVUsR0FBQyxJQUFJOVAsSUFBSixDQUFTa04sUUFBVCxDQUFmO0FBQ0UsUUFBSTZDLEtBQUssR0FBQyxJQUFJL1AsSUFBSixFQUFWO0FBQ0QsUUFBSWlPLElBQUksR0FBQzhCLEtBQUssQ0FBQ2xILFdBQU4sS0FBb0JpSCxVQUFVLENBQUNqSCxXQUFYLEVBQTdCO0FBQ0MsV0FBT29GLElBQVA7QUFDRixHQUxEOztBQU1BWixjQUFZLEdBQUMsVUFBU0gsUUFBVCxFQUFrQkMsUUFBbEIsRUFBMkI7QUFDdEMsUUFBSTJDLFVBQVUsR0FBQyxJQUFJOVAsSUFBSixDQUFTa04sUUFBVCxDQUFmO0FBQ0MsUUFBSTZDLEtBQUssR0FBQyxJQUFJL1AsSUFBSixFQUFWO0FBQ0QsUUFBSWlPLElBQUksR0FBQzhCLEtBQUssQ0FBQ2xILFdBQU4sS0FBb0JpSCxVQUFVLENBQUNqSCxXQUFYLEVBQTdCO0FBQ0QsUUFBR3NFLFFBQUgsRUFBWSxPQUFPLFFBQVA7QUFDVixXQUFPYyxJQUFJLEdBQUN3SSxjQUFMLEdBQW9CLGNBQXBCLEdBQW1DLFdBQTFDO0FBQ0YsR0FORDs7QUFPQXZJLGlCQUFlLEdBQUMsVUFBU0MsT0FBVCxFQUNoQjtBQUNFLFFBQUlDLGlCQUFpQixHQUFDcFEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsQ0FBdEI7QUFDRSxRQUFJbUssY0FBYyxHQUFDclEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsQ0FBbkI7QUFDQSxRQUFJb0ssV0FBVyxHQUFDdFEsUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsV0FBSyxFQUFDO0FBQVAsS0FBakIsQ0FBaEI7QUFFRixRQUFJcUssS0FBSyxHQUFDQyxNQUFNLENBQUN6SSxPQUFQLENBQWU7QUFBQ3BFLFNBQUcsRUFBQ3dNO0FBQUwsS0FBZixDQUFWO0FBQ0EsUUFBSTJCLFVBQVUsR0FBQyxJQUFJOVAsSUFBSixDQUFTdU8sS0FBSyxDQUFDRSxlQUFmLENBQWY7QUFDQSxRQUFJc0IsS0FBSyxHQUFDLElBQUkvUCxJQUFKLEVBQVY7QUFDQSxRQUFJaU8sSUFBSSxHQUFDOEIsS0FBSyxDQUFDbEgsV0FBTixLQUFvQmlILFVBQVUsQ0FBQ2pILFdBQVgsRUFBN0I7QUFFQSxRQUFHMEYsS0FBSyxDQUFDcEIsUUFBVCxFQUFrQixPQUFPbUIsV0FBVyxDQUFDbkssS0FBbkI7QUFDbEIsUUFBRzhKLElBQUksR0FBQ3dJLGNBQVIsRUFBd0IsT0FBT3JJLGlCQUFpQixDQUFDakssS0FBekI7QUFDeEIsV0FBT2tLLGNBQWMsQ0FBQ2xLLEtBQXRCO0FBQ0QsR0FkRDs7QUFlQXZHLFFBQU0sQ0FBQytRLE9BQVAsR0FBZXRCLFlBQWY7Ozs7Ozs7Ozs7OztBQzFDQSxJQUFJbk0sTUFBSjtBQUFXdEQsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDcUQsUUFBTSxDQUFDcEQsQ0FBRCxFQUFHO0FBQUNvRCxVQUFNLEdBQUNwRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFERixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWjtBQUE4QixJQUFJdVMsU0FBSjtBQUFjeFMsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ3VTLFdBQVMsQ0FBQ3RTLENBQUQsRUFBRztBQUFDc1MsYUFBUyxHQUFDdFMsQ0FBVjtBQUFZOztBQUExQixDQUE3QixFQUF5RCxDQUF6RDs7QUFJMUcsTUFBTTRZLFVBQVUsR0FBR3BRLE9BQU8sQ0FBQyxhQUFELENBQTFCLEMsQ0FDRjtBQUNBOzs7QUFFQSxJQUFJcVEsTUFBTSxHQUFDM1ksUUFBUSxDQUFDK0gsT0FBVCxDQUFpQjtBQUFDN0IsT0FBSyxFQUFDO0FBQVAsQ0FBakIsQ0FBWDtBQUNBLElBQUkwUyxTQUFTLEdBQUNELE1BQU0sR0FBQ0EsTUFBTSxDQUFDeFMsS0FBUixHQUFjLEVBQWxDO0FBRUE2TSxPQUFPLENBQUM2RixHQUFSLENBQVlDLFFBQVosR0FBcUJGLFNBQXJCLEMsQ0FFQTs7QUFDQ0csVUFBVSxHQUFDLFFBQVg7QUFDREMsVUFBVSxHQUFDLE9BQVgsQyxDQUNDOztBQUNEakwsU0FBUyxHQUFDLFVBQVNDLEdBQVQsRUFDVjtBQUNFLE1BQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxPQUFQO0FBQ1YsTUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLFNBQVA7QUFDVixNQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sT0FBUDtBQUNWLE1BQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxPQUFQO0FBQ1YsTUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLE1BQVA7QUFDVixNQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sT0FBUDtBQUNWLE1BQUdBLEdBQUcsSUFBRSxDQUFSLEVBQVUsT0FBTyxPQUFQO0FBQ1YsTUFBR0EsR0FBRyxJQUFFLENBQVIsRUFBVSxPQUFPLFFBQVA7QUFDVixNQUFHQSxHQUFHLElBQUUsQ0FBUixFQUFVLE9BQU8sV0FBUDtBQUNWLE1BQUdBLEdBQUcsSUFBRSxFQUFSLEVBQVcsT0FBTyxTQUFQO0FBQ1gsTUFBR0EsR0FBRyxJQUFFLEVBQVIsRUFBVyxPQUFPLFdBQVA7QUFDWCxNQUFHQSxHQUFHLElBQUUsRUFBUixFQUFXLE9BQU8sV0FBUDtBQUNYLFNBQU8sS0FBUDtBQUNELENBZkQ7O0FBZ0JBLElBQUlpTCxDQUFDLEdBQUMsSUFBSTdHLFNBQUosRUFBTjtBQUVBbFAsTUFBTSxDQUFDZ1csT0FBUCxDQUFlO0FBQ2Isc0JBQW1CRCxDQUFDLENBQUNyRyxnQkFEUjtBQUViLHNCQUFtQnFHLENBQUMsQ0FBQ3BHLGdCQUZSO0FBR2Isc0JBQW1Cb0csQ0FBQyxDQUFDdEYsZ0JBSFI7QUFJYixpQkFBY3NGLENBQUMsQ0FBQ3hHLFdBSkg7QUFLYixzQkFBbUJ3RyxDQUFDLENBQUNsRSxnQkFMUjtBQU1iLDRCQUF5QmtFLENBQUMsQ0FBQ2hFLHNCQU5kO0FBT2Isd0JBQXFCZ0UsQ0FBQyxDQUFDN0Qsa0JBUFY7QUFRZCw4QkFBMkI2RCxDQUFDLENBQUM5RCx3QkFSZjtBQVNiLGdDQUE2QjhELENBQUMsQ0FBQ0UsMEJBVGxCO0FBVWQsZUFBYUYsQ0FBQyxDQUFDdkQsU0FWRDtBQVdkLGdCQUFjdUQsQ0FBQyxDQUFDNUMsVUFYRjtBQVliLGdCQUFhNEMsQ0FBQyxDQUFDL0MsVUFaRjtBQWFkLGNBQVcrQyxDQUFDLENBQUMxQyxRQWJDO0FBY2Qsb0JBQWtCMEMsQ0FBQyxDQUFDekMsY0FkTjtBQWVkLGdCQUFheUMsQ0FBQyxDQUFDdEMsVUFmRDtBQWdCYixzQkFBbUJzQyxDQUFDLENBQUN2RjtBQWhCUixDQUFmO0FBbUJBeFEsTUFBTSxDQUFDa1csT0FBUCxDQUFlLE1BQU07QUFFbEJsVyxRQUFNLENBQUNtVyxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFVO0FBQ3BDLFdBQU9yWixRQUFRLENBQUM2RSxJQUFULEVBQVA7QUFDSCxHQUZFO0FBSUEzQixRQUFNLENBQUNtVyxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFVO0FBQ3BDLFdBQU96SCxrQkFBa0IsQ0FBQyxVQUFELENBQXpCO0FBQ0gsR0FGRTtBQUdDMU8sUUFBTSxDQUFDbVcsT0FBUCxDQUFlLGlCQUFmLEVBQWtDLFlBQVU7QUFDNUMsV0FBT3pILGtCQUFrQixDQUFDLGlCQUFELENBQXpCO0FBQ0gsR0FGRztBQUdFMU8sUUFBTSxDQUFDbVcsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBVTtBQUN2QyxXQUFPN1ksUUFBUSxDQUFDcUUsSUFBVCxFQUFQO0FBQ0gsR0FGSztBQUlFM0IsUUFBTSxDQUFDbVcsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBVTtBQUN4QyxXQUFPekgsa0JBQWtCLENBQUMsVUFBRCxDQUF6QjtBQUNKLEdBRk87QUFHRTFPLFFBQU0sQ0FBQ21XLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxZQUFVO0FBQ2hELFdBQU96SCxrQkFBa0IsQ0FBQyx1QkFBRCxDQUF6QjtBQUVYLEdBSFM7QUFJQzFPLFFBQU0sQ0FBQ21XLE9BQVAsQ0FBZSxjQUFmLEVBQStCLFlBQVU7QUFDaEQsV0FBTzlZLFlBQVksQ0FBQ3NFLElBQWIsRUFBUDtBQUNILEdBRlU7QUFNVixDQTdCRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuXG5pbXBvcnQgeyBGaWxlc0NvbGxlY3Rpb24gfSBmcm9tICdtZXRlb3Ivb3N0cmlvOmZpbGVzJztcblNldHRpbmdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NldHRpbmdzJyk7XG5BbmNsYWplcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbmNsYWplcycpO1xuQW5jbGFqZXNFcXVpcG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2FuY2xhamVzRXF1aXBvcycpO1xuUGVyc29uYWwgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGVyc29uYWwnKTtcblBlcnNvbmFsTGlxdWlkYWNpb25lcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwZXJzb25hbExpcXVpZGFjaW9uZXMnKTtcblRpcG9QZXJmaWxlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0aXBvUGVyZmlsZXMnKTtcbkFyY2hpdm9zID0gbmV3IEZpbGVzQ29sbGVjdGlvbih7Y29sbGVjdGlvbk5hbWU6ICdBcmNoaXZvcyd9KTtcbi8vIGV4cG9ydCBkZWZhdWx0IEFyY2hpdm9zOyBcbi8vIEFyY2hpdm9zID0gbmV3IEZTLkNvbGxlY3Rpb24oXCJhcmNoaXZvc1wiLCB7XG4vLyAgIHN0b3JlczogW25ldyBGUy5TdG9yZS5GaWxlU3lzdGVtKFwiYXJjaGl2b3NcIiwge3BhdGg6IFwiL3Zhci93d3cvdXBsb2Fkc1wifSldXG4vLyB9KTtcbi8vIEFyY2hpdm9zLmFsbG93KHtcbi8vICBpbnNlcnQ6IGZ1bmN0aW9uKCl7XG4vLyAgcmV0dXJuIHRydWU7XG4vLyAgfSxcbi8vICB1cGRhdGU6IGZ1bmN0aW9uKCl7XG4vLyAgcmV0dXJuIHRydWU7XG4vLyAgfSxcbi8vICByZW1vdmU6IGZ1bmN0aW9uKCl7XG4vLyAgcmV0dXJuIHRydWU7XG4vLyAgfSxcbi8vICBkb3dubG9hZDogZnVuY3Rpb24oKXtcbi8vICByZXR1cm4gdHJ1ZTtcbi8vICB9XG4vLyB9KTtcblRpcG9QZXJmaWxlcy5hdHRhY2hTY2hlbWEobmV3IFNpbXBsZVNjaGVtYSh7XG4gIG5vbWJyZVBlcmZpbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJOb21icmUgUGVyZmlsXCIsXG4gIH0sXG4gICBlc0FkbWluaXN0cmFkb3I6IHtcbiAgICB0eXBlOiBCb29sZWFuLFxuICAgIGxhYmVsOiBcIkVzIGFkbWluaXN0cmFkb3I/XCIsXG4gICAgYXV0b2Zvcm06eyB0eXBlOlwiYm9vbGVhbi1jaGVja2JveFwiIH0sXG4gIH0sXG5cbiAgbW9kdWxvc0FjY2Vzbzoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGxhYmVsOiAnTW9kdWxvcyBkZSBBY2Nlc28nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIFwibW9kdWxvc0FjY2Vzby4kXCI6e1xuICAgIHR5cGU6T2JqZWN0LFxuICB9LFxuICAgXCJtb2R1bG9zQWNjZXNvLiQuX2lkXCI6e1xuXG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGF1dG9mb3JtOntcbiAgICAgIHR5cGU6XCJoaWRkZW5cIlxuICAgIH0sXG4gICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBSYW5kb20uaWQoKTtcbiAgICB9XG4gXG4gIH0sXG4gICBcIm1vZHVsb3NBY2Nlc28uJC5zb2xvVmVyTWlvc1wiOntcblxuICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgYXV0b2Zvcm06e1xuICAgICAgdHlwZTpcImJvb2xlYW4tY2hlY2tib3hcIlxuICAgIH0sXG4gICAgb3B0aW9uYWw6dHJ1ZVxuIFxuICB9LFxuICBcIm1vZHVsb3NBY2Nlc28uJC5ub21icmVcIjp7XG5cbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6XCJOb21icmUgTW9kdWxvIFthY2Npb25lc11cIlxuIFxuICB9LFxuXG4gXG4gXG59KSk7XG5cblxuXG5QZXJzb25hbExpcXVpZGFjaW9uZXMuYXR0YWNoU2NoZW1hKG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgaG9yYXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0hvcmFzJyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBcImhvcmFzLiRcIjp7XG4gICAgdHlwZTpPYmplY3QsXG4gIH0sXG4gICBcImhvcmFzLiQuX2lkXCI6e1xuXG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gUmFuZG9tLmlkKCk7XG4gICAgfVxuIFxuICB9LFxuICAgXCJob3Jhcy4kLmRpYVwiOntcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgb3B0aW9uYWw6dHJ1ZSxcbiAgICBsYWJlbDpcIkTDrWFcIixcbiAgICBhdXRvZm9ybToge1xuICAgICAgc3R5bGU6XCJ3aWR0aDo2MHB4XCJcbiAgICAgIH0sXG4gXG4gIH0sXG4gIFwiaG9yYXMuJC52aWFuZGFzXCI6e1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBvcHRpb25hbDp0cnVlLFxuICAgIGF1dG9mb3JtOiB7XG4gICAgICBzdHlsZTpcIndpZHRoOjYwcHhcIlxuICAgICAgfSxcbiBcbiAgfSxcbiAgXCJob3Jhcy4kLmNhbnRpZGFkXCI6e1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBvcHRpb25hbDpmYWxzZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgc3R5bGU6XCJ3aWR0aDo2MHB4XCJcbiAgICAgIH0sXG4gXG4gIH0sXG4gIFwiaG9yYXMuJC5pZFBlcnNvbmFsXCI6e1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDpmYWxzZSxcbiAgICBsYWJlbDpcIlBlcnNvbmFsXCIsXG4gICAgYXV0b2Zvcm06IHtcbiAgICAgIHR5cGU6XCJoaWRkZW5cIixcbiAgICAgIHN0eWxlOlwid2lkdGg6NjBweFwiXG4gICAgICB9LFxuIFxuICB9LFxuICAgXCJob3Jhcy4kLnRpcG9Ib3JhXCI6e1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDp0cnVlLFxuICAgIGxhYmVsOlwiVGlwbyBkZSBIb3JhXCIsXG4gICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInNlbGVjdDJcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6ICdTZWxlY2Npb25lLi4uJyxcbiAgICAgICAgc3R5bGU6IFwid2lkdGg6MTIwcHhcIixcbiAgICAgICAgb3B0aW9uczogW1xuXG4gICAgICAgICAgICB7bGFiZWw6IFwiTk9STUFMXCIsIHZhbHVlOiBcIk5PUk1BTFwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJBTCA1MCVcIiwgdmFsdWU6IFwiQUwgNTAlXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIkFMIDEwMCVcIiwgdmFsdWU6IFwiQUwgMTAwJVwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCI1MCUgTk9DVC5cIiwgdmFsdWU6IFwiNTAlIE5PQ1QuXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIjEwMCUgTk9DVFwiLCB2YWx1ZTogXCIxMDAlIE5PQ1RcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiRkVSSUFET1wiLCB2YWx1ZTogXCJGRVJJQURPXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIkVTUEVDSUFMXCIsIHZhbHVlOiBcIkVTUEVDSUFMXCJ9LFxuXG5cbiAgICAgIF1cbiAgICB9XG4gXG4gIH0sXG4gIGZlY2hhRGVzZGU6IHtcbiAgICB0eXBlOiBEYXRlLFxuICAgIGxhYmVsOiBcIkRlc2RlXCIsXG4gIH0sXG4gIGZlY2hhSGFzdGE6IHtcbiAgICB0eXBlOiBEYXRlLFxuICAgIGxhYmVsOiBcIkhhc3RhXCIsXG4gIH0sXG4gIHRpcG9QZXJzb25hbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJUaXBvIFBlcnNvbmFsXCIsXG4gICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInNlbGVjdDJcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6ICdUSVBPIFBFUlNPTkFMJyxcbiAgICAgICAgc3R5bGU6IFwid2lkdGg6MjIwcHhcIixcbiAgICAgICAgb3B0aW9uczogW1xuXG4gICAgICAgICAgICB7bGFiZWw6IFwiVU9DUkFcIiwgdmFsdWU6IFwiVU9DUkFcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiRlVFUkEgQ09OVkVOSU9cIiwgdmFsdWU6IFwiRlVFUkEgQ09OVkVOSU9cIn0sXG4gICAgICBdXG4gICAgfVxuICB9LFxuICAgZXN0YWRvOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiBcIkVzdGFkb1wiLFxuICAgIGF1dG9mb3JtOiB7XG4gICAgICAgdHlwZTogXCJzZWxlY3QyXCIsXG4gICAgICAgIHBsYWNlaG9sZGVyOiAnRXN0YWRvJyxcbiAgICAgICAgc3R5bGU6IFwid2lkdGg6MjIwcHhcIixcbiAgICAgICAgb3B0aW9uczogW1xuXG4gICAgICAgICAgICB7bGFiZWw6IFwiUEVORElFTlRFXCIsIHZhbHVlOiBcIlBFTkRJRU5URVwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJDQU5DRUxBRE9cIiwgdmFsdWU6IFwiQ0FOQ0VMQURPXCJ9LFxuICAgICAgXVxuICAgIH1cbiAgfSxcbn0pIClcblxuUGVyc29uYWwuYXR0YWNoU2NoZW1hKG5ldyBTaW1wbGVTY2hlbWEoe1xuICBhY2NpZGVudGVzOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdBY2NpZGVudGVzJyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBcImFjY2lkZW50ZXMuJFwiOntcbiAgICB0eXBlOk9iamVjdCxcbiAgfSxcbiAgIFwiYWNjaWRlbnRlcy4kLl9pZFwiOntcblxuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIFJhbmRvbS5pZCgpOyAgXG4gICAgfVxuIFxuICB9LFxuICBcImFjY2lkZW50ZXMuJC5mZWNoYUFjY2lkZW50ZVwiOiB7XG4gICAgdHlwZTogRGF0ZSxcbiAgICBsYWJlbDogXCJGZWNoYSBBY2NpZGVudGVcIixcbiAgICBhdXRvZm9ybTp7XG4gICAgICAgc3R5bGU6XCJmb250LXNpemU6OXB4O3RleHQtaW5kZW50OjAuNXB4XCIsXG4gICAgfVxuICB9LFxuICBcImFjY2lkZW50ZXMuJC5mZWNoYURlbnVuY3VhXCI6IHtcbiAgICB0eXBlOiBEYXRlLFxuICAgIGxhYmVsOiBcIkZlY2hhIERlbnVuY2lhXCIsXG4gICAgIGF1dG9mb3JtOntcbiAgICAgIHN0eWxlOlwiZm9udC1zaXplOjlweDt0ZXh0LWluZGVudDowLjVweFwiLFxuXG4gICAgfVxuICB9LFxuICBcImFjY2lkZW50ZXMuJC5mZWNoYUFsdGFcIjoge1xuICAgIHR5cGU6IERhdGUsXG4gICAgbGFiZWw6IFwiRmVjaGEgQWx0YVwiLFxuICAgICBhdXRvZm9ybTp7XG4gICAgICAgc3R5bGU6XCJmb250LXNpemU6OXB4O3RleHQtaW5kZW50OjAuNXB4XCIsXG4gICAgfVxuICB9LFxuICBcImFjY2lkZW50ZXMuJC5jb21lbnRhcmlvXCI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6dHJ1ZSxcbiAgICBsYWJlbDogXCJDb21lbnRhcmlvc1wiLFxuICAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwidGV4dGFyZWFcIixcbiAgICAgfVxuICB9LFxuICBhcGVsbGlkbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJBcGVsbGlkb1wiLFxuICB9LFxuICBub21icmU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiTm9tYnJlXCIsXG4gIH0sXG4gIG5yb0xlZ2Fqbzoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICB1bmlxdWU6dHJ1ZSxcbiAgICBsYWJlbDogXCJOcm8gTGVnYWpvXCIsXG4gIH0sXG4gIGN1aWw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiQ1VJTFwiLFxuICB9LFxuICB0aXBvUGVyc29uYWw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiVGlwbyBQZXJzb25hbFwiLFxuICAgIGF1dG9mb3JtOiB7XG4gICAgICAgdHlwZTogXCJzZWxlY3QyXCIsXG4gICAgICAgIHBsYWNlaG9sZGVyOiAnVElQTyBQRVJTT05BTCcsXG4gICAgICAgIHN0eWxlOiBcIndpZHRoOjE0MHB4XCIsXG4gICAgICAgIG9wdGlvbnM6IFtcblxuICAgICAgICAgICAge2xhYmVsOiBcIlVPQ1JBXCIsIHZhbHVlOiBcIlVPQ1JBXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIkZVRVJBIENPTlZFTklPXCIsIHZhbHVlOiBcIkZVRVJBIENPTlZFTklPXCJ9LFxuICAgICAgXVxuICAgIH1cbiAgfSxcblxuICBvYnJhU29jaWFsOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiBcIk9icmEgU29jaWFsXCIsXG4gIH0sXG4gIHN1ZWxkbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJTdWVsZG9cIixcbiAgfSxcbiAgY2VudHJvQ29zdG86IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiQ0NcIixcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0MlwiLFxuICAgICAgICBwbGFjZWhvbGRlcjogJ0NDJyxcbiAgICAgICAgc3R5bGU6IFwid2lkdGg6ODBweFwiLFxuICAgICAgICBvcHRpb25zOiBbXG5cbiAgICAgICAgICAgIHtsYWJlbDogXCIxMDBcIiwgdmFsdWU6IFwiMTAwXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIjEwMVwiLCB2YWx1ZTogXCIxMDFcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiMjAwXCIsIHZhbHVlOiBcIjIwMFwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCIzMDBcIiwgdmFsdWU6IFwiMzAwXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIjUwMFwiLCB2YWx1ZTogXCI1MDBcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiNjAwXCIsIHZhbHVlOiBcIjYwMFwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCI2MDFcIiwgdmFsdWU6IFwiNjAxXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIjYwM1wiLCB2YWx1ZTogXCI2MDNcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiNzAwXCIsIHZhbHVlOiBcIjcwMFwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCI3MDFcIiwgdmFsdWU6IFwiNzAxXCJ9LFxuICAgICAgXVxuICAgIH1cbiAgfSxcbiAgY2F0ZWdvcmlhOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiBcIkNhY3RlZ29yaWFcIixcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0MlwiLFxuICAgICAgICBwbGFjZWhvbGRlcjogJ0NhdGVnb3JpYScsXG4gICAgICAgIHN0eWxlOiBcIndpZHRoOjE2MHB4XCIsXG4gICAgICAgIG9wdGlvbnM6IFtcblxuICAgICAgICAgICAge2xhYmVsOiBcIkFZVURBTlRFXCIsIHZhbHVlOiBcIkFZVURBTlRFXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIk1FRElPIE9GSUNJQUxcIiwgdmFsdWU6IFwiTUVESU8gT0ZJQ0lBTFwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJPRklDSUFMXCIsIHZhbHVlOiBcIk9GSUNJQUxcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiT0ZJQ0lBTCBFU1BFQ0lBTFwiLCB2YWx1ZTogXCJPRklDSUFMIEVTUEVDSUFMXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIlNFUkVOT1wiLCB2YWx1ZTogXCJTRVJFTk9cIn0sXG4gICAgICBdXG4gICAgfVxuICB9LFxuICBmZWNoYUV4YW1lbjoge1xuICAgIHR5cGU6IERhdGUsXG4gICAgbGFiZWw6IFwiRXjDoW1lbiBQcmVvYy5cIixcbiAgICBvcHRpb25hbDp0cnVlXG4gIH0sXG4gIGVzdGFkbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJFc3RhZG9cIixcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0MlwiLFxuICAgICAgICBwbGFjZWhvbGRlcjogJ0VzdGFkbycsXG4gICAgICAgIHN0eWxlOiBcIndpZHRoOjE2MHB4XCIsXG4gICAgICAgIG9wdGlvbnM6IFtcblxuICAgICAgICAgICAge2xhYmVsOiBcIkFMVEFcIiwgdmFsdWU6IFwiQUxUQVwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJCQUpBXCIsIHZhbHVlOiBcIkJBSkFcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiU1VTUEVORElET1wiLCB2YWx1ZTogXCJTVVNQRU5ESURPXCJ9LFxuICAgICAgXVxuICAgIH1cbiAgfSxcbn0pKVxuXG5BbmNsYWplc0VxdWlwb3MuYXR0YWNoU2NoZW1hKG5ldyBTaW1wbGVTY2hlbWEoe1xuICBub21icmVFcXVpcG86IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiTm9tYnJlIEVxdWlwb1wiLFxuICB9LFxuICBkZXRhbGxlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnRGV0YWxsZScsXG4gICAgb3B0aW9uYWw6dHJ1ZSxcbiAgICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInRleHRhcmVhXCIsXG4gICAgICAgIHBsYWNlaG9sZGVyOiAnRGV0YWxsZSBwYXJhIGVsIGVxdWlwbyBkZSBlbnNheW8nLFxuICAgICBcbiAgICB9LFxuICB9LFxuICBpZFVzdWFyaW86IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdVc3VhcmlvJyxcbiAgICBvcHRpb25hbDp0cnVlLFxuICAgICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInNlbGVjdDJcIixcbiAgICAgICBvcHRpb25zOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmKE1ldGVvci5pc0NsaWVudClcbiAgICAgICAgcmV0dXJuIF8ubWFwKFNlc3Npb24uZ2V0KFwidXN1YXJpb3NcIiksIGZ1bmN0aW9uIChjLCBpKSB7XG4gICAgICAgICAgcmV0dXJuIHtsYWJlbDogYy51c2VybmFtZSwgdmFsdWU6IGMuX2lkfTtcbiAgICAgICAgfSl9LFxuICAgICAgICBzdHlsZTogXCJ3aWR0aDoyNTBweFwiLFxuICAgICAgfSxcbiAgfSxcbiAgY3JlYXRlZDoge1xuICAgIHR5cGU6IERhdGUsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSB7XG4gICAgICAgIHJldHVybiBuZXcgRGF0ZSgpO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLmlzVXBzZXJ0KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgJHNldE9uSW5zZXJ0OiBuZXcgRGF0ZSgpXG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnVuc2V0KCk7XG4gICAgICB9XG4gICAgfSxcbiAgfSxcbiAgdXBkYXRlZDoge1xuICAgIHR5cGU6IERhdGUsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgIGlmICh0aGlzLmlzVXBkYXRlKSB7XG4gICAgICAgIHJldHVybiBuZXcgRGF0ZSgpO1xuICAgICAgfVxuICAgIH0sXG4gIH0sXG4gXG59KSk7IFxuXG5BbmNsYWplcy5hdHRhY2hTY2hlbWEoIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAvLyB6b25hOiB7XG4gIC8vICAgdHlwZTogU3RyaW5nLFxuICAvLyAgIGxhYmVsOiAnWm9uYScsXG4gIC8vICAgYXV0b2Zvcm06IHtcbiAgLy8gICAgICB0eXBlOiBcInNlbGVjdDJcIixcbiAgLy8gICAgIHBsYWNlaG9sZGVyOiAnU2VsZWNjaW9uZSBab25hJyxcbiAgLy8gICAgIHN0eWxlOiBcIndpZHRoOjgwcHhcIixcbiAgLy8gICAgIG9wdGlvbnM6IFtcbiAgLy8gICAgICAge2xhYmVsOiBcIkFIXCIsIHZhbHVlOiBcIkFIXCJ9LFxuICAvLyAgICAgICAgICAge2xhYmVsOiBcIkJWXCIsIHZhbHVlOiBcIkJWXCJ9LFxuICAvLyAgICAgICAgICAge2xhYmVsOiBcIkNMXCIsIHZhbHVlOiBcIkNMXCJ9LFxuICAvLyAgICAgICAgICAge2xhYmVsOiBcIkNNXCIsIHZhbHVlOiBcIkNNXCJ9LFxuICAvLyAgICAgICAgICAge2xhYmVsOiBcIkNPVlwiLCB2YWx1ZTogXCJDT1ZcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiQ1NcIiwgdmFsdWU6IFwiQ1NcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiQ1dcIiwgdmFsdWU6IFwiQ1dcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiRUNcIiwgdmFsdWU6IFwiRUNcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiRUhcIiwgdmFsdWU6IFwiRUhcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiSFRcIiwgdmFsdWU6IFwiRVRcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiS0tcIiwgdmFsdWU6IFwiS0tcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiTEhcIiwgdmFsdWU6IFwiTEhcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiTUVcIiwgdmFsdWU6IFwiTUVcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiTVNcIiwgdmFsdWU6IFwiTVNcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiTVNBXCIsIHZhbHVlOiBcIk1TQVwifSxcbiAgLy8gICAgICAgICAgIHtsYWJlbDogXCJQQ1wiLCB2YWx1ZTogXCJQQ1wifSxcbiAgLy8gICAgICAgICAgIHtsYWJlbDogXCJQQ1hcIiwgdmFsdWU6IFwiUENYXCJ9LFxuICAvLyAgICAgICAgICAge2xhYmVsOiBcIlNQQ1wiLCB2YWx1ZTogXCJTUENcIn0sXG4gIC8vICAgICAgICAgICB7bGFiZWw6IFwiVFBcIiwgdmFsdWU6IFwiVFBcIn0sXG4gIC8vICAgICBdXG4gIC8vICAgfSxcbiAgLy8gICBtYXg6IDIwMFxuICAvLyB9LFxuICBjZXJ0aWZpY2Fkbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDp0cnVlLFxuICAgIGxhYmVsOlwiQ2VydGlmaWNhZG9cIixcblxuICAgIGF1dG9mb3JtOiB7XG4gICAgICBwbGFjZWhvbGRlcjpcIkNsaWNrIHBhcmEgc2VsZWNjaW9uYXIgZWwgYXJjaGl2byBkZWwgQ0VSVElGSUNBRE8gKHB1ZWRlIGFycmFzdHJhciBhcXXDrSB0YW1iaWVuKS4uLlwiLFxuICAgICAgLy8gYWZGaWVsZElucHV0OiB7XG4gICAgICAvLyAgIHR5cGU6IFwiY2ZzLWZpbGVcIixcbiAgICAgIC8vICAgY29sbGVjdGlvbjogXCJhcmNoaXZvc1wiXG4gICAgICAvLyB9XG4gICAgICAgYWZGaWVsZElucHV0OiB7XG4gICAgICAgIHR5cGU6ICdmaWxlVXBsb2FkJyxcbiAgICAgICAgY29sbGVjdGlvbjogJ0FyY2hpdm9zJyxcbiAgICAgICAgLy8gdXBsb2FkVGVtcGxhdGU6ICd1cGxvYWRGaWVsZCcgLy8gPC0gT3B0aW9uYWxcbiAgICAgICAgLy8gcHJldmlld1RlbXBsYXRlOiAndXBsb2FkUHJldmlldycgLy8gPC0gT3B0aW9uYWxcbiAgICAgIH1cbiAgICB9XG4gIH0sXG5cbiAgIHBvem86IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdQb3pvJ1xuICB9LFxuICBiYXRlcmlhOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnQmF0ZXJpYScsXG4gICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIGlkVXN1YXJpbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1VzdWFyaW8nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIGNlcnRpZmljYWNpb246IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdOcm8gQ2VydC4nXG4gIH0sXG4gIGVxdWlwb0Vuc2F5bzp7XG4gICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDp0cnVlLFxuICAgIGxhYmVsOlwiRXF1aXBvIEVuc2F5b1wiLFxuICAgIGF1dG9mb3JtOiB7XG4gICAgICAgdHlwZTogXCJzZWxlY3QyXCIsXG4gICAgICAgc2VsZWN0Mk9wdGlvbnM6e1xuICAgICAgICAgICBwbGFjZWhvbGRlcjogJ1NlbGVjY2lvbmUuLi4nLFxuICAgICAgICAgd2lkdGg6XCIyMDBweFwiLFxuICAgICAgICAgYWxsb3dDbGVhcjp0cnVlLFxuICAgICAgIH0sXG4gICAgICAgb3B0aW9uczogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXy5tYXAoQW5jbGFqZXNFcXVpcG9zLmZpbmQoKS5mZXRjaCgpLCBmdW5jdGlvbiAoYywgaSkge1xuICAgICAgICAgIHJldHVybiB7bGFiZWw6IGMubm9tYnJlRXF1aXBvLCB2YWx1ZTogYy5faWR9O1xuICAgICAgICB9KX0sXG4gICAgICAgIHN0eWxlOiBcIndpZHRoOjI1MHB4XCIsXG4gICAgICB9LFxuICB9LFxuICAgZXF1aXBvSW5ncmVzYW50ZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ0VxdWlwbyBJbmdyZXNhbnRlJyxcbiAgICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInNlbGVjdDJcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6ICdFcXVpcG8gSW5ncmVzYW50ZScsXG4gICAgICAgIHN0eWxlOiBcIndpZHRoOjEyMHB4XCIsXG4gICAgICAgIG9wdGlvbnM6IFtcblxuICAgICAgICAgICAge2xhYmVsOiBcIlBVTExJTkdcIiwgdmFsdWU6IFwiUFVMTElOR1wifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJEUklMTElOR1wiLCB2YWx1ZTogXCJEUklMTElOR1wifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJXT1JLIE9WRVJcIiwgdmFsdWU6IFwiV09SSyBPVkVSXCJ9LFxuICAgICAgXVxuICAgIH1cbiAgfSxcbiAgZmVjaGFFbnNheW86e1xuICAgIHR5cGU6IERhdGUsXG4gICAgbGFiZWw6ICdGZWNoYSBDb25zdHJ1Y2Npb24nLFxuICAgIG9wdGlvbmFsOnRydWVcbiAgfSxcbiAgIGZlY2hhQ29uc3RydWNjaW9uOntcbiAgICB0eXBlOiBEYXRlLFxuICAgIGxhYmVsOiAnRmVjaGEgRW5zYXlvJyxcbiAgICBvcHRpb25hbDp0cnVlXG4gIH0sXG4gICBob3JhRW5zYXlvOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnSG9yYSBFbnNheW8nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIG51bWVyb0FGRToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ05ybyBBRkUnLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIGNhbnRpZGFkQW5jbGFqZXM6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdDYW50LiBDb25zdHJ1aWRvcycsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgdGlwb0FuY2xhamVzQ29uc3RydWlkb3M6IHtcbiAgICB0eXBlOiBOdW1iZXIsXG4gICAgbGFiZWw6ICdUaXBvIEFuY2xhamUgQ29uc3RydWlkbycsXG4gICAgIGF1dG9mb3JtOiB7XG4gICAgICAgdHlwZTogXCJzZWxlY3QyXCIsXG4gICAgICAgIHBsYWNlaG9sZGVyOiAnVGlwbyBBbmNsYWplIENvbnN0cnVpZG8nLFxuICAgICAgICBzdHlsZTpcIndpZHRoOjMwMHB4XCIsXG4gICAgICAgIG9wdGlvbnM6IFtcblxuICAgICAgICAgICAge2xhYmVsOiBcIlBFUkZPUkFDScOTTlwiLCB2YWx1ZTogXCJQRVJGT1JBQ0nDk05cIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiVEVSTUlOQUNJw5NOXCIsIHZhbHVlOiBcIlRFUk1JTkFDScOTTlwifSxcbiAgICAgIF1cbiAgICB9LFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIG51bWVyb0ZhY3R1cmE6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdOcm8gRmFjdHVyYScsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgYXJjaGl2bzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ0FyY2hpdm8nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgIFxuICB9LFxuICBjb25zdEVuc2F5bzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ2NvbnN0RW5zYXlvJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBcbiAgfSxcbiAgY2FudGlkYWRBbmNsYWplOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnY2FudGlkYWRBbmNsYWplJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBcbiAgfSxcbiAgY29uc3RDb25zdHJ1aWRvOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnY29uc3RDb25zdHJ1aWRvJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBcbiAgfSxcbiAgZXN0YWRvTk86IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdOTycsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgYXV0b2Zvcm06IHtcbiAgICAgICB0eXBlOiBcInNlbGVjdFwiLFxuICAgICAgIGZpcnN0T3B0aW9uOlwiXCIsXG4gICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgIHtsYWJlbDogXCJBXCIsIHZhbHVlOiBcIkFcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiUlwiLCB2YWx1ZTogXCJSXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIlwiLCB2YWx1ZTogXCJcIn0sXG5cbiAgICAgIF1cbiAgICB9LFxuICB9LFxuICBlc3RhZG9ORToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ05FJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0XCIsXG4gICAgICAgZmlyc3RPcHRpb246XCJcIixcbiAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAge2xhYmVsOiBcIkFcIiwgdmFsdWU6IFwiQVwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJSXCIsIHZhbHVlOiBcIlJcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiXCIsIHZhbHVlOiBcIlwifSxcbiAgICAgIF1cbiAgICB9LFxuICB9LFxuICBlc3RhZG9TTzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1NPJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0XCIsXG4gICAgICAgZmlyc3RPcHRpb246XCJcIixcbiAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAge2xhYmVsOiBcIkFcIiwgdmFsdWU6IFwiQVwifSxcbiAgICAgICAgICAgIHtsYWJlbDogXCJSXCIsIHZhbHVlOiBcIlJcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiXCIsIHZhbHVlOiBcIlwifSxcbiAgICAgIF1cbiAgICB9LFxuICB9LFxuICBlc3RhZG9TRToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1NFJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgIHR5cGU6IFwic2VsZWN0XCIsXG4gICAgIGZpcnN0T3B0aW9uOlwiXCIsXG4gICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgIHtsYWJlbDogXCJBXCIsIHZhbHVlOiBcIkFcIn0sXG4gICAgICAgICAgICB7bGFiZWw6IFwiUlwiLCB2YWx1ZTogXCJSXCJ9LFxuICAgICAgICAgICAge2xhYmVsOiBcIlwiLCB2YWx1ZTogXCJcIn0sXG4gICAgICBdXG4gICAgfSxcbiAgfSxcbiAgIG5yb1JlcG9ydGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdOcm8gUmVwb3J0ZScsXG4gICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIFxuICBvYnNlcnZhY2lvbmVzOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgbGFiZWw6ICdPYnNlcnZhY2lvbmVzJyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBcIm9ic2VydmFjaW9uZXMuJFwiOntcbiAgICB0eXBlOk9iamVjdCxcbiAgfSxcbiAgIFwib2JzZXJ2YWNpb25lcy4kLl9pZFwiOntcblxuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIFJhbmRvbS5pZCgpO1xuICAgIH1cbiBcbiAgfSxcbiAgIFwib2JzZXJ2YWNpb25lcy4kLmZlY2hhXCI6e1xuICAgIHR5cGU6IERhdGUsXG4gICAgb3B0aW9uYWw6dHJ1ZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgdHlwZTpcImhpZGRlblwiLFxuICAgICAgfSxcbiBcbiAgfSxcbiAgXCJvYnNlcnZhY2lvbmVzLiQudXN1YXJpb1wiOntcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6dHJ1ZSxcbiAgICBhdXRvZm9ybToge1xuICAgICAgdHlwZTpcImhpZGRlblwiLFxuICAgICAgfSxcbiBcbiAgfSxcbiAgXCJvYnNlcnZhY2lvbmVzLiQuZGV0YWxsZVwiOntcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6XCJPYnNlcnZhY2lvblwiLFxuICAgIC8vIG9wdGlvbmFsOnRydWUsXG4gICAgYXV0b2Zvcm06IHtcbiAgICAgIC8vIHR5cGU6XCJ0ZXh0YXJlYVwiLFxuICAgICAgLy8gc3R5bGU6XCJ3aWR0aDo0NTBweFwiLFxuICAgICAgcGxhY2Vob2xkZXI6XCJEZXNjcmliYSBsYSBvYnNlcnZhY2nDs24uLi5cIlxuICAgICAgfSxcbiBcbiAgfSxcbiAgZXN0YWRvOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnRXN0YWRvJyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxufSkgKTtcblxuU2V0dGluZ3MuYXR0YWNoU2NoZW1hKG5ldyBTaW1wbGVTY2hlbWEoe1xuICBjbGF2ZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJDbGF2ZVwiLFxuICB9LFxuICB2YWxvcjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1ZhbG9yJyxcbiAgfSxcbiAgZmVjaGE6IHtcbiAgICB0eXBlOiBEYXRlLFxuICAgICBsYWJlbDogJ0ZlY2hhJyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcblxuICB9LFxuICBjcmVhdGVkOiB7XG4gICAgdHlwZTogRGF0ZSxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKCk7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMuaXNVcHNlcnQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAkc2V0T25JbnNlcnQ6IG5ldyBEYXRlKClcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMudW5zZXQoKTtcbiAgICAgIH1cbiAgICB9LFxuICB9LFxuICB1cGRhdGVkOiB7XG4gICAgdHlwZTogRGF0ZSxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKHRoaXMuaXNVcGRhdGUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKCk7XG4gICAgICB9XG4gICAgfSxcbiAgfSxcbiBcbn0pKTtcblxuVGlwb1BlcmZpbGVzLmFsbG93KHtcbiAgaW5zZXJ0OiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIHVwZGF0ZTogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59KVxuQW5jbGFqZXMuYWxsb3coe1xuICBpbnNlcnQ6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgdXBkYXRlOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn0pXG5cbkFuY2xhamVzRXF1aXBvcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufSlcblBlcnNvbmFsTGlxdWlkYWNpb25lcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufSlcblBlcnNvbmFsTGlxdWlkYWNpb25lcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufSlcblRpcG9QZXJmaWxlcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufSlcbiIsIlxuXHRhcHBsaWNhdGlvbkNvbnRyb2xsZXIgPSBSb3V0ZUNvbnRyb2xsZXIuZXh0ZW5kKHtcbiAgbGF5b3V0VGVtcGxhdGU6ICdsYXlvdXRBcHAnLFxuXHQgIGxvYWRpbmdUZW1wbGF0ZTogJ2xvYWRlckdyYWwnLFxuXHQgIG5vdEZvdW5kVGVtbHBsYXRlOiAnbm90Rm91bmQnLFxuLy8gXHQgIHlpZWxkVGVtcGxhdGVzOiB7XG4vLyBcdFx0J2FwcGxpY2F0aW9uSGVhZGVyJzoge3RvOiAnaGVhZGVyJ30sXG4vLyBcdFx0J3Byb2plY3RTd2l0Y2hlcic6IHt0bzogJ3Byb2plY3RTd2l0Y2hlcid9LFxuLy8gXHRcdCdhcHBsaWNhdGlvbk1haW5OYXYnOiB7dG86ICdtYWluTmF2J30sXG4vLyBcdFx0J2FwcGxpY2F0aW9uRm9vdGVyJzoge3RvOiAnZm9vdGVyJ31cbi8vIFx0ICB9LFxuXHQgIHdhaXRPbjogZnVuY3Rpb24oKSB7XG5cdFx0cmV0dXJuIFtcblx0XHRcdCBcbiAgICAgICBcblx0XHRdO1xuXHQgIH0sXG5cdCAgb25CZWZvcmVBY3Rpb246IGZ1bmN0aW9uKHBhdXNlKSB7XG5cdFx0dGhpcy5yZW5kZXIoJ2xvYWRlckdyYWwnKTtcblx0XHRcblx0XHRpZiAoICFNZXRlb3IudXNlcigpIClcblx0XHRcdHt0aGlzLnJlbmRlcignbG9naW4nKTt9XG4vLyBcdFx0aWYgKCEhdGhpcy5yZWFkeSgpICYmIFByb2plY3RzLmZpbmQoKS5jb3VudCgpID09PSAwKVxuIFx0ZWxzZVx0XHR7dGhpcy5uZXh0KCk7fVxuXHQgIH0sXG5cdCAgYWN0aW9uOiBmdW5jdGlvbiAoKSB7XG5cdFx0aWYgKCF0aGlzLnJlYWR5KCkpIHtcbiAgICAgIFxuXHRcdCAgdGhpcy5yZW5kZXIoJ2xvYWRlckdyYWwnKTtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRVSUJsb2NrLnVuYmxvY2soKTtcblx0XHQgIHRoaXMucmVuZGVyKCk7XG5cblx0XHR9XG5cdCAgfVxuXHR9KTtcblxuUm91dGVyLnJvdXRlKCcvaW5pY2lvJywge1xuIHBhdGg6ICcvaW5pY2lvJyxcbiAvLyBsYXlvdXRUZW1wbGF0ZTogJ2xheW91dFZhY2lvJyxcbiAgICB0ZW1wbGF0ZTpcImluaWNpb1wiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCdkZXNjYXJnYUNlcnRpZmljYWRvJywge1xuICAgIHdoZXJlOiAnc2VydmVyJyxcbiAgICBwYXRoOiAnL2Rlc2NhcmdhQ2VydGlmaWNhZG8vOmlkJyxcbiAgICBhY3Rpb246IGZ1bmN0aW9uKCkge1xuICAgIFx0dmFyIGE9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJmb2xkZXJVcGxvYWRzXCJ9KVxuICAgIFx0dmFyIHBhdGhVcGxvYWRzPWE/YS52YWxvcjpcIi92YXIvd3d3Lz8/XCI7XG4gICAgXHR2YXIgYXJjaGl2bz1BcmNoaXZvcy5maW5kT25lKHtfaWQ6dGhpcy5wYXJhbXMuaWR9KTtcbiAgICBcdGlmKGFyY2hpdm8pe1xuICAgIFxuICAgIFx0XHQgdmFyIGZpbGVuYW1lID0gYXJjaGl2by5wYXRoO1xuICAgICAgICBcbiAgICAgIHZhciBwYXRoID0gcGF0aFVwbG9hZHMrZmlsZW5hbWU7XG5cbiAgICAgIHZhciBzZXJ2PXRoaXM7XG4gICAgIGZzID0gTnBtLnJlcXVpcmUoJ2ZzJyk7XG4gICAgIGlmKCFmcy5leGlzdHNTeW5jKHBhdGgpKSB7XG4gICAgICAgdGhpcy5yZXNwb25zZS53cml0ZUhlYWQoMjAwLCB7ICdDb250ZW50LURpc3Bvc2l0aW9uJzogXCJhdHRhY2htZW50OyBmaWxlbmFtZT1ub3RGb3VuZC5wZGZcIiAgfSk7XG4gICAgICByZXR1cm4gdGhpcy5yZXNwb25zZS5lbmQoZmFsc2UpO1xufVxuXHRcdHZhciBkYXRhID0gZnMucmVhZEZpbGVTeW5jKHBhdGgpO1xuICAgIHRoaXMucmVzcG9uc2Uud3JpdGVIZWFkKDIwMCwgeyAnQ29udGVudC1EaXNwb3NpdGlvbic6IFwiYXR0YWNobWVudDsgZmlsZW5hbWU9XCIrZmlsZW5hbWUgIH0pO1xuICAgICAgIFxuICAgICAgcmV0dXJuIHRoaXMucmVzcG9uc2UuZW5kKGRhdGEpO1xuICAgIFxuICAgIFx0fVxuICAgIFx0Ly8gcmV0dXJuIHRoaXMucmVzcG9uc2UuZW5kKFwiTm8gZW5jdWVudHJvIGFyY2hpdm8hXCIpO1xuICAgICBcbiAgICAgIFxuICAgICBcbiAgICB9XG4gIH0pXG5Sb3V0ZXIucm91dGUoJy9wZXJzb25hbExpcXVpZGFjaW9uZXMnLCB7XG4gcGF0aDogJy9wZXJzb25hbExpcXVpZGFjaW9uZXMnLFxuIC8vIGxheW91dFRlbXBsYXRlOiAnbGF5b3V0VmFjaW8nLFxuICAgIHRlbXBsYXRlOlwicGVyc29uYWxMaXF1aWRhY2lvbmVzXCIsXG5cdFx0Y29udHJvbGxlcjogYXBwbGljYXRpb25Db250cm9sbGVyLFxufSk7XG5Sb3V0ZXIucm91dGUoJy90aXBvUGVyZmlsZXMnLCB7XG4gcGF0aDogJy90aXBvUGVyZmlsZXMnLFxuIC8vIGxheW91dFRlbXBsYXRlOiAnbGF5b3V0VmFjaW8nLFxuICAgIHRlbXBsYXRlOlwidGlwb1BlcmZpbGVzXCIsXG5cdFx0Y29udHJvbGxlcjogYXBwbGljYXRpb25Db250cm9sbGVyLFxufSk7XG5Sb3V0ZXIucm91dGUoJy9ob3Jhc0xpcXVpZGFjaW9uLzpfaWQnLCB7XG4gICAgdGVtcGxhdGU6ICdob3Jhc0xpcXVpZGFjaW9uJyxcbiAgICBjb250cm9sbGVyOiBhcHBsaWNhdGlvbkNvbnRyb2xsZXJcbn0pO1xuUm91dGVyLnJvdXRlKCcvcGVyc29uYWwnLCB7XG4gcGF0aDogJy9wZXJzb25hbCcsXG4gLy8gbGF5b3V0VGVtcGxhdGU6ICdsYXlvdXRWYWNpbycsXG4gICAgdGVtcGxhdGU6XCJwZXJzb25hbFwiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCcvJywge1xuIHBhdGg6ICcvJyxcbiAvLyBsYXlvdXRUZW1wbGF0ZTogJ2xheW91dFZhY2lvJyxcbiAgICB0ZW1wbGF0ZTpcImluaWNpb1wiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCcvYW5jbGFqZXMnLCB7XG4gcGF0aDogJy9hbmNsYWplcycsXG4gLy8gbGF5b3V0VGVtcGxhdGU6ICdsYXlvdXRWYWNpbycsXG4gICAgdGVtcGxhdGU6XCJhbmNsYWplc1wiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCcvYW5jbGFqZXNFcXVpcG9zJywge1xuIHBhdGg6ICcvYW5jbGFqZXNFcXVpcG9zJyxcbiAvLyBsYXlvdXRUZW1wbGF0ZTogJ2xheW91dFZhY2lvJyxcbiAgICB0ZW1wbGF0ZTpcImFuY2xhamVzRXF1aXBvc1wiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCcvZGF0b3NTaXN0ZW1hJywge1xuIHBhdGg6ICcvZGF0b3NTaXN0ZW1hJyxcbiAvLyBsYXlvdXRUZW1wbGF0ZTogJ2xheW91dFZhY2lvJyxcbiAgICB0ZW1wbGF0ZTpcImRhdG9zU2lzdGVtYVwiLFxuXHRcdGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbn0pO1xuUm91dGVyLnJvdXRlKCcvbW9kaWZpY2FyRGF0b3NTaXN0ZW1hLzpfaWQnLCB7XG4gICAgdGVtcGxhdGU6ICdtb2RpZmljYXJEYXRvc1Npc3RlbWEnLFxuICAgIGNvbnRyb2xsZXI6IGFwcGxpY2F0aW9uQ29udHJvbGxlcixcbiAgICBkYXRhOiBmdW5jdGlvbigpe1xuICAgICAgICAgdmFyIHNhbD1TZXR0aW5ncy5maW5kT25lKHtfaWQ6IHRoaXMucGFyYW1zLl9pZH0pO1xuICAgICAgICAgcmV0dXJuIHNhbDtcbiAgICB9XG59KTtcblJvdXRlci5yb3V0ZSgnL3VzdWFyaW9zJywge1xuIHBhdGg6ICcvdXN1YXJpb3MnLFxuIC8vIGxheW91dFRlbXBsYXRlOiAnbGF5b3V0VmFjaW8nLFxuICAgIHRlbXBsYXRlOlwidXN1YXJpb3NcIixcblx0XHRjb250cm9sbGVyOiBhcHBsaWNhdGlvbkNvbnRyb2xsZXIsXG59KTsiLCIgaW1wb3J0IFRhYnVsYXIgZnJvbSAnbWV0ZW9yL2FsZGVlZDp0YWJ1bGFyJztcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50JztcblxuIHNvX189bmV3IFRhYnVsYXIuVGFibGUoe1xuICBuYW1lOiBcIkFuY2xhamVzXCIsXG4gICBsYW5ndWFnZToge1xuICAgICBwcm9jZXNzaW5nOiBcIjxpbWcgc3JjPScvaW1hZ2VzL2xvYWRpbmcuZ2lmJz5cIlxuICB9LFxuICAgcHJvY2Vzc2luZzogdHJ1ZSxcbiAgIHN0YXRlU2F2ZTogdHJ1ZSxcbiAgY29sbGVjdGlvbjogQW5jbGFqZXMsXG4gIGZpbHRlcnM6IFsnZmlsdHJvX2VxdWlwb0Vuc2F5byddLFxuICAgY3JlYXRlZFJvdyggcm93LCBkYXRhLCBkYXRhSW5kZXggKSB7XG4gICAgaWYoZGF0YS5lc3RhZG89PVwiQkFKQVwiKXtcbiAgICAgIHZhciBmaWxhPSQocm93KTtcbiAgICAgIFxuICAgICAgdmFyIGRpYXM9Z2V0RGlhc1Z0byhyb3cuZmVjaGFFbnNheW8pO1xuICAgICAgICBpZihkaWFzPDkwKSBmaWxhLmF0dHIoXCJjbGFzc1wiLFwid2FybmluZ1wiKTsgLy9kYW5nZXIsIHN1Y2Nlc3MsaW5mb1xuICAgICAgICBcbiAgICB9XG4gIH0sXG4gICBleHRyYUZpZWxkczogWydlcXVpcG9FbnNheW8nLCAnaG9yYUVuc2F5bycsXCJjZXJ0aWZpY2Fkb1wiLFwib2JzZXJ2YWNpb25lc1wiLFwiZXF1aXBvSW5ncmVzYW50ZVwiXSxcbiAgICBidXR0b25zOiBbJ2NvcHknLCAnZXhjZWwnLCAnY3N2JywgJ2NvbHZpcyddLFxuICAgYXV0b1dpZHRoOiBmYWxzZSwgLy8gcHVzZSBlc3RvIHBvciBxdWUgY3VhbmRvIGVsaW1pbmFiYSB1biBzb2NpbyB5IHZvbHZpYSBhIHNvY2lvcyBxdWVkYSBsYSB0YWJsYSBwb3IgbGEgbWl0YWRcbi8vY2xhc3NuYW1lOlwiY29tcGFjdFwiLFxuICBjb2x1bW5zOiBbXG4gICAgIHtcbiAgICAgICAgdGl0bGU6ICdWdG8uJyxcbiAgICAgICB3aWR0aDogJzgwcHgnLFxuICAgICAgIGRhdGE6XCJmZWNoYUVuc2F5b1wiLFxuICAgICAgcmVuZGVyOmZ1bmN0aW9uICh2YWx1ZSwgdHlwZSwgb2JqZWN0KSB7XG4gICAgICAgICB2YXIgZGlhcz1nZXREaWFzVnRvKHZhbHVlKTtcbiAgICAgICAgaWYoZGlhczw5MCkgcmV0dXJuIFwiTXV5IFZlbmNpZG9cIjtcbiAgICAgICAgcmV0dXJuIGRpYXMrXCIgZGlhc1wiO1xuICAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdQb3pvJyxcbiAgICAgICAgd2lkdGg6ICcxMDBweCcsXG4gICAgICAgIGRhdGE6XCJwb3pvXCJcbiAgICAgIH0sXG4gICAgICBcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdCYXRlcmlhJyxcbiAgICAgICBcdHdpZHRoOiAnNzBweCcsXG4gICAgICBcdGRhdGE6XCJiYXRlcmlhXCIsXG4gICAgICAgIHJlbmRlcjpmdW5jdGlvbiAodmFsdWUsIHR5cGUsIG9iamVjdCkge1xuICAgICAgICAgaWYodmFsdWUpcmV0dXJuIHZhbHVlO1xuICAgICAgICAgcmV0dXJuIFwiLVwiXG4gICAgICAgICB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ0NlcnQuJyxcbiAgICAgICBcdHdpZHRoOiAnNzBweCcsXG4gICAgICBcdGRhdGE6XCJjZXJ0aWZpY2FjaW9uXCJcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnRXF1aXBvJyxcbiAgICAgICBcdHdpZHRoOiAnMTAwcHgnLFxuICAgICAgXHRkYXRhOlwiZXF1aXBvRW5zYXlvXCIsXG4gICAgICAgIHJlbmRlcjpmdW5jdGlvbiAodmFsdWUsIHR5cGUsIG9iamVjdCkge1xuICAgICAgICAgdmFyIGF1eD1BbmNsYWplc0VxdWlwb3MuZmluZE9uZSh2YWx1ZSk7XG4gICAgICAgICBpZihhdXgpcmV0dXJuIGF1eC5ub21icmVFcXVpcG87XG4gICAgICAgICByZXR1cm4gXCItXCJcbiAgICAgICAgIH0sXG4gICAgICAgICB2aXNpYmxlOnRydWVcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnRW5zYXlhZG8uLicsXG4gICAgICAgXHR3aWR0aDogJzEwMHB4JyxcbiAgICAgICBcdGRhdGE6XCJmZWNoYUVuc2F5b1wiLFxuICAgICAgXHRyZW5kZXI6ZnVuY3Rpb24gKHZhbHVlLCB0eXBlLCBvYmplY3QpIHtcbiAgICAgICAgIHZhciBkID0gbmV3IERhdGUodmFsdWUpO1xuICAgICAgICB2YXIgaG9yYT1vYmplY3QuaG9yYUFuY2xhamU/b2JqZWN0LmhvcmFBbmNsYWplOlwiXCI7XG4gICAgICAgICAgIGlmKHZhbHVlKSByZXR1cm4gZC5nZXREYXRlKCkrXCIvXCIrZC5nZXRNb250aCgpK1wiL1wiK2QuZ2V0RnVsbFllYXIoKStcIiBcIitob3JhO1xuICAgICAgICAgICByZXR1cm4gXCItXCJcbiAgICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnQ29uc3RydWlkby4uJyxcbiAgICAgICBcdHdpZHRoOiAnMTAwcHgnLFxuICAgICAgIFx0ZGF0YTpcImZlY2hhQ29uc3RydWNjaW9uXCIsXG4gICAgICBcdHJlbmRlcjpmdW5jdGlvbiAodmFsdWUsIHR5cGUsIG9iamVjdCkge1xuICAgICAgICAgdmFyIGQgPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gICAgICAgIGlmKHZhbHVlKSAgcmV0dXJuIGQuZ2V0RGF0ZSgpK1wiL1wiK2QuZ2V0TW9udGgoKStcIi9cIitkLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgIHJldHVybiBcIi1cIlxuICAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdOTycsXG4gICAgICAgXHR3aWR0aDogJzMwcHgnLFxuICAgICAgXHRkYXRhOlwiZXN0YWRvTk9cIixcbiAgICAgIFx0cmVuZGVyOmZ1bmN0aW9uICh2YWx1ZSwgdHlwZSwgb2JqZWN0KSB7XG4gICAgICAgICAgcmV0dXJuICBuZXcgU3BhY2ViYXJzLlNhZmVTdHJpbmcoY29sb3JlYXJFc3RhZG8odmFsdWUpKVxuICAgICAgICAgfVxuXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ05FJyxcbiAgICAgICBcdHdpZHRoOiAnMzBweCcsXG4gICAgICBcdGRhdGE6XCJlc3RhZG9ORVwiLFxuICAgICAgXHRyZW5kZXI6ZnVuY3Rpb24gKHZhbHVlLCB0eXBlLCBvYmplY3QpIHtcbiAgICAgICAgICByZXR1cm4gIG5ldyBTcGFjZWJhcnMuU2FmZVN0cmluZyhjb2xvcmVhckVzdGFkbyh2YWx1ZSkpXG4gICAgICAgICB9XG5cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU08nLFxuICAgICAgIFx0d2lkdGg6ICczMHB4JyxcbiAgICAgIFx0ZGF0YTpcImVzdGFkb1NPXCIsXG4gICAgICBcdHJlbmRlcjpmdW5jdGlvbiAodmFsdWUsIHR5cGUsIG9iamVjdCkge1xuICAgICAgICAgIHJldHVybiAgbmV3IFNwYWNlYmFycy5TYWZlU3RyaW5nKGNvbG9yZWFyRXN0YWRvKHZhbHVlKSlcbiAgICAgICAgIH1cblxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTRScsXG4gICAgICAgXHR3aWR0aDogJzMwcHgnLFxuICAgICAgXHRkYXRhOlwiZXN0YWRvU0VcIixcbiAgICAgIFx0cmVuZGVyOmZ1bmN0aW9uICh2YWx1ZSwgdHlwZSwgb2JqZWN0KSB7XG4gICAgICAgICAgcmV0dXJuICBuZXcgU3BhY2ViYXJzLlNhZmVTdHJpbmcoY29sb3JlYXJFc3RhZG8odmFsdWUpKVxuICAgICAgICAgfVxuXG4gICAgICB9LFxuICAgICAge1xuICAgICAgXHR3aWR0aDogJzE2MHB4JyxcbiAgICAgIHRtcGw6IE1ldGVvci5pc0NsaWVudCAmJiBUZW1wbGF0ZS5hY2Npb25lc0FuY2xhamVzXG4gICAgfVxuICAgICAgXG4gIF1cbn0pO1xuIGZ1bmN0aW9uIGNvbG9yZWFyRXN0YWRvKGVzdGFkbylcbntcbiAgaWYoZXN0YWRvPT1cIkFcIilyZXR1cm4gXCI8YiBzdHlsZT0nY29sb3I6Z3JlZW4nPlwiK2VzdGFkbytcIjwvYj5cIjtcbiAgaWYoZXN0YWRvPT1cIlJcIilyZXR1cm4gXCI8YiBzdHlsZT0nY29sb3I6cmVkJz5cIitlc3RhZG8rXCI8L2I+XCI7XG4gIHJldHVybiBcIjxiIHN0eWxlPSdjb2xvcjpncmV5Jz4gLSA8L2I+XCI7XG59IiwiLyplc2xpbnQtZGlzYWJsZSBuby11bnJlYWNoYWJsZSwgbm8tZXh0ZW5kLW5hdGl2ZSwgbm8tdW5kZWYsIHNlbWkqL1xuU3RyaW5nLnByb3RvdHlwZS5scGFkID0gZnVuY3Rpb24ocGFkU3RyaW5nLCBsZW5ndGgpIHtcbiAgICB2YXIgc3RyID0gdGhpcztcbiAgICB3aGlsZSAoc3RyLmxlbmd0aCA8IGxlbmd0aClcbiAgICAgICAgc3RyID0gcGFkU3RyaW5nICsgc3RyO1xuICAgIHJldHVybiBzdHI7XG59XG5EYXRlLnByb3RvdHlwZS5hZGRIb3VycyA9IGZ1bmN0aW9uKGgpIHtcbiAgIHRoaXMuc2V0VGltZSh0aGlzLmdldFRpbWUoKSArIChoKjYwKjYwKjEwMDApKTsgXG4gICByZXR1cm4gdGhpczsgICBcbn1cbkRhdGUucHJvdG90eXBlLmFkZERheXMgPSBmdW5jdGlvbiAobnVtKSB7XG4gICAgdmFyIHZhbHVlID0gdGhpcy52YWx1ZU9mKCk7XG4gICAgdmFsdWUgKz0gODY0MDAwMDAgKiBudW07XG4gICAgcmV0dXJuIG5ldyBEYXRlKHZhbHVlKTtcbn1cblN0cmluZy5wcm90b3R5cGUubHBhZCA9IGZ1bmN0aW9uKHBhZFN0cmluZywgbGVuZ3RoKSB7XG4gICAgdmFyIHN0ciA9IHRoaXM7XG4gICAgd2hpbGUgKHN0ci5sZW5ndGggPCBsZW5ndGgpXG4gICAgICAgIHN0ciA9IHBhZFN0cmluZyArIHN0cjtcbiAgICByZXR1cm4gc3RyO1xufVxuU3RyaW5nLnByb3RvdHlwZS5jYXBpdGFsaXphciA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdGhpcy5zbGljZSgxKTtcbn1cblN0cmluZy5wcm90b3R5cGUucnBhZCA9IGZ1bmN0aW9uKHBhZFN0cmluZywgbGVuZ3RoKSB7XG4gICAgdmFyIHN0ciA9IHRoaXM7XG4gICAgd2hpbGUgKHN0ci5sZW5ndGggPCBsZW5ndGgpXG4gICAgICAgIHN0ciA9IHN0cisgcGFkU3RyaW5nIDtcbiAgICByZXR1cm4gc3RyO1xufVxuRGF0ZS5wcm90b3R5cGUuZ2V0RmVjaGEgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHZhbHVlID0gdGhpcy52YWx1ZU9mKCk7XG4gICAgdmFsdWUgKz0gODY0MDAwMDAgKiAxO1xuICAgIHZhciBkPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gIHJldHVybiBkLmdldERhdGUoKStcIi9cIisoZC5nZXRNb250aCgpKzEpK1wiL1wiK2QuZ2V0RnVsbFllYXIoKTtcbn1cbkRhdGUucHJvdG90eXBlLmdldEZlY2hhMiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdmFsdWUgPSB0aGlzLnZhbHVlT2YoKTtcbiAgICB2YWx1ZSArPSA4NjQwMDAwMCAqIDE7XG4gICAgdmFyIGQ9IG5ldyBEYXRlKHZhbHVlKTtcbiAgcmV0dXJuIGQuZ2V0RGF0ZSgpK1wiL1wiKyhkLmdldE1vbnRoKCkrMSkrXCIvXCIrZC5nZXRGdWxsWWVhcigpO1xufVxuRGF0ZS5wcm90b3R5cGUuZ2V0TWVzID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB2YWx1ZSA9IHRoaXMudmFsdWVPZigpO1xuICAgIHZhbHVlICs9IDg2NDAwMDAwICogMTtcbiAgICB2YXIgZD0gbmV3IERhdGUodmFsdWUpO1xuICByZXR1cm4gZC5nZXRNb250aCgpKzFcbn1cbkRhdGUucHJvdG90eXBlLmdldERpYT0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB2YWx1ZSA9IHRoaXMudmFsdWVPZigpO1xuICAgIHZhbHVlICs9IDg2NDAwMDAwICogMTtcbiAgICB2YXIgZD0gbmV3IERhdGUodmFsdWUpO1xuICByZXR1cm4gZC5nZXREYXRlKClcbn1cbkRhdGUucHJvdG90eXBlLmdldEFubz0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB2YWx1ZSA9IHRoaXMudmFsdWVPZigpO1xuICAgIHZhbHVlICs9IDg2NDAwMDAwICogMTtcbiAgICB2YXIgZD0gbmV3IERhdGUodmFsdWUpO1xuICByZXR1cm4gZC5nZXRGdWxsWWVhcigpXG59XG5OdW1iZXIucHJvdG90eXBlLmZvcm1hdE1vbmV5ID0gZnVuY3Rpb24obiwgeCwgcywgYykge1xuICAgIHZhciByZSA9ICdcXFxcZCg/PShcXFxcZHsnICsgKHggfHwgMykgKyAnfSkrJyArIChuID4gMCA/ICdcXFxcRCcgOiAnJCcpICsgJyknLFxuICAgICAgICBudW0gPSB0aGlzLnRvRml4ZWQoTWF0aC5tYXgoMCwgfn5uKSk7XG5cbiAgICByZXR1cm4gKGMgPyBudW0ucmVwbGFjZSgnLicsIGMpIDogbnVtKS5yZXBsYWNlKG5ldyBSZWdFeHAocmUsICdnJyksICckJicgKyAocyB8fCAnLCcpKTtcbn07XG5mdW5jdGlvbiB2YWxpZGFyTGFyZ29DQlUoY2J1KSB7XG4gIGlmIChjYnUubGVuZ3RoICE9IDIyKSB7IHJldHVybiBmYWxzZSB9XG5cdHJldHVybiB0cnVlXG59XG5cbnZhciB2YWxpZGFyQ29kaWdvQmFuY289ZnVuY3Rpb24oY29kaWdvKSB7XG4gaWYgKGNvZGlnby5sZW5ndGggIT0gOCkgeyByZXR1cm4gZmFsc2UgfVxuIHZhciBiYW5jbyA9IGNvZGlnby5zdWJzdHIoMCwzKVxuIHZhciBkaWdpdG9WZXJpZmljYWRvcjEgPSBjb2RpZ29bM11cbiB2YXIgc3VjdXJzYWwgPSBjb2RpZ28uc3Vic3RyKDQsMylcbiB2YXIgZGlnaXRvVmVyaWZpY2Fkb3IyID0gY29kaWdvWzddXG5cbiB2YXIgc3VtYSA9IGJhbmNvWzBdICogNyArIGJhbmNvWzFdICogMSArIGJhbmNvWzJdICogMyArIGRpZ2l0b1ZlcmlmaWNhZG9yMSAqIDkgKyBzdWN1cnNhbFswXSAqIDcgKyBzdWN1cnNhbFsxXSAqIDEgKyBzdWN1cnNhbFsyXSAqIDNcblxuIHZhciBkaWZlcmVuY2lhID0gMTAgLSAoc3VtYSAlIDEwKVxuXG4gcmV0dXJuIGRpZmVyZW5jaWEgPT0gZGlnaXRvVmVyaWZpY2Fkb3IyXG59XG5tZXNMZXRyYXM9ZnVuY3Rpb24obWVzKVxue1xuICBpZihtZXM9PTEpcmV0dXJuIFwiRU5FUk9cIjtcbiAgaWYobWVzPT0yKXJldHVybiBcIkZFQlJFUk9cIjtcbiAgaWYobWVzPT0zKXJldHVybiBcIk1BUlpPXCI7XG4gIGlmKG1lcz09NClyZXR1cm4gXCJBQlJJTFwiO1xuICBpZihtZXM9PTUpcmV0dXJuIFwiTUFZT1wiO1xuICBpZihtZXM9PTYpcmV0dXJuIFwiSlVOSU9cIjtcbiAgaWYobWVzPT03KXJldHVybiBcIkpVTElPXCI7XG4gIGlmKG1lcz09OClyZXR1cm4gXCJBR09TVE9cIjtcbiAgaWYobWVzPT05KXJldHVybiBcIlNFUFRFTUJSRVwiO1xuICBpZihtZXM9PTEwKXJldHVybiBcIk9DVFVCUkVcIjtcbiAgaWYobWVzPT0xMSlyZXR1cm4gXCJOT1ZJRU1CUkVcIjtcbiAgaWYobWVzPT0xMilyZXR1cm4gXCJESUNJRU1CUkVcIjtcbiAgcmV0dXJuIFwicy9hXCI7XG59XG5tZXNOdW1lcm9zPWZ1bmN0aW9uKG1lcylcbntcbiAgaWYobWVzPT1cIkVORVJPXCIpcmV0dXJuIDE7XG4gIGlmKG1lcz09XCJGRUJSRVJPXCIpcmV0dXJuIDI7XG4gIGlmKG1lcz09XCJNQVJaT1wiKXJldHVybiAzO1xuICBpZihtZXM9PSBcIkFCUklMXCIpcmV0dXJuIDQ7XG4gIGlmKG1lcz09XCJNQVlPXCIpcmV0dXJuIDU7XG4gIGlmKG1lcz09XCJKVU5JT1wiKXJldHVybiA2O1xuICBpZihtZXM9PSBcIkpVTElPXCIpcmV0dXJuIDc7XG4gIGlmKG1lcz09XCJBR09TVE9cIilyZXR1cm4gODtcbiAgaWYobWVzPT1cIlNFUFRFTUJSRVwiKXJldHVybiA5O1xuICBpZihtZXM9PVwiT0NUVUJSRVwiKXJldHVybiAxMDtcbiAgaWYobWVzPT1cIk5PVklFTUJSRVwiKXJldHVybiAxMTtcbiAgaWYobWVzPT1cIkRJQ0lFTUJSRVwiKXJldHVybiAxMjtcbiAgcmV0dXJuIG51bGw7XG59XG5nZXRNZXNlcz1mdW5jdGlvbigpXG57XG4gIHJldHVybiBbXCJFTkVST1wiLFwiRkVCUkVST1wiLFwiTUFSWk9cIixcIkFCUklMXCIsXCJNQVlPXCIsXCJKVU5JT1wiLFwiSlVMSU9cIixcIkFHT1NUT1wiLFwiU0VQVEVNQlJFXCIsXCJPQ1RVQlJFXCIsXCJOT1ZJRU1CUkVcIixcIkRJQ0lFTUJSRVwiXTtcbn1cbnJpcEZlY2hhQXJjaGl2bz1mdW5jdGlvbihmZWNoYURhdGUpXG57XG4gICAgdmFyIHN0PWZlY2hhRGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoKTtcbiAgICB2YXIgYXJyPXN0LnNwbGl0KFwiL1wiKTtcbiAgICBcbiAgICByZXR1cm4gYXJyWzBdLmxwYWQoXCIwXCIsMikrYXJyWzFdLmxwYWQoXCIwXCIsMikrYXJyWzJdLmxwYWQoXCIwXCIsMilcbn1cbmdldEltcG9ydGVUb3RhbFNvY2lvcz1mdW5jdGlvbihhcnIpXG57XG4gICAgdmFyIHN1bT0wO1xuICAgIGZvcih2YXIgaT0wO2k8YXJyLmxlbmd0aDtpKyspc3VtKz1hcnJbaV0uaW1wb3J0ZSoxO1xuICAgIHJldHVybiBzdW07XG59XG5yaXBJbXBvcnRlQXJjaGl2bz1mdW5jdGlvbihpbXBvcnRlKVxue1xuICAgIGltcG9ydGU9aW1wb3J0ZStcIlwiO1xuICAgIHZhciBhcnI9aW1wb3J0ZS5zcGxpdChcIi5cIik7XG4gICAgaWYoYXJyLmxlbmd0aD4xKXJldHVybiBhcnJbMF0ubHBhZChcIjBcIiw4KSthcnJbMV0ubHBhZChcIjBcIiwyKTtcbiAgICByZXR1cm4gYXJyWzBdLmxwYWQoXCIwXCIsOCkrXCIwMFwiO1xufVxudmFyIHZhbGlkYXJDdWVudGE9ZnVuY3Rpb24oY3VlbnRhKSB7XG4gaWYgKGN1ZW50YS5sZW5ndGggIT0gMTQpIHsgcmV0dXJuIGZhbHNlIH1cbiB2YXIgZGlnaXRvVmVyaWZpY2Fkb3IgPSBjdWVudGFbMTNdXG4gdmFyIHN1bWEgPSBjdWVudGFbMF0gKiAzICsgY3VlbnRhWzFdICogOSArIGN1ZW50YVsyXSAqIDcgKyBjdWVudGFbM10gKiAxICsgY3VlbnRhWzRdICogMyArIGN1ZW50YVs1XSAqIDkgKyBjdWVudGFbNl0gKiA3ICsgY3VlbnRhWzddICogMSArIGN1ZW50YVs4XSAqIDMgKyBjdWVudGFbOV0gKiA5ICsgY3VlbnRhWzEwXSAqIDcgKyBjdWVudGFbMTFdICogMSArIGN1ZW50YVsxMl0gKiAzXG4gdmFyIGRpZmVyZW5jaWEgPSAxMCAtIChzdW1hICUgMTApXG4gcmV0dXJuIGRpZmVyZW5jaWEgPT0gZGlnaXRvVmVyaWZpY2Fkb3Jcbn1cblxudmFsaWRhckNCVT1mdW5jdGlvbihjYnUpIHtcbiByZXR1cm4gdmFsaWRhckxhcmdvQ0JVKGNidSkgJiYgdmFsaWRhckNvZGlnb0JhbmNvKGNidS5zdWJzdHIoMCw4KSkgJiYgdmFsaWRhckN1ZW50YShjYnUuc3Vic3RyKDgsMTQpKVxufVxuZ2V0Q2xhc2VUaXBvU29jaW89ZnVuY3Rpb24oZmVjaGFOYWMsZXNBY3Rpdm8sZXN0YWRvKXtcblx0dmFyIHRpcG89Z2V0VGlwb1NvY2lvKGZlY2hhTmFjLGVzQWN0aXZvKTtcblx0aWYoZXN0YWRvPT1cIkJBSkFcIilyZXR1cm4gXCJiYWphU29jaW9cIjtcblx0dmFyIGNsYXNlPXRpcG89PT1cIlBBUlRJQ0lQQU5URVwiP1widGV4dC13YXJuaW5nXCI6XCJ0ZXh0LWluZm9cIjtcblx0XHRpZih0aXBvPT09XCJBQ1RJVk9cIiljbGFzZT1cInRleHQtZGFuZ2VyXCI7XG5cdHJldHVybiBjbGFzZTtcbn1cbmdlVGlwb1NvY2lvRWRhZD1mdW5jdGlvbihlZGFkLGFjdGl2bylcbntcblx0dmFyIGVkYWRBZGhlcmVudGU9cGFyc2VGbG9hdChTZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImVkYWRBZGhlcmVudGVcIn0pLnZhbG9yKTtcblx0aWYoYWN0aXZvKSByZXR1cm4gXCJBQ1RJVk9cIlxuXHRpZihlZGFkPj1lZGFkQWRoZXJlbnRlKXJldHVybiBcIkFESEVSRU5URVwiO1xuXHRcblx0cmV0dXJuIFwiUEFSVElDSVBBTlRFXCI7XG59XG5nZXRJbXBvcnRlU29jaW9FZGFkPWZ1bmN0aW9uKGVkYWQsYWN0aXZvKVxue1xuXHR2YXIgZWRhZEFkaGVyZW50ZT1wYXJzZUZsb2F0KFNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiZWRhZEFkaGVyZW50ZVwifSkudmFsb3IpO1xuXHRpZihhY3Rpdm8pIHJldHVybiBwYXJzZUZsb2F0KFNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZUFjdGl2b3NcIn0pLnZhbG9yKVxuXHRpZihlZGFkPj1lZGFkQWRoZXJlbnRlKXJldHVybiBwYXJzZUZsb2F0KFNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wcnRlQWRoZXJlbnRlc1wifSkudmFsb3IpXG5cdFxuXHRyZXR1cm4gcGFyc2VGbG9hdChTZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVQYXJ0aWNpcGFudGVzXCJ9KS52YWxvcilcbn1cbmdldEVkYWRTb2Npbz1mdW5jdGlvbihmZWNoYU5hYyl7XG5cdHZhciBob3kgPSBuZXcgRGF0ZSgpO1xuICAgIHZhciBjdW1wbGVhbm9zID0gbmV3IERhdGUoZmVjaGFOYWMpO1xuICAgIHZhciBlZGFkID0gaG95LmdldEFubygpIC0gY3VtcGxlYW5vcy5nZXRBbm8oKTtcbiAgICB2YXIgbSA9IGhveS5nZXRNZXMoKSAtIGN1bXBsZWFub3MuZ2V0TWVzKCk7XG5cbiAgICBpZiAobSA8IDAgfHwgKG0gPT09IDAgJiYgaG95LmdldERpYSgpIDwgY3VtcGxlYW5vcy5nZXREaWEoKSkpIHtcbiAgICAgICAgZWRhZC0tO1xuICAgIH1cblxuICAgIHJldHVybiBlZGFkO1xufVxuZ2V0VGlwb1NvY2lvPWZ1bmN0aW9uKGZlY2hhTmFjLGVzQWN0aXZvKXtcblx0dmFyIGVkYWRBZGhlcmVudGU9cGFyc2VGbG9hdChTZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImVkYWRBZGhlcmVudGVcIn0pLnZhbG9yKTtcblx0XG5cdCB2YXIgYW5vcz1nZXRFZGFkU29jaW8oZmVjaGFOYWMpO1xuXHRpZihlc0FjdGl2bylyZXR1cm4gXCJBQ1RJVk9cIjtcbiAgIHJldHVybiBhbm9zPGVkYWRBZGhlcmVudGU/XCJQQVJUSUNJUEFOVEVcIjpcIkFESEVSRU5URVwiO1xufVxuZ2V0SW1wb3J0ZVNvY2lvPWZ1bmN0aW9uKGlkU29jaW8pXG57XG4gIHZhciBkYXRhUGFydGljaXBhbnRlcz1TZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVQYXJ0aWNpcGFudGVzXCJ9KTtcbiAgICB2YXIgZGF0YUFkaGVyZW50ZXM9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJpbXBvcnRlQWRoZXJlbnRlc1wifSk7XG4gICAgdmFyIGRhdGFBY3Rpdm9zPVNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZUFjdGl2b3NcIn0pO1xudmFyIGVkYWRBZGhlcmVudGU9cGFyc2VGbG9hdChTZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImVkYWRBZGhlcmVudGVcIn0pLnZhbG9yKTtcbiAgXG4gIHZhciBzb2Npbz1Tb2Npb3MuZmluZE9uZSh7X2lkOmlkU29jaW99KTtcbiAgdmFyIGFub3M9Z2V0RWRhZFNvY2lvKHNvY2lvLmZlY2hhTmFjaW1pZW50byk7XG5cdFxuICBpZihzb2Npby5lc0FjdGl2bylyZXR1cm4gZGF0YUFjdGl2b3MudmFsb3I7XG4gIGlmKGFub3M8ZWRhZEFkaGVyZW50ZSkgcmV0dXJuIGRhdGFQYXJ0aWNpcGFudGVzLnZhbG9yO1xuICByZXR1cm4gZGF0YUFkaGVyZW50ZXMudmFsb3I7XG59XG5nZXRJbXBvcnRlU29jaW9EYXRvcz1mdW5jdGlvbihmZWNoYU5hY2ltaWVudG8sZXNBY3Rpdm8pXG57XG4gIHZhciBkYXRhUGFydGljaXBhbnRlcz1TZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVQYXJ0aWNpcGFudGVzXCJ9KTtcbiAgICB2YXIgZGF0YUFkaGVyZW50ZXM9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJpbXBvcnRlQWRoZXJlbnRlc1wifSk7XG4gICAgdmFyIGRhdGFBY3Rpdm9zPVNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZUFjdGl2b3NcIn0pO1xudmFyIGVkYWRBZGhlcmVudGU9cGFyc2VGbG9hdChTZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImVkYWRBZGhlcmVudGVcIn0pLnZhbG9yKTtcbiAgXG5cbiAgdmFyIGFub3M9Z2V0RWRhZFNvY2lvKGZlY2hhTmFjaW1pZW50byk7XG5cdFxuICBpZihlc0FjdGl2bylyZXR1cm4gZGF0YUFjdGl2b3MudmFsb3I7XG4gIGlmKGFub3M8ZWRhZEFkaGVyZW50ZSkgcmV0dXJuIGRhdGFQYXJ0aWNpcGFudGVzLnZhbG9yO1xuICByZXR1cm4gZGF0YUFkaGVyZW50ZXMudmFsb3I7XG59XG5cbm1vZHVsZS5leHBvcnRzPWdldFRpcG9Tb2NpbzsiLCJnZXRNb2R1bG89ZnVuY3Rpb24obm9tYnJlTW9kdWxvLG1vZHVsb3MpXG57XG5pZihtb2R1bG9zKVxuICBmb3IgKHZhciBpID0gMDsgaSA8IG1vZHVsb3MubGVuZ3RoOyBpKyspXG4gICAgaWYoU3RyaW5nKG1vZHVsb3NbaV0ubm9tYnJlKS50b0xvY2FsZUxvd2VyQ2FzZSgpPT1TdHJpbmcobm9tYnJlTW9kdWxvKS50b0xvd2VyQ2FzZSgpKXJldHVybiBtb2R1bG9zW2ldXG4gIFxuICByZXR1cm4gZmFsc2U7XG59XG5nZXRNb2R1bG8yPWZ1bmN0aW9uKG5vbWJyZU1vZHVsbylcbntcbiAgdmFyIHRpcG9QZXJmaWw9VGlwb1BlcmZpbGVzLmZpbmRPbmUoe19pZDpNZXRlb3IudXNlcigpLnByb2ZpbGV9KTtcbiAgY29uc29sZS5sb2coTWV0ZW9yLnVzZXIoKS5wcm9maWxlKVxuICBpZih0aXBvUGVyZmlsKXtcbiAgICB2YXIgbW9kdWxvcz10aXBvUGVyZmlsLm1vZHVsb3NBY2Nlc287XG4gICAgaWYodGlwb1BlcmZpbC5lc0FkbWluaXN0cmFkb3IpcmV0dXJuIHRydWU7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbW9kdWxvcy5sZW5ndGg7IGkrKylcbiAgICBpZihTdHJpbmcobW9kdWxvc1tpXS5ub21icmUpLnRvTG9jYWxlTG93ZXJDYXNlKCk9PVN0cmluZyhub21icmVNb2R1bG8pLnRvTG93ZXJDYXNlKCkpcmV0dXJuIG1vZHVsb3NbaV1cbiAgXG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5nZXRDb2xlY2Npb25BY2Nlc289ZnVuY3Rpb24odGlwb1BlcmZpbCx1c2VyLCBub21icmVDb2xlY2Npb24pXG57XG4gIHZhciBDb2xlY2Npb249ZXZhbChub21icmVDb2xlY2Npb24pO1xuICB2YXIgbW9kdWxvPWdldE1vZHVsbyhcImFuY2xhamVzXCIsdGlwb1BlcmZpbC5tb2R1bG9zQWNjZXNvKTtcbiAgaWYodGlwb1BlcmZpbC5lc0FkbWluaXN0cmFkb3IpcmV0dXJuIENvbGVjY2lvbi5maW5kKCk7XG4gIGlmKG1vZHVsbyl7XG4gICAgIGlmKG1vZHVsby5zb2xvVmVyTWlvcyl7XG4gICAgICByZXR1cm4gQ29sZWNjaW9uLmZpbmQoe2lkVXN1YXJpbzp1c2VyLl9pZH0pO1xuICAgICB9XG4gIHJldHVybiBDb2xlY2Npb24uZmluZCgpO1xuICB9XG5cbiAgXG59XG5nZXRDb2xlY2Npb25QZXJmaWw9ZnVuY3Rpb24obm9tYnJlQ29sZWNjaW9uKVxue1xuICB2YXIgdXN1YXJpbz1NZXRlb3IudXNlcigpO1xuICBpZih1c3VhcmlvKXtcbiAgICB2YXIgdGlwb1BlcmZpbD1UaXBvUGVyZmlsZXMuZmluZE9uZSh7X2lkOnVzdWFyaW8ucHJvZmlsZX0pO1xuICAgIGlmKHRpcG9QZXJmaWwpcmV0dXJuIGdldENvbGVjY2lvbkFjY2Vzbyh0aXBvUGVyZmlsLHVzdWFyaW8sIG5vbWJyZUNvbGVjY2lvbilcbiAgfXJldHVybiBbXVxuICAgIFxufSIsInZhciBnZXRJbXBvcnRlU29jaW89ZnVuY3Rpb24oaWRTb2NpbylcbntcbiAgdmFyIGRhdGFQYXJ0aWNpcGFudGVzPVNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZVBhcnRpY2lwYW50ZXNcIn0pO1xuICAgIHZhciBkYXRhQWRoZXJlbnRlcz1TZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVBZGhlcmVudGVzXCJ9KTtcbiAgICB2YXIgZGF0YUFjdGl2b3M9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJpbXBvcnRlQWN0aXZvc1wifSk7XG4gIFxuICB2YXIgc29jaW89U29jaW9zLmZpbmRPbmUoe19pZDppZFNvY2lvfSk7XG4gIHZhciBuYWNpbWllbnRvPW5ldyBEYXRlKHNvY2lvLmZlY2hhTmFjaW1pZW50byk7XG4gIHZhciBhaG9yYT1uZXcgRGF0ZSgpO1xuICB2YXIgYW5vcz1haG9yYS5nZXRGdWxsWWVhcigpLW5hY2ltaWVudG8uZ2V0RnVsbFllYXIoKTtcblx0XG4gIGlmKHNvY2lvLmVzQWN0aXZvKXJldHVybiBkYXRhQWN0aXZvcy52YWxvcjtcbiAgaWYoYW5vczw9MTgpIHJldHVybiBkYXRhUGFydGljaXBhbnRlcy52YWxvcjtcbiAgcmV0dXJuIGRhdGFBZGhlcmVudGVzLnZhbG9yO1xufVxuZnVuY3Rpb24gRGV1ZGFTb2Npb3MoZGV0YWxsZSwgZmVjaGEsZXNDdW90YVNvY2lhbCwgZXhjbHVpZG8pIHtcbiBcbiAgXG4gIFxuXG4gXG4gXG5cdFxufVxuLy8gdmFyIGRlPW5ldyBEZXVkYVNvY2lvcyhcIkNVT1RBIFNPQ0lBTFwiLCBuZXcgRGF0ZSgpLHRydWUsIFtdKTtcblx0XHQvL3ZhciBleGNsdWlyID0gZG9jLmFjdGl2aWRhZGVzRXhjbHVpciA/IGRvYy5hY3RpdmlkYWRlc0V4Y2x1aXIgOiBbXTtcbi8vICAgICBkZS5jYXJnYXJEZXVkYVNvY2lvcygpO1xuZ2V0SW1wb3J0ZVNvY2lvPWZ1bmN0aW9uKGlkU29jaW8pXG57XG4gIHZhciBkYXRhUGFydGljaXBhbnRlcz1TZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVQYXJ0aWNpcGFudGVzXCJ9KTtcbiAgICB2YXIgZGF0YUFkaGVyZW50ZXM9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJpbXBvcnRlQWRoZXJlbnRlc1wifSk7XG4gICAgdmFyIGRhdGFBY3Rpdm9zPVNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZUFjdGl2b3NcIn0pO1xuICBcbiAgdmFyIHNvY2lvPVNvY2lvcy5maW5kT25lKHtfaWQ6aWRTb2Npb30pO1xuICB2YXIgbmFjaW1pZW50bz1uZXcgRGF0ZShzb2Npby5mZWNoYU5hY2ltaWVudG8pO1xuICB2YXIgYWhvcmE9bmV3IERhdGUoKTtcbiAgdmFyIGFub3M9YWhvcmEuZ2V0RnVsbFllYXIoKS1uYWNpbWllbnRvLmdldEZ1bGxZZWFyKCk7XG5cdFxuICBpZihzb2Npby5lc0FjdGl2bylyZXR1cm4gZGF0YUFjdGl2b3MudmFsb3I7XG4gIGlmKGFub3M8PTE4KSByZXR1cm4gZGF0YVBhcnRpY2lwYW50ZXMudmFsb3I7XG4gIHJldHVybiBkYXRhQWRoZXJlbnRlcy52YWxvcjtcbn1cbiIsIi8qZXNsaW50LWRpc2FibGUgbm8tdW5yZWFjaGFibGUsIHNlbWksIG5vLXVuZGVmLCB1bmtub3duLXJlcXVpcmUsIG5vLWVtcHR5LWxhYmVsLCBuby1leHRyYS1zZW1pLCBuby11bnVzZWQtcGFyYW1zLFxuIGZvcmJpZGRlbkV4cG9ydEltcG9ydCwgbm8tdW51c2VkLXZhcnMqL1xuaW1wb3J0IHsgQXV4aWxpYXJlcyB9IGZyb20gXCIuL2Z1bmNpb25lc19hdXguanNcIjtcbnZhciBfQVVYPSBuZXcgQXV4aWxpYXJlcygpO1xuXHRGdXR1cmUgPSBOcG0ucmVxdWlyZSgnZmliZXJzL2Z1dHVyZScpO1xuXHRpbXBvcnQge1B5dGhvblNoZWxsfSBmcm9tICdweXRob24tc2hlbGwnO1xuXHR2YXIgZnMgPSBOcG0ucmVxdWlyZSgnZnMnKTtcbmV4cG9ydCBjbGFzcyBGdW5jaW9uZXNcbntcdFxuXHRhc3luYyBnZXRBcmNoaXZvcygpe1xuXHRcdCBBcmNoaXZvcy5yZW1vdmUoe30pIFxuXHRcdC8vIGNvbnNvbGUubG9nKEFyY2hpdm9zLmZpbmQoKS5mZXRjaCgpKVxuXHRcdF9BVVguY2FyZ2FySW1hZ2VuZXMoKTtcblx0XHRcblx0XG5cdH1cblx0ZWxpbWluYXJBbmNsYWplcygpXG5cdHtcblx0XHRBbmNsYWplcy5yZW1vdmUoe30pO1xuXHRcdEFyY2hpdm9zLnJlbW92ZSh7fSk7XG5cdH0gXG5cdGltcG9ydGFyQW5jbGFqZXMoKXtcblx0XG5cblx0XHR2YXIgZnV0MSA9IG5ldyBGdXR1cmUoKTtcblx0XHQvLyB2YXIgUHl0aG9uU2hlbGwgPSByZXF1aXJlKCdweXRob24tc2hlbGwnKTtcblx0XHR2YXIgYXJjaGkgPSAnLi9pbXBvcnRhckFuY2xhamVzLnB5Jztcblx0XHR2YXIgcGF0aCA9IHByb2Nlc3MuY3dkKCkgKyAnLy4uL3dlYi5icm93c2VyL2FwcC9zaGVsbFB5dGhvbic7XG5cdFx0dmFyIG9wdGlvbnMgPSB7IFxuXHRcdFx0bW9kZTogJ3RleHQnLFxuXHRcdFx0cHl0aG9uUGF0aDogJy91c3IvYmluL3B5dGhvbjInLFxuXHRcdFx0c2NyaXB0UGF0aDogcGF0aCxcblx0XHRcdGFyZ3M6IFtdXG5cdFx0fTtcblx0XHRQeXRob25TaGVsbC5ydW4oYXJjaGksIG9wdGlvbnMsIGZ1bmN0aW9uKGVyciwgcmVzKSB7XG5cdFx0XHRpZiAoZXJyKSB0aHJvdyBlcnI7XG5cdFx0XHQgcmV0dXJuIF9BVVguY2FyZ2FySW1hZ2VuZXMoZnV0MSk7XG5cdFx0XHRcblxuXHRcdH0pO1xuXHRcdHJldHVybiBmdXQxLndhaXQoKTtcblx0fVxuXHRcblx0Z2VuZXJhclZhcmlhYmxlcyAoKSB7XG5cdFx0Ly9TZXR0aW5ncy5yZW1vdmUoe30pO1xuICAgIFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcbiAgICBcdFx0XHRjbGF2ZTogXCJkYklueWVjY2lvblwiXG4gICAgXHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuICAgIFx0XHRjbGF2ZTogXCJkYklueWVjY2lvblwiLFxuICAgIFx0XHR2YWxvcjogXCJ1dGVzYVwiXG4gICAgXHR9KTtcbiAgICBcdGlmICghU2V0dGluZ3MuZmluZE9uZSh7XG4gICAgXHRcdFx0Y2xhdmU6IFwiY2xhdmVJbnllY2Npb25cIlxuICAgIFx0XHR9KSkgU2V0dGluZ3MuaW5zZXJ0KHtcbiAgICBcdFx0Y2xhdmU6IFwiY2xhdmVJbnllY2Npb25cIixcbiAgICBcdFx0dmFsb3I6IFwicGV0ZXJldGVcIiBcbiAgICBcdH0pO1xuICAgIFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcbiAgICBcdFx0XHRjbGF2ZTogXCJ1c3VhcmlvSW55ZWNjaW9uXCJcbiAgICBcdFx0fSkpIFNldHRpbmdzLmluc2VydCh7XG4gICAgXHRcdGNsYXZlOiBcInVzdWFyaW9JbnllY2Npb25cIixcbiAgICBcdFx0dmFsb3I6IFwiYWxlamFuZHJvXCJcbiAgICBcdH0pO1xuICAgIFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcbiAgICBcdFx0XHRjbGF2ZTogXCJob3N0SW55ZWNjaW9uXCJcbiAgICBcdFx0fSkpIFNldHRpbmdzLmluc2VydCh7XG4gICAgXHRcdGNsYXZlOiBcImhvc3RJbnllY2Npb25cIixcbiAgICBcdFx0dmFsb3I6IFwiMTM0LjIwOS4xNzUuMTU2XCJcbiAgICBcdH0pO1xuICAgIFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcbiAgICBcdFx0XHRjbGF2ZTogXCJjdWl0RW1wcmVzYVwiXG4gICAgXHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuICAgIFx0XHRjbGF2ZTogXCJjdWl0RW1wcmVzYVwiLFxuICAgIFx0XHR2YWxvcjogXCIzMDY3MDI1MTE0MDAwMVwiXG4gICAgXHR9KTtcblx0XHRpZiAoIVNldHRpbmdzLmZpbmRPbmUoe1xuXHRcdFx0XHRjbGF2ZTogXCJkYXRvc0NvbnRhY3RvXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwiZGF0b3NDb250YWN0b1wiLFxuXHRcdFx0dmFsb3I6IFwiZW1haWw6c3UgZW1haWwsIGRvbWljaWxpbzpzdURvbWljaWxpbyBvdHJvcyBkYXRvc1wiXG5cdFx0fSk7XG5cdFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcblx0XHRcdFx0Y2xhdmU6IFwiY2FkZW5hQ29uZXhpb25NYWlsXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwiY2FkZW5hQ29uZXhpb25NYWlsXCIsXG5cdFx0XHR2YWxvcjogXCJzbXRwOi8vVVNVQVJJTyU0MGdtYWlsLmNvbTpDTEFWRUBzbXRwLmdtYWlsLmNvbTo0NjUvXCJcblx0XHR9KTtcblx0XHRpZiAoIVNldHRpbmdzLmZpbmRPbmUoe1xuXHRcdFx0XHRjbGF2ZTogXCJwdW50b1ZlbnRhRGV1ZGFzXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwicHVudG9WZW50YURldWRhc1wiLFxuXHRcdFx0dmFsb3I6IFwiM1wiXG5cdFx0fSk7XG5cdFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcblx0XHRcdFx0Y2xhdmU6IFwiZm9sZGVyVXBsb2Fkc1wiXG5cdFx0XHR9KSkgU2V0dGluZ3MuaW5zZXJ0KHtcblx0XHRcdGNsYXZlOiBcImZvbGRlclVwbG9hZHNcIixcblx0XHRcdHZhbG9yOiBcIi92YXIvd3d3L3VwbG9hZHMvXCJcblx0XHR9KTtcblx0XHRpZiAoIVNldHRpbmdzLmZpbmRPbmUoe1xuXHRcdFx0XHRjbGF2ZTogXCJkZXNkZUhhc3RhSW1wb3J0YUFuY2xhamVcIlxuXHRcdFx0fSkpIFNldHRpbmdzLmluc2VydCh7XG5cdFx0XHRjbGF2ZTogXCJkZXNkZUhhc3RhSW1wb3J0YUFuY2xhamVcIixcblx0XHRcdHZhbG9yOiBcIjEsMTAwMFwiXG5cdFx0fSk7XG5cdFx0aWYgKCFTZXR0aW5ncy5maW5kT25lKHtcblx0XHRcdFx0Y2xhdmU6IFwibW9kb1NlcnZpZG9yXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwibW9kb1NlcnZpZG9yXCIsXG5cdFx0XHR2YWxvcjogXCJQUk9EVUNDSU9OXCJcblx0XHR9KTtcblx0XHRpZiAoIVNldHRpbmdzLmZpbmRPbmUoe1xuXHRcdFx0XHRjbGF2ZTogXCJub21icmVFbXByZXNhXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwibm9tYnJlRW1wcmVzYVwiLFxuXHRcdFx0dmFsb3I6IFwiTm9tYnJlIEZhbnRhc2lhXCJcblx0XHR9KTtcblx0XHRpZiAoIVNldHRpbmdzLmZpbmRPbmUoe1xuXHRcdFx0XHRjbGF2ZTogXCJwcm94TnJvUmVjaXZvRGV1ZGFzXCJcblx0XHRcdH0pKSBTZXR0aW5ncy5pbnNlcnQoe1xuXHRcdFx0Y2xhdmU6IFwicHJveE5yb1JlY2l2b0RldWRhc1wiLFxuXHRcdFx0dmFsb3I6IFwiMVwiXG5cdFx0fSk7XG5cdFx0XHRcblx0fVxuXHRnZXRIb3Jhc1BlcnNvbmFsKGlkTGlxdWlkYWNpb24saWRQZXJzb25hbClcblx0e1xuXHRcdHZhciB1bnc9eyBcdCR1bndpbmQ6ICB7IHBhdGg6IFwiJGhvcmFzXCIgfSB9XG5cdFx0dmFyIHByb3k9eyBcdCRwcm9qZWN0OiB7XG5cdFx0XHRcdF9pZDogXCIkaG9yYXMuX2lkXCIsXG5cdFx0XHRcdGlkTGlxdWlkYWNpb246XCIkX2lkXCIsXG5cdFx0XHRcdGRpYTpcIiRob3Jhcy5kaWFcIixcblx0XHRcdFx0dGlwb0hvcmE6XCIkaG9yYXMudGlwb0hvcmFcIixcblx0XHRcdFx0Y2FudGlkYWQ6XCIkaG9yYXMuY2FudGlkYWRcIixcblx0XHRcdFx0dmlhbmRhczpcIiRob3Jhcy52aWFuZGFzXCIsXG5cdFx0XHRcdGlkUGVyc29uYWw6XCIkaG9yYXMuaWRQZXJzb25hbFwiLFxuXHRcdFx0XHRpZEhvcmE6XCIkaG9yYXMuX2lkXCIsXG5cdFx0XHR9XG5cdFx0fTtcblx0XHR2YXIgbWF0Y2g9e1xuXHRcdFx0JG1hdGNoOiB7XG5cdFx0XHRcdGlkTGlxdWlkYWNpb246IGlkTGlxdWlkYWNpb24sXG5cdFx0XHRcdGlkUGVyc29uYWw6IGlkUGVyc29uYWwsXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHZhciByYXcgPSBQZXJzb25hbExpcXVpZGFjaW9uZXMucmF3Q29sbGVjdGlvbigpO1xuXHRcdHZhciBxID0gTWV0ZW9yLndyYXBBc3luYyhyYXcuYWdncmVnYXRlLCByYXcpXG5cdFx0cmV0dXJuIHEoWyB1bncsIHByb3ksbWF0Y2ggXSkudG9BcnJheSgpO1xuXHR9XG5cdGdldERhdGFTZWxlY2Npb24oY29sZWNjaW9uLGlkKVxuXHR7XG5cdFx0dmFyIENvbGVjY2lvbj1ldmFsKGNvbGVjY2lvbik7XG5cdFx0cmV0dXJuIENvbGVjY2lvbi5maW5kT25lKHtfaWQ6aWR9KTtcblx0fVxuXHRnZXRQZXJzb25hbExpcXVpZGFjaW9uKGlkTGlxdWlkYWNpb24pXG5cdHtcblx0XHR2YXIgbGlxdT1QZXJzb25hbExpcXVpZGFjaW9uZXMuZmluZE9uZSh7X2lkOmlkTGlxdWlkYWNpb259KTtcblx0XHRpZihsaXF1KXtcblx0XHRcdHJldHVybiBQZXJzb25hbC5maW5kKHt0aXBvUGVyc29uYWw6bGlxdS50aXBvUGVyc29uYWwsZXN0YWRvOlwiQUxUQVwifSkuZmV0Y2goKTtcblx0XHR9XG5cdFx0cmV0dXJuIFtdXG5cdH1cblx0YnVzY2FyUGVyc29uYWxBY2NpZGVudGVzKGlkUGVyc29uYWwpXG5cdHtcblx0XHR2YXIgZGF0YT1QZXJzb25hbC5maW5kT25lKHtfaWQ6aWRQZXJzb25hbH0pO1xuXHRcdGlmKGRhdGEpXG5cdFx0XHRpZihkYXRhLmFjY2lkZW50ZXMpcmV0dXJuIGRhdGEuYWNjaWRlbnRlcztcblx0XHRyZXR1cm4gW107XG5cdH1cblx0cXVpdGFySXRlbUdlbmVyaWNvKGNvbGVjY2lvbixpZCxzdWJjb2xlY2Npb24saWRTdWJDb2xlY2Npb24pXG5cdHtcblx0XHRcblx0XHR2YXIgQ29sZWNjaW9uPWV2YWwoY29sZWNjaW9uKTtcblx0XHRpZihzdWJjb2xlY2Npb24pe1xuXHRcdFx0dmFyIHJlcyA9IENvbGVjY2lvbi51cGRhdGUoXG5cdFx0ICAgIHtfaWQ6IGlkIH0sIFxuXHRcdCAgICB7ICRwdWxsOiB7IFtzdWJjb2xlY2Npb25dOiB7IFwiX2lkXCI6IGlkU3ViQ29sZWNjaW9uIH0gfSB9LFxuXHRcdCAgICB7IGdldEF1dG9WYWx1ZXM6IGZhbHNlIH0gLy8gU0lOIEVTVEUgUEFSQU1FVFJPIE5PIFFVSVRBISFcblx0XHQgICAgKVxuXHRcdH1lbHNle1xuXG5cdFx0fVxuXHRcdHZhciBhdXg9IENvbGVjY2lvbi5maW5kT25lKHtfaWQ6aWR9KTtcblx0XHRjb25zb2xlLmxvZyhhdXhbc3ViY29sZWNjaW9uXSlcblx0XHRyZXR1cm4gYXV4W3N1YmNvbGVjY2lvbl07XG5cdH1cblx0XCJidXNjYXJPYnNlcnZhY2lvbmVzQW5jbGFqZVwiKGlkQW5jbGFqZSlcblx0e1xuXHRcdHZhciBkYXRhPUFuY2xhamVzLmZpbmRPbmUoe19pZDppZEFuY2xhamV9KTtcblx0XHRjb25zb2xlLmxvZyhkYXRhLGlkQW5jbGFqZSlcblx0XHRpZihkYXRhKVxuXHRcdFx0aWYoZGF0YS5vYnNlcnZhY2lvbmVzKXJldHVybiBkYXRhLm9ic2VydmFjaW9uZXM7XG5cdFx0cmV0dXJuIFtdO1xuXHR9XG5cdGxvZ2luVXNlciAoZGF0YSkge1xuXHRcdC8vIE1ldGVvci5jYWxsKCdsb2dpblVzZXInLHtlbWFpbDogXCJ2eHh4eHhAeHh4eC5jb21cIixwYXNzd29yZDogXCIxMjM0NTZcIn0sIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuXHRcdC8vICAgICAgaWYoIWVycm9yKSBNZXRlb3IubG9naW5XaXRoVG9rZW4ocmVzdWx0LnRva2VuKTtcblx0XHQvLyB9KTtcblx0XHRjb25zb2xlLmxvZyhkYXRhKTtcblx0XHR2YXIgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHtcblx0XHRcdCdlbWFpbHMuYWRkcmVzcyc6IGRhdGEuZW1haWxcblx0XHR9KTtcblx0XHRpZiAodXNlcikge1xuXHRcdFx0dmFyIHBhc3N3b3JkID0gZGF0YS5wYXNzd29yZDtcblx0XHRcdHZhciByZXN1bHQgPSBBY2NvdW50cy5fY2hlY2tQYXNzd29yZCh1c2VyLCBwYXNzd29yZCk7XG5cdFx0XHRjb25zb2xlLmxvZyhyZXN1bHQpO1xuXHRcdFx0aWYgKHJlc3VsdC5lcnJvcikge1xuXHRcdFx0XHRyZXR1cm4gcmVzdWx0LmVycm9yO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXJyb3I6IFwidXNlciBub3QgZm91bmRcIlxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHQgdXNlclVwZGF0ZSAoZG9jKSB7XG5cdFx0Y29uc29sZS5sb2coZG9jKVxuXHRcdE1ldGVvci51c2Vycy51cGRhdGUoe19pZDpkb2MuX2lkfSx7JHNldDpkb2N9KTtcblx0XHRjb25zb2xlLmxvZyhNZXRlb3IudXNlcnMuZmluZCgpLmZldGNoKCkpXG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdCB1c2VySW5zZXJ0IChkb2MpIHtcblx0XHRjb25zb2xlLmxvZyhkb2MpXG5cdFx0aWQgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHtcblx0XHRcdHVzZXJuYW1lOiBkb2MudXNlcm5hbWUsXG5cdFx0XHRwYXNzd29yZDogZG9jLnBhc3N3b3JkLFxuXHRcdFx0cHJvZmlsZTogZG9jLnByb2ZpbGVcblx0XHR9KTtcblx0XHRjb25zb2xlLmxvZyhNZXRlb3IudXNlcnMuZmluZCgpLmZldGNoKCkpXG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdCB1c3VhcmlvcyAoKSB7XG5cdFx0dmFyIHJlcyA9IE1ldGVvci51c2Vycy5maW5kKCkuZmV0Y2goKTtcblx0XHRjb25zb2xlLmxvZyhyZXMpO1xuXHRcdHJldHVybiByZXM7XG5cdH1cblx0IG1vZGlmaWNhckNsYXZlIChpZCwgY2xhdmUpIHtcblx0XHR2YXIgcmVzID0gQWNjb3VudHMuc2V0UGFzc3dvcmQoaWQsIGNsYXZlLCB7XG5cdFx0XHRsb2dvdXQ6IGZhbHNlXG5cdFx0fSk7XG5cdFx0Y29uc29sZS5sb2cocmVzKVxuXHRcdGNvbnNvbGUubG9nKGlkKVxuXHRcdGNvbnNvbGUubG9nKGNsYXZlKVxuXHR9XG5cdCB1c2VyUmVtb3ZlIChpZCkge1xuXG5cdFx0TWV0ZW9yLnVzZXJzLnJlbW92ZShpZCk7XG5cblx0XHRyZXR1cm4gaWQ7XG5cdH1cblx0XG5cbn1cblxuIiwiLy8qKioqKioqKioqKioqKioqKioqKioqKioqIEZVTkNJT05FUyBBVVggKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqLy9cbi8qZXNsaW50LWRpc2FibGUgbm8tdW5kZWYsIHNlbWksIHNlbWksIGVxZXFlcSwgbm8tdW5kZWYsIG5vLXVucmVhY2hhYmxlLCB1bmtub3duLXJlcXVpcmUsIGZvcmJpZGRlbkV4cG9ydEltcG9ydCwgbm8tdW51c2VkLXZhcnMsIG5vLWVtcHR5LWxhYmVsLCBmb3JiaWRkZW5FeHBvcnRJbXBvcnQqL1xuICAgIGltcG9ydCBcIi4uL2xpYi91dGlscy5qc1wiO1xudmFyIGV4ZWMgPSBOcG0ucmVxdWlyZSgnY2hpbGRfcHJvY2VzcycpLmV4ZWM7XG52YXIgRmliZXIgPSBOcG0ucmVxdWlyZSgnZmliZXJzJyk7XG52YXIgRnV0dXJlID0gTnBtLnJlcXVpcmUoJ2ZpYmVycy9mdXR1cmUnKTtcbnZhciBmcyA9IE5wbS5yZXF1aXJlKCdmcycpO1xuY29uc3QgZmV0Y2ggPSBOcG0ucmVxdWlyZSgnbm9kZS1mZXRjaCcpO1xuXG5leHBvcnQgY2xhc3MgQXV4aWxpYXJlcyB7XG5cbmFzeW5jIGNhcmdhSW1hZ2VuKGFyY2hpdm8saWQpXG57XG5cdGNvbnN0IGh0dHAgPSByZXF1aXJlKFwiaHR0cFwiKTtcblx0dmFyIHBhdGg9XCJodHRwOi8vYXBwaWJlcm8ueWF2dS5jb20uYXIvamF2aWVyL2FyY2hpdm9zL1wiK2lkK1wiL1wiK2FyY2hpdm87XG5jb25zdCBmaWxlID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0oYXJjaGl2byk7XG5jb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHBhdGgpO1xuICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuYnVmZmVyKCk7XG4gICBBcmNoaXZvcy53cml0ZShkYXRhLCB7XG4gICAgICBmaWxlTmFtZTogYXJjaGl2byxcbiAgICAgIGZpZWxJZDogaWQsIC8vb3B0aW9uYWxcbiAgICB9LCBmdW5jdGlvbiAod3JpdGVFcnJvciwgZmlsZVJlZikge1xuICAgICAgaWYgKHdyaXRlRXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd3JpdGVFcnJvcjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICBcdEFuY2xhamVzLnVwZGF0ZSh7X2lkOmlkfSx7JHNldDp7Y2VydGlmaWNhZG86ZmlsZVJlZi5faWR9fSlcbiAgICAgICAgY29uc29sZS5sb2coZmlsZVJlZi5uYW1lICsgJyBpcyBzdWNjZXNzZnVsbHkgc2F2ZWQgdG8gRlMuIF9pZDogJyArIGZpbGVSZWYuX2lkKTtcbiAgICAgIH1cbiAgICB9KTtcbi8vIHRyeXtcbi8vIGF3YWl0IGh0dHAuZ2V0KCwgcmVzcG9uc2UgPT4ge1xuLy8gICByZXNwb25zZS5waXBlKGZpbGUpO1xuLy8gICB2YXIgZGF0YT0gZnMucmVhZEZpbGVTeW5jKGFyY2hpdm8pXG5cbi8vICAgZnMucmVhZEZpbGUoYXJjaGl2bywgZnVuY3Rpb24gKGVycm9yLCBkYXRhKSB7XG4vLyAgIGlmIChlcnJvcikge1xuLy8gICAgIHRocm93IGVycm9yO1xuLy8gICB9IGVsc2Uge1xuICAgIC8vICBBcmNoaXZvcy53cml0ZShkYXRhLCB7XG4gICAgLy8gICBmaWxlTmFtZTogYXJjaGl2byxcbiAgICAvLyAgIGZpZWxJZDogaWQsIC8vb3B0aW9uYWxcbiAgICAvLyB9LCBmdW5jdGlvbiAod3JpdGVFcnJvciwgZmlsZVJlZikge1xuICAgIC8vICAgaWYgKHdyaXRlRXJyb3IpIHtcbiAgICAvLyAgICAgdGhyb3cgd3JpdGVFcnJvcjtcbiAgICAvLyAgIH0gZWxzZSB7XG4gICAgLy8gICAgIGNvbnNvbGUubG9nKGZpbGVSZWYubmFtZSArICcgaXMgc3VjY2Vzc2Z1bGx5IHNhdmVkIHRvIEZTLiBfaWQ6ICcgKyBmaWxlUmVmLl9pZCk7XG4gICAgLy8gICB9XG4gICAgLy8gfSk7XG4vLyAgIH1cbi8vIH0pO1xuXG4vLyB9KTtcbi8vIH1jYXRjaCAoZXJyKXtcbi8vIFx0Y29uc29sZS5sb2coXCJubyBlbmN1ZW50cm9cIilcbi8vIH1cbn1cbmFzeW5jIGNhcmdhckltYWdlbmVzKGZ1dDEpeyBcblxudmFyIHBhdGg9XCJodHRwOi8vYXBwaWJlcm8ueWF2dS5jb20uYXIvamF2aWVyL2FyY2hpdm9zL1wiO1xuLy8gQXJjaGl2b3MucmVtb3ZlKHt9KVxuLy8gcmV0dXJuO1xudmFyIGE9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6IFwiZGVzZGVIYXN0YUltcG9ydGFBbmNsYWplXCJ9KS52YWxvci5zcGxpdChcIixcIik7XG52YXIgZGVzZGU9YVswXSoxO1xudmFyIGhhc3RhPWFbMV0qMTtcbnZhciBjYW50aWRhZEltYWdlbmVzPTA7XG5jb25zb2xlLmxvZyhcIkRFU0RFOiBcIitkZXNkZStcIiBIU1RBOiBcIitoYXN0YSlcbmZvciAodmFyIGkgPSBkZXNkZTsgaSA8IGhhc3RhOyBpKyspIHtcblx0dmFyIGF1eD1hd2FpdCBBbmNsYWplcy5maW5kT25lKHtfaWQ6KGkrXCJcIil9KSBcblx0aWYoYXV4KXtcblx0XHRjYW50aWRhZEltYWdlbmVzKys7XG5cdFx0dmFyIGFyY2hpdm89aStcIl8xLnBkZlwiO1xuXHRcdGF3YWl0IHRoaXMuY2FyZ2FJbWFnZW4oYXJjaGl2byxpK1wiXCIpXG5cdFx0XG5cdH1cblx0XG59XG5mdXQxLnJldHVybihjYW50aWRhZEltYWdlbmVzKyBcImltYWdlbmVzIGNhcmdhZGFzXCIpIFxuIC8vIGNvbnNvbGUubG9nKEFyY2hpdm9zLmZpbmQoKS5mZXRjaCgpKVxuXHR9XG5cblxufVxuXG5cbiBcbi8vZ2V0VG90YWxEZWJpdG9zQXV0b21hdGljb3MoMjAxNyxudWxsLG51bGwsbnVsbCk7XG5cblxuLy8gZGIuc29jaW9zLmFnZ3JlZ2F0ZShbeyR1bndpbmQ6IFwiJGNhbWJpb3NFc3RhZG9cIn0seyRwcm9qZWN0OntfaWQ6MSxlc3RhZG86XCIkZXN0YWRvXCIsYW5vOnskeWVhcjpcIiRjYW1iaW9zRXN0YWRvLmZlY2hhXCJ9LG1lczp7JG1vbnRoOlwiJGNhbWJpb3NFc3RhZG8uZmVjaGFcIn0sbm9tYnJlOlwiJG5vbWJyZVwiLGFwZWxsaWRvOlwiJGFwZWxsaWRvXCIsdG90YWw6MSxlZGFkOiB7XG4vLyAgICAgICAgICAgICAgICAgICRkaXZpZGU6IFt7JHN1YnRyYWN0OiBbIG5ldyBEYXRlKCksIFwiJGZlY2hhTmFjaW1pZW50b1wiIF0gfSwgXG4vLyAgICAgICAgICAgICAgICAgICAgICgzNjUgKiAyNCo2MCo2MCoxMDAwKV1cbi8vICAgICAgICAgICAgIH0sZXNBY3Rpdm86XCIkZXNBY3Rpdm9cIn19LHskbWF0Y2g6e2VkYWQ6eyRndGU6MjB9LGVzdGFkbzpcIkFMVEFcIixhbm86MjAxNyxtZXM6MTF9fSx7JGdyb3VwOiB7X2lkOiBudWxsLHRvdGFsOnskc3VtOjF9fX1dKVxuXG5cblxuLy8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqRlVOQ0lPTkVTIEFVWCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi8vIiwiTWV0ZW9yLnB1Ymxpc2hDb21wb3NpdGUoXCJhbmNsYWplc1B1Ymxpc2hcIiwgZnVuY3Rpb24gKHRhYmxlTmFtZSwgaWRzLCBmaWVsZHMpIHtcbiAgLy8gY2hlY2sodGFibGVOYW1lLCBTdHJpbmcpO1xuICAvLyBjaGVjayhpZHMsIEFycmF5KTtcbiAgLy8gY2hlY2soZmllbGRzLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcblxuICAvLyB0aGlzLnVuYmxvY2soKTsgLy8gcmVxdWlyZXMgbWV0ZW9yaGFja3M6dW5ibG9jayBwYWNrYWdlXG5cbiAgcmV0dXJuIHtcbiAgICBmaW5kOiBmdW5jdGlvbiAoKSB7XG4gICAgICAvLyB0aGlzLnVuYmxvY2soKTsgLy8gcmVxdWlyZXMgbWV0ZW9yaGFja3M6dW5ibG9jayBwYWNrYWdlXG5cbiAgICAgIC8vIGNoZWNrIGZvciBhZG1pbiByb2xlIHdpdGggYWxhbm5pbmc6cm9sZXMgcGFja2FnZVxuICAgICAgLy8gaWYgKCFSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdhZG1pbicpKSB7XG4gICAgICAvLyAgIHJldHVybiBbXTtcbiAgICAgIC8vIH1cbiAgICAgIHZhciBtb2Q9Z2V0TW9kdWxvMihcIkFuY2xhamVzXCIpO1xuXG4gICAgICBpZihtb2Qpe1xuICAgICAgICBcbiAgICAgICAgaWYobW9kLmhhc093blByb3BlcnR5KFwic29sb1Zlck1pb3NcIikpe1xuICAgICAgICAgIFxuICAgICAgICAgIGlmKG1vZC5zb2xvVmVyTWlvcyl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhNZXRlb3IudXNlcigpLl9pZClcbiAgICAgICAgICAgIHJldHVybiBBbmNsYWplcy5maW5kKHtfaWQ6IHskaW46IGlkc319LCB7aWRVc3VhcmlvOlwiMmdhMzdyZHg1N3NHR0xEN2ZcIn0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFtdO1xuICAgICAgXG4gICAgfSxcbiAgICBjaGlsZHJlbjogW1xuICAgICAge1xuICAgICAgICBmaW5kOiBmdW5jdGlvbihmZWVkYmFjaykge1xuICAgICAgICAgIC8vIHRoaXMudW5ibG9jaygpOyAvLyByZXF1aXJlcyBtZXRlb3JoYWNrczp1bmJsb2NrIHBhY2thZ2VcbiAgICAgICAgICAvLyBQdWJsaXNoIHRoZSByZWxhdGVkIHVzZXJcbiAgICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe19pZDogZmVlZGJhY2sudXNlcklkfSwge2xpbWl0OiAxLCBmaWVsZHM6IHtlbWFpbHM6IDF9LCBzb3J0OiB7X2lkOiAxfX0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgXVxuICB9O1xufSk7IiwiU3RyaW5nLnByb3RvdHlwZS5scGFkID0gZnVuY3Rpb24ocGFkU3RyaW5nLCBsZW5ndGgpIHtcbiAgICB2YXIgc3RyID0gdGhpcztcbiAgICB3aGlsZSAoc3RyLmxlbmd0aCA8IGxlbmd0aClcbiAgICAgICAgc3RyID0gcGFkU3RyaW5nICsgc3RyO1xuICAgIHJldHVybiBzdHI7XG59XG5cbkVEQURfQURIRVJFTlRFPTIwO1xuZ2V0Q2xhc2VUaXBvU29jaW89ZnVuY3Rpb24oZmVjaGFOYWMsZXNBY3Rpdm8pe1xuXHR2YXIgdGlwbz1nZXRUaXBvU29jaW8oZmVjaGFOYWMsZXNBY3Rpdm8pO1xuXHR2YXIgY2xhc2U9dGlwbz09PVwiUEFSVElDSVBBTlRFXCI/XCJ0ZXh0LXdhcm5pbmdcIjpcInRleHQtaW5mb1wiO1xuXHRcdGlmKHRpcG89PT1cIkFDVElWT1wiKWNsYXNlPVwidGV4dC1kYW5nZXJcIjtcblx0cmV0dXJuIGNsYXNlO1xufVxuZ2V0RWRhZFNvY2lvPWZ1bmN0aW9uKGZlY2hhTmFjKXtcblx0dmFyIG5hY2ltaWVudG89bmV3IERhdGUoZmVjaGFOYWMpO1xuICAgdmFyIGFob3JhPW5ldyBEYXRlKCk7XG5cdCB2YXIgYW5vcz1haG9yYS5nZXRGdWxsWWVhcigpLW5hY2ltaWVudG8uZ2V0RnVsbFllYXIoKTtcbiAgIHJldHVybiBhbm9zO1xufVxuZ2V0VGlwb1NvY2lvPWZ1bmN0aW9uKGZlY2hhTmFjLGVzQWN0aXZvKXtcblx0IHZhciBuYWNpbWllbnRvPW5ldyBEYXRlKGZlY2hhTmFjKTtcbiAgIHZhciBhaG9yYT1uZXcgRGF0ZSgpO1xuXHQgdmFyIGFub3M9YWhvcmEuZ2V0RnVsbFllYXIoKS1uYWNpbWllbnRvLmdldEZ1bGxZZWFyKCk7XG5cdGlmKGVzQWN0aXZvKXJldHVybiBcIkFDVElWT1wiO1xuICAgcmV0dXJuIGFub3M8RURBRF9BREhFUkVOVEU/XCJQQVJUSUNJUEFOVEVcIjpcIkFESEVSRU5URVwiO1xufVxuZ2V0SW1wb3J0ZVNvY2lvPWZ1bmN0aW9uKGlkU29jaW8pXG57XG4gIHZhciBkYXRhUGFydGljaXBhbnRlcz1TZXR0aW5ncy5maW5kT25lKHtjbGF2ZTpcImltcG9ydGVQYXJ0aWNpcGFudGVzXCJ9KTtcbiAgICB2YXIgZGF0YUFkaGVyZW50ZXM9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJpbXBvcnRlQWRoZXJlbnRlc1wifSk7XG4gICAgdmFyIGRhdGFBY3Rpdm9zPVNldHRpbmdzLmZpbmRPbmUoe2NsYXZlOlwiaW1wb3J0ZUFjdGl2b3NcIn0pO1xuICBcbiAgdmFyIHNvY2lvPVNvY2lvcy5maW5kT25lKHtfaWQ6aWRTb2Npb30pO1xuICB2YXIgbmFjaW1pZW50bz1uZXcgRGF0ZShzb2Npby5mZWNoYU5hY2ltaWVudG8pO1xuICB2YXIgYWhvcmE9bmV3IERhdGUoKTtcbiAgdmFyIGFub3M9YWhvcmEuZ2V0RnVsbFllYXIoKS1uYWNpbWllbnRvLmdldEZ1bGxZZWFyKCk7XG5cdFxuICBpZihzb2Npby5lc0FjdGl2bylyZXR1cm4gZGF0YUFjdGl2b3MudmFsb3I7XG4gIGlmKGFub3M8RURBRF9BREhFUkVOVEUpIHJldHVybiBkYXRhUGFydGljaXBhbnRlcy52YWxvcjtcbiAgcmV0dXJuIGRhdGFBZGhlcmVudGVzLnZhbG9yO1xufVxubW9kdWxlLmV4cG9ydHM9Z2V0VGlwb1NvY2lvOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuIFxuaW1wb3J0IFwiLi9mdW5jaW9uZXMuanNcIjtcbmltcG9ydCB7IEZ1bmNpb25lcyB9IGZyb20gXCIuL2Z1bmNpb25lcy5qc1wiO1xuICBjb25zdCBib2R5UGFyc2VyID0gcmVxdWlyZSgnYm9keS1wYXJzZXInKTtcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKGJvZHlQYXJzZXIudXJsZW5jb2RlZCh7ZXh0ZW5kZWQ6IGZhbHNlfSkpXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3NldEZvdG9QZXJmaWwnLCBib2R5UGFyc2VyLnVybGVuY29kZWQoKSk7XG5cbnZhciBzZXRpbmc9U2V0dGluZ3MuZmluZE9uZSh7Y2xhdmU6XCJjYWRlbmFDb25leGlvbk1haWxcIn0pO1xudmFyIHZhbG9yTWFpbD1zZXRpbmc/c2V0aW5nLnZhbG9yOlwiXCI7XG5cbnByb2Nlc3MuZW52Lk1BSUxfVVJMPXZhbG9yTWFpbDtcblxuLy9EQVRPUyBERSBMQSBCQVNFIERFIERBVE9TISEhIS8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cdG5vbWJyZUJhc2U9XCJhcHBDYWlcIjtcbnB1ZXJ0b0Jhc2U9XCIyNzAxN1wiO1xuXHQvL0RBVE9TIERFIExBIEJBU0UgREUgREFUT1MhISEhLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbm1lc0xldHJhcz1mdW5jdGlvbihtZXMpXG57IFxuICBpZihtZXM9PTEpcmV0dXJuIFwiRU5FUk9cIjtcbiAgaWYobWVzPT0yKXJldHVybiBcIkZFQlJFUk9cIjsgXG4gIGlmKG1lcz09MylyZXR1cm4gXCJNQVJaT1wiOyBcbiAgaWYobWVzPT00KXJldHVybiBcIkFCUklMXCI7XG4gIGlmKG1lcz09NSlyZXR1cm4gXCJNQVlPXCI7XG4gIGlmKG1lcz09NilyZXR1cm4gXCJKVU5JT1wiO1xuICBpZihtZXM9PTcpcmV0dXJuIFwiSlVMSU9cIjtcbiAgaWYobWVzPT04KXJldHVybiBcIkFHT1NUT1wiO1xuICBpZihtZXM9PTkpcmV0dXJuIFwiU0VQVEVNQlJFXCI7XG4gIGlmKG1lcz09MTApcmV0dXJuIFwiT0NUVUJSRVwiO1xuICBpZihtZXM9PTExKXJldHVybiBcIk5PVklFTUJSRVwiO1xuICBpZihtZXM9PTEyKXJldHVybiBcIkRJQ0lFTUJSRVwiO1xuICByZXR1cm4gXCJzL2FcIjtcbn1cbnZhciBmPW5ldyBGdW5jaW9uZXMoKTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBcImVsaW1pbmFyQW5jbGFqZXNcIjpmLmVsaW1pbmFyQW5jbGFqZXMsXG4gIFwiaW1wb3J0YXJBbmNsYWplc1wiOmYuaW1wb3J0YXJBbmNsYWplcyxcbiAgXCJnZXRIb3Jhc1BlcnNvbmFsXCI6Zi5nZXRIb3Jhc1BlcnNvbmFsLFxuICBcImdldEFyY2hpdm9zXCI6Zi5nZXRBcmNoaXZvcyxcbiAgXCJnZXREYXRhU2VsZWNjaW9uXCI6Zi5nZXREYXRhU2VsZWNjaW9uLFxuICBcImdldFBlcnNvbmFsTGlxdWlkYWNpb25cIjpmLmdldFBlcnNvbmFsTGlxdWlkYWNpb24sXG4gIFwicXVpdGFySXRlbUdlbmVyaWNvXCI6Zi5xdWl0YXJJdGVtR2VuZXJpY28sXG5cdFwiYnVzY2FyUGVyc29uYWxBY2NpZGVudGVzXCI6Zi5idXNjYXJQZXJzb25hbEFjY2lkZW50ZXMsXG4gIFwiYnVzY2FyT2JzZXJ2YWNpb25lc0FuY2xhamVcIjpmLmJ1c2Nhck9ic2VydmFjaW9uZXNBbmNsYWplLFxuXHRcImxvZ2luVXNlclwiOiBmLmxvZ2luVXNlcixcblx0XCJ1c2VySW5zZXJ0XCI6IGYudXNlckluc2VydCxcbiAgXCJ1c2VyVXBkYXRlXCI6Zi51c2VyVXBkYXRlLFxuXHRcInVzdWFyaW9zXCI6Zi51c3VhcmlvcyAsXG5cdFwibW9kaWZpY2FyQ2xhdmVcIjogZi5tb2RpZmljYXJDbGF2ZSxcblx0XCJ1c2VyUmVtb3ZlXCI6Zi51c2VyUmVtb3ZlICxcbiAgXCJnZW5lcmFyVmFyaWFibGVzXCI6Zi5nZW5lcmFyVmFyaWFibGVzICxcbn0pOyBcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuIFxuICAgTWV0ZW9yLnB1Ymxpc2goJ1NldHRpbmdzJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gU2V0dGluZ3MuZmluZCgpO1xufSk7IFxuICAgXG4gICBNZXRlb3IucHVibGlzaCgnQW5jbGFqZXMnLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBnZXRDb2xlY2Npb25QZXJmaWwoXCJBbmNsYWplc1wiKTtcbn0pO1xuICAgIE1ldGVvci5wdWJsaXNoKCdBbmNsYWplc0VxdWlwb3MnLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBnZXRDb2xlY2Npb25QZXJmaWwoXCJBbmNsYWplc0VxdWlwb3NcIik7XG59KTtcbiAgICAgIE1ldGVvci5wdWJsaXNoKCdBcmNoaXZvcycsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIEFyY2hpdm9zLmZpbmQoKTtcbn0pO1xuICAgICAgXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdQZXJzb25hbCcsIGZ1bmN0aW9uKCl7XG4gICAgIHJldHVybiBnZXRDb2xlY2Npb25QZXJmaWwoXCJQZXJzb25hbFwiKTtcbn0pO1xuICAgICAgICAgIE1ldGVvci5wdWJsaXNoKCdQZXJzb25hbExpcXVpZGFjaW9uZXMnLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgcmV0dXJuIGdldENvbGVjY2lvblBlcmZpbChcIlBlcnNvbmFsTGlxdWlkYWNpb25lc1wiKTtcblxufSk7XG4gICAgICAgICAgIE1ldGVvci5wdWJsaXNoKCdUaXBvUGVyZmlsZXMnLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBUaXBvUGVyZmlsZXMuZmluZCgpO1xufSk7XG5cbiBcbiBcbn0pO1xuIl19
