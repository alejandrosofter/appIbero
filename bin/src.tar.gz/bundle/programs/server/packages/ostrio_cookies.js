(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:cookies":{"cookies.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ostrio_cookies/cookies.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Cookies: () => Cookies
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
let WebApp;

if (Meteor.isServer) {
  WebApp = require('meteor/webapp').WebApp;
} else {
  HTTP = require('meteor/http').HTTP;
}

const NoOp = () => {};

const urlRE = /\/___cookie___\/set/;
const rootUrl = Meteor.isServer ? process.env.ROOT_URL : window.__meteor_runtime_config__.ROOT_URL || window.__meteor_runtime_config__.meteorEnv.ROOT_URL || false;
const mobileRootUrl = Meteor.isServer ? process.env.MOBILE_ROOT_URL : window.__meteor_runtime_config__.MOBILE_ROOT_URL || window.__meteor_runtime_config__.meteorEnv.MOBILE_ROOT_URL || false;
const helpers = {
  isUndefined(obj) {
    return obj === void 0;
  },

  isArray(obj) {
    return Array.isArray(obj);
  },

  clone(obj) {
    if (!this.isObject(obj)) return obj;
    return this.isArray(obj) ? obj.slice() : Object.assign({}, obj);
  }

};
const _helpers = ['Number', 'Object', 'Function'];

for (let i = 0; i < _helpers.length; i++) {
  helpers['is' + _helpers[i]] = function (obj) {
    return Object.prototype.toString.call(obj) === '[object ' + _helpers[i] + ']';
  };
}
/*
 * @url https://github.com/jshttp/cookie/blob/master/index.js
 * @name cookie
 * @author jshttp
 * @license
 * (The MIT License)
 *
 * Copyright (c) 2012-2014 Roman Shtylman <shtylman@gmail.com>
 * Copyright (c) 2015 Douglas Christopher Wilson <doug@somethingdoug.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * 'Software'), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


const decode = decodeURIComponent;
const encode = encodeURIComponent;
const pairSplitRegExp = /; */;
/*
 * RegExp to match field-content in RFC 7230 sec 3.2
 *
 * field-content = field-vchar [ 1*( SP / HTAB ) field-vchar ]
 * field-vchar   = VCHAR / obs-text
 * obs-text      = %x80-FF
 */

const fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
/*
 * @function
 * @name tryDecode
 * @param {String} str
 * @param {Function} d
 * @summary Try decoding a string using a decoding function.
 * @private
 */

const tryDecode = (str, d) => {
  try {
    return d(str);
  } catch (e) {
    return str;
  }
};
/*
 * @function
 * @name parse
 * @param {String} str
 * @param {Object} [options]
 * @return {Object}
 * @summary
 * Parse a cookie header.
 * Parse the given cookie header string into an object
 * The object has the various cookies as keys(names) => values
 * @private
 */


const parse = (str, options) => {
  if (typeof str !== 'string') {
    throw new Meteor.Error(404, 'argument str must be a string');
  }

  const obj = {};
  const opt = options || {};
  let val;
  let key;
  let eqIndx;
  str.split(pairSplitRegExp).forEach(pair => {
    eqIndx = pair.indexOf('=');

    if (eqIndx < 0) {
      return;
    }

    key = pair.substr(0, eqIndx).trim();
    key = tryDecode(unescape(key), opt.decode || decode);
    val = pair.substr(++eqIndx, pair.length).trim();

    if (val[0] === '"') {
      val = val.slice(1, -1);
    }

    if (void 0 === obj[key]) {
      obj[key] = tryDecode(val, opt.decode || decode);
    }
  });
  return obj;
};
/*
 * @function
 * @name antiCircular
 * @param data {Object} - Circular or any other object which needs to be non-circular
 * @private
 */


const antiCircular = _obj => {
  const object = helpers.clone(_obj);
  const cache = new Map();
  return JSON.stringify(object, (key, value) => {
    if (typeof value === 'object' && value !== null) {
      if (cache.get(value)) {
        return void 0;
      }

      cache.set(value, true);
    }

    return value;
  });
};
/*
 * @function
 * @name serialize
 * @param {String} name
 * @param {String} val
 * @param {Object} [options]
 * @return { cookieString: String, sanitizedValue: Mixed }
 * @summary
 * Serialize data into a cookie header.
 * Serialize the a name value pair into a cookie string suitable for
 * http headers. An optional options object specified cookie parameters.
 * serialize('foo', 'bar', { httpOnly: true }) => "foo=bar; httpOnly"
 * @private
 */


const serialize = function (key, val) {
  let opt = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  let name;

  if (!fieldContentRegExp.test(key)) {
    name = escape(key);
  } else {
    name = key;
  }

  let sanitizedValue = val;
  let value = val;

  if (!helpers.isUndefined(value)) {
    if (helpers.isObject(value) || helpers.isArray(value)) {
      const stringified = antiCircular(value);
      value = encode("JSON.parse(".concat(stringified, ")"));
      sanitizedValue = JSON.parse(stringified);
    } else {
      value = encode(value);

      if (value && !fieldContentRegExp.test(value)) {
        value = escape(value);
      }
    }
  } else {
    value = '';
  }

  const pairs = ["".concat(name, "=").concat(value)];

  if (helpers.isNumber(opt.maxAge)) {
    pairs.push("Max-Age=".concat(opt.maxAge));
  }

  if (opt.domain && typeof opt.domain === 'string') {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new Meteor.Error(404, 'option domain is invalid');
    }

    pairs.push("Domain=".concat(opt.domain));
  }

  if (opt.path && typeof opt.path === 'string') {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new Meteor.Error(404, 'option path is invalid');
    }

    pairs.push("Path=".concat(opt.path));
  } else {
    pairs.push('Path=/');
  }

  opt.expires = opt.expires || opt.expire || false;

  if (opt.expires === Infinity) {
    pairs.push('Expires=Fri, 31 Dec 9999 23:59:59 GMT');
  } else if (opt.expires instanceof Date) {
    pairs.push("Expires=".concat(opt.expires.toUTCString()));
  } else if (opt.expires === 0) {
    pairs.push('Expires=0');
  } else if (helpers.isNumber(opt.expires)) {
    pairs.push("Expires=".concat(new Date(opt.expires).toUTCString()));
  }

  if (opt.httpOnly) {
    pairs.push('HttpOnly');
  }

  if (opt.secure) {
    pairs.push('Secure');
  }

  if (opt.firstPartyOnly) {
    pairs.push('First-Party-Only');
  }

  if (opt.sameSite) {
    pairs.push(opt.sameSite === true ? 'SameSite' : "SameSite=".concat(opt.sameSite));
  }

  return {
    cookieString: pairs.join('; '),
    sanitizedValue
  };
};

const isStringifiedRegEx = /JSON\.parse\((.*)\)/;
const isTypedRegEx = /false|true|null|undefined/;

const deserialize = string => {
  if (typeof string !== 'string') {
    return string;
  }

  if (isStringifiedRegEx.test(string)) {
    let obj = string.match(isStringifiedRegEx)[1];

    if (obj) {
      try {
        return JSON.parse(decode(obj));
      } catch (e) {
        console.error('[ostrio:cookies] [.get()] [deserialize()] Exception:', e, string, obj);
        return string;
      }
    }

    return string;
  } else if (isTypedRegEx.test(string)) {
    return JSON.parse(string);
  }

  return string;
};
/*
 * @locus Anywhere
 * @class __cookies
 * @param opts {Object} - Options (configuration) object
 * @param opts._cookies {Object|String} - Current cookies as String or Object
 * @param opts.TTL {Number|Boolean} - Default cookies expiration time (max-age) in milliseconds, by default - session (false)
 * @param opts.runOnServer {Boolean} - Expose Cookies class to Server
 * @param opts.response {http.ServerResponse|Object} - This object is created internally by a HTTP server
 * @param opts.allowQueryStringCookies {Boolean} - Allow passing Cookies in a query string (in URL). Primary should be used only in Cordova environment
 * @param opts.allowedCordovaOrigins {Regex|Boolean} - [Server] Allow setting Cookies from that specific origin which in Meteor/Cordova is localhost:12XXX (^http://localhost:12[0-9]{3}$)
 * @summary Internal Class
 */


class __cookies {
  constructor(opts) {
    this.__pendingCookies = [];
    this.TTL = opts.TTL || false;
    this.response = opts.response || false;
    this.runOnServer = opts.runOnServer || false;
    this.allowQueryStringCookies = opts.allowQueryStringCookies || false;
    this.allowedCordovaOrigins = opts.allowedCordovaOrigins || false;

    if (this.allowedCordovaOrigins === true) {
      this.allowedCordovaOrigins = /^http:\/\/localhost:12[0-9]{3}$/;
    }

    this.originRE = new RegExp("^https?://(".concat(rootUrl ? rootUrl : '').concat(mobileRootUrl ? '|' + mobileRootUrl : '', ")$"));

    if (helpers.isObject(opts._cookies)) {
      this.cookies = opts._cookies;
    } else {
      this.cookies = parse(opts._cookies);
    }
  }
  /*
   * @locus Anywhere
   * @memberOf __cookies
   * @name get
   * @param {String} key  - The name of the cookie to read
   * @param {String} _tmp - Unparsed string instead of user's cookies
   * @summary Read a cookie. If the cookie doesn't exist a null value will be returned.
   * @returns {String|void}
   */


  get(key, _tmp) {
    const cookieString = _tmp ? parse(_tmp) : this.cookies;

    if (!key || !cookieString) {
      return void 0;
    }

    if (cookieString.hasOwnProperty(key)) {
      return deserialize(cookieString[key]);
    }

    return void 0;
  }
  /*
   * @locus Anywhere
   * @memberOf __cookies
   * @name set
   * @param {String} key   - The name of the cookie to create/overwrite
   * @param {String} value - The value of the cookie
   * @param {Object} opts  - [Optional] Cookie options (see readme docs)
   * @summary Create/overwrite a cookie.
   * @returns {Boolean}
   */


  set(key, value) {
    let opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    if (key && !helpers.isUndefined(value)) {
      if (helpers.isNumber(this.TTL) && opts.expires === undefined) {
        opts.expires = new Date(+new Date() + this.TTL);
      }

      const {
        cookieString,
        sanitizedValue
      } = serialize(key, value, opts);
      this.cookies[key] = sanitizedValue;

      if (Meteor.isClient) {
        document.cookie = cookieString;
      } else if (this.response) {
        this.__pendingCookies.push(cookieString);

        this.response.setHeader('Set-Cookie', this.__pendingCookies);
      }

      return true;
    }

    return false;
  }
  /*
   * @locus Anywhere
   * @memberOf __cookies
   * @name remove
   * @param {String} key    - The name of the cookie to create/overwrite
   * @param {String} path   - [Optional] The path from where the cookie will be
   * readable. E.g., "/", "/mydir"; if not specified, defaults to the current
   * path of the current document location (string or null). The path must be
   * absolute (see RFC 2965). For more information on how to use relative paths
   * in this argument, see: https://developer.mozilla.org/en-US/docs/Web/API/document.cookie#Using_relative_URLs_in_the_path_parameter
   * @param {String} domain - [Optional] The domain from where the cookie will
   * be readable. E.g., "example.com", ".example.com" (includes all subdomains)
   * or "subdomain.example.com"; if not specified, defaults to the host portion
   * of the current document location (string or null).
   * @summary Remove a cookie(s).
   * @returns {Boolean}
   */


  remove(key) {
    let path = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '/';
    let domain = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';

    if (key && this.cookies.hasOwnProperty(key)) {
      const {
        cookieString
      } = serialize(key, '', {
        domain,
        path,
        expires: new Date(0)
      });
      delete this.cookies[key];

      if (Meteor.isClient) {
        document.cookie = cookieString;
      } else if (this.response) {
        this.response.setHeader('Set-Cookie', cookieString);
      }

      return true;
    } else if (!key && this.keys().length > 0 && this.keys()[0] !== '') {
      const keys = Object.keys(this.cookies);

      for (let i = 0; i < keys.length; i++) {
        this.remove(keys[i]);
      }

      return true;
    }

    return false;
  }
  /*
   * @locus Anywhere
   * @memberOf __cookies
   * @name has
   * @param {String} key  - The name of the cookie to create/overwrite
   * @param {String} _tmp - Unparsed string instead of user's cookies
   * @summary Check whether a cookie exists in the current position.
   * @returns {Boolean}
   */


  has(key, _tmp) {
    const cookieString = _tmp ? parse(_tmp) : this.cookies;

    if (!key || !cookieString) {
      return false;
    }

    return cookieString.hasOwnProperty(key);
  }
  /*
   * @locus Anywhere
   * @memberOf __cookies
   * @name keys
   * @summary Returns an array of all readable cookies from this location.
   * @returns {[String]}
   */


  keys() {
    if (this.cookies) {
      return Object.keys(this.cookies);
    }

    return [];
  }
  /*
   * @locus Client
   * @memberOf __cookies
   * @name send
   * @param cb {Function} - Callback
   * @summary Send all cookies over XHR to server.
   * @returns {void}
   */


  send() {
    let cb = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : NoOp;

    if (Meteor.isServer) {
      cb(new Meteor.Error(400, 'Can\'t run `.send()` on server, it\'s Client only method!'));
    }

    if (this.runOnServer) {
      let path = "".concat(window.__meteor_runtime_config__.ROOT_URL_PATH_PREFIX || window.__meteor_runtime_config__.meteorEnv.ROOT_URL_PATH_PREFIX || '', "/___cookie___/set");
      let query = '';

      if (Meteor.isCordova && this.allowQueryStringCookies) {
        const cookiesKeys = this.keys();
        const cookiesArray = [];

        for (let i = 0; i < cookiesKeys.length; i++) {
          const {
            sanitizedValue
          } = serialize(cookiesKeys[i], this.get(cookiesKeys[i]));
          const pair = "".concat(cookiesKeys[i], "=").concat(sanitizedValue);

          if (!cookiesArray.includes(pair)) {
            cookiesArray.push(pair);
          }
        }

        if (cookiesArray.length) {
          path = Meteor.absoluteUrl('___cookie___/set');
          query = "?___cookies___=".concat(encodeURIComponent(cookiesArray.join('; ')));
        }
      }

      HTTP.get("".concat(path).concat(query), {
        beforeSend(xhr) {
          xhr.withCredentials = true;
          return true;
        }

      }, cb);
    } else {
      cb(new Meteor.Error(400, 'Can\'t send cookies on server when `runOnServer` is false.'));
    }

    return void 0;
  }

}
/*
 * @function
 * @locus Server
 * @summary Middleware handler
 * @private
 */


const __middlewareHandler = (request, response, opts) => {
  let _cookies = {};

  if (opts.runOnServer) {
    if (request.headers && request.headers.cookie) {
      _cookies = parse(request.headers.cookie);
    }

    return new __cookies({
      _cookies,
      TTL: opts.TTL,
      runOnServer: opts.runOnServer,
      response,
      allowQueryStringCookies: opts.allowQueryStringCookies
    });
  }

  throw new Meteor.Error(400, 'Can\'t use middleware when `runOnServer` is false.');
};
/*
 * @locus Anywhere
 * @class Cookies
 * @param opts {Object}
 * @param opts.TTL {Number} - Default cookies expiration time (max-age) in milliseconds, by default - session (false)
 * @param opts.auto {Boolean} - [Server] Auto-bind in middleware as `req.Cookies`, by default `true`
 * @param opts.handler {Function} - [Server] Middleware handler
 * @param opts.runOnServer {Boolean} - Expose Cookies class to Server
 * @param opts.allowQueryStringCookies {Boolean} - Allow passing Cookies in a query string (in URL). Primary should be used only in Cordova environment
 * @param opts.allowedCordovaOrigins {Regex|Boolean} - [Server] Allow setting Cookies from that specific origin which in Meteor/Cordova is localhost:12XXX (^http://localhost:12[0-9]{3}$)
 * @summary Main Cookie class
 */


class Cookies extends __cookies {
  constructor() {
    let opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    opts.TTL = helpers.isNumber(opts.TTL) ? opts.TTL : false;
    opts.runOnServer = opts.runOnServer !== false ? true : false;
    opts.allowQueryStringCookies = opts.allowQueryStringCookies !== true ? false : true;

    if (Meteor.isClient) {
      opts._cookies = document.cookie;
      super(opts);
    } else {
      opts._cookies = {};
      super(opts);
      opts.auto = opts.auto !== false ? true : false;
      this.opts = opts;
      this.handler = helpers.isFunction(opts.handler) ? opts.handler : false;
      this.onCookies = helpers.isFunction(opts.onCookies) ? opts.onCookies : false;

      if (opts.runOnServer && !Cookies.isLoadedOnServer) {
        Cookies.isLoadedOnServer = true;

        if (opts.auto) {
          WebApp.connectHandlers.use((req, res, next) => {
            if (urlRE.test(req._parsedUrl.path)) {
              const matchedCordovaOrigin = !!req.headers.origin && this.allowedCordovaOrigins && this.allowedCordovaOrigins.test(req.headers.origin);
              const matchedOrigin = matchedCordovaOrigin || !!req.headers.origin && this.originRE.test(req.headers.origin);

              if (matchedOrigin) {
                res.setHeader('Access-Control-Allow-Credentials', 'true');
                res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
              }

              const cookiesArray = [];
              let cookiesObject = {};

              if (matchedCordovaOrigin && opts.allowQueryStringCookies && req.query.___cookies___) {
                cookiesObject = parse(decodeURIComponent(req.query.___cookies___));
              } else if (req.headers.cookie) {
                cookiesObject = parse(req.headers.cookie);
              }

              const cookiesKeys = Object.keys(cookiesObject);

              if (cookiesKeys.length) {
                for (let i = 0; i < cookiesKeys.length; i++) {
                  const {
                    cookieString
                  } = serialize(cookiesKeys[i], cookiesObject[cookiesKeys[i]]);

                  if (!cookiesArray.includes(cookieString)) {
                    cookiesArray.push(cookieString);
                  }
                }

                if (cookiesArray.length) {
                  res.setHeader('Set-Cookie', cookiesArray);
                }
              }

              helpers.isFunction(this.onCookies) && this.onCookies(__middlewareHandler(req, res, opts));
              res.writeHead(200);
              res.end('');
            } else {
              req.Cookies = __middlewareHandler(req, res, opts);
              helpers.isFunction(this.handler) && this.handler(req.Cookies);
              next();
            }
          });
        }
      }
    }
  }
  /*
   * @locus Server
   * @memberOf Cookies
   * @name middleware
   * @summary Get Cookies instance into callback
   * @returns {void}
   */


  middleware() {
    if (!Meteor.isServer) {
      throw new Meteor.Error(500, '[ostrio:cookies] Can\'t use `.middleware()` on Client, it\'s Server only!');
    }

    return (req, res, next) => {
      helpers.isFunction(this.handler) && this.handler(__middlewareHandler(req, res, this.opts));
      next();
    };
  }

}

if (Meteor.isServer) {
  Cookies.isLoadedOnServer = false;
}
/* Export the Cookies class */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/ostrio:cookies/cookies.js");

/* Exports */
Package._define("ostrio:cookies", exports);

})();

//# sourceURL=meteor://💻app/packages/ostrio_cookies.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmNvb2tpZXMvY29va2llcy5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJDb29raWVzIiwiTWV0ZW9yIiwibGluayIsInYiLCJIVFRQIiwiV2ViQXBwIiwiaXNTZXJ2ZXIiLCJyZXF1aXJlIiwiTm9PcCIsInVybFJFIiwicm9vdFVybCIsInByb2Nlc3MiLCJlbnYiLCJST09UX1VSTCIsIndpbmRvdyIsIl9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18iLCJtZXRlb3JFbnYiLCJtb2JpbGVSb290VXJsIiwiTU9CSUxFX1JPT1RfVVJMIiwiaGVscGVycyIsImlzVW5kZWZpbmVkIiwib2JqIiwiaXNBcnJheSIsIkFycmF5IiwiY2xvbmUiLCJpc09iamVjdCIsInNsaWNlIiwiT2JqZWN0IiwiYXNzaWduIiwiX2hlbHBlcnMiLCJpIiwibGVuZ3RoIiwicHJvdG90eXBlIiwidG9TdHJpbmciLCJjYWxsIiwiZGVjb2RlIiwiZGVjb2RlVVJJQ29tcG9uZW50IiwiZW5jb2RlIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwicGFpclNwbGl0UmVnRXhwIiwiZmllbGRDb250ZW50UmVnRXhwIiwidHJ5RGVjb2RlIiwic3RyIiwiZCIsImUiLCJwYXJzZSIsIm9wdGlvbnMiLCJFcnJvciIsIm9wdCIsInZhbCIsImtleSIsImVxSW5keCIsInNwbGl0IiwiZm9yRWFjaCIsInBhaXIiLCJpbmRleE9mIiwic3Vic3RyIiwidHJpbSIsInVuZXNjYXBlIiwiYW50aUNpcmN1bGFyIiwiX29iaiIsIm9iamVjdCIsImNhY2hlIiwiTWFwIiwiSlNPTiIsInN0cmluZ2lmeSIsInZhbHVlIiwiZ2V0Iiwic2V0Iiwic2VyaWFsaXplIiwibmFtZSIsInRlc3QiLCJlc2NhcGUiLCJzYW5pdGl6ZWRWYWx1ZSIsInN0cmluZ2lmaWVkIiwicGFpcnMiLCJpc051bWJlciIsIm1heEFnZSIsInB1c2giLCJkb21haW4iLCJwYXRoIiwiZXhwaXJlcyIsImV4cGlyZSIsIkluZmluaXR5IiwiRGF0ZSIsInRvVVRDU3RyaW5nIiwiaHR0cE9ubHkiLCJzZWN1cmUiLCJmaXJzdFBhcnR5T25seSIsInNhbWVTaXRlIiwiY29va2llU3RyaW5nIiwiam9pbiIsImlzU3RyaW5naWZpZWRSZWdFeCIsImlzVHlwZWRSZWdFeCIsImRlc2VyaWFsaXplIiwic3RyaW5nIiwibWF0Y2giLCJjb25zb2xlIiwiZXJyb3IiLCJfX2Nvb2tpZXMiLCJjb25zdHJ1Y3RvciIsIm9wdHMiLCJfX3BlbmRpbmdDb29raWVzIiwiVFRMIiwicmVzcG9uc2UiLCJydW5PblNlcnZlciIsImFsbG93UXVlcnlTdHJpbmdDb29raWVzIiwiYWxsb3dlZENvcmRvdmFPcmlnaW5zIiwib3JpZ2luUkUiLCJSZWdFeHAiLCJfY29va2llcyIsImNvb2tpZXMiLCJfdG1wIiwiaGFzT3duUHJvcGVydHkiLCJ1bmRlZmluZWQiLCJpc0NsaWVudCIsImRvY3VtZW50IiwiY29va2llIiwic2V0SGVhZGVyIiwicmVtb3ZlIiwia2V5cyIsImhhcyIsInNlbmQiLCJjYiIsIlJPT1RfVVJMX1BBVEhfUFJFRklYIiwicXVlcnkiLCJpc0NvcmRvdmEiLCJjb29raWVzS2V5cyIsImNvb2tpZXNBcnJheSIsImluY2x1ZGVzIiwiYWJzb2x1dGVVcmwiLCJiZWZvcmVTZW5kIiwieGhyIiwid2l0aENyZWRlbnRpYWxzIiwiX19taWRkbGV3YXJlSGFuZGxlciIsInJlcXVlc3QiLCJoZWFkZXJzIiwiYXV0byIsImhhbmRsZXIiLCJpc0Z1bmN0aW9uIiwib25Db29raWVzIiwiaXNMb2FkZWRPblNlcnZlciIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlcyIsIm5leHQiLCJfcGFyc2VkVXJsIiwibWF0Y2hlZENvcmRvdmFPcmlnaW4iLCJvcmlnaW4iLCJtYXRjaGVkT3JpZ2luIiwiY29va2llc09iamVjdCIsIl9fX2Nvb2tpZXNfX18iLCJ3cml0ZUhlYWQiLCJlbmQiLCJtaWRkbGV3YXJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJQyxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBRWhELElBQUlDLElBQUo7QUFDQSxJQUFJQyxNQUFKOztBQUVBLElBQUlKLE1BQU0sQ0FBQ0ssUUFBWCxFQUFxQjtBQUNuQkQsUUFBTSxHQUFHRSxPQUFPLENBQUMsZUFBRCxDQUFQLENBQXlCRixNQUFsQztBQUNELENBRkQsTUFFTztBQUNMRCxNQUFJLEdBQUdHLE9BQU8sQ0FBQyxhQUFELENBQVAsQ0FBdUJILElBQTlCO0FBQ0Q7O0FBRUQsTUFBTUksSUFBSSxHQUFJLE1BQU0sQ0FBRSxDQUF0Qjs7QUFDQSxNQUFNQyxLQUFLLEdBQUcscUJBQWQ7QUFDQSxNQUFNQyxPQUFPLEdBQUdULE1BQU0sQ0FBQ0ssUUFBUCxHQUFrQkssT0FBTyxDQUFDQyxHQUFSLENBQVlDLFFBQTlCLEdBQTBDQyxNQUFNLENBQUNDLHlCQUFQLENBQWlDRixRQUFqQyxJQUE2Q0MsTUFBTSxDQUFDQyx5QkFBUCxDQUFpQ0MsU0FBakMsQ0FBMkNILFFBQXhGLElBQW9HLEtBQTlKO0FBQ0EsTUFBTUksYUFBYSxHQUFHaEIsTUFBTSxDQUFDSyxRQUFQLEdBQWtCSyxPQUFPLENBQUNDLEdBQVIsQ0FBWU0sZUFBOUIsR0FBaURKLE1BQU0sQ0FBQ0MseUJBQVAsQ0FBaUNHLGVBQWpDLElBQW9ESixNQUFNLENBQUNDLHlCQUFQLENBQWlDQyxTQUFqQyxDQUEyQ0UsZUFBL0YsSUFBa0gsS0FBekw7QUFFQSxNQUFNQyxPQUFPLEdBQUc7QUFDZEMsYUFBVyxDQUFDQyxHQUFELEVBQU07QUFDZixXQUFPQSxHQUFHLEtBQUssS0FBSyxDQUFwQjtBQUNELEdBSGE7O0FBSWRDLFNBQU8sQ0FBQ0QsR0FBRCxFQUFNO0FBQ1gsV0FBT0UsS0FBSyxDQUFDRCxPQUFOLENBQWNELEdBQWQsQ0FBUDtBQUNELEdBTmE7O0FBT2RHLE9BQUssQ0FBQ0gsR0FBRCxFQUFNO0FBQ1QsUUFBSSxDQUFDLEtBQUtJLFFBQUwsQ0FBY0osR0FBZCxDQUFMLEVBQXlCLE9BQU9BLEdBQVA7QUFDekIsV0FBTyxLQUFLQyxPQUFMLENBQWFELEdBQWIsSUFBb0JBLEdBQUcsQ0FBQ0ssS0FBSixFQUFwQixHQUFrQ0MsTUFBTSxDQUFDQyxNQUFQLENBQWMsRUFBZCxFQUFrQlAsR0FBbEIsQ0FBekM7QUFDRDs7QUFWYSxDQUFoQjtBQVlBLE1BQU1RLFFBQVEsR0FBRyxDQUFDLFFBQUQsRUFBVyxRQUFYLEVBQXFCLFVBQXJCLENBQWpCOztBQUNBLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsUUFBUSxDQUFDRSxNQUE3QixFQUFxQ0QsQ0FBQyxFQUF0QyxFQUEwQztBQUN4Q1gsU0FBTyxDQUFDLE9BQU9VLFFBQVEsQ0FBQ0MsQ0FBRCxDQUFoQixDQUFQLEdBQThCLFVBQVVULEdBQVYsRUFBZTtBQUMzQyxXQUFPTSxNQUFNLENBQUNLLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQmIsR0FBL0IsTUFBd0MsYUFBYVEsUUFBUSxDQUFDQyxDQUFELENBQXJCLEdBQTJCLEdBQTFFO0FBQ0QsR0FGRDtBQUdEO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUssTUFBTSxHQUFHQyxrQkFBZjtBQUNBLE1BQU1DLE1BQU0sR0FBR0Msa0JBQWY7QUFDQSxNQUFNQyxlQUFlLEdBQUcsS0FBeEI7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNQyxrQkFBa0IsR0FBRyx1Q0FBM0I7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQU1DLFNBQVMsR0FBRyxDQUFDQyxHQUFELEVBQU1DLENBQU4sS0FBWTtBQUM1QixNQUFJO0FBQ0YsV0FBT0EsQ0FBQyxDQUFDRCxHQUFELENBQVI7QUFDRCxHQUZELENBRUUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1YsV0FBT0YsR0FBUDtBQUNEO0FBQ0YsQ0FORDtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUcsS0FBSyxHQUFHLENBQUNILEdBQUQsRUFBTUksT0FBTixLQUFrQjtBQUM5QixNQUFJLE9BQU9KLEdBQVAsS0FBZSxRQUFuQixFQUE2QjtBQUMzQixVQUFNLElBQUl6QyxNQUFNLENBQUM4QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLCtCQUF0QixDQUFOO0FBQ0Q7O0FBQ0QsUUFBTTFCLEdBQUcsR0FBRyxFQUFaO0FBQ0EsUUFBTTJCLEdBQUcsR0FBR0YsT0FBTyxJQUFJLEVBQXZCO0FBQ0EsTUFBSUcsR0FBSjtBQUNBLE1BQUlDLEdBQUo7QUFDQSxNQUFJQyxNQUFKO0FBRUFULEtBQUcsQ0FBQ1UsS0FBSixDQUFVYixlQUFWLEVBQTJCYyxPQUEzQixDQUFvQ0MsSUFBRCxJQUFVO0FBQzNDSCxVQUFNLEdBQUdHLElBQUksQ0FBQ0MsT0FBTCxDQUFhLEdBQWIsQ0FBVDs7QUFDQSxRQUFJSixNQUFNLEdBQUcsQ0FBYixFQUFnQjtBQUNkO0FBQ0Q7O0FBQ0RELE9BQUcsR0FBR0ksSUFBSSxDQUFDRSxNQUFMLENBQVksQ0FBWixFQUFlTCxNQUFmLEVBQXVCTSxJQUF2QixFQUFOO0FBQ0FQLE9BQUcsR0FBR1QsU0FBUyxDQUFDaUIsUUFBUSxDQUFDUixHQUFELENBQVQsRUFBaUJGLEdBQUcsQ0FBQ2IsTUFBSixJQUFjQSxNQUEvQixDQUFmO0FBQ0FjLE9BQUcsR0FBR0ssSUFBSSxDQUFDRSxNQUFMLENBQVksRUFBRUwsTUFBZCxFQUFzQkcsSUFBSSxDQUFDdkIsTUFBM0IsRUFBbUMwQixJQUFuQyxFQUFOOztBQUNBLFFBQUlSLEdBQUcsQ0FBQyxDQUFELENBQUgsS0FBVyxHQUFmLEVBQW9CO0FBQ2xCQSxTQUFHLEdBQUdBLEdBQUcsQ0FBQ3ZCLEtBQUosQ0FBVSxDQUFWLEVBQWEsQ0FBQyxDQUFkLENBQU47QUFDRDs7QUFDRCxRQUFJLEtBQUssQ0FBTCxLQUFXTCxHQUFHLENBQUM2QixHQUFELENBQWxCLEVBQXlCO0FBQ3ZCN0IsU0FBRyxDQUFDNkIsR0FBRCxDQUFILEdBQVdULFNBQVMsQ0FBQ1EsR0FBRCxFQUFPRCxHQUFHLENBQUNiLE1BQUosSUFBY0EsTUFBckIsQ0FBcEI7QUFDRDtBQUNGLEdBZEQ7QUFlQSxTQUFPZCxHQUFQO0FBQ0QsQ0ExQkQ7QUE0QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNc0MsWUFBWSxHQUFJQyxJQUFELElBQVU7QUFDN0IsUUFBTUMsTUFBTSxHQUFHMUMsT0FBTyxDQUFDSyxLQUFSLENBQWNvQyxJQUFkLENBQWY7QUFDQSxRQUFNRSxLQUFLLEdBQUksSUFBSUMsR0FBSixFQUFmO0FBQ0EsU0FBT0MsSUFBSSxDQUFDQyxTQUFMLENBQWVKLE1BQWYsRUFBdUIsQ0FBQ1gsR0FBRCxFQUFNZ0IsS0FBTixLQUFnQjtBQUM1QyxRQUFJLE9BQU9BLEtBQVAsS0FBaUIsUUFBakIsSUFBNkJBLEtBQUssS0FBSyxJQUEzQyxFQUFpRDtBQUMvQyxVQUFJSixLQUFLLENBQUNLLEdBQU4sQ0FBVUQsS0FBVixDQUFKLEVBQXNCO0FBQ3BCLGVBQU8sS0FBSyxDQUFaO0FBQ0Q7O0FBQ0RKLFdBQUssQ0FBQ00sR0FBTixDQUFVRixLQUFWLEVBQWlCLElBQWpCO0FBQ0Q7O0FBQ0QsV0FBT0EsS0FBUDtBQUNELEdBUk0sQ0FBUDtBQVNELENBWkQ7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNRyxTQUFTLEdBQUcsVUFBQ25CLEdBQUQsRUFBTUQsR0FBTixFQUF3QjtBQUFBLE1BQWJELEdBQWEsdUVBQVAsRUFBTztBQUN4QyxNQUFJc0IsSUFBSjs7QUFFQSxNQUFJLENBQUM5QixrQkFBa0IsQ0FBQytCLElBQW5CLENBQXdCckIsR0FBeEIsQ0FBTCxFQUFtQztBQUNqQ29CLFFBQUksR0FBR0UsTUFBTSxDQUFDdEIsR0FBRCxDQUFiO0FBQ0QsR0FGRCxNQUVPO0FBQ0xvQixRQUFJLEdBQUdwQixHQUFQO0FBQ0Q7O0FBRUQsTUFBSXVCLGNBQWMsR0FBR3hCLEdBQXJCO0FBQ0EsTUFBSWlCLEtBQUssR0FBR2pCLEdBQVo7O0FBQ0EsTUFBSSxDQUFDOUIsT0FBTyxDQUFDQyxXQUFSLENBQW9COEMsS0FBcEIsQ0FBTCxFQUFpQztBQUMvQixRQUFJL0MsT0FBTyxDQUFDTSxRQUFSLENBQWlCeUMsS0FBakIsS0FBMkIvQyxPQUFPLENBQUNHLE9BQVIsQ0FBZ0I0QyxLQUFoQixDQUEvQixFQUF1RDtBQUNyRCxZQUFNUSxXQUFXLEdBQUdmLFlBQVksQ0FBQ08sS0FBRCxDQUFoQztBQUNBQSxXQUFLLEdBQUc3QixNQUFNLHNCQUFlcUMsV0FBZixPQUFkO0FBQ0FELG9CQUFjLEdBQUdULElBQUksQ0FBQ25CLEtBQUwsQ0FBVzZCLFdBQVgsQ0FBakI7QUFDRCxLQUpELE1BSU87QUFDTFIsV0FBSyxHQUFHN0IsTUFBTSxDQUFDNkIsS0FBRCxDQUFkOztBQUNBLFVBQUlBLEtBQUssSUFBSSxDQUFDMUIsa0JBQWtCLENBQUMrQixJQUFuQixDQUF3QkwsS0FBeEIsQ0FBZCxFQUE4QztBQUM1Q0EsYUFBSyxHQUFHTSxNQUFNLENBQUNOLEtBQUQsQ0FBZDtBQUNEO0FBQ0Y7QUFDRixHQVhELE1BV087QUFDTEEsU0FBSyxHQUFHLEVBQVI7QUFDRDs7QUFFRCxRQUFNUyxLQUFLLEdBQUcsV0FBSUwsSUFBSixjQUFZSixLQUFaLEVBQWQ7O0FBRUEsTUFBSS9DLE9BQU8sQ0FBQ3lELFFBQVIsQ0FBaUI1QixHQUFHLENBQUM2QixNQUFyQixDQUFKLEVBQWtDO0FBQ2hDRixTQUFLLENBQUNHLElBQU4sbUJBQXNCOUIsR0FBRyxDQUFDNkIsTUFBMUI7QUFDRDs7QUFFRCxNQUFJN0IsR0FBRyxDQUFDK0IsTUFBSixJQUFjLE9BQU8vQixHQUFHLENBQUMrQixNQUFYLEtBQXNCLFFBQXhDLEVBQWtEO0FBQ2hELFFBQUksQ0FBQ3ZDLGtCQUFrQixDQUFDK0IsSUFBbkIsQ0FBd0J2QixHQUFHLENBQUMrQixNQUE1QixDQUFMLEVBQTBDO0FBQ3hDLFlBQU0sSUFBSTlFLE1BQU0sQ0FBQzhDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsMEJBQXRCLENBQU47QUFDRDs7QUFDRDRCLFNBQUssQ0FBQ0csSUFBTixrQkFBcUI5QixHQUFHLENBQUMrQixNQUF6QjtBQUNEOztBQUVELE1BQUkvQixHQUFHLENBQUNnQyxJQUFKLElBQVksT0FBT2hDLEdBQUcsQ0FBQ2dDLElBQVgsS0FBb0IsUUFBcEMsRUFBOEM7QUFDNUMsUUFBSSxDQUFDeEMsa0JBQWtCLENBQUMrQixJQUFuQixDQUF3QnZCLEdBQUcsQ0FBQ2dDLElBQTVCLENBQUwsRUFBd0M7QUFDdEMsWUFBTSxJQUFJL0UsTUFBTSxDQUFDOEMsS0FBWCxDQUFpQixHQUFqQixFQUFzQix3QkFBdEIsQ0FBTjtBQUNEOztBQUNENEIsU0FBSyxDQUFDRyxJQUFOLGdCQUFtQjlCLEdBQUcsQ0FBQ2dDLElBQXZCO0FBQ0QsR0FMRCxNQUtPO0FBQ0xMLFNBQUssQ0FBQ0csSUFBTixDQUFXLFFBQVg7QUFDRDs7QUFFRDlCLEtBQUcsQ0FBQ2lDLE9BQUosR0FBY2pDLEdBQUcsQ0FBQ2lDLE9BQUosSUFBZWpDLEdBQUcsQ0FBQ2tDLE1BQW5CLElBQTZCLEtBQTNDOztBQUNBLE1BQUlsQyxHQUFHLENBQUNpQyxPQUFKLEtBQWdCRSxRQUFwQixFQUE4QjtBQUM1QlIsU0FBSyxDQUFDRyxJQUFOLENBQVcsdUNBQVg7QUFDRCxHQUZELE1BRU8sSUFBSTlCLEdBQUcsQ0FBQ2lDLE9BQUosWUFBdUJHLElBQTNCLEVBQWlDO0FBQ3RDVCxTQUFLLENBQUNHLElBQU4sbUJBQXNCOUIsR0FBRyxDQUFDaUMsT0FBSixDQUFZSSxXQUFaLEVBQXRCO0FBQ0QsR0FGTSxNQUVBLElBQUlyQyxHQUFHLENBQUNpQyxPQUFKLEtBQWdCLENBQXBCLEVBQXVCO0FBQzVCTixTQUFLLENBQUNHLElBQU4sQ0FBVyxXQUFYO0FBQ0QsR0FGTSxNQUVBLElBQUkzRCxPQUFPLENBQUN5RCxRQUFSLENBQWlCNUIsR0FBRyxDQUFDaUMsT0FBckIsQ0FBSixFQUFtQztBQUN4Q04sU0FBSyxDQUFDRyxJQUFOLG1CQUF1QixJQUFJTSxJQUFKLENBQVNwQyxHQUFHLENBQUNpQyxPQUFiLENBQUQsQ0FBd0JJLFdBQXhCLEVBQXRCO0FBQ0Q7O0FBRUQsTUFBSXJDLEdBQUcsQ0FBQ3NDLFFBQVIsRUFBa0I7QUFDaEJYLFNBQUssQ0FBQ0csSUFBTixDQUFXLFVBQVg7QUFDRDs7QUFFRCxNQUFJOUIsR0FBRyxDQUFDdUMsTUFBUixFQUFnQjtBQUNkWixTQUFLLENBQUNHLElBQU4sQ0FBVyxRQUFYO0FBQ0Q7O0FBRUQsTUFBSTlCLEdBQUcsQ0FBQ3dDLGNBQVIsRUFBd0I7QUFDdEJiLFNBQUssQ0FBQ0csSUFBTixDQUFXLGtCQUFYO0FBQ0Q7O0FBRUQsTUFBSTlCLEdBQUcsQ0FBQ3lDLFFBQVIsRUFBa0I7QUFDaEJkLFNBQUssQ0FBQ0csSUFBTixDQUFXOUIsR0FBRyxDQUFDeUMsUUFBSixLQUFpQixJQUFqQixHQUF3QixVQUF4QixzQkFBaUR6QyxHQUFHLENBQUN5QyxRQUFyRCxDQUFYO0FBQ0Q7O0FBRUQsU0FBTztBQUFFQyxnQkFBWSxFQUFFZixLQUFLLENBQUNnQixJQUFOLENBQVcsSUFBWCxDQUFoQjtBQUFrQ2xCO0FBQWxDLEdBQVA7QUFDRCxDQTVFRDs7QUE4RUEsTUFBTW1CLGtCQUFrQixHQUFHLHFCQUEzQjtBQUNBLE1BQU1DLFlBQVksR0FBRywyQkFBckI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFJQyxNQUFELElBQVk7QUFDOUIsTUFBSSxPQUFPQSxNQUFQLEtBQWtCLFFBQXRCLEVBQWdDO0FBQzlCLFdBQU9BLE1BQVA7QUFDRDs7QUFFRCxNQUFJSCxrQkFBa0IsQ0FBQ3JCLElBQW5CLENBQXdCd0IsTUFBeEIsQ0FBSixFQUFxQztBQUNuQyxRQUFJMUUsR0FBRyxHQUFHMEUsTUFBTSxDQUFDQyxLQUFQLENBQWFKLGtCQUFiLEVBQWlDLENBQWpDLENBQVY7O0FBQ0EsUUFBSXZFLEdBQUosRUFBUztBQUNQLFVBQUk7QUFDRixlQUFPMkMsSUFBSSxDQUFDbkIsS0FBTCxDQUFXVixNQUFNLENBQUNkLEdBQUQsQ0FBakIsQ0FBUDtBQUNELE9BRkQsQ0FFRSxPQUFPdUIsQ0FBUCxFQUFVO0FBQ1ZxRCxlQUFPLENBQUNDLEtBQVIsQ0FBYyxzREFBZCxFQUFzRXRELENBQXRFLEVBQXlFbUQsTUFBekUsRUFBaUYxRSxHQUFqRjtBQUNBLGVBQU8wRSxNQUFQO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPQSxNQUFQO0FBQ0QsR0FYRCxNQVdPLElBQUlGLFlBQVksQ0FBQ3RCLElBQWIsQ0FBa0J3QixNQUFsQixDQUFKLEVBQStCO0FBQ3BDLFdBQU8vQixJQUFJLENBQUNuQixLQUFMLENBQVdrRCxNQUFYLENBQVA7QUFDRDs7QUFDRCxTQUFPQSxNQUFQO0FBQ0QsQ0FwQkQ7QUFzQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNSSxTQUFOLENBQWdCO0FBQ2RDLGFBQVcsQ0FBQ0MsSUFBRCxFQUFPO0FBQ2hCLFNBQUtDLGdCQUFMLEdBQXdCLEVBQXhCO0FBQ0EsU0FBS0MsR0FBTCxHQUFXRixJQUFJLENBQUNFLEdBQUwsSUFBWSxLQUF2QjtBQUNBLFNBQUtDLFFBQUwsR0FBZ0JILElBQUksQ0FBQ0csUUFBTCxJQUFpQixLQUFqQztBQUNBLFNBQUtDLFdBQUwsR0FBbUJKLElBQUksQ0FBQ0ksV0FBTCxJQUFvQixLQUF2QztBQUNBLFNBQUtDLHVCQUFMLEdBQStCTCxJQUFJLENBQUNLLHVCQUFMLElBQWdDLEtBQS9EO0FBQ0EsU0FBS0MscUJBQUwsR0FBNkJOLElBQUksQ0FBQ00scUJBQUwsSUFBOEIsS0FBM0Q7O0FBRUEsUUFBSSxLQUFLQSxxQkFBTCxLQUErQixJQUFuQyxFQUF5QztBQUN2QyxXQUFLQSxxQkFBTCxHQUE2QixpQ0FBN0I7QUFDRDs7QUFFRCxTQUFLQyxRQUFMLEdBQWdCLElBQUlDLE1BQUosc0JBQTJCbkcsT0FBTyxHQUFHQSxPQUFILEdBQWEsRUFBL0MsU0FBb0RPLGFBQWEsR0FBSSxNQUFNQSxhQUFWLEdBQTJCLEVBQTVGLFFBQWhCOztBQUVBLFFBQUlFLE9BQU8sQ0FBQ00sUUFBUixDQUFpQjRFLElBQUksQ0FBQ1MsUUFBdEIsQ0FBSixFQUFxQztBQUNuQyxXQUFLQyxPQUFMLEdBQWVWLElBQUksQ0FBQ1MsUUFBcEI7QUFDRCxLQUZELE1BRU87QUFDTCxXQUFLQyxPQUFMLEdBQWVsRSxLQUFLLENBQUN3RCxJQUFJLENBQUNTLFFBQU4sQ0FBcEI7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTNDLEtBQUcsQ0FBQ2pCLEdBQUQsRUFBTThELElBQU4sRUFBWTtBQUNiLFVBQU10QixZQUFZLEdBQUdzQixJQUFJLEdBQUduRSxLQUFLLENBQUNtRSxJQUFELENBQVIsR0FBaUIsS0FBS0QsT0FBL0M7O0FBQ0EsUUFBSSxDQUFDN0QsR0FBRCxJQUFRLENBQUN3QyxZQUFiLEVBQTJCO0FBQ3pCLGFBQU8sS0FBSyxDQUFaO0FBQ0Q7O0FBRUQsUUFBSUEsWUFBWSxDQUFDdUIsY0FBYixDQUE0Qi9ELEdBQTVCLENBQUosRUFBc0M7QUFDcEMsYUFBTzRDLFdBQVcsQ0FBQ0osWUFBWSxDQUFDeEMsR0FBRCxDQUFiLENBQWxCO0FBQ0Q7O0FBRUQsV0FBTyxLQUFLLENBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWtCLEtBQUcsQ0FBQ2xCLEdBQUQsRUFBTWdCLEtBQU4sRUFBd0I7QUFBQSxRQUFYbUMsSUFBVyx1RUFBSixFQUFJOztBQUN6QixRQUFJbkQsR0FBRyxJQUFJLENBQUMvQixPQUFPLENBQUNDLFdBQVIsQ0FBb0I4QyxLQUFwQixDQUFaLEVBQXdDO0FBQ3RDLFVBQUkvQyxPQUFPLENBQUN5RCxRQUFSLENBQWlCLEtBQUsyQixHQUF0QixLQUE4QkYsSUFBSSxDQUFDcEIsT0FBTCxLQUFpQmlDLFNBQW5ELEVBQThEO0FBQzVEYixZQUFJLENBQUNwQixPQUFMLEdBQWUsSUFBSUcsSUFBSixDQUFTLENBQUMsSUFBSUEsSUFBSixFQUFELEdBQWMsS0FBS21CLEdBQTVCLENBQWY7QUFDRDs7QUFDRCxZQUFNO0FBQUViLG9CQUFGO0FBQWdCakI7QUFBaEIsVUFBbUNKLFNBQVMsQ0FBQ25CLEdBQUQsRUFBTWdCLEtBQU4sRUFBYW1DLElBQWIsQ0FBbEQ7QUFFQSxXQUFLVSxPQUFMLENBQWE3RCxHQUFiLElBQW9CdUIsY0FBcEI7O0FBQ0EsVUFBSXhFLE1BQU0sQ0FBQ2tILFFBQVgsRUFBcUI7QUFDbkJDLGdCQUFRLENBQUNDLE1BQVQsR0FBa0IzQixZQUFsQjtBQUNELE9BRkQsTUFFTyxJQUFJLEtBQUtjLFFBQVQsRUFBbUI7QUFDeEIsYUFBS0YsZ0JBQUwsQ0FBc0J4QixJQUF0QixDQUEyQlksWUFBM0I7O0FBQ0EsYUFBS2MsUUFBTCxDQUFjYyxTQUFkLENBQXdCLFlBQXhCLEVBQXNDLEtBQUtoQixnQkFBM0M7QUFDRDs7QUFDRCxhQUFPLElBQVA7QUFDRDs7QUFDRCxXQUFPLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFaUIsUUFBTSxDQUFDckUsR0FBRCxFQUErQjtBQUFBLFFBQXpCOEIsSUFBeUIsdUVBQWxCLEdBQWtCO0FBQUEsUUFBYkQsTUFBYSx1RUFBSixFQUFJOztBQUNuQyxRQUFJN0IsR0FBRyxJQUFJLEtBQUs2RCxPQUFMLENBQWFFLGNBQWIsQ0FBNEIvRCxHQUE1QixDQUFYLEVBQTZDO0FBQzNDLFlBQU07QUFBRXdDO0FBQUYsVUFBbUJyQixTQUFTLENBQUNuQixHQUFELEVBQU0sRUFBTixFQUFVO0FBQzFDNkIsY0FEMEM7QUFFMUNDLFlBRjBDO0FBRzFDQyxlQUFPLEVBQUUsSUFBSUcsSUFBSixDQUFTLENBQVQ7QUFIaUMsT0FBVixDQUFsQztBQU1BLGFBQU8sS0FBSzJCLE9BQUwsQ0FBYTdELEdBQWIsQ0FBUDs7QUFDQSxVQUFJakQsTUFBTSxDQUFDa0gsUUFBWCxFQUFxQjtBQUNuQkMsZ0JBQVEsQ0FBQ0MsTUFBVCxHQUFrQjNCLFlBQWxCO0FBQ0QsT0FGRCxNQUVPLElBQUksS0FBS2MsUUFBVCxFQUFtQjtBQUN4QixhQUFLQSxRQUFMLENBQWNjLFNBQWQsQ0FBd0IsWUFBeEIsRUFBc0M1QixZQUF0QztBQUNEOztBQUNELGFBQU8sSUFBUDtBQUNELEtBZEQsTUFjTyxJQUFJLENBQUN4QyxHQUFELElBQVEsS0FBS3NFLElBQUwsR0FBWXpGLE1BQVosR0FBcUIsQ0FBN0IsSUFBa0MsS0FBS3lGLElBQUwsR0FBWSxDQUFaLE1BQW1CLEVBQXpELEVBQTZEO0FBQ2xFLFlBQU1BLElBQUksR0FBRzdGLE1BQU0sQ0FBQzZGLElBQVAsQ0FBWSxLQUFLVCxPQUFqQixDQUFiOztBQUNBLFdBQUssSUFBSWpGLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcwRixJQUFJLENBQUN6RixNQUF6QixFQUFpQ0QsQ0FBQyxFQUFsQyxFQUFzQztBQUNwQyxhQUFLeUYsTUFBTCxDQUFZQyxJQUFJLENBQUMxRixDQUFELENBQWhCO0FBQ0Q7O0FBQ0QsYUFBTyxJQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMkYsS0FBRyxDQUFDdkUsR0FBRCxFQUFNOEQsSUFBTixFQUFZO0FBQ2IsVUFBTXRCLFlBQVksR0FBR3NCLElBQUksR0FBR25FLEtBQUssQ0FBQ21FLElBQUQsQ0FBUixHQUFpQixLQUFLRCxPQUEvQzs7QUFDQSxRQUFJLENBQUM3RCxHQUFELElBQVEsQ0FBQ3dDLFlBQWIsRUFBMkI7QUFDekIsYUFBTyxLQUFQO0FBQ0Q7O0FBRUQsV0FBT0EsWUFBWSxDQUFDdUIsY0FBYixDQUE0Qi9ELEdBQTVCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXNFLE1BQUksR0FBRztBQUNMLFFBQUksS0FBS1QsT0FBVCxFQUFrQjtBQUNoQixhQUFPcEYsTUFBTSxDQUFDNkYsSUFBUCxDQUFZLEtBQUtULE9BQWpCLENBQVA7QUFDRDs7QUFDRCxXQUFPLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFVyxNQUFJLEdBQVk7QUFBQSxRQUFYQyxFQUFXLHVFQUFObkgsSUFBTTs7QUFDZCxRQUFJUCxNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFDbkJxSCxRQUFFLENBQUMsSUFBSTFILE1BQU0sQ0FBQzhDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsMkRBQXRCLENBQUQsQ0FBRjtBQUNEOztBQUVELFFBQUksS0FBSzBELFdBQVQsRUFBc0I7QUFDcEIsVUFBSXpCLElBQUksYUFBTWxFLE1BQU0sQ0FBQ0MseUJBQVAsQ0FBaUM2RyxvQkFBakMsSUFBeUQ5RyxNQUFNLENBQUNDLHlCQUFQLENBQWlDQyxTQUFqQyxDQUEyQzRHLG9CQUFwRyxJQUE0SCxFQUFsSSxzQkFBUjtBQUNBLFVBQUlDLEtBQUssR0FBRyxFQUFaOztBQUVBLFVBQUk1SCxNQUFNLENBQUM2SCxTQUFQLElBQW9CLEtBQUtwQix1QkFBN0IsRUFBc0Q7QUFDcEQsY0FBTXFCLFdBQVcsR0FBRyxLQUFLUCxJQUFMLEVBQXBCO0FBQ0EsY0FBTVEsWUFBWSxHQUFHLEVBQXJCOztBQUNBLGFBQUssSUFBSWxHLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdpRyxXQUFXLENBQUNoRyxNQUFoQyxFQUF3Q0QsQ0FBQyxFQUF6QyxFQUE2QztBQUMzQyxnQkFBTTtBQUFFMkM7QUFBRixjQUFxQkosU0FBUyxDQUFDMEQsV0FBVyxDQUFDakcsQ0FBRCxDQUFaLEVBQWlCLEtBQUtxQyxHQUFMLENBQVM0RCxXQUFXLENBQUNqRyxDQUFELENBQXBCLENBQWpCLENBQXBDO0FBQ0EsZ0JBQU13QixJQUFJLGFBQU15RSxXQUFXLENBQUNqRyxDQUFELENBQWpCLGNBQXdCMkMsY0FBeEIsQ0FBVjs7QUFDQSxjQUFJLENBQUN1RCxZQUFZLENBQUNDLFFBQWIsQ0FBc0IzRSxJQUF0QixDQUFMLEVBQWtDO0FBQ2hDMEUsd0JBQVksQ0FBQ2xELElBQWIsQ0FBa0J4QixJQUFsQjtBQUNEO0FBQ0Y7O0FBRUQsWUFBSTBFLFlBQVksQ0FBQ2pHLE1BQWpCLEVBQXlCO0FBQ3ZCaUQsY0FBSSxHQUFHL0UsTUFBTSxDQUFDaUksV0FBUCxDQUFtQixrQkFBbkIsQ0FBUDtBQUNBTCxlQUFLLDRCQUFxQnZGLGtCQUFrQixDQUFDMEYsWUFBWSxDQUFDckMsSUFBYixDQUFrQixJQUFsQixDQUFELENBQXZDLENBQUw7QUFDRDtBQUNGOztBQUVEdkYsVUFBSSxDQUFDK0QsR0FBTCxXQUFZYSxJQUFaLFNBQW1CNkMsS0FBbkIsR0FBNEI7QUFDMUJNLGtCQUFVLENBQUNDLEdBQUQsRUFBTTtBQUNkQSxhQUFHLENBQUNDLGVBQUosR0FBc0IsSUFBdEI7QUFDQSxpQkFBTyxJQUFQO0FBQ0Q7O0FBSnlCLE9BQTVCLEVBS0dWLEVBTEg7QUFNRCxLQTNCRCxNQTJCTztBQUNMQSxRQUFFLENBQUMsSUFBSTFILE1BQU0sQ0FBQzhDLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsNERBQXRCLENBQUQsQ0FBRjtBQUNEOztBQUNELFdBQU8sS0FBSyxDQUFaO0FBQ0Q7O0FBL0xhO0FBa01oQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU11RixtQkFBbUIsR0FBRyxDQUFDQyxPQUFELEVBQVUvQixRQUFWLEVBQW9CSCxJQUFwQixLQUE2QjtBQUN2RCxNQUFJUyxRQUFRLEdBQUcsRUFBZjs7QUFDQSxNQUFJVCxJQUFJLENBQUNJLFdBQVQsRUFBc0I7QUFDcEIsUUFBSThCLE9BQU8sQ0FBQ0MsT0FBUixJQUFtQkQsT0FBTyxDQUFDQyxPQUFSLENBQWdCbkIsTUFBdkMsRUFBK0M7QUFDN0NQLGNBQVEsR0FBR2pFLEtBQUssQ0FBQzBGLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQm5CLE1BQWpCLENBQWhCO0FBQ0Q7O0FBRUQsV0FBTyxJQUFJbEIsU0FBSixDQUFjO0FBQ25CVyxjQURtQjtBQUVuQlAsU0FBRyxFQUFFRixJQUFJLENBQUNFLEdBRlM7QUFHbkJFLGlCQUFXLEVBQUVKLElBQUksQ0FBQ0ksV0FIQztBQUluQkQsY0FKbUI7QUFLbkJFLDZCQUF1QixFQUFFTCxJQUFJLENBQUNLO0FBTFgsS0FBZCxDQUFQO0FBT0Q7O0FBRUQsUUFBTSxJQUFJekcsTUFBTSxDQUFDOEMsS0FBWCxDQUFpQixHQUFqQixFQUFzQixvREFBdEIsQ0FBTjtBQUNELENBakJEO0FBbUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTS9DLE9BQU4sU0FBc0JtRyxTQUF0QixDQUFnQztBQUM5QkMsYUFBVyxHQUFZO0FBQUEsUUFBWEMsSUFBVyx1RUFBSixFQUFJO0FBQ3JCQSxRQUFJLENBQUNFLEdBQUwsR0FBV3BGLE9BQU8sQ0FBQ3lELFFBQVIsQ0FBaUJ5QixJQUFJLENBQUNFLEdBQXRCLElBQTZCRixJQUFJLENBQUNFLEdBQWxDLEdBQXdDLEtBQW5EO0FBQ0FGLFFBQUksQ0FBQ0ksV0FBTCxHQUFvQkosSUFBSSxDQUFDSSxXQUFMLEtBQXFCLEtBQXRCLEdBQStCLElBQS9CLEdBQXNDLEtBQXpEO0FBQ0FKLFFBQUksQ0FBQ0ssdUJBQUwsR0FBZ0NMLElBQUksQ0FBQ0ssdUJBQUwsS0FBaUMsSUFBbEMsR0FBMEMsS0FBMUMsR0FBa0QsSUFBakY7O0FBRUEsUUFBSXpHLE1BQU0sQ0FBQ2tILFFBQVgsRUFBcUI7QUFDbkJkLFVBQUksQ0FBQ1MsUUFBTCxHQUFnQk0sUUFBUSxDQUFDQyxNQUF6QjtBQUNBLFlBQU1oQixJQUFOO0FBQ0QsS0FIRCxNQUdPO0FBQ0xBLFVBQUksQ0FBQ1MsUUFBTCxHQUFnQixFQUFoQjtBQUNBLFlBQU1ULElBQU47QUFDQUEsVUFBSSxDQUFDb0MsSUFBTCxHQUFhcEMsSUFBSSxDQUFDb0MsSUFBTCxLQUFjLEtBQWYsR0FBd0IsSUFBeEIsR0FBK0IsS0FBM0M7QUFDQSxXQUFLcEMsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsV0FBS3FDLE9BQUwsR0FBZXZILE9BQU8sQ0FBQ3dILFVBQVIsQ0FBbUJ0QyxJQUFJLENBQUNxQyxPQUF4QixJQUFtQ3JDLElBQUksQ0FBQ3FDLE9BQXhDLEdBQWtELEtBQWpFO0FBQ0EsV0FBS0UsU0FBTCxHQUFpQnpILE9BQU8sQ0FBQ3dILFVBQVIsQ0FBbUJ0QyxJQUFJLENBQUN1QyxTQUF4QixJQUFxQ3ZDLElBQUksQ0FBQ3VDLFNBQTFDLEdBQXNELEtBQXZFOztBQUVBLFVBQUl2QyxJQUFJLENBQUNJLFdBQUwsSUFBb0IsQ0FBQ3pHLE9BQU8sQ0FBQzZJLGdCQUFqQyxFQUFtRDtBQUNqRDdJLGVBQU8sQ0FBQzZJLGdCQUFSLEdBQTJCLElBQTNCOztBQUNBLFlBQUl4QyxJQUFJLENBQUNvQyxJQUFULEVBQWU7QUFDYnBJLGdCQUFNLENBQUN5SSxlQUFQLENBQXVCQyxHQUF2QixDQUEyQixDQUFDQyxHQUFELEVBQU1DLEdBQU4sRUFBV0MsSUFBWCxLQUFvQjtBQUM3QyxnQkFBSXpJLEtBQUssQ0FBQzhELElBQU4sQ0FBV3lFLEdBQUcsQ0FBQ0csVUFBSixDQUFlbkUsSUFBMUIsQ0FBSixFQUFxQztBQUNuQyxvQkFBTW9FLG9CQUFvQixHQUFHLENBQUMsQ0FBQ0osR0FBRyxDQUFDUixPQUFKLENBQVlhLE1BQWQsSUFDeEIsS0FBSzFDLHFCQURtQixJQUV4QixLQUFLQSxxQkFBTCxDQUEyQnBDLElBQTNCLENBQWdDeUUsR0FBRyxDQUFDUixPQUFKLENBQVlhLE1BQTVDLENBRkw7QUFHQSxvQkFBTUMsYUFBYSxHQUFHRixvQkFBb0IsSUFDcEMsQ0FBQyxDQUFDSixHQUFHLENBQUNSLE9BQUosQ0FBWWEsTUFBZCxJQUF3QixLQUFLekMsUUFBTCxDQUFjckMsSUFBZCxDQUFtQnlFLEdBQUcsQ0FBQ1IsT0FBSixDQUFZYSxNQUEvQixDQUQ5Qjs7QUFHQSxrQkFBSUMsYUFBSixFQUFtQjtBQUNqQkwsbUJBQUcsQ0FBQzNCLFNBQUosQ0FBYyxrQ0FBZCxFQUFrRCxNQUFsRDtBQUNBMkIsbUJBQUcsQ0FBQzNCLFNBQUosQ0FBYyw2QkFBZCxFQUE2QzBCLEdBQUcsQ0FBQ1IsT0FBSixDQUFZYSxNQUF6RDtBQUNEOztBQUVELG9CQUFNckIsWUFBWSxHQUFHLEVBQXJCO0FBQ0Esa0JBQUl1QixhQUFhLEdBQUcsRUFBcEI7O0FBQ0Esa0JBQUlILG9CQUFvQixJQUFJL0MsSUFBSSxDQUFDSyx1QkFBN0IsSUFBd0RzQyxHQUFHLENBQUNuQixLQUFKLENBQVUyQixhQUF0RSxFQUFxRjtBQUNuRkQsNkJBQWEsR0FBRzFHLEtBQUssQ0FBQ1Qsa0JBQWtCLENBQUM0RyxHQUFHLENBQUNuQixLQUFKLENBQVUyQixhQUFYLENBQW5CLENBQXJCO0FBQ0QsZUFGRCxNQUVPLElBQUlSLEdBQUcsQ0FBQ1IsT0FBSixDQUFZbkIsTUFBaEIsRUFBd0I7QUFDN0JrQyw2QkFBYSxHQUFHMUcsS0FBSyxDQUFDbUcsR0FBRyxDQUFDUixPQUFKLENBQVluQixNQUFiLENBQXJCO0FBQ0Q7O0FBRUQsb0JBQU1VLFdBQVcsR0FBR3BHLE1BQU0sQ0FBQzZGLElBQVAsQ0FBWStCLGFBQVosQ0FBcEI7O0FBQ0Esa0JBQUl4QixXQUFXLENBQUNoRyxNQUFoQixFQUF3QjtBQUN0QixxQkFBSyxJQUFJRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaUcsV0FBVyxDQUFDaEcsTUFBaEMsRUFBd0NELENBQUMsRUFBekMsRUFBNkM7QUFDM0Msd0JBQU07QUFBRTREO0FBQUYsc0JBQW1CckIsU0FBUyxDQUFDMEQsV0FBVyxDQUFDakcsQ0FBRCxDQUFaLEVBQWlCeUgsYUFBYSxDQUFDeEIsV0FBVyxDQUFDakcsQ0FBRCxDQUFaLENBQTlCLENBQWxDOztBQUNBLHNCQUFJLENBQUNrRyxZQUFZLENBQUNDLFFBQWIsQ0FBc0J2QyxZQUF0QixDQUFMLEVBQTBDO0FBQ3hDc0MsZ0NBQVksQ0FBQ2xELElBQWIsQ0FBa0JZLFlBQWxCO0FBQ0Q7QUFDRjs7QUFFRCxvQkFBSXNDLFlBQVksQ0FBQ2pHLE1BQWpCLEVBQXlCO0FBQ3ZCa0gscUJBQUcsQ0FBQzNCLFNBQUosQ0FBYyxZQUFkLEVBQTRCVSxZQUE1QjtBQUNEO0FBQ0Y7O0FBRUQ3RyxxQkFBTyxDQUFDd0gsVUFBUixDQUFtQixLQUFLQyxTQUF4QixLQUFzQyxLQUFLQSxTQUFMLENBQWVOLG1CQUFtQixDQUFDVSxHQUFELEVBQU1DLEdBQU4sRUFBVzVDLElBQVgsQ0FBbEMsQ0FBdEM7QUFFQTRDLGlCQUFHLENBQUNRLFNBQUosQ0FBYyxHQUFkO0FBQ0FSLGlCQUFHLENBQUNTLEdBQUosQ0FBUSxFQUFSO0FBQ0QsYUF0Q0QsTUFzQ087QUFDTFYsaUJBQUcsQ0FBQ2hKLE9BQUosR0FBY3NJLG1CQUFtQixDQUFDVSxHQUFELEVBQU1DLEdBQU4sRUFBVzVDLElBQVgsQ0FBakM7QUFDQWxGLHFCQUFPLENBQUN3SCxVQUFSLENBQW1CLEtBQUtELE9BQXhCLEtBQW9DLEtBQUtBLE9BQUwsQ0FBYU0sR0FBRyxDQUFDaEosT0FBakIsQ0FBcEM7QUFDQWtKLGtCQUFJO0FBQ0w7QUFDRixXQTVDRDtBQTZDRDtBQUNGO0FBQ0Y7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVMsWUFBVSxHQUFHO0FBQ1gsUUFBSSxDQUFDMUosTUFBTSxDQUFDSyxRQUFaLEVBQXNCO0FBQ3BCLFlBQU0sSUFBSUwsTUFBTSxDQUFDOEMsS0FBWCxDQUFpQixHQUFqQixFQUFzQiwyRUFBdEIsQ0FBTjtBQUNEOztBQUVELFdBQU8sQ0FBQ2lHLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQ3pCL0gsYUFBTyxDQUFDd0gsVUFBUixDQUFtQixLQUFLRCxPQUF4QixLQUFvQyxLQUFLQSxPQUFMLENBQWFKLG1CQUFtQixDQUFDVSxHQUFELEVBQU1DLEdBQU4sRUFBVyxLQUFLNUMsSUFBaEIsQ0FBaEMsQ0FBcEM7QUFDQTZDLFVBQUk7QUFDTCxLQUhEO0FBSUQ7O0FBdEY2Qjs7QUF5RmhDLElBQUlqSixNQUFNLENBQUNLLFFBQVgsRUFBcUI7QUFDbkJOLFNBQU8sQ0FBQzZJLGdCQUFSLEdBQTJCLEtBQTNCO0FBQ0Q7QUFFRCw4QiIsImZpbGUiOiIvcGFja2FnZXMvb3N0cmlvX2Nvb2tpZXMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxubGV0IEhUVFA7XG5sZXQgV2ViQXBwO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIFdlYkFwcCA9IHJlcXVpcmUoJ21ldGVvci93ZWJhcHAnKS5XZWJBcHA7XG59IGVsc2Uge1xuICBIVFRQID0gcmVxdWlyZSgnbWV0ZW9yL2h0dHAnKS5IVFRQO1xufVxuXG5jb25zdCBOb09wICA9ICgpID0+IHt9O1xuY29uc3QgdXJsUkUgPSAvXFwvX19fY29va2llX19fXFwvc2V0LztcbmNvbnN0IHJvb3RVcmwgPSBNZXRlb3IuaXNTZXJ2ZXIgPyBwcm9jZXNzLmVudi5ST09UX1VSTCA6ICh3aW5kb3cuX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5ST09UX1VSTCB8fCB3aW5kb3cuX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5tZXRlb3JFbnYuUk9PVF9VUkwgfHwgZmFsc2UpO1xuY29uc3QgbW9iaWxlUm9vdFVybCA9IE1ldGVvci5pc1NlcnZlciA/IHByb2Nlc3MuZW52Lk1PQklMRV9ST09UX1VSTCA6ICh3aW5kb3cuX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5NT0JJTEVfUk9PVF9VUkwgfHwgd2luZG93Ll9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18ubWV0ZW9yRW52Lk1PQklMRV9ST09UX1VSTCB8fCBmYWxzZSk7XG5cbmNvbnN0IGhlbHBlcnMgPSB7XG4gIGlzVW5kZWZpbmVkKG9iaikge1xuICAgIHJldHVybiBvYmogPT09IHZvaWQgMDtcbiAgfSxcbiAgaXNBcnJheShvYmopIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShvYmopO1xuICB9LFxuICBjbG9uZShvYmopIHtcbiAgICBpZiAoIXRoaXMuaXNPYmplY3Qob2JqKSkgcmV0dXJuIG9iajtcbiAgICByZXR1cm4gdGhpcy5pc0FycmF5KG9iaikgPyBvYmouc2xpY2UoKSA6IE9iamVjdC5hc3NpZ24oe30sIG9iaik7XG4gIH1cbn07XG5jb25zdCBfaGVscGVycyA9IFsnTnVtYmVyJywgJ09iamVjdCcsICdGdW5jdGlvbiddO1xuZm9yIChsZXQgaSA9IDA7IGkgPCBfaGVscGVycy5sZW5ndGg7IGkrKykge1xuICBoZWxwZXJzWydpcycgKyBfaGVscGVyc1tpXV0gPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopID09PSAnW29iamVjdCAnICsgX2hlbHBlcnNbaV0gKyAnXSc7XG4gIH07XG59XG5cbi8qXG4gKiBAdXJsIGh0dHBzOi8vZ2l0aHViLmNvbS9qc2h0dHAvY29va2llL2Jsb2IvbWFzdGVyL2luZGV4LmpzXG4gKiBAbmFtZSBjb29raWVcbiAqIEBhdXRob3IganNodHRwXG4gKiBAbGljZW5zZVxuICogKFRoZSBNSVQgTGljZW5zZSlcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTItMjAxNCBSb21hbiBTaHR5bG1hbiA8c2h0eWxtYW5AZ21haWwuY29tPlxuICogQ29weXJpZ2h0IChjKSAyMDE1IERvdWdsYXMgQ2hyaXN0b3BoZXIgV2lsc29uIDxkb3VnQHNvbWV0aGluZ2RvdWcuY29tPlxuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZ1xuICogYSBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4gKiAnU29mdHdhcmUnKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4gKiB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4gKiBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0b1xuICogdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxuICpcbiAqIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlXG4gKiBpbmNsdWRlZCBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbiAqXG4gKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgJ0FTIElTJywgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCxcbiAqIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuICogTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULlxuICogSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTllcbiAqIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsXG4gKiBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRVxuICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4gKi9cbmNvbnN0IGRlY29kZSA9IGRlY29kZVVSSUNvbXBvbmVudDtcbmNvbnN0IGVuY29kZSA9IGVuY29kZVVSSUNvbXBvbmVudDtcbmNvbnN0IHBhaXJTcGxpdFJlZ0V4cCA9IC87ICovO1xuXG4vKlxuICogUmVnRXhwIHRvIG1hdGNoIGZpZWxkLWNvbnRlbnQgaW4gUkZDIDcyMzAgc2VjIDMuMlxuICpcbiAqIGZpZWxkLWNvbnRlbnQgPSBmaWVsZC12Y2hhciBbIDEqKCBTUCAvIEhUQUIgKSBmaWVsZC12Y2hhciBdXG4gKiBmaWVsZC12Y2hhciAgID0gVkNIQVIgLyBvYnMtdGV4dFxuICogb2JzLXRleHQgICAgICA9ICV4ODAtRkZcbiAqL1xuY29uc3QgZmllbGRDb250ZW50UmVnRXhwID0gL15bXFx1MDAwOVxcdTAwMjAtXFx1MDA3ZVxcdTAwODAtXFx1MDBmZl0rJC87XG5cbi8qXG4gKiBAZnVuY3Rpb25cbiAqIEBuYW1lIHRyeURlY29kZVxuICogQHBhcmFtIHtTdHJpbmd9IHN0clxuICogQHBhcmFtIHtGdW5jdGlvbn0gZFxuICogQHN1bW1hcnkgVHJ5IGRlY29kaW5nIGEgc3RyaW5nIHVzaW5nIGEgZGVjb2RpbmcgZnVuY3Rpb24uXG4gKiBAcHJpdmF0ZVxuICovXG5jb25zdCB0cnlEZWNvZGUgPSAoc3RyLCBkKSA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGQoc3RyKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBzdHI7XG4gIH1cbn07XG5cbi8qXG4gKiBAZnVuY3Rpb25cbiAqIEBuYW1lIHBhcnNlXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcmV0dXJuIHtPYmplY3R9XG4gKiBAc3VtbWFyeVxuICogUGFyc2UgYSBjb29raWUgaGVhZGVyLlxuICogUGFyc2UgdGhlIGdpdmVuIGNvb2tpZSBoZWFkZXIgc3RyaW5nIGludG8gYW4gb2JqZWN0XG4gKiBUaGUgb2JqZWN0IGhhcyB0aGUgdmFyaW91cyBjb29raWVzIGFzIGtleXMobmFtZXMpID0+IHZhbHVlc1xuICogQHByaXZhdGVcbiAqL1xuY29uc3QgcGFyc2UgPSAoc3RyLCBvcHRpb25zKSA9PiB7XG4gIGlmICh0eXBlb2Ygc3RyICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDA0LCAnYXJndW1lbnQgc3RyIG11c3QgYmUgYSBzdHJpbmcnKTtcbiAgfVxuICBjb25zdCBvYmogPSB7fTtcbiAgY29uc3Qgb3B0ID0gb3B0aW9ucyB8fCB7fTtcbiAgbGV0IHZhbDtcbiAgbGV0IGtleTtcbiAgbGV0IGVxSW5keDtcblxuICBzdHIuc3BsaXQocGFpclNwbGl0UmVnRXhwKS5mb3JFYWNoKChwYWlyKSA9PiB7XG4gICAgZXFJbmR4ID0gcGFpci5pbmRleE9mKCc9Jyk7XG4gICAgaWYgKGVxSW5keCA8IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAga2V5ID0gcGFpci5zdWJzdHIoMCwgZXFJbmR4KS50cmltKCk7XG4gICAga2V5ID0gdHJ5RGVjb2RlKHVuZXNjYXBlKGtleSksIChvcHQuZGVjb2RlIHx8IGRlY29kZSkpO1xuICAgIHZhbCA9IHBhaXIuc3Vic3RyKCsrZXFJbmR4LCBwYWlyLmxlbmd0aCkudHJpbSgpO1xuICAgIGlmICh2YWxbMF0gPT09ICdcIicpIHtcbiAgICAgIHZhbCA9IHZhbC5zbGljZSgxLCAtMSk7XG4gICAgfVxuICAgIGlmICh2b2lkIDAgPT09IG9ialtrZXldKSB7XG4gICAgICBvYmpba2V5XSA9IHRyeURlY29kZSh2YWwsIChvcHQuZGVjb2RlIHx8IGRlY29kZSkpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBvYmo7XG59O1xuXG4vKlxuICogQGZ1bmN0aW9uXG4gKiBAbmFtZSBhbnRpQ2lyY3VsYXJcbiAqIEBwYXJhbSBkYXRhIHtPYmplY3R9IC0gQ2lyY3VsYXIgb3IgYW55IG90aGVyIG9iamVjdCB3aGljaCBuZWVkcyB0byBiZSBub24tY2lyY3VsYXJcbiAqIEBwcml2YXRlXG4gKi9cbmNvbnN0IGFudGlDaXJjdWxhciA9IChfb2JqKSA9PiB7XG4gIGNvbnN0IG9iamVjdCA9IGhlbHBlcnMuY2xvbmUoX29iaik7XG4gIGNvbnN0IGNhY2hlICA9IG5ldyBNYXAoKTtcbiAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KG9iamVjdCwgKGtleSwgdmFsdWUpID0+IHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbCkge1xuICAgICAgaWYgKGNhY2hlLmdldCh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgIH1cbiAgICAgIGNhY2hlLnNldCh2YWx1ZSwgdHJ1ZSk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfSk7XG59O1xuXG4vKlxuICogQGZ1bmN0aW9uXG4gKiBAbmFtZSBzZXJpYWxpemVcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lXG4gKiBAcGFyYW0ge1N0cmluZ30gdmFsXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcmV0dXJuIHsgY29va2llU3RyaW5nOiBTdHJpbmcsIHNhbml0aXplZFZhbHVlOiBNaXhlZCB9XG4gKiBAc3VtbWFyeVxuICogU2VyaWFsaXplIGRhdGEgaW50byBhIGNvb2tpZSBoZWFkZXIuXG4gKiBTZXJpYWxpemUgdGhlIGEgbmFtZSB2YWx1ZSBwYWlyIGludG8gYSBjb29raWUgc3RyaW5nIHN1aXRhYmxlIGZvclxuICogaHR0cCBoZWFkZXJzLiBBbiBvcHRpb25hbCBvcHRpb25zIG9iamVjdCBzcGVjaWZpZWQgY29va2llIHBhcmFtZXRlcnMuXG4gKiBzZXJpYWxpemUoJ2ZvbycsICdiYXInLCB7IGh0dHBPbmx5OiB0cnVlIH0pID0+IFwiZm9vPWJhcjsgaHR0cE9ubHlcIlxuICogQHByaXZhdGVcbiAqL1xuY29uc3Qgc2VyaWFsaXplID0gKGtleSwgdmFsLCBvcHQgPSB7fSkgPT4ge1xuICBsZXQgbmFtZTtcblxuICBpZiAoIWZpZWxkQ29udGVudFJlZ0V4cC50ZXN0KGtleSkpIHtcbiAgICBuYW1lID0gZXNjYXBlKGtleSk7XG4gIH0gZWxzZSB7XG4gICAgbmFtZSA9IGtleTtcbiAgfVxuXG4gIGxldCBzYW5pdGl6ZWRWYWx1ZSA9IHZhbDtcbiAgbGV0IHZhbHVlID0gdmFsO1xuICBpZiAoIWhlbHBlcnMuaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgaWYgKGhlbHBlcnMuaXNPYmplY3QodmFsdWUpIHx8IGhlbHBlcnMuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIGNvbnN0IHN0cmluZ2lmaWVkID0gYW50aUNpcmN1bGFyKHZhbHVlKTtcbiAgICAgIHZhbHVlID0gZW5jb2RlKGBKU09OLnBhcnNlKCR7c3RyaW5naWZpZWR9KWApO1xuICAgICAgc2FuaXRpemVkVmFsdWUgPSBKU09OLnBhcnNlKHN0cmluZ2lmaWVkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFsdWUgPSBlbmNvZGUodmFsdWUpO1xuICAgICAgaWYgKHZhbHVlICYmICFmaWVsZENvbnRlbnRSZWdFeHAudGVzdCh2YWx1ZSkpIHtcbiAgICAgICAgdmFsdWUgPSBlc2NhcGUodmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICB2YWx1ZSA9ICcnO1xuICB9XG5cbiAgY29uc3QgcGFpcnMgPSBbYCR7bmFtZX09JHt2YWx1ZX1gXTtcblxuICBpZiAoaGVscGVycy5pc051bWJlcihvcHQubWF4QWdlKSkge1xuICAgIHBhaXJzLnB1c2goYE1heC1BZ2U9JHtvcHQubWF4QWdlfWApO1xuICB9XG5cbiAgaWYgKG9wdC5kb21haW4gJiYgdHlwZW9mIG9wdC5kb21haW4gPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKCFmaWVsZENvbnRlbnRSZWdFeHAudGVzdChvcHQuZG9tYWluKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDQsICdvcHRpb24gZG9tYWluIGlzIGludmFsaWQnKTtcbiAgICB9XG4gICAgcGFpcnMucHVzaChgRG9tYWluPSR7b3B0LmRvbWFpbn1gKTtcbiAgfVxuXG4gIGlmIChvcHQucGF0aCAmJiB0eXBlb2Ygb3B0LnBhdGggPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKCFmaWVsZENvbnRlbnRSZWdFeHAudGVzdChvcHQucGF0aCkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDA0LCAnb3B0aW9uIHBhdGggaXMgaW52YWxpZCcpO1xuICAgIH1cbiAgICBwYWlycy5wdXNoKGBQYXRoPSR7b3B0LnBhdGh9YCk7XG4gIH0gZWxzZSB7XG4gICAgcGFpcnMucHVzaCgnUGF0aD0vJyk7XG4gIH1cblxuICBvcHQuZXhwaXJlcyA9IG9wdC5leHBpcmVzIHx8IG9wdC5leHBpcmUgfHwgZmFsc2U7XG4gIGlmIChvcHQuZXhwaXJlcyA9PT0gSW5maW5pdHkpIHtcbiAgICBwYWlycy5wdXNoKCdFeHBpcmVzPUZyaSwgMzEgRGVjIDk5OTkgMjM6NTk6NTkgR01UJyk7XG4gIH0gZWxzZSBpZiAob3B0LmV4cGlyZXMgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgcGFpcnMucHVzaChgRXhwaXJlcz0ke29wdC5leHBpcmVzLnRvVVRDU3RyaW5nKCl9YCk7XG4gIH0gZWxzZSBpZiAob3B0LmV4cGlyZXMgPT09IDApIHtcbiAgICBwYWlycy5wdXNoKCdFeHBpcmVzPTAnKTtcbiAgfSBlbHNlIGlmIChoZWxwZXJzLmlzTnVtYmVyKG9wdC5leHBpcmVzKSkge1xuICAgIHBhaXJzLnB1c2goYEV4cGlyZXM9JHsobmV3IERhdGUob3B0LmV4cGlyZXMpKS50b1VUQ1N0cmluZygpfWApO1xuICB9XG5cbiAgaWYgKG9wdC5odHRwT25seSkge1xuICAgIHBhaXJzLnB1c2goJ0h0dHBPbmx5Jyk7XG4gIH1cblxuICBpZiAob3B0LnNlY3VyZSkge1xuICAgIHBhaXJzLnB1c2goJ1NlY3VyZScpO1xuICB9XG5cbiAgaWYgKG9wdC5maXJzdFBhcnR5T25seSkge1xuICAgIHBhaXJzLnB1c2goJ0ZpcnN0LVBhcnR5LU9ubHknKTtcbiAgfVxuXG4gIGlmIChvcHQuc2FtZVNpdGUpIHtcbiAgICBwYWlycy5wdXNoKG9wdC5zYW1lU2l0ZSA9PT0gdHJ1ZSA/ICdTYW1lU2l0ZScgOiBgU2FtZVNpdGU9JHtvcHQuc2FtZVNpdGV9YCk7XG4gIH1cblxuICByZXR1cm4geyBjb29raWVTdHJpbmc6IHBhaXJzLmpvaW4oJzsgJyksIHNhbml0aXplZFZhbHVlIH07XG59O1xuXG5jb25zdCBpc1N0cmluZ2lmaWVkUmVnRXggPSAvSlNPTlxcLnBhcnNlXFwoKC4qKVxcKS87XG5jb25zdCBpc1R5cGVkUmVnRXggPSAvZmFsc2V8dHJ1ZXxudWxsfHVuZGVmaW5lZC87XG5jb25zdCBkZXNlcmlhbGl6ZSA9IChzdHJpbmcpID0+IHtcbiAgaWYgKHR5cGVvZiBzdHJpbmcgIT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHN0cmluZztcbiAgfVxuXG4gIGlmIChpc1N0cmluZ2lmaWVkUmVnRXgudGVzdChzdHJpbmcpKSB7XG4gICAgbGV0IG9iaiA9IHN0cmluZy5tYXRjaChpc1N0cmluZ2lmaWVkUmVnRXgpWzFdO1xuICAgIGlmIChvYmopIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKGRlY29kZShvYmopKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignW29zdHJpbzpjb29raWVzXSBbLmdldCgpXSBbZGVzZXJpYWxpemUoKV0gRXhjZXB0aW9uOicsIGUsIHN0cmluZywgb2JqKTtcbiAgICAgICAgcmV0dXJuIHN0cmluZztcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0cmluZztcbiAgfSBlbHNlIGlmIChpc1R5cGVkUmVnRXgudGVzdChzdHJpbmcpKSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2Uoc3RyaW5nKTtcbiAgfVxuICByZXR1cm4gc3RyaW5nO1xufTtcblxuLypcbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGNsYXNzIF9fY29va2llc1xuICogQHBhcmFtIG9wdHMge09iamVjdH0gLSBPcHRpb25zIChjb25maWd1cmF0aW9uKSBvYmplY3RcbiAqIEBwYXJhbSBvcHRzLl9jb29raWVzIHtPYmplY3R8U3RyaW5nfSAtIEN1cnJlbnQgY29va2llcyBhcyBTdHJpbmcgb3IgT2JqZWN0XG4gKiBAcGFyYW0gb3B0cy5UVEwge051bWJlcnxCb29sZWFufSAtIERlZmF1bHQgY29va2llcyBleHBpcmF0aW9uIHRpbWUgKG1heC1hZ2UpIGluIG1pbGxpc2Vjb25kcywgYnkgZGVmYXVsdCAtIHNlc3Npb24gKGZhbHNlKVxuICogQHBhcmFtIG9wdHMucnVuT25TZXJ2ZXIge0Jvb2xlYW59IC0gRXhwb3NlIENvb2tpZXMgY2xhc3MgdG8gU2VydmVyXG4gKiBAcGFyYW0gb3B0cy5yZXNwb25zZSB7aHR0cC5TZXJ2ZXJSZXNwb25zZXxPYmplY3R9IC0gVGhpcyBvYmplY3QgaXMgY3JlYXRlZCBpbnRlcm5hbGx5IGJ5IGEgSFRUUCBzZXJ2ZXJcbiAqIEBwYXJhbSBvcHRzLmFsbG93UXVlcnlTdHJpbmdDb29raWVzIHtCb29sZWFufSAtIEFsbG93IHBhc3NpbmcgQ29va2llcyBpbiBhIHF1ZXJ5IHN0cmluZyAoaW4gVVJMKS4gUHJpbWFyeSBzaG91bGQgYmUgdXNlZCBvbmx5IGluIENvcmRvdmEgZW52aXJvbm1lbnRcbiAqIEBwYXJhbSBvcHRzLmFsbG93ZWRDb3Jkb3ZhT3JpZ2lucyB7UmVnZXh8Qm9vbGVhbn0gLSBbU2VydmVyXSBBbGxvdyBzZXR0aW5nIENvb2tpZXMgZnJvbSB0aGF0IHNwZWNpZmljIG9yaWdpbiB3aGljaCBpbiBNZXRlb3IvQ29yZG92YSBpcyBsb2NhbGhvc3Q6MTJYWFggKF5odHRwOi8vbG9jYWxob3N0OjEyWzAtOV17M30kKVxuICogQHN1bW1hcnkgSW50ZXJuYWwgQ2xhc3NcbiAqL1xuY2xhc3MgX19jb29raWVzIHtcbiAgY29uc3RydWN0b3Iob3B0cykge1xuICAgIHRoaXMuX19wZW5kaW5nQ29va2llcyA9IFtdO1xuICAgIHRoaXMuVFRMID0gb3B0cy5UVEwgfHwgZmFsc2U7XG4gICAgdGhpcy5yZXNwb25zZSA9IG9wdHMucmVzcG9uc2UgfHwgZmFsc2U7XG4gICAgdGhpcy5ydW5PblNlcnZlciA9IG9wdHMucnVuT25TZXJ2ZXIgfHwgZmFsc2U7XG4gICAgdGhpcy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcyA9IG9wdHMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMgfHwgZmFsc2U7XG4gICAgdGhpcy5hbGxvd2VkQ29yZG92YU9yaWdpbnMgPSBvcHRzLmFsbG93ZWRDb3Jkb3ZhT3JpZ2lucyB8fCBmYWxzZTtcblxuICAgIGlmICh0aGlzLmFsbG93ZWRDb3Jkb3ZhT3JpZ2lucyA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5hbGxvd2VkQ29yZG92YU9yaWdpbnMgPSAvXmh0dHA6XFwvXFwvbG9jYWxob3N0OjEyWzAtOV17M30kLztcbiAgICB9XG5cbiAgICB0aGlzLm9yaWdpblJFID0gbmV3IFJlZ0V4cChgXmh0dHBzPzpcXC9cXC8oJHtyb290VXJsID8gcm9vdFVybCA6ICcnfSR7bW9iaWxlUm9vdFVybCA/ICgnfCcgKyBtb2JpbGVSb290VXJsKSA6ICcnfSkkYCk7XG5cbiAgICBpZiAoaGVscGVycy5pc09iamVjdChvcHRzLl9jb29raWVzKSkge1xuICAgICAgdGhpcy5jb29raWVzID0gb3B0cy5fY29va2llcztcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb29raWVzID0gcGFyc2Uob3B0cy5fY29va2llcyk7XG4gICAgfVxuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBfX2Nvb2tpZXNcbiAgICogQG5hbWUgZ2V0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBrZXkgIC0gVGhlIG5hbWUgb2YgdGhlIGNvb2tpZSB0byByZWFkXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBfdG1wIC0gVW5wYXJzZWQgc3RyaW5nIGluc3RlYWQgb2YgdXNlcidzIGNvb2tpZXNcbiAgICogQHN1bW1hcnkgUmVhZCBhIGNvb2tpZS4gSWYgdGhlIGNvb2tpZSBkb2Vzbid0IGV4aXN0IGEgbnVsbCB2YWx1ZSB3aWxsIGJlIHJldHVybmVkLlxuICAgKiBAcmV0dXJucyB7U3RyaW5nfHZvaWR9XG4gICAqL1xuICBnZXQoa2V5LCBfdG1wKSB7XG4gICAgY29uc3QgY29va2llU3RyaW5nID0gX3RtcCA/IHBhcnNlKF90bXApIDogdGhpcy5jb29raWVzO1xuICAgIGlmICgha2V5IHx8ICFjb29raWVTdHJpbmcpIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuXG4gICAgaWYgKGNvb2tpZVN0cmluZy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICByZXR1cm4gZGVzZXJpYWxpemUoY29va2llU3RyaW5nW2tleV0pO1xuICAgIH1cblxuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIF9fY29va2llc1xuICAgKiBAbmFtZSBzZXRcbiAgICogQHBhcmFtIHtTdHJpbmd9IGtleSAgIC0gVGhlIG5hbWUgb2YgdGhlIGNvb2tpZSB0byBjcmVhdGUvb3ZlcndyaXRlXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB2YWx1ZSAtIFRoZSB2YWx1ZSBvZiB0aGUgY29va2llXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzICAtIFtPcHRpb25hbF0gQ29va2llIG9wdGlvbnMgKHNlZSByZWFkbWUgZG9jcylcbiAgICogQHN1bW1hcnkgQ3JlYXRlL292ZXJ3cml0ZSBhIGNvb2tpZS5cbiAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAqL1xuICBzZXQoa2V5LCB2YWx1ZSwgb3B0cyA9IHt9KSB7XG4gICAgaWYgKGtleSAmJiAhaGVscGVycy5pc1VuZGVmaW5lZCh2YWx1ZSkpIHtcbiAgICAgIGlmIChoZWxwZXJzLmlzTnVtYmVyKHRoaXMuVFRMKSAmJiBvcHRzLmV4cGlyZXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBvcHRzLmV4cGlyZXMgPSBuZXcgRGF0ZSgrbmV3IERhdGUoKSArIHRoaXMuVFRMKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgY29va2llU3RyaW5nLCBzYW5pdGl6ZWRWYWx1ZSB9ID0gc2VyaWFsaXplKGtleSwgdmFsdWUsIG9wdHMpO1xuXG4gICAgICB0aGlzLmNvb2tpZXNba2V5XSA9IHNhbml0aXplZFZhbHVlO1xuICAgICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgICBkb2N1bWVudC5jb29raWUgPSBjb29raWVTdHJpbmc7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMucmVzcG9uc2UpIHtcbiAgICAgICAgdGhpcy5fX3BlbmRpbmdDb29raWVzLnB1c2goY29va2llU3RyaW5nKTtcbiAgICAgICAgdGhpcy5yZXNwb25zZS5zZXRIZWFkZXIoJ1NldC1Db29raWUnLCB0aGlzLl9fcGVuZGluZ0Nvb2tpZXMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgX19jb29raWVzXG4gICAqIEBuYW1lIHJlbW92ZVxuICAgKiBAcGFyYW0ge1N0cmluZ30ga2V5ICAgIC0gVGhlIG5hbWUgb2YgdGhlIGNvb2tpZSB0byBjcmVhdGUvb3ZlcndyaXRlXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBwYXRoICAgLSBbT3B0aW9uYWxdIFRoZSBwYXRoIGZyb20gd2hlcmUgdGhlIGNvb2tpZSB3aWxsIGJlXG4gICAqIHJlYWRhYmxlLiBFLmcuLCBcIi9cIiwgXCIvbXlkaXJcIjsgaWYgbm90IHNwZWNpZmllZCwgZGVmYXVsdHMgdG8gdGhlIGN1cnJlbnRcbiAgICogcGF0aCBvZiB0aGUgY3VycmVudCBkb2N1bWVudCBsb2NhdGlvbiAoc3RyaW5nIG9yIG51bGwpLiBUaGUgcGF0aCBtdXN0IGJlXG4gICAqIGFic29sdXRlIChzZWUgUkZDIDI5NjUpLiBGb3IgbW9yZSBpbmZvcm1hdGlvbiBvbiBob3cgdG8gdXNlIHJlbGF0aXZlIHBhdGhzXG4gICAqIGluIHRoaXMgYXJndW1lbnQsIHNlZTogaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL2RvY3VtZW50LmNvb2tpZSNVc2luZ19yZWxhdGl2ZV9VUkxzX2luX3RoZV9wYXRoX3BhcmFtZXRlclxuICAgKiBAcGFyYW0ge1N0cmluZ30gZG9tYWluIC0gW09wdGlvbmFsXSBUaGUgZG9tYWluIGZyb20gd2hlcmUgdGhlIGNvb2tpZSB3aWxsXG4gICAqIGJlIHJlYWRhYmxlLiBFLmcuLCBcImV4YW1wbGUuY29tXCIsIFwiLmV4YW1wbGUuY29tXCIgKGluY2x1ZGVzIGFsbCBzdWJkb21haW5zKVxuICAgKiBvciBcInN1YmRvbWFpbi5leGFtcGxlLmNvbVwiOyBpZiBub3Qgc3BlY2lmaWVkLCBkZWZhdWx0cyB0byB0aGUgaG9zdCBwb3J0aW9uXG4gICAqIG9mIHRoZSBjdXJyZW50IGRvY3VtZW50IGxvY2F0aW9uIChzdHJpbmcgb3IgbnVsbCkuXG4gICAqIEBzdW1tYXJ5IFJlbW92ZSBhIGNvb2tpZShzKS5cbiAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAqL1xuICByZW1vdmUoa2V5LCBwYXRoID0gJy8nLCBkb21haW4gPSAnJykge1xuICAgIGlmIChrZXkgJiYgdGhpcy5jb29raWVzLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgIGNvbnN0IHsgY29va2llU3RyaW5nIH0gPSBzZXJpYWxpemUoa2V5LCAnJywge1xuICAgICAgICBkb21haW4sXG4gICAgICAgIHBhdGgsXG4gICAgICAgIGV4cGlyZXM6IG5ldyBEYXRlKDApXG4gICAgICB9KTtcblxuICAgICAgZGVsZXRlIHRoaXMuY29va2llc1trZXldO1xuICAgICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgICBkb2N1bWVudC5jb29raWUgPSBjb29raWVTdHJpbmc7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMucmVzcG9uc2UpIHtcbiAgICAgICAgdGhpcy5yZXNwb25zZS5zZXRIZWFkZXIoJ1NldC1Db29raWUnLCBjb29raWVTdHJpbmcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIGlmICgha2V5ICYmIHRoaXMua2V5cygpLmxlbmd0aCA+IDAgJiYgdGhpcy5rZXlzKClbMF0gIT09ICcnKSB7XG4gICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXModGhpcy5jb29raWVzKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICB0aGlzLnJlbW92ZShrZXlzW2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIF9fY29va2llc1xuICAgKiBAbmFtZSBoYXNcbiAgICogQHBhcmFtIHtTdHJpbmd9IGtleSAgLSBUaGUgbmFtZSBvZiB0aGUgY29va2llIHRvIGNyZWF0ZS9vdmVyd3JpdGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IF90bXAgLSBVbnBhcnNlZCBzdHJpbmcgaW5zdGVhZCBvZiB1c2VyJ3MgY29va2llc1xuICAgKiBAc3VtbWFyeSBDaGVjayB3aGV0aGVyIGEgY29va2llIGV4aXN0cyBpbiB0aGUgY3VycmVudCBwb3NpdGlvbi5cbiAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAqL1xuICBoYXMoa2V5LCBfdG1wKSB7XG4gICAgY29uc3QgY29va2llU3RyaW5nID0gX3RtcCA/IHBhcnNlKF90bXApIDogdGhpcy5jb29raWVzO1xuICAgIGlmICgha2V5IHx8ICFjb29raWVTdHJpbmcpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gY29va2llU3RyaW5nLmhhc093blByb3BlcnR5KGtleSk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIF9fY29va2llc1xuICAgKiBAbmFtZSBrZXlzXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgYW4gYXJyYXkgb2YgYWxsIHJlYWRhYmxlIGNvb2tpZXMgZnJvbSB0aGlzIGxvY2F0aW9uLlxuICAgKiBAcmV0dXJucyB7W1N0cmluZ119XG4gICAqL1xuICBrZXlzKCkge1xuICAgIGlmICh0aGlzLmNvb2tpZXMpIHtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLmNvb2tpZXMpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQ2xpZW50XG4gICAqIEBtZW1iZXJPZiBfX2Nvb2tpZXNcbiAgICogQG5hbWUgc2VuZFxuICAgKiBAcGFyYW0gY2Ige0Z1bmN0aW9ufSAtIENhbGxiYWNrXG4gICAqIEBzdW1tYXJ5IFNlbmQgYWxsIGNvb2tpZXMgb3ZlciBYSFIgdG8gc2VydmVyLlxuICAgKiBAcmV0dXJucyB7dm9pZH1cbiAgICovXG4gIHNlbmQoY2IgPSBOb09wKSB7XG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgY2IobmV3IE1ldGVvci5FcnJvcig0MDAsICdDYW5cXCd0IHJ1biBgLnNlbmQoKWAgb24gc2VydmVyLCBpdFxcJ3MgQ2xpZW50IG9ubHkgbWV0aG9kIScpKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5ydW5PblNlcnZlcikge1xuICAgICAgbGV0IHBhdGggPSBgJHt3aW5kb3cuX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5ST09UX1VSTF9QQVRIX1BSRUZJWCB8fCB3aW5kb3cuX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5tZXRlb3JFbnYuUk9PVF9VUkxfUEFUSF9QUkVGSVggfHwgJyd9L19fX2Nvb2tpZV9fXy9zZXRgO1xuICAgICAgbGV0IHF1ZXJ5ID0gJyc7XG5cbiAgICAgIGlmIChNZXRlb3IuaXNDb3Jkb3ZhICYmIHRoaXMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMpIHtcbiAgICAgICAgY29uc3QgY29va2llc0tleXMgPSB0aGlzLmtleXMoKTtcbiAgICAgICAgY29uc3QgY29va2llc0FycmF5ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY29va2llc0tleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCB7IHNhbml0aXplZFZhbHVlIH0gPSBzZXJpYWxpemUoY29va2llc0tleXNbaV0sIHRoaXMuZ2V0KGNvb2tpZXNLZXlzW2ldKSk7XG4gICAgICAgICAgY29uc3QgcGFpciA9IGAke2Nvb2tpZXNLZXlzW2ldfT0ke3Nhbml0aXplZFZhbHVlfWA7XG4gICAgICAgICAgaWYgKCFjb29raWVzQXJyYXkuaW5jbHVkZXMocGFpcikpIHtcbiAgICAgICAgICAgIGNvb2tpZXNBcnJheS5wdXNoKHBhaXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb29raWVzQXJyYXkubGVuZ3RoKSB7XG4gICAgICAgICAgcGF0aCA9IE1ldGVvci5hYnNvbHV0ZVVybCgnX19fY29va2llX19fL3NldCcpO1xuICAgICAgICAgIHF1ZXJ5ID0gYD9fX19jb29raWVzX19fPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNvb2tpZXNBcnJheS5qb2luKCc7ICcpKX1gO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIEhUVFAuZ2V0KGAke3BhdGh9JHtxdWVyeX1gLCB7XG4gICAgICAgIGJlZm9yZVNlbmQoeGhyKSB7XG4gICAgICAgICAgeGhyLndpdGhDcmVkZW50aWFscyA9IHRydWU7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0sIGNiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2IobmV3IE1ldGVvci5FcnJvcig0MDAsICdDYW5cXCd0IHNlbmQgY29va2llcyBvbiBzZXJ2ZXIgd2hlbiBgcnVuT25TZXJ2ZXJgIGlzIGZhbHNlLicpKTtcbiAgICB9XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxufVxuXG4vKlxuICogQGZ1bmN0aW9uXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAc3VtbWFyeSBNaWRkbGV3YXJlIGhhbmRsZXJcbiAqIEBwcml2YXRlXG4gKi9cbmNvbnN0IF9fbWlkZGxld2FyZUhhbmRsZXIgPSAocmVxdWVzdCwgcmVzcG9uc2UsIG9wdHMpID0+IHtcbiAgbGV0IF9jb29raWVzID0ge307XG4gIGlmIChvcHRzLnJ1bk9uU2VydmVyKSB7XG4gICAgaWYgKHJlcXVlc3QuaGVhZGVycyAmJiByZXF1ZXN0LmhlYWRlcnMuY29va2llKSB7XG4gICAgICBfY29va2llcyA9IHBhcnNlKHJlcXVlc3QuaGVhZGVycy5jb29raWUpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgX19jb29raWVzKHtcbiAgICAgIF9jb29raWVzLFxuICAgICAgVFRMOiBvcHRzLlRUTCxcbiAgICAgIHJ1bk9uU2VydmVyOiBvcHRzLnJ1bk9uU2VydmVyLFxuICAgICAgcmVzcG9uc2UsXG4gICAgICBhbGxvd1F1ZXJ5U3RyaW5nQ29va2llczogb3B0cy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llc1xuICAgIH0pO1xuICB9XG5cbiAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICdDYW5cXCd0IHVzZSBtaWRkbGV3YXJlIHdoZW4gYHJ1bk9uU2VydmVyYCBpcyBmYWxzZS4nKTtcbn07XG5cbi8qXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBjbGFzcyBDb29raWVzXG4gKiBAcGFyYW0gb3B0cyB7T2JqZWN0fVxuICogQHBhcmFtIG9wdHMuVFRMIHtOdW1iZXJ9IC0gRGVmYXVsdCBjb29raWVzIGV4cGlyYXRpb24gdGltZSAobWF4LWFnZSkgaW4gbWlsbGlzZWNvbmRzLCBieSBkZWZhdWx0IC0gc2Vzc2lvbiAoZmFsc2UpXG4gKiBAcGFyYW0gb3B0cy5hdXRvIHtCb29sZWFufSAtIFtTZXJ2ZXJdIEF1dG8tYmluZCBpbiBtaWRkbGV3YXJlIGFzIGByZXEuQ29va2llc2AsIGJ5IGRlZmF1bHQgYHRydWVgXG4gKiBAcGFyYW0gb3B0cy5oYW5kbGVyIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBNaWRkbGV3YXJlIGhhbmRsZXJcbiAqIEBwYXJhbSBvcHRzLnJ1bk9uU2VydmVyIHtCb29sZWFufSAtIEV4cG9zZSBDb29raWVzIGNsYXNzIHRvIFNlcnZlclxuICogQHBhcmFtIG9wdHMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMge0Jvb2xlYW59IC0gQWxsb3cgcGFzc2luZyBDb29raWVzIGluIGEgcXVlcnkgc3RyaW5nIChpbiBVUkwpLiBQcmltYXJ5IHNob3VsZCBiZSB1c2VkIG9ubHkgaW4gQ29yZG92YSBlbnZpcm9ubWVudFxuICogQHBhcmFtIG9wdHMuYWxsb3dlZENvcmRvdmFPcmlnaW5zIHtSZWdleHxCb29sZWFufSAtIFtTZXJ2ZXJdIEFsbG93IHNldHRpbmcgQ29va2llcyBmcm9tIHRoYXQgc3BlY2lmaWMgb3JpZ2luIHdoaWNoIGluIE1ldGVvci9Db3Jkb3ZhIGlzIGxvY2FsaG9zdDoxMlhYWCAoXmh0dHA6Ly9sb2NhbGhvc3Q6MTJbMC05XXszfSQpXG4gKiBAc3VtbWFyeSBNYWluIENvb2tpZSBjbGFzc1xuICovXG5jbGFzcyBDb29raWVzIGV4dGVuZHMgX19jb29raWVzIHtcbiAgY29uc3RydWN0b3Iob3B0cyA9IHt9KSB7XG4gICAgb3B0cy5UVEwgPSBoZWxwZXJzLmlzTnVtYmVyKG9wdHMuVFRMKSA/IG9wdHMuVFRMIDogZmFsc2U7XG4gICAgb3B0cy5ydW5PblNlcnZlciA9IChvcHRzLnJ1bk9uU2VydmVyICE9PSBmYWxzZSkgPyB0cnVlIDogZmFsc2U7XG4gICAgb3B0cy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcyA9IChvcHRzLmFsbG93UXVlcnlTdHJpbmdDb29raWVzICE9PSB0cnVlKSA/IGZhbHNlIDogdHJ1ZTtcblxuICAgIGlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAgIG9wdHMuX2Nvb2tpZXMgPSBkb2N1bWVudC5jb29raWU7XG4gICAgICBzdXBlcihvcHRzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0cy5fY29va2llcyA9IHt9O1xuICAgICAgc3VwZXIob3B0cyk7XG4gICAgICBvcHRzLmF1dG8gPSAob3B0cy5hdXRvICE9PSBmYWxzZSkgPyB0cnVlIDogZmFsc2U7XG4gICAgICB0aGlzLm9wdHMgPSBvcHRzO1xuICAgICAgdGhpcy5oYW5kbGVyID0gaGVscGVycy5pc0Z1bmN0aW9uKG9wdHMuaGFuZGxlcikgPyBvcHRzLmhhbmRsZXIgOiBmYWxzZTtcbiAgICAgIHRoaXMub25Db29raWVzID0gaGVscGVycy5pc0Z1bmN0aW9uKG9wdHMub25Db29raWVzKSA/IG9wdHMub25Db29raWVzIDogZmFsc2U7XG5cbiAgICAgIGlmIChvcHRzLnJ1bk9uU2VydmVyICYmICFDb29raWVzLmlzTG9hZGVkT25TZXJ2ZXIpIHtcbiAgICAgICAgQ29va2llcy5pc0xvYWRlZE9uU2VydmVyID0gdHJ1ZTtcbiAgICAgICAgaWYgKG9wdHMuYXV0bykge1xuICAgICAgICAgIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKChyZXEsIHJlcywgbmV4dCkgPT4ge1xuICAgICAgICAgICAgaWYgKHVybFJFLnRlc3QocmVxLl9wYXJzZWRVcmwucGF0aCkpIHtcbiAgICAgICAgICAgICAgY29uc3QgbWF0Y2hlZENvcmRvdmFPcmlnaW4gPSAhIXJlcS5oZWFkZXJzLm9yaWdpblxuICAgICAgICAgICAgICAgICYmIHRoaXMuYWxsb3dlZENvcmRvdmFPcmlnaW5zXG4gICAgICAgICAgICAgICAgJiYgdGhpcy5hbGxvd2VkQ29yZG92YU9yaWdpbnMudGVzdChyZXEuaGVhZGVycy5vcmlnaW4pO1xuICAgICAgICAgICAgICBjb25zdCBtYXRjaGVkT3JpZ2luID0gbWF0Y2hlZENvcmRvdmFPcmlnaW5cbiAgICAgICAgICAgICAgICB8fCAoISFyZXEuaGVhZGVycy5vcmlnaW4gJiYgdGhpcy5vcmlnaW5SRS50ZXN0KHJlcS5oZWFkZXJzLm9yaWdpbikpO1xuXG4gICAgICAgICAgICAgIGlmIChtYXRjaGVkT3JpZ2luKSB7XG4gICAgICAgICAgICAgICAgcmVzLnNldEhlYWRlcignQWNjZXNzLUNvbnRyb2wtQWxsb3ctQ3JlZGVudGlhbHMnLCAndHJ1ZScpO1xuICAgICAgICAgICAgICAgIHJlcy5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbicsIHJlcS5oZWFkZXJzLm9yaWdpbik7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBjb29raWVzQXJyYXkgPSBbXTtcbiAgICAgICAgICAgICAgbGV0IGNvb2tpZXNPYmplY3QgPSB7fTtcbiAgICAgICAgICAgICAgaWYgKG1hdGNoZWRDb3Jkb3ZhT3JpZ2luICYmIG9wdHMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMgJiYgcmVxLnF1ZXJ5Ll9fX2Nvb2tpZXNfX18pIHtcbiAgICAgICAgICAgICAgICBjb29raWVzT2JqZWN0ID0gcGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KHJlcS5xdWVyeS5fX19jb29raWVzX19fKSk7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAocmVxLmhlYWRlcnMuY29va2llKSB7XG4gICAgICAgICAgICAgICAgY29va2llc09iamVjdCA9IHBhcnNlKHJlcS5oZWFkZXJzLmNvb2tpZSk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBjb29raWVzS2V5cyA9IE9iamVjdC5rZXlzKGNvb2tpZXNPYmplY3QpO1xuICAgICAgICAgICAgICBpZiAoY29va2llc0tleXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb29raWVzS2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgY29uc3QgeyBjb29raWVTdHJpbmcgfSA9IHNlcmlhbGl6ZShjb29raWVzS2V5c1tpXSwgY29va2llc09iamVjdFtjb29raWVzS2V5c1tpXV0pO1xuICAgICAgICAgICAgICAgICAgaWYgKCFjb29raWVzQXJyYXkuaW5jbHVkZXMoY29va2llU3RyaW5nKSkge1xuICAgICAgICAgICAgICAgICAgICBjb29raWVzQXJyYXkucHVzaChjb29raWVTdHJpbmcpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChjb29raWVzQXJyYXkubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgY29va2llc0FycmF5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkNvb2tpZXMpICYmIHRoaXMub25Db29raWVzKF9fbWlkZGxld2FyZUhhbmRsZXIocmVxLCByZXMsIG9wdHMpKTtcblxuICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgICAgICAgIHJlcy5lbmQoJycpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmVxLkNvb2tpZXMgPSBfX21pZGRsZXdhcmVIYW5kbGVyKHJlcSwgcmVzLCBvcHRzKTtcbiAgICAgICAgICAgICAgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMuaGFuZGxlcikgJiYgdGhpcy5oYW5kbGVyKHJlcS5Db29raWVzKTtcbiAgICAgICAgICAgICAgbmV4dCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgQ29va2llc1xuICAgKiBAbmFtZSBtaWRkbGV3YXJlXG4gICAqIEBzdW1tYXJ5IEdldCBDb29raWVzIGluc3RhbmNlIGludG8gY2FsbGJhY2tcbiAgICogQHJldHVybnMge3ZvaWR9XG4gICAqL1xuICBtaWRkbGV3YXJlKCkge1xuICAgIGlmICghTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJ1tvc3RyaW86Y29va2llc10gQ2FuXFwndCB1c2UgYC5taWRkbGV3YXJlKClgIG9uIENsaWVudCwgaXRcXCdzIFNlcnZlciBvbmx5IScpO1xuICAgIH1cblxuICAgIHJldHVybiAocmVxLCByZXMsIG5leHQpID0+IHtcbiAgICAgIGhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLmhhbmRsZXIpICYmIHRoaXMuaGFuZGxlcihfX21pZGRsZXdhcmVIYW5kbGVyKHJlcSwgcmVzLCB0aGlzLm9wdHMpKTtcbiAgICAgIG5leHQoKTtcbiAgICB9O1xuICB9XG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgQ29va2llcy5pc0xvYWRlZE9uU2VydmVyID0gZmFsc2U7XG59XG5cbi8qIEV4cG9ydCB0aGUgQ29va2llcyBjbGFzcyAqL1xuZXhwb3J0IHsgQ29va2llcyB9O1xuIl19
