(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var NpmModuleBcrypt = Package['npm-bcrypt'].NpmModuleBcrypt;
var Accounts = Package['accounts-base'].Accounts;
var SRP = Package.srp.SRP;
var SHA256 = Package.sha.SHA256;
var EJSON = Package.ejson.EJSON;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Email = Package.email.Email;
var EmailInternals = Package.email.EmailInternals;
var Random = Package.random.Random;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"accounts-password":{"email_templates.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/accounts-password/email_templates.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const greet = welcomeMsg => (user, url) => {
  const greeting = user.profile && user.profile.name ? "Hello ".concat(user.profile.name, ",") : "Hello,";
  return "".concat(greeting, "\n\n").concat(welcomeMsg, ", simply click the link below.\n\n").concat(url, "\n\nThanks.\n");
};
/**
 * @summary Options to customize emails sent from the Accounts system.
 * @locus Server
 * @importFromPackage accounts-base
 */


Accounts.emailTemplates = {
  from: "Accounts Example <no-reply@example.com>",
  siteName: Meteor.absoluteUrl().replace(/^https?:\/\//, '').replace(/\/$/, ''),
  resetPassword: {
    subject: () => "How to reset your password on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To reset your password")
  },
  verifyEmail: {
    subject: () => "How to verify email address on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To verify your account email")
  },
  enrollAccount: {
    subject: () => "An account has been created for you on ".concat(Accounts.emailTemplates.siteName),
    text: greet("To start using the service")
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"password_server.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/accounts-password/password_server.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
/// BCRYPT
const bcrypt = NpmModuleBcrypt;
const bcryptHash = Meteor.wrapAsync(bcrypt.hash);
const bcryptCompare = Meteor.wrapAsync(bcrypt.compare); // Utility for grabbing user

const getUserById = id => Meteor.users.findOne(id); // User records have a 'services.password.bcrypt' field on them to hold
// their hashed passwords (unless they have a 'services.password.srp'
// field, in which case they will be upgraded to bcrypt the next time
// they log in).
//
// When the client sends a password to the server, it can either be a
// string (the plaintext password) or an object with keys 'digest' and
// 'algorithm' (must be "sha-256" for now). The Meteor client always sends
// password objects { digest: *, algorithm: "sha-256" }, but DDP clients
// that don't have access to SHA can just send plaintext passwords as
// strings.
//
// When the server receives a plaintext password as a string, it always
// hashes it with SHA256 before passing it into bcrypt. When the server
// receives a password as an object, it asserts that the algorithm is
// "sha-256" and then passes the digest to bcrypt.


Accounts._bcryptRounds = () => Accounts._options.bcryptRounds || 10; // Given a 'password' from the client, extract the string that we should
// bcrypt. 'password' can be one of:
//  - String (the plaintext password)
//  - Object with 'digest' and 'algorithm' keys. 'algorithm' must be "sha-256".
//


const getPasswordString = password => {
  if (typeof password === "string") {
    password = SHA256(password);
  } else {
    // 'password' is an object
    if (password.algorithm !== "sha-256") {
      throw new Error("Invalid password hash algorithm. " + "Only 'sha-256' is allowed.");
    }

    password = password.digest;
  }

  return password;
}; // Use bcrypt to hash the password for storage in the database.
// `password` can be a string (in which case it will be run through
// SHA256 before bcrypt) or an object with properties `digest` and
// `algorithm` (in which case we bcrypt `password.digest`).
//


const hashPassword = password => {
  password = getPasswordString(password);
  return bcryptHash(password, Accounts._bcryptRounds());
}; // Extract the number of rounds used in the specified bcrypt hash.


const getRoundsFromBcryptHash = hash => {
  let rounds;

  if (hash) {
    const hashSegments = hash.split('$');

    if (hashSegments.length > 2) {
      rounds = parseInt(hashSegments[2], 10);
    }
  }

  return rounds;
}; // Check whether the provided password matches the bcrypt'ed password in
// the database user record. `password` can be a string (in which case
// it will be run through SHA256 before bcrypt) or an object with
// properties `digest` and `algorithm` (in which case we bcrypt
// `password.digest`).
//


Accounts._checkPassword = (user, password) => {
  const result = {
    userId: user._id
  };
  const formattedPassword = getPasswordString(password);
  const hash = user.services.password.bcrypt;
  const hashRounds = getRoundsFromBcryptHash(hash);

  if (!bcryptCompare(formattedPassword, hash)) {
    result.error = handleError("Incorrect password", false);
  } else if (hash && Accounts._bcryptRounds() != hashRounds) {
    // The password checks out, but the user's bcrypt hash needs to be updated.
    Meteor.defer(() => {
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          'services.password.bcrypt': bcryptHash(formattedPassword, Accounts._bcryptRounds())
        }
      });
    });
  }

  return result;
};

const checkPassword = Accounts._checkPassword; ///
/// ERROR HANDLER
///

const handleError = function (msg) {
  let throwError = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  const error = new Meteor.Error(403, Accounts._options.ambiguousErrorMessages ? "Something went wrong. Please check your credentials." : msg);

  if (throwError) {
    throw error;
  }

  return error;
}; ///
/// LOGIN
///


Accounts._findUserByQuery = query => {
  let user = null;

  if (query.id) {
    user = getUserById(query.id);
  } else {
    let fieldName;
    let fieldValue;

    if (query.username) {
      fieldName = 'username';
      fieldValue = query.username;
    } else if (query.email) {
      fieldName = 'emails.address';
      fieldValue = query.email;
    } else {
      throw new Error("shouldn't happen (validation missed something)");
    }

    let selector = {};
    selector[fieldName] = fieldValue;
    user = Meteor.users.findOne(selector); // If user is not found, try a case insensitive lookup

    if (!user) {
      selector = selectorForFastCaseInsensitiveLookup(fieldName, fieldValue);
      const candidateUsers = Meteor.users.find(selector).fetch(); // No match if multiple candidates are found

      if (candidateUsers.length === 1) {
        user = candidateUsers[0];
      }
    }
  }

  return user;
};
/**
 * @summary Finds the user with the specified username.
 * First tries to match username case sensitively; if that fails, it
 * tries case insensitively; but if more than one user matches the case
 * insensitive search, it returns null.
 * @locus Server
 * @param {String} username The username to look for
 * @returns {Object} A user if found, else null
 * @importFromPackage accounts-base
 */


Accounts.findUserByUsername = username => Accounts._findUserByQuery({
  username
});
/**
 * @summary Finds the user with the specified email.
 * First tries to match email case sensitively; if that fails, it
 * tries case insensitively; but if more than one user matches the case
 * insensitive search, it returns null.
 * @locus Server
 * @param {String} email The email address to look for
 * @returns {Object} A user if found, else null
 * @importFromPackage accounts-base
 */


Accounts.findUserByEmail = email => Accounts._findUserByQuery({
  email
}); // Generates a MongoDB selector that can be used to perform a fast case
// insensitive lookup for the given fieldName and string. Since MongoDB does
// not support case insensitive indexes, and case insensitive regex queries
// are slow, we construct a set of prefix selectors for all permutations of
// the first 4 characters ourselves. We first attempt to matching against
// these, and because 'prefix expression' regex queries do use indexes (see
// http://docs.mongodb.org/v2.6/reference/operator/query/regex/#index-use),
// this has been found to greatly improve performance (from 1200ms to 5ms in a
// test with 1.000.000 users).


const selectorForFastCaseInsensitiveLookup = (fieldName, string) => {
  // Performance seems to improve up to 4 prefix characters
  const prefix = string.substring(0, Math.min(string.length, 4));
  const orClause = generateCasePermutationsForString(prefix).map(prefixPermutation => {
    const selector = {};
    selector[fieldName] = new RegExp("^".concat(Meteor._escapeRegExp(prefixPermutation)));
    return selector;
  });
  const caseInsensitiveClause = {};
  caseInsensitiveClause[fieldName] = new RegExp("^".concat(Meteor._escapeRegExp(string), "$"), 'i');
  return {
    $and: [{
      $or: orClause
    }, caseInsensitiveClause]
  };
}; // Generates permutations of all case variations of a given string.


const generateCasePermutationsForString = string => {
  let permutations = [''];

  for (let i = 0; i < string.length; i++) {
    const ch = string.charAt(i);
    permutations = [].concat(...permutations.map(prefix => {
      const lowerCaseChar = ch.toLowerCase();
      const upperCaseChar = ch.toUpperCase(); // Don't add unneccesary permutations when ch is not a letter

      if (lowerCaseChar === upperCaseChar) {
        return [prefix + ch];
      } else {
        return [prefix + lowerCaseChar, prefix + upperCaseChar];
      }
    }));
  }

  return permutations;
};

const checkForCaseInsensitiveDuplicates = (fieldName, displayName, fieldValue, ownUserId) => {
  // Some tests need the ability to add users with the same case insensitive
  // value, hence the _skipCaseInsensitiveChecksForTest check
  const skipCheck = Object.prototype.hasOwnProperty.call(Accounts._skipCaseInsensitiveChecksForTest, fieldValue);

  if (fieldValue && !skipCheck) {
    const matchedUsers = Meteor.users.find(selectorForFastCaseInsensitiveLookup(fieldName, fieldValue)).fetch();

    if (matchedUsers.length > 0 && ( // If we don't have a userId yet, any match we find is a duplicate
    !ownUserId || // Otherwise, check to see if there are multiple matches or a match
    // that is not us
    matchedUsers.length > 1 || matchedUsers[0]._id !== ownUserId)) {
      handleError("".concat(displayName, " already exists."));
    }
  }
}; // XXX maybe this belongs in the check package


const NonEmptyString = Match.Where(x => {
  check(x, String);
  return x.length > 0;
});
const userQueryValidator = Match.Where(user => {
  check(user, {
    id: Match.Optional(NonEmptyString),
    username: Match.Optional(NonEmptyString),
    email: Match.Optional(NonEmptyString)
  });
  if (Object.keys(user).length !== 1) throw new Match.Error("User property must have exactly one field");
  return true;
});
const passwordValidator = Match.OneOf(String, {
  digest: String,
  algorithm: String
}); // Handler to login with a password.
//
// The Meteor client sets options.password to an object with keys
// 'digest' (set to SHA256(password)) and 'algorithm' ("sha-256").
//
// For other DDP clients which don't have access to SHA, the handler
// also accepts the plaintext password in options.password as a string.
//
// (It might be nice if servers could turn the plaintext password
// option off. Or maybe it should be opt-in, not opt-out?
// Accounts.config option?)
//
// Note that neither password option is secure without SSL.
//

Accounts.registerLoginHandler("password", options => {
  if (!options.password || options.srp) return undefined; // don't handle

  check(options, {
    user: userQueryValidator,
    password: passwordValidator
  });

  const user = Accounts._findUserByQuery(options.user);

  if (!user) {
    handleError("User not found");
  }

  if (!user.services || !user.services.password || !(user.services.password.bcrypt || user.services.password.srp)) {
    handleError("User has no password set");
  }

  if (!user.services.password.bcrypt) {
    if (typeof options.password === "string") {
      // The client has presented a plaintext password, and the user is
      // not upgraded to bcrypt yet. We don't attempt to tell the client
      // to upgrade to bcrypt, because it might be a standalone DDP
      // client doesn't know how to do such a thing.
      const verifier = user.services.password.srp;
      const newVerifier = SRP.generateVerifier(options.password, {
        identity: verifier.identity,
        salt: verifier.salt
      });

      if (verifier.verifier !== newVerifier.verifier) {
        return {
          userId: Accounts._options.ambiguousErrorMessages ? null : user._id,
          error: handleError("Incorrect password", false)
        };
      }

      return {
        userId: user._id
      };
    } else {
      // Tell the client to use the SRP upgrade process.
      throw new Meteor.Error(400, "old password format", EJSON.stringify({
        format: 'srp',
        identity: user.services.password.srp.identity
      }));
    }
  }

  return checkPassword(user, options.password);
}); // Handler to login using the SRP upgrade path. To use this login
// handler, the client must provide:
//   - srp: H(identity + ":" + password)
//   - password: a string or an object with properties 'digest' and 'algorithm'
//
// We use `options.srp` to verify that the client knows the correct
// password without doing a full SRP flow. Once we've checked that, we
// upgrade the user to bcrypt and remove the SRP information from the
// user document.
//
// The client ends up using this login handler after trying the normal
// login handler (above), which throws an error telling the client to
// try the SRP upgrade path.
//
// XXX COMPAT WITH 0.8.1.3

Accounts.registerLoginHandler("password", options => {
  if (!options.srp || !options.password) {
    return undefined; // don't handle
  }

  check(options, {
    user: userQueryValidator,
    srp: String,
    password: passwordValidator
  });

  const user = Accounts._findUserByQuery(options.user);

  if (!user) {
    handleError("User not found");
  } // Check to see if another simultaneous login has already upgraded
  // the user record to bcrypt.


  if (user.services && user.services.password && user.services.password.bcrypt) {
    return checkPassword(user, options.password);
  }

  if (!(user.services && user.services.password && user.services.password.srp)) {
    handleError("User has no password set");
  }

  const v1 = user.services.password.srp.verifier;
  const v2 = SRP.generateVerifier(null, {
    hashedIdentityAndPassword: options.srp,
    salt: user.services.password.srp.salt
  }).verifier;

  if (v1 !== v2) {
    return {
      userId: Accounts._options.ambiguousErrorMessages ? null : user._id,
      error: handleError("Incorrect password", false)
    };
  } // Upgrade to bcrypt on successful login.


  const salted = hashPassword(options.password);
  Meteor.users.update(user._id, {
    $unset: {
      'services.password.srp': 1
    },
    $set: {
      'services.password.bcrypt': salted
    }
  });
  return {
    userId: user._id
  };
}); ///
/// CHANGING
///

/**
 * @summary Change a user's username. Use this instead of updating the
 * database directly. The operation will fail if there is an existing user
 * with a username only differing in case.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} newUsername A new username for the user.
 * @importFromPackage accounts-base
 */

Accounts.setUsername = (userId, newUsername) => {
  check(userId, NonEmptyString);
  check(newUsername, NonEmptyString);
  const user = getUserById(userId);

  if (!user) {
    handleError("User not found");
  }

  const oldUsername = user.username; // Perform a case insensitive check for duplicates before update

  checkForCaseInsensitiveDuplicates('username', 'Username', newUsername, user._id);
  Meteor.users.update({
    _id: user._id
  }, {
    $set: {
      username: newUsername
    }
  }); // Perform another check after update, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('username', 'Username', newUsername, user._id);
  } catch (ex) {
    // Undo update if the check fails
    Meteor.users.update({
      _id: user._id
    }, {
      $set: {
        username: oldUsername
      }
    });
    throw ex;
  }
}; // Let the user change their own password if they know the old
// password. `oldPassword` and `newPassword` should be objects with keys
// `digest` and `algorithm` (representing the SHA256 of the password).
//
// XXX COMPAT WITH 0.8.1.3
// Like the login method, if the user hasn't been upgraded from SRP to
// bcrypt yet, then this method will throw an 'old password format'
// error. The client should call the SRP upgrade login handler and then
// retry this method again.
//
// UNLIKE the login method, there is no way to avoid getting SRP upgrade
// errors thrown. The reasoning for this is that clients using this
// method directly will need to be updated anyway because we no longer
// support the SRP flow that they would have been doing to use this
// method previously.


Meteor.methods({
  changePassword: function (oldPassword, newPassword) {
    check(oldPassword, passwordValidator);
    check(newPassword, passwordValidator);

    if (!this.userId) {
      throw new Meteor.Error(401, "Must be logged in");
    }

    const user = getUserById(this.userId);

    if (!user) {
      handleError("User not found");
    }

    if (!user.services || !user.services.password || !user.services.password.bcrypt && !user.services.password.srp) {
      handleError("User has no password set");
    }

    if (!user.services.password.bcrypt) {
      throw new Meteor.Error(400, "old password format", EJSON.stringify({
        format: 'srp',
        identity: user.services.password.srp.identity
      }));
    }

    const result = checkPassword(user, oldPassword);

    if (result.error) {
      throw result.error;
    }

    const hashed = hashPassword(newPassword); // It would be better if this removed ALL existing tokens and replaced
    // the token for the current connection with a new one, but that would
    // be tricky, so we'll settle for just replacing all tokens other than
    // the one for the current connection.

    const currentToken = Accounts._getLoginToken(this.connection.id);

    Meteor.users.update({
      _id: this.userId
    }, {
      $set: {
        'services.password.bcrypt': hashed
      },
      $pull: {
        'services.resume.loginTokens': {
          hashedToken: {
            $ne: currentToken
          }
        }
      },
      $unset: {
        'services.password.reset': 1
      }
    });
    return {
      passwordChanged: true
    };
  }
}); // Force change the users password.

/**
 * @summary Forcibly change the password for a user.
 * @locus Server
 * @param {String} userId The id of the user to update.
 * @param {String} newPassword A new password for the user.
 * @param {Object} [options]
 * @param {Object} options.logout Logout all current connections with this userId (default: true)
 * @importFromPackage accounts-base
 */

Accounts.setPassword = (userId, newPlaintextPassword, options) => {
  options = _objectSpread({
    logout: true
  }, options);
  const user = getUserById(userId);

  if (!user) {
    throw new Meteor.Error(403, "User not found");
  }

  const update = {
    $unset: {
      'services.password.srp': 1,
      // XXX COMPAT WITH 0.8.1.3
      'services.password.reset': 1
    },
    $set: {
      'services.password.bcrypt': hashPassword(newPlaintextPassword)
    }
  };

  if (options.logout) {
    update.$unset['services.resume.loginTokens'] = 1;
  }

  Meteor.users.update({
    _id: user._id
  }, update);
}; ///
/// RESETTING VIA EMAIL
///
// Utility for plucking addresses from emails


const pluckAddresses = function () {
  let emails = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return emails.map(email => email.address);
}; // Method called by a user to request a password reset email. This is
// the start of the reset process.


Meteor.methods({
  forgotPassword: options => {
    check(options, {
      email: String
    });
    const user = Accounts.findUserByEmail(options.email);

    if (!user) {
      handleError("User not found");
    }

    const emails = pluckAddresses(user.emails);
    const caseSensitiveEmail = emails.find(email => email.toLowerCase() === options.email.toLowerCase());
    Accounts.sendResetPasswordEmail(user._id, caseSensitiveEmail);
  }
});
/**
 * @summary Generates a reset token and saves it into the database.
 * @locus Server
 * @param {String} userId The id of the user to generate the reset token for.
 * @param {String} email Which address of the user to generate the reset token for. This address must be in the user's `emails` list. If `null`, defaults to the first email in the list.
 * @param {String} reason `resetPassword` or `enrollAccount`.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token} values.
 * @importFromPackage accounts-base
 */

Accounts.generateResetToken = (userId, email, reason, extraTokenData) => {
  // Make sure the user exists, and email is one of their addresses.
  const user = getUserById(userId);

  if (!user) {
    handleError("Can't find user");
  } // pick the first email if we weren't passed an email.


  if (!email && user.emails && user.emails[0]) {
    email = user.emails[0].address;
  } // make sure we have a valid email


  if (!email || !pluckAddresses(user.emails).includes(email)) {
    handleError("No such email for user.");
  }

  const token = Random.secret();
  const tokenRecord = {
    token,
    email,
    when: new Date()
  };

  if (reason === 'resetPassword') {
    tokenRecord.reason = 'reset';
  } else if (reason === 'enrollAccount') {
    tokenRecord.reason = 'enroll';
  } else if (reason) {
    // fallback so that this function can be used for unknown reasons as well
    tokenRecord.reason = reason;
  }

  if (extraTokenData) {
    Object.assign(tokenRecord, extraTokenData);
  }

  Meteor.users.update({
    _id: user._id
  }, {
    $set: {
      'services.password.reset': tokenRecord
    }
  }); // before passing to template, update user object with new token

  Meteor._ensure(user, 'services', 'password').reset = tokenRecord;
  return {
    email,
    user,
    token
  };
};
/**
 * @summary Generates an e-mail verification token and saves it into the database.
 * @locus Server
 * @param {String} userId The id of the user to generate the  e-mail verification token for.
 * @param {String} email Which address of the user to generate the e-mail verification token for. This address must be in the user's `emails` list. If `null`, defaults to the first unverified email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token} values.
 * @importFromPackage accounts-base
 */


Accounts.generateVerificationToken = (userId, email, extraTokenData) => {
  // Make sure the user exists, and email is one of their addresses.
  const user = getUserById(userId);

  if (!user) {
    handleError("Can't find user");
  } // pick the first unverified email if we weren't passed an email.


  if (!email) {
    const emailRecord = (user.emails || []).find(e => !e.verified);
    email = (emailRecord || {}).address;

    if (!email) {
      handleError("That user has no unverified email addresses.");
    }
  } // make sure we have a valid email


  if (!email || !pluckAddresses(user.emails).includes(email)) {
    handleError("No such email for user.");
  }

  const token = Random.secret();
  const tokenRecord = {
    token,
    // TODO: This should probably be renamed to "email" to match reset token record.
    address: email,
    when: new Date()
  };

  if (extraTokenData) {
    Object.assign(tokenRecord, extraTokenData);
  }

  Meteor.users.update({
    _id: user._id
  }, {
    $push: {
      'services.email.verificationTokens': tokenRecord
    }
  }); // before passing to template, update user object with new token

  Meteor._ensure(user, 'services', 'email');

  if (!user.services.email.verificationTokens) {
    user.services.email.verificationTokens = [];
  }

  user.services.email.verificationTokens.push(tokenRecord);
  return {
    email,
    user,
    token
  };
};
/**
 * @summary Creates options for email sending for reset password and enroll account emails.
 * You can use this function when customizing a reset password or enroll account email sending.
 * @locus Server
 * @param {Object} email Which address of the user's to send the email to.
 * @param {Object} user The user object to generate options for.
 * @param {String} url URL to which user is directed to confirm the email.
 * @param {String} reason `resetPassword` or `enrollAccount`.
 * @returns {Object} Options which can be passed to `Email.send`.
 * @importFromPackage accounts-base
 */


Accounts.generateOptionsForEmail = (email, user, url, reason) => {
  const options = {
    to: email,
    from: Accounts.emailTemplates[reason].from ? Accounts.emailTemplates[reason].from(user) : Accounts.emailTemplates.from,
    subject: Accounts.emailTemplates[reason].subject(user)
  };

  if (typeof Accounts.emailTemplates[reason].text === 'function') {
    options.text = Accounts.emailTemplates[reason].text(user, url);
  }

  if (typeof Accounts.emailTemplates[reason].html === 'function') {
    options.html = Accounts.emailTemplates[reason].html(user, url);
  }

  if (typeof Accounts.emailTemplates.headers === 'object') {
    options.headers = Accounts.emailTemplates.headers;
  }

  return options;
}; // send the user an email with a link that when opened allows the user
// to set a new password, without the old password.

/**
 * @summary Send an email with a link the user can use to reset their password.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */


Accounts.sendResetPasswordEmail = (userId, email, extraTokenData) => {
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateResetToken(userId, email, 'resetPassword', extraTokenData);
  const url = Accounts.urls.resetPassword(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'resetPassword');
  Email.send(options);
  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // send the user an email informing them that their account was created, with
// a link that when opened both marks their email as verified and forces them
// to choose their password. The email must be one of the addresses in the
// user's emails field, or undefined to pick the first email automatically.
//
// This is not called automatically. It must be called manually if you
// want to use enrollment emails.

/**
 * @summary Send an email with a link the user can use to set their initial password.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */


Accounts.sendEnrollmentEmail = (userId, email, extraTokenData) => {
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateResetToken(userId, email, 'enrollAccount', extraTokenData);
  const url = Accounts.urls.enrollAccount(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'enrollAccount');
  Email.send(options);
  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // Take token from sendResetPasswordEmail or sendEnrollmentEmail, change
// the users password, and log them in.


Meteor.methods({
  resetPassword: function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    const token = args[0];
    const newPassword = args[1];
    return Accounts._loginMethod(this, "resetPassword", args, "password", () => {
      check(token, String);
      check(newPassword, passwordValidator);
      const user = Meteor.users.findOne({
        "services.password.reset.token": token
      });

      if (!user) {
        throw new Meteor.Error(403, "Token expired");
      }

      const {
        when,
        reason,
        email
      } = user.services.password.reset;

      let tokenLifetimeMs = Accounts._getPasswordResetTokenLifetimeMs();

      if (reason === "enroll") {
        tokenLifetimeMs = Accounts._getPasswordEnrollTokenLifetimeMs();
      }

      const currentTimeMs = Date.now();
      if (currentTimeMs - when > tokenLifetimeMs) throw new Meteor.Error(403, "Token expired");
      if (!pluckAddresses(user.emails).includes(email)) return {
        userId: user._id,
        error: new Meteor.Error(403, "Token has invalid email address")
      };
      const hashed = hashPassword(newPassword); // NOTE: We're about to invalidate tokens on the user, who we might be
      // logged in as. Make sure to avoid logging ourselves out if this
      // happens. But also make sure not to leave the connection in a state
      // of having a bad token set if things fail.

      const oldToken = Accounts._getLoginToken(this.connection.id);

      Accounts._setLoginToken(user._id, this.connection, null);

      const resetToOldToken = () => Accounts._setLoginToken(user._id, this.connection, oldToken);

      try {
        // Update the user record by:
        // - Changing the password to the new one
        // - Forgetting about the reset token that was just used
        // - Verifying their email, since they got the password reset via email.
        const affectedRecords = Meteor.users.update({
          _id: user._id,
          'emails.address': email,
          'services.password.reset.token': token
        }, {
          $set: {
            'services.password.bcrypt': hashed,
            'emails.$.verified': true
          },
          $unset: {
            'services.password.reset': 1,
            'services.password.srp': 1
          }
        });
        if (affectedRecords !== 1) return {
          userId: user._id,
          error: new Meteor.Error(403, "Invalid email")
        };
      } catch (err) {
        resetToOldToken();
        throw err;
      } // Replace all valid login tokens with new ones (changing
      // password should invalidate existing sessions).


      Accounts._clearAllLoginTokens(user._id);

      return {
        userId: user._id
      };
    });
  }
}); ///
/// EMAIL VERIFICATION
///
// send the user an email with a link that when opened marks that
// address as verified

/**
 * @summary Send an email with a link the user can use verify their email address.
 * @locus Server
 * @param {String} userId The id of the user to send email to.
 * @param {String} [email] Optional. Which address of the user's to send the email to. This address must be in the user's `emails` list. Defaults to the first unverified email in the list.
 * @param {Object} [extraTokenData] Optional additional data to be added into the token record.
 * @returns {Object} Object with {email, user, token, url, options} values.
 * @importFromPackage accounts-base
 */

Accounts.sendVerificationEmail = (userId, email, extraTokenData) => {
  // XXX Also generate a link using which someone can delete this
  // account if they own said address but weren't those who created
  // this account.
  const {
    email: realEmail,
    user,
    token
  } = Accounts.generateVerificationToken(userId, email, extraTokenData);
  const url = Accounts.urls.verifyEmail(token);
  const options = Accounts.generateOptionsForEmail(realEmail, user, url, 'verifyEmail');
  Email.send(options);
  return {
    email: realEmail,
    user,
    token,
    url,
    options
  };
}; // Take token from sendVerificationEmail, mark the email as verified,
// and log them in.


Meteor.methods({
  verifyEmail: function () {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    const token = args[0];
    return Accounts._loginMethod(this, "verifyEmail", args, "password", () => {
      check(token, String);
      const user = Meteor.users.findOne({
        'services.email.verificationTokens.token': token
      });
      if (!user) throw new Meteor.Error(403, "Verify email link expired");
      const tokenRecord = user.services.email.verificationTokens.find(t => t.token == token);
      if (!tokenRecord) return {
        userId: user._id,
        error: new Meteor.Error(403, "Verify email link expired")
      };
      const emailsRecord = user.emails.find(e => e.address == tokenRecord.address);
      if (!emailsRecord) return {
        userId: user._id,
        error: new Meteor.Error(403, "Verify email link is for unknown address")
      }; // By including the address in the query, we can use 'emails.$' in the
      // modifier to get a reference to the specific object in the emails
      // array. See
      // http://www.mongodb.org/display/DOCS/Updating/#Updating-The%24positionaloperator)
      // http://www.mongodb.org/display/DOCS/Updating#Updating-%24pull

      Meteor.users.update({
        _id: user._id,
        'emails.address': tokenRecord.address
      }, {
        $set: {
          'emails.$.verified': true
        },
        $pull: {
          'services.email.verificationTokens': {
            address: tokenRecord.address
          }
        }
      });
      return {
        userId: user._id
      };
    });
  }
});
/**
 * @summary Add an email address for a user. Use this instead of directly
 * updating the database. The operation will fail if there is a different user
 * with an email only differing in case. If the specified user has an existing
 * email only differing in case however, we replace it.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} newEmail A new email address for the user.
 * @param {Boolean} [verified] Optional - whether the new email address should
 * be marked as verified. Defaults to false.
 * @importFromPackage accounts-base
 */

Accounts.addEmail = (userId, newEmail, verified) => {
  check(userId, NonEmptyString);
  check(newEmail, NonEmptyString);
  check(verified, Match.Optional(Boolean));

  if (verified === void 0) {
    verified = false;
  }

  const user = getUserById(userId);
  if (!user) throw new Meteor.Error(403, "User not found"); // Allow users to change their own email to a version with a different case
  // We don't have to call checkForCaseInsensitiveDuplicates to do a case
  // insensitive check across all emails in the database here because: (1) if
  // there is no case-insensitive duplicate between this user and other users,
  // then we are OK and (2) if this would create a conflict with other users
  // then there would already be a case-insensitive duplicate and we can't fix
  // that in this code anyway.

  const caseInsensitiveRegExp = new RegExp("^".concat(Meteor._escapeRegExp(newEmail), "$"), 'i');
  const didUpdateOwnEmail = (user.emails || []).reduce((prev, email) => {
    if (caseInsensitiveRegExp.test(email.address)) {
      Meteor.users.update({
        _id: user._id,
        'emails.address': email.address
      }, {
        $set: {
          'emails.$.address': newEmail,
          'emails.$.verified': verified
        }
      });
      return true;
    } else {
      return prev;
    }
  }, false); // In the other updates below, we have to do another call to
  // checkForCaseInsensitiveDuplicates to make sure that no conflicting values
  // were added to the database in the meantime. We don't have to do this for
  // the case where the user is updating their email address to one that is the
  // same as before, but only different because of capitalization. Read the
  // big comment above to understand why.

  if (didUpdateOwnEmail) {
    return;
  } // Perform a case insensitive check for duplicates before update


  checkForCaseInsensitiveDuplicates('emails.address', 'Email', newEmail, user._id);
  Meteor.users.update({
    _id: user._id
  }, {
    $addToSet: {
      emails: {
        address: newEmail,
        verified: verified
      }
    }
  }); // Perform another check after update, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('emails.address', 'Email', newEmail, user._id);
  } catch (ex) {
    // Undo update if the check fails
    Meteor.users.update({
      _id: user._id
    }, {
      $pull: {
        emails: {
          address: newEmail
        }
      }
    });
    throw ex;
  }
};
/**
 * @summary Remove an email address for a user. Use this instead of updating
 * the database directly.
 * @locus Server
 * @param {String} userId The ID of the user to update.
 * @param {String} email The email address to remove.
 * @importFromPackage accounts-base
 */


Accounts.removeEmail = (userId, email) => {
  check(userId, NonEmptyString);
  check(email, NonEmptyString);
  const user = getUserById(userId);
  if (!user) throw new Meteor.Error(403, "User not found");
  Meteor.users.update({
    _id: user._id
  }, {
    $pull: {
      emails: {
        address: email
      }
    }
  });
}; ///
/// CREATING USERS
///
// Shared createUser function called from the createUser method, both
// if originates in client or server code. Calls user provided hooks,
// does the actual user insertion.
//
// returns the user id


const createUser = options => {
  // Unknown keys allowed, because a onCreateUserHook can take arbitrary
  // options.
  check(options, Match.ObjectIncluding({
    username: Match.Optional(String),
    email: Match.Optional(String),
    password: Match.Optional(passwordValidator)
  }));
  const {
    username,
    email,
    password
  } = options;
  if (!username && !email) throw new Meteor.Error(400, "Need to set a username or email");
  const user = {
    services: {}
  };

  if (password) {
    const hashed = hashPassword(password);
    user.services.password = {
      bcrypt: hashed
    };
  }

  if (username) user.username = username;
  if (email) user.emails = [{
    address: email,
    verified: false
  }]; // Perform a case insensitive check before insert

  checkForCaseInsensitiveDuplicates('username', 'Username', username);
  checkForCaseInsensitiveDuplicates('emails.address', 'Email', email);
  const userId = Accounts.insertUserDoc(options, user); // Perform another check after insert, in case a matching user has been
  // inserted in the meantime

  try {
    checkForCaseInsensitiveDuplicates('username', 'Username', username, userId);
    checkForCaseInsensitiveDuplicates('emails.address', 'Email', email, userId);
  } catch (ex) {
    // Remove inserted user if the check fails
    Meteor.users.remove(userId);
    throw ex;
  }

  return userId;
}; // method for create user. Requests come from the client.


Meteor.methods({
  createUser: function () {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    const options = args[0];
    return Accounts._loginMethod(this, "createUser", args, "password", () => {
      // createUser() above does more checking.
      check(options, Object);
      if (Accounts._options.forbidClientAccountCreation) return {
        error: new Meteor.Error(403, "Signups forbidden")
      }; // Create user. result contains id and token.

      const userId = createUser(options); // safety belt. createUser is supposed to throw on error. send 500 error
      // instead of sending a verification email with empty userid.

      if (!userId) throw new Error("createUser failed to insert new user"); // If `Accounts._options.sendVerificationEmail` is set, register
      // a token to verify the user's primary email, and send it to
      // that address.

      if (options.email && Accounts._options.sendVerificationEmail) Accounts.sendVerificationEmail(userId, options.email); // client gets logged in as the new user afterwards.

      return {
        userId: userId
      };
    });
  }
}); // Create user directly on the server.
//
// Unlike the client version, this does not log you in as this user
// after creation.
//
// returns userId or throws an error if it can't create
//
// XXX add another argument ("server options") that gets sent to onCreateUser,
// which is always empty when called from the createUser method? eg, "admin:
// true", which we want to prevent the client from setting, but which a custom
// method calling Accounts.createUser could set?
//

Accounts.createUser = (options, callback) => {
  options = _objectSpread({}, options); // XXX allow an optional callback?

  if (callback) {
    throw new Error("Accounts.createUser with callback not supported on the server yet.");
  }

  return createUser(options);
}; ///
/// PASSWORD-SPECIFIC INDEXES ON USERS
///


Meteor.users._ensureIndex('services.email.verificationTokens.token', {
  unique: 1,
  sparse: 1
});

Meteor.users._ensureIndex('services.password.reset.token', {
  unique: 1,
  sparse: 1
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/accounts-password/email_templates.js");
require("/node_modules/meteor/accounts-password/password_server.js");

/* Exports */
Package._define("accounts-password");

})();

//# sourceURL=meteor://💻app/packages/accounts-password.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWNjb3VudHMtcGFzc3dvcmQvZW1haWxfdGVtcGxhdGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9hY2NvdW50cy1wYXNzd29yZC9wYXNzd29yZF9zZXJ2ZXIuanMiXSwibmFtZXMiOlsiZ3JlZXQiLCJ3ZWxjb21lTXNnIiwidXNlciIsInVybCIsImdyZWV0aW5nIiwicHJvZmlsZSIsIm5hbWUiLCJBY2NvdW50cyIsImVtYWlsVGVtcGxhdGVzIiwiZnJvbSIsInNpdGVOYW1lIiwiTWV0ZW9yIiwiYWJzb2x1dGVVcmwiLCJyZXBsYWNlIiwicmVzZXRQYXNzd29yZCIsInN1YmplY3QiLCJ0ZXh0IiwidmVyaWZ5RW1haWwiLCJlbnJvbGxBY2NvdW50IiwiX29iamVjdFNwcmVhZCIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsImJjcnlwdCIsIk5wbU1vZHVsZUJjcnlwdCIsImJjcnlwdEhhc2giLCJ3cmFwQXN5bmMiLCJoYXNoIiwiYmNyeXB0Q29tcGFyZSIsImNvbXBhcmUiLCJnZXRVc2VyQnlJZCIsImlkIiwidXNlcnMiLCJmaW5kT25lIiwiX2JjcnlwdFJvdW5kcyIsIl9vcHRpb25zIiwiYmNyeXB0Um91bmRzIiwiZ2V0UGFzc3dvcmRTdHJpbmciLCJwYXNzd29yZCIsIlNIQTI1NiIsImFsZ29yaXRobSIsIkVycm9yIiwiZGlnZXN0IiwiaGFzaFBhc3N3b3JkIiwiZ2V0Um91bmRzRnJvbUJjcnlwdEhhc2giLCJyb3VuZHMiLCJoYXNoU2VnbWVudHMiLCJzcGxpdCIsImxlbmd0aCIsInBhcnNlSW50IiwiX2NoZWNrUGFzc3dvcmQiLCJyZXN1bHQiLCJ1c2VySWQiLCJfaWQiLCJmb3JtYXR0ZWRQYXNzd29yZCIsInNlcnZpY2VzIiwiaGFzaFJvdW5kcyIsImVycm9yIiwiaGFuZGxlRXJyb3IiLCJkZWZlciIsInVwZGF0ZSIsIiRzZXQiLCJjaGVja1Bhc3N3b3JkIiwibXNnIiwidGhyb3dFcnJvciIsImFtYmlndW91c0Vycm9yTWVzc2FnZXMiLCJfZmluZFVzZXJCeVF1ZXJ5IiwicXVlcnkiLCJmaWVsZE5hbWUiLCJmaWVsZFZhbHVlIiwidXNlcm5hbWUiLCJlbWFpbCIsInNlbGVjdG9yIiwic2VsZWN0b3JGb3JGYXN0Q2FzZUluc2Vuc2l0aXZlTG9va3VwIiwiY2FuZGlkYXRlVXNlcnMiLCJmaW5kIiwiZmV0Y2giLCJmaW5kVXNlckJ5VXNlcm5hbWUiLCJmaW5kVXNlckJ5RW1haWwiLCJzdHJpbmciLCJwcmVmaXgiLCJzdWJzdHJpbmciLCJNYXRoIiwibWluIiwib3JDbGF1c2UiLCJnZW5lcmF0ZUNhc2VQZXJtdXRhdGlvbnNGb3JTdHJpbmciLCJtYXAiLCJwcmVmaXhQZXJtdXRhdGlvbiIsIlJlZ0V4cCIsIl9lc2NhcGVSZWdFeHAiLCJjYXNlSW5zZW5zaXRpdmVDbGF1c2UiLCIkYW5kIiwiJG9yIiwicGVybXV0YXRpb25zIiwiaSIsImNoIiwiY2hhckF0IiwiY29uY2F0IiwibG93ZXJDYXNlQ2hhciIsInRvTG93ZXJDYXNlIiwidXBwZXJDYXNlQ2hhciIsInRvVXBwZXJDYXNlIiwiY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzIiwiZGlzcGxheU5hbWUiLCJvd25Vc2VySWQiLCJza2lwQ2hlY2siLCJPYmplY3QiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJfc2tpcENhc2VJbnNlbnNpdGl2ZUNoZWNrc0ZvclRlc3QiLCJtYXRjaGVkVXNlcnMiLCJOb25FbXB0eVN0cmluZyIsIk1hdGNoIiwiV2hlcmUiLCJ4IiwiY2hlY2siLCJTdHJpbmciLCJ1c2VyUXVlcnlWYWxpZGF0b3IiLCJPcHRpb25hbCIsImtleXMiLCJwYXNzd29yZFZhbGlkYXRvciIsIk9uZU9mIiwicmVnaXN0ZXJMb2dpbkhhbmRsZXIiLCJvcHRpb25zIiwic3JwIiwidW5kZWZpbmVkIiwidmVyaWZpZXIiLCJuZXdWZXJpZmllciIsIlNSUCIsImdlbmVyYXRlVmVyaWZpZXIiLCJpZGVudGl0eSIsInNhbHQiLCJFSlNPTiIsInN0cmluZ2lmeSIsImZvcm1hdCIsInYxIiwidjIiLCJoYXNoZWRJZGVudGl0eUFuZFBhc3N3b3JkIiwic2FsdGVkIiwiJHVuc2V0Iiwic2V0VXNlcm5hbWUiLCJuZXdVc2VybmFtZSIsIm9sZFVzZXJuYW1lIiwiZXgiLCJtZXRob2RzIiwiY2hhbmdlUGFzc3dvcmQiLCJvbGRQYXNzd29yZCIsIm5ld1Bhc3N3b3JkIiwiaGFzaGVkIiwiY3VycmVudFRva2VuIiwiX2dldExvZ2luVG9rZW4iLCJjb25uZWN0aW9uIiwiJHB1bGwiLCJoYXNoZWRUb2tlbiIsIiRuZSIsInBhc3N3b3JkQ2hhbmdlZCIsInNldFBhc3N3b3JkIiwibmV3UGxhaW50ZXh0UGFzc3dvcmQiLCJsb2dvdXQiLCJwbHVja0FkZHJlc3NlcyIsImVtYWlscyIsImFkZHJlc3MiLCJmb3Jnb3RQYXNzd29yZCIsImNhc2VTZW5zaXRpdmVFbWFpbCIsInNlbmRSZXNldFBhc3N3b3JkRW1haWwiLCJnZW5lcmF0ZVJlc2V0VG9rZW4iLCJyZWFzb24iLCJleHRyYVRva2VuRGF0YSIsImluY2x1ZGVzIiwidG9rZW4iLCJSYW5kb20iLCJzZWNyZXQiLCJ0b2tlblJlY29yZCIsIndoZW4iLCJEYXRlIiwiYXNzaWduIiwiX2Vuc3VyZSIsInJlc2V0IiwiZ2VuZXJhdGVWZXJpZmljYXRpb25Ub2tlbiIsImVtYWlsUmVjb3JkIiwiZSIsInZlcmlmaWVkIiwiJHB1c2giLCJ2ZXJpZmljYXRpb25Ub2tlbnMiLCJwdXNoIiwiZ2VuZXJhdGVPcHRpb25zRm9yRW1haWwiLCJ0byIsImh0bWwiLCJoZWFkZXJzIiwicmVhbEVtYWlsIiwidXJscyIsIkVtYWlsIiwic2VuZCIsInNlbmRFbnJvbGxtZW50RW1haWwiLCJhcmdzIiwiX2xvZ2luTWV0aG9kIiwidG9rZW5MaWZldGltZU1zIiwiX2dldFBhc3N3b3JkUmVzZXRUb2tlbkxpZmV0aW1lTXMiLCJfZ2V0UGFzc3dvcmRFbnJvbGxUb2tlbkxpZmV0aW1lTXMiLCJjdXJyZW50VGltZU1zIiwibm93Iiwib2xkVG9rZW4iLCJfc2V0TG9naW5Ub2tlbiIsInJlc2V0VG9PbGRUb2tlbiIsImFmZmVjdGVkUmVjb3JkcyIsImVyciIsIl9jbGVhckFsbExvZ2luVG9rZW5zIiwic2VuZFZlcmlmaWNhdGlvbkVtYWlsIiwidCIsImVtYWlsc1JlY29yZCIsImFkZEVtYWlsIiwibmV3RW1haWwiLCJCb29sZWFuIiwiY2FzZUluc2Vuc2l0aXZlUmVnRXhwIiwiZGlkVXBkYXRlT3duRW1haWwiLCJyZWR1Y2UiLCJwcmV2IiwidGVzdCIsIiRhZGRUb1NldCIsInJlbW92ZUVtYWlsIiwiY3JlYXRlVXNlciIsIk9iamVjdEluY2x1ZGluZyIsImluc2VydFVzZXJEb2MiLCJyZW1vdmUiLCJmb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb24iLCJjYWxsYmFjayIsIl9lbnN1cmVJbmRleCIsInVuaXF1ZSIsInNwYXJzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTUEsS0FBSyxHQUFHQyxVQUFVLElBQUksQ0FBQ0MsSUFBRCxFQUFPQyxHQUFQLEtBQWU7QUFDckMsUUFBTUMsUUFBUSxHQUFJRixJQUFJLENBQUNHLE9BQUwsSUFBZ0JILElBQUksQ0FBQ0csT0FBTCxDQUFhQyxJQUE5QixtQkFDREosSUFBSSxDQUFDRyxPQUFMLENBQWFDLElBRFosU0FDdUIsUUFEeEM7QUFFQSxtQkFBVUYsUUFBVixpQkFFSkgsVUFGSSwrQ0FJSkUsR0FKSTtBQVFMLENBWEQ7QUFhQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQUksUUFBUSxDQUFDQyxjQUFULEdBQTBCO0FBQ3hCQyxNQUFJLEVBQUUseUNBRGtCO0FBRXhCQyxVQUFRLEVBQUVDLE1BQU0sQ0FBQ0MsV0FBUCxHQUFxQkMsT0FBckIsQ0FBNkIsY0FBN0IsRUFBNkMsRUFBN0MsRUFBaURBLE9BQWpELENBQXlELEtBQXpELEVBQWdFLEVBQWhFLENBRmM7QUFJeEJDLGVBQWEsRUFBRTtBQUNiQyxXQUFPLEVBQUUsOENBQXVDUixRQUFRLENBQUNDLGNBQVQsQ0FBd0JFLFFBQS9ELENBREk7QUFFYk0sUUFBSSxFQUFFaEIsS0FBSyxDQUFDLHdCQUFEO0FBRkUsR0FKUztBQVF4QmlCLGFBQVcsRUFBRTtBQUNYRixXQUFPLEVBQUUsK0NBQXdDUixRQUFRLENBQUNDLGNBQVQsQ0FBd0JFLFFBQWhFLENBREU7QUFFWE0sUUFBSSxFQUFFaEIsS0FBSyxDQUFDLDhCQUFEO0FBRkEsR0FSVztBQVl4QmtCLGVBQWEsRUFBRTtBQUNiSCxXQUFPLEVBQUUsdURBQWdEUixRQUFRLENBQUNDLGNBQVQsQ0FBd0JFLFFBQXhFLENBREk7QUFFYk0sUUFBSSxFQUFFaEIsS0FBSyxDQUFDLDRCQUFEO0FBRkU7QUFaUyxDQUExQixDOzs7Ozs7Ozs7OztBQ2xCQSxJQUFJbUIsYUFBSjs7QUFBa0JDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNKLGlCQUFhLEdBQUNJLENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCO0FBRUEsTUFBTUMsTUFBTSxHQUFHQyxlQUFmO0FBQ0EsTUFBTUMsVUFBVSxHQUFHZixNQUFNLENBQUNnQixTQUFQLENBQWlCSCxNQUFNLENBQUNJLElBQXhCLENBQW5CO0FBQ0EsTUFBTUMsYUFBYSxHQUFHbEIsTUFBTSxDQUFDZ0IsU0FBUCxDQUFpQkgsTUFBTSxDQUFDTSxPQUF4QixDQUF0QixDLENBRUE7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHQyxFQUFFLElBQUlyQixNQUFNLENBQUNzQixLQUFQLENBQWFDLE9BQWIsQ0FBcUJGLEVBQXJCLENBQTFCLEMsQ0FFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0F6QixRQUFRLENBQUM0QixhQUFULEdBQXlCLE1BQU01QixRQUFRLENBQUM2QixRQUFULENBQWtCQyxZQUFsQixJQUFrQyxFQUFqRSxDLENBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUdDLFFBQVEsSUFBSTtBQUNwQyxNQUFJLE9BQU9BLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDaENBLFlBQVEsR0FBR0MsTUFBTSxDQUFDRCxRQUFELENBQWpCO0FBQ0QsR0FGRCxNQUVPO0FBQUU7QUFDUCxRQUFJQSxRQUFRLENBQUNFLFNBQVQsS0FBdUIsU0FBM0IsRUFBc0M7QUFDcEMsWUFBTSxJQUFJQyxLQUFKLENBQVUsc0NBQ0EsNEJBRFYsQ0FBTjtBQUVEOztBQUNESCxZQUFRLEdBQUdBLFFBQVEsQ0FBQ0ksTUFBcEI7QUFDRDs7QUFDRCxTQUFPSixRQUFQO0FBQ0QsQ0FYRCxDLENBYUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUssWUFBWSxHQUFHTCxRQUFRLElBQUk7QUFDL0JBLFVBQVEsR0FBR0QsaUJBQWlCLENBQUNDLFFBQUQsQ0FBNUI7QUFDQSxTQUFPYixVQUFVLENBQUNhLFFBQUQsRUFBV2hDLFFBQVEsQ0FBQzRCLGFBQVQsRUFBWCxDQUFqQjtBQUNELENBSEQsQyxDQUtBOzs7QUFDQSxNQUFNVSx1QkFBdUIsR0FBR2pCLElBQUksSUFBSTtBQUN0QyxNQUFJa0IsTUFBSjs7QUFDQSxNQUFJbEIsSUFBSixFQUFVO0FBQ1IsVUFBTW1CLFlBQVksR0FBR25CLElBQUksQ0FBQ29CLEtBQUwsQ0FBVyxHQUFYLENBQXJCOztBQUNBLFFBQUlELFlBQVksQ0FBQ0UsTUFBYixHQUFzQixDQUExQixFQUE2QjtBQUMzQkgsWUFBTSxHQUFHSSxRQUFRLENBQUNILFlBQVksQ0FBQyxDQUFELENBQWIsRUFBa0IsRUFBbEIsQ0FBakI7QUFDRDtBQUNGOztBQUNELFNBQU9ELE1BQVA7QUFDRCxDQVRELEMsQ0FXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdkMsUUFBUSxDQUFDNEMsY0FBVCxHQUEwQixDQUFDakQsSUFBRCxFQUFPcUMsUUFBUCxLQUFvQjtBQUM1QyxRQUFNYSxNQUFNLEdBQUc7QUFDYkMsVUFBTSxFQUFFbkQsSUFBSSxDQUFDb0Q7QUFEQSxHQUFmO0FBSUEsUUFBTUMsaUJBQWlCLEdBQUdqQixpQkFBaUIsQ0FBQ0MsUUFBRCxDQUEzQztBQUNBLFFBQU1YLElBQUksR0FBRzFCLElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJmLE1BQXBDO0FBQ0EsUUFBTWlDLFVBQVUsR0FBR1osdUJBQXVCLENBQUNqQixJQUFELENBQTFDOztBQUVBLE1BQUksQ0FBRUMsYUFBYSxDQUFDMEIsaUJBQUQsRUFBb0IzQixJQUFwQixDQUFuQixFQUE4QztBQUM1Q3dCLFVBQU0sQ0FBQ00sS0FBUCxHQUFlQyxXQUFXLENBQUMsb0JBQUQsRUFBdUIsS0FBdkIsQ0FBMUI7QUFDRCxHQUZELE1BRU8sSUFBSS9CLElBQUksSUFBSXJCLFFBQVEsQ0FBQzRCLGFBQVQsTUFBNEJzQixVQUF4QyxFQUFvRDtBQUN6RDtBQUNBOUMsVUFBTSxDQUFDaUQsS0FBUCxDQUFhLE1BQU07QUFDakJqRCxZQUFNLENBQUNzQixLQUFQLENBQWE0QixNQUFiLENBQW9CO0FBQUVQLFdBQUcsRUFBRXBELElBQUksQ0FBQ29EO0FBQVosT0FBcEIsRUFBdUM7QUFDckNRLFlBQUksRUFBRTtBQUNKLHNDQUNFcEMsVUFBVSxDQUFDNkIsaUJBQUQsRUFBb0JoRCxRQUFRLENBQUM0QixhQUFULEVBQXBCO0FBRlI7QUFEK0IsT0FBdkM7QUFNRCxLQVBEO0FBUUQ7O0FBRUQsU0FBT2lCLE1BQVA7QUFDRCxDQXhCRDs7QUF5QkEsTUFBTVcsYUFBYSxHQUFHeEQsUUFBUSxDQUFDNEMsY0FBL0IsQyxDQUVBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNUSxXQUFXLEdBQUcsVUFBQ0ssR0FBRCxFQUE0QjtBQUFBLE1BQXRCQyxVQUFzQix1RUFBVCxJQUFTO0FBQzlDLFFBQU1QLEtBQUssR0FBRyxJQUFJL0MsTUFBTSxDQUFDK0IsS0FBWCxDQUNaLEdBRFksRUFFWm5DLFFBQVEsQ0FBQzZCLFFBQVQsQ0FBa0I4QixzQkFBbEIsR0FDSSxzREFESixHQUVJRixHQUpRLENBQWQ7O0FBTUEsTUFBSUMsVUFBSixFQUFnQjtBQUNkLFVBQU1QLEtBQU47QUFDRDs7QUFDRCxTQUFPQSxLQUFQO0FBQ0QsQ0FYRCxDLENBYUE7QUFDQTtBQUNBOzs7QUFFQW5ELFFBQVEsQ0FBQzRELGdCQUFULEdBQTRCQyxLQUFLLElBQUk7QUFDbkMsTUFBSWxFLElBQUksR0FBRyxJQUFYOztBQUVBLE1BQUlrRSxLQUFLLENBQUNwQyxFQUFWLEVBQWM7QUFDWjlCLFFBQUksR0FBRzZCLFdBQVcsQ0FBQ3FDLEtBQUssQ0FBQ3BDLEVBQVAsQ0FBbEI7QUFDRCxHQUZELE1BRU87QUFDTCxRQUFJcUMsU0FBSjtBQUNBLFFBQUlDLFVBQUo7O0FBQ0EsUUFBSUYsS0FBSyxDQUFDRyxRQUFWLEVBQW9CO0FBQ2xCRixlQUFTLEdBQUcsVUFBWjtBQUNBQyxnQkFBVSxHQUFHRixLQUFLLENBQUNHLFFBQW5CO0FBQ0QsS0FIRCxNQUdPLElBQUlILEtBQUssQ0FBQ0ksS0FBVixFQUFpQjtBQUN0QkgsZUFBUyxHQUFHLGdCQUFaO0FBQ0FDLGdCQUFVLEdBQUdGLEtBQUssQ0FBQ0ksS0FBbkI7QUFDRCxLQUhNLE1BR0E7QUFDTCxZQUFNLElBQUk5QixLQUFKLENBQVUsZ0RBQVYsQ0FBTjtBQUNEOztBQUNELFFBQUkrQixRQUFRLEdBQUcsRUFBZjtBQUNBQSxZQUFRLENBQUNKLFNBQUQsQ0FBUixHQUFzQkMsVUFBdEI7QUFDQXBFLFFBQUksR0FBR1MsTUFBTSxDQUFDc0IsS0FBUCxDQUFhQyxPQUFiLENBQXFCdUMsUUFBckIsQ0FBUCxDQWRLLENBZUw7O0FBQ0EsUUFBSSxDQUFDdkUsSUFBTCxFQUFXO0FBQ1R1RSxjQUFRLEdBQUdDLG9DQUFvQyxDQUFDTCxTQUFELEVBQVlDLFVBQVosQ0FBL0M7QUFDQSxZQUFNSyxjQUFjLEdBQUdoRSxNQUFNLENBQUNzQixLQUFQLENBQWEyQyxJQUFiLENBQWtCSCxRQUFsQixFQUE0QkksS0FBNUIsRUFBdkIsQ0FGUyxDQUdUOztBQUNBLFVBQUlGLGNBQWMsQ0FBQzFCLE1BQWYsS0FBMEIsQ0FBOUIsRUFBaUM7QUFDL0IvQyxZQUFJLEdBQUd5RSxjQUFjLENBQUMsQ0FBRCxDQUFyQjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxTQUFPekUsSUFBUDtBQUNELENBaENEO0FBa0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQUssUUFBUSxDQUFDdUUsa0JBQVQsR0FDRVAsUUFBUSxJQUFJaEUsUUFBUSxDQUFDNEQsZ0JBQVQsQ0FBMEI7QUFBRUk7QUFBRixDQUExQixDQURkO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBaEUsUUFBUSxDQUFDd0UsZUFBVCxHQUEyQlAsS0FBSyxJQUFJakUsUUFBUSxDQUFDNEQsZ0JBQVQsQ0FBMEI7QUFBRUs7QUFBRixDQUExQixDQUFwQyxDLENBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNRSxvQ0FBb0MsR0FBRyxDQUFDTCxTQUFELEVBQVlXLE1BQVosS0FBdUI7QUFDbEU7QUFDQSxRQUFNQyxNQUFNLEdBQUdELE1BQU0sQ0FBQ0UsU0FBUCxDQUFpQixDQUFqQixFQUFvQkMsSUFBSSxDQUFDQyxHQUFMLENBQVNKLE1BQU0sQ0FBQy9CLE1BQWhCLEVBQXdCLENBQXhCLENBQXBCLENBQWY7QUFDQSxRQUFNb0MsUUFBUSxHQUFHQyxpQ0FBaUMsQ0FBQ0wsTUFBRCxDQUFqQyxDQUEwQ00sR0FBMUMsQ0FDZkMsaUJBQWlCLElBQUk7QUFDbkIsVUFBTWYsUUFBUSxHQUFHLEVBQWpCO0FBQ0FBLFlBQVEsQ0FBQ0osU0FBRCxDQUFSLEdBQ0UsSUFBSW9CLE1BQUosWUFBZTlFLE1BQU0sQ0FBQytFLGFBQVAsQ0FBcUJGLGlCQUFyQixDQUFmLEVBREY7QUFFQSxXQUFPZixRQUFQO0FBQ0QsR0FOYyxDQUFqQjtBQU9BLFFBQU1rQixxQkFBcUIsR0FBRyxFQUE5QjtBQUNBQSx1QkFBcUIsQ0FBQ3RCLFNBQUQsQ0FBckIsR0FDRSxJQUFJb0IsTUFBSixZQUFlOUUsTUFBTSxDQUFDK0UsYUFBUCxDQUFxQlYsTUFBckIsQ0FBZixRQUFnRCxHQUFoRCxDQURGO0FBRUEsU0FBTztBQUFDWSxRQUFJLEVBQUUsQ0FBQztBQUFDQyxTQUFHLEVBQUVSO0FBQU4sS0FBRCxFQUFrQk0scUJBQWxCO0FBQVAsR0FBUDtBQUNELENBZEQsQyxDQWdCQTs7O0FBQ0EsTUFBTUwsaUNBQWlDLEdBQUdOLE1BQU0sSUFBSTtBQUNsRCxNQUFJYyxZQUFZLEdBQUcsQ0FBQyxFQUFELENBQW5COztBQUNBLE9BQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2YsTUFBTSxDQUFDL0IsTUFBM0IsRUFBbUM4QyxDQUFDLEVBQXBDLEVBQXdDO0FBQ3RDLFVBQU1DLEVBQUUsR0FBR2hCLE1BQU0sQ0FBQ2lCLE1BQVAsQ0FBY0YsQ0FBZCxDQUFYO0FBQ0FELGdCQUFZLEdBQUcsR0FBR0ksTUFBSCxDQUFVLEdBQUlKLFlBQVksQ0FBQ1AsR0FBYixDQUFpQk4sTUFBTSxJQUFJO0FBQ3RELFlBQU1rQixhQUFhLEdBQUdILEVBQUUsQ0FBQ0ksV0FBSCxFQUF0QjtBQUNBLFlBQU1DLGFBQWEsR0FBR0wsRUFBRSxDQUFDTSxXQUFILEVBQXRCLENBRnNELENBR3REOztBQUNBLFVBQUlILGFBQWEsS0FBS0UsYUFBdEIsRUFBcUM7QUFDbkMsZUFBTyxDQUFDcEIsTUFBTSxHQUFHZSxFQUFWLENBQVA7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPLENBQUNmLE1BQU0sR0FBR2tCLGFBQVYsRUFBeUJsQixNQUFNLEdBQUdvQixhQUFsQyxDQUFQO0FBQ0Q7QUFDRixLQVQ0QixDQUFkLENBQWY7QUFVRDs7QUFDRCxTQUFPUCxZQUFQO0FBQ0QsQ0FoQkQ7O0FBa0JBLE1BQU1TLGlDQUFpQyxHQUFHLENBQUNsQyxTQUFELEVBQVltQyxXQUFaLEVBQXlCbEMsVUFBekIsRUFBcUNtQyxTQUFyQyxLQUFtRDtBQUMzRjtBQUNBO0FBQ0EsUUFBTUMsU0FBUyxHQUFHQyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQ3ZHLFFBQVEsQ0FBQ3dHLGlDQUE5QyxFQUFpRnpDLFVBQWpGLENBQWxCOztBQUVBLE1BQUlBLFVBQVUsSUFBSSxDQUFDb0MsU0FBbkIsRUFBOEI7QUFDNUIsVUFBTU0sWUFBWSxHQUFHckcsTUFBTSxDQUFDc0IsS0FBUCxDQUFhMkMsSUFBYixDQUNuQkYsb0NBQW9DLENBQUNMLFNBQUQsRUFBWUMsVUFBWixDQURqQixFQUMwQ08sS0FEMUMsRUFBckI7O0FBR0EsUUFBSW1DLFlBQVksQ0FBQy9ELE1BQWIsR0FBc0IsQ0FBdEIsTUFDQTtBQUNDLEtBQUN3RCxTQUFELElBQ0Q7QUFDQTtBQUNDTyxnQkFBWSxDQUFDL0QsTUFBYixHQUFzQixDQUF0QixJQUEyQitELFlBQVksQ0FBQyxDQUFELENBQVosQ0FBZ0IxRCxHQUFoQixLQUF3Qm1ELFNBTHBELENBQUosRUFLcUU7QUFDbkU5QyxpQkFBVyxXQUFJNkMsV0FBSixzQkFBWDtBQUNEO0FBQ0Y7QUFDRixDQWxCRCxDLENBb0JBOzs7QUFDQSxNQUFNUyxjQUFjLEdBQUdDLEtBQUssQ0FBQ0MsS0FBTixDQUFZQyxDQUFDLElBQUk7QUFDdENDLE9BQUssQ0FBQ0QsQ0FBRCxFQUFJRSxNQUFKLENBQUw7QUFDQSxTQUFPRixDQUFDLENBQUNuRSxNQUFGLEdBQVcsQ0FBbEI7QUFDRCxDQUhzQixDQUF2QjtBQUtBLE1BQU1zRSxrQkFBa0IsR0FBR0wsS0FBSyxDQUFDQyxLQUFOLENBQVlqSCxJQUFJLElBQUk7QUFDN0NtSCxPQUFLLENBQUNuSCxJQUFELEVBQU87QUFDVjhCLE1BQUUsRUFBRWtGLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmLENBRE07QUFFVjFDLFlBQVEsRUFBRTJDLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmLENBRkE7QUFHVnpDLFNBQUssRUFBRTBDLEtBQUssQ0FBQ00sUUFBTixDQUFlUCxjQUFmO0FBSEcsR0FBUCxDQUFMO0FBS0EsTUFBSU4sTUFBTSxDQUFDYyxJQUFQLENBQVl2SCxJQUFaLEVBQWtCK0MsTUFBbEIsS0FBNkIsQ0FBakMsRUFDRSxNQUFNLElBQUlpRSxLQUFLLENBQUN4RSxLQUFWLENBQWdCLDJDQUFoQixDQUFOO0FBQ0YsU0FBTyxJQUFQO0FBQ0QsQ0FUMEIsQ0FBM0I7QUFXQSxNQUFNZ0YsaUJBQWlCLEdBQUdSLEtBQUssQ0FBQ1MsS0FBTixDQUN4QkwsTUFEd0IsRUFFeEI7QUFBRTNFLFFBQU0sRUFBRTJFLE1BQVY7QUFBa0I3RSxXQUFTLEVBQUU2RTtBQUE3QixDQUZ3QixDQUExQixDLENBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQS9HLFFBQVEsQ0FBQ3FILG9CQUFULENBQThCLFVBQTlCLEVBQTBDQyxPQUFPLElBQUk7QUFDbkQsTUFBSSxDQUFFQSxPQUFPLENBQUN0RixRQUFWLElBQXNCc0YsT0FBTyxDQUFDQyxHQUFsQyxFQUNFLE9BQU9DLFNBQVAsQ0FGaUQsQ0FFL0I7O0FBRXBCVixPQUFLLENBQUNRLE9BQUQsRUFBVTtBQUNiM0gsUUFBSSxFQUFFcUgsa0JBRE87QUFFYmhGLFlBQVEsRUFBRW1GO0FBRkcsR0FBVixDQUFMOztBQU1BLFFBQU14SCxJQUFJLEdBQUdLLFFBQVEsQ0FBQzRELGdCQUFULENBQTBCMEQsT0FBTyxDQUFDM0gsSUFBbEMsQ0FBYjs7QUFDQSxNQUFJLENBQUNBLElBQUwsRUFBVztBQUNUeUQsZUFBVyxDQUFDLGdCQUFELENBQVg7QUFDRDs7QUFFRCxNQUFJLENBQUN6RCxJQUFJLENBQUNzRCxRQUFOLElBQWtCLENBQUN0RCxJQUFJLENBQUNzRCxRQUFMLENBQWNqQixRQUFqQyxJQUNBLEVBQUVyQyxJQUFJLENBQUNzRCxRQUFMLENBQWNqQixRQUFkLENBQXVCZixNQUF2QixJQUFpQ3RCLElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJ1RixHQUExRCxDQURKLEVBQ29FO0FBQ2xFbkUsZUFBVyxDQUFDLDBCQUFELENBQVg7QUFDRDs7QUFFRCxNQUFJLENBQUN6RCxJQUFJLENBQUNzRCxRQUFMLENBQWNqQixRQUFkLENBQXVCZixNQUE1QixFQUFvQztBQUNsQyxRQUFJLE9BQU9xRyxPQUFPLENBQUN0RixRQUFmLEtBQTRCLFFBQWhDLEVBQTBDO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBTXlGLFFBQVEsR0FBRzlILElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJ1RixHQUF4QztBQUNBLFlBQU1HLFdBQVcsR0FBR0MsR0FBRyxDQUFDQyxnQkFBSixDQUFxQk4sT0FBTyxDQUFDdEYsUUFBN0IsRUFBdUM7QUFDekQ2RixnQkFBUSxFQUFFSixRQUFRLENBQUNJLFFBRHNDO0FBQzVCQyxZQUFJLEVBQUVMLFFBQVEsQ0FBQ0s7QUFEYSxPQUF2QyxDQUFwQjs7QUFHQSxVQUFJTCxRQUFRLENBQUNBLFFBQVQsS0FBc0JDLFdBQVcsQ0FBQ0QsUUFBdEMsRUFBZ0Q7QUFDOUMsZUFBTztBQUNMM0UsZ0JBQU0sRUFBRTlDLFFBQVEsQ0FBQzZCLFFBQVQsQ0FBa0I4QixzQkFBbEIsR0FBMkMsSUFBM0MsR0FBa0RoRSxJQUFJLENBQUNvRCxHQUQxRDtBQUVMSSxlQUFLLEVBQUVDLFdBQVcsQ0FBQyxvQkFBRCxFQUF1QixLQUF2QjtBQUZiLFNBQVA7QUFJRDs7QUFFRCxhQUFPO0FBQUNOLGNBQU0sRUFBRW5ELElBQUksQ0FBQ29EO0FBQWQsT0FBUDtBQUNELEtBakJELE1BaUJPO0FBQ0w7QUFDQSxZQUFNLElBQUkzQyxNQUFNLENBQUMrQixLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHFCQUF0QixFQUE2QzRGLEtBQUssQ0FBQ0MsU0FBTixDQUFnQjtBQUNqRUMsY0FBTSxFQUFFLEtBRHlEO0FBRWpFSixnQkFBUSxFQUFFbEksSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBZCxDQUF1QnVGLEdBQXZCLENBQTJCTTtBQUY0QixPQUFoQixDQUE3QyxDQUFOO0FBSUQ7QUFDRjs7QUFFRCxTQUFPckUsYUFBYSxDQUNsQjdELElBRGtCLEVBRWxCMkgsT0FBTyxDQUFDdEYsUUFGVSxDQUFwQjtBQUlELENBbkRELEUsQ0FxREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBaEMsUUFBUSxDQUFDcUgsb0JBQVQsQ0FBOEIsVUFBOUIsRUFBMENDLE9BQU8sSUFBSTtBQUNuRCxNQUFJLENBQUNBLE9BQU8sQ0FBQ0MsR0FBVCxJQUFnQixDQUFDRCxPQUFPLENBQUN0RixRQUE3QixFQUF1QztBQUNyQyxXQUFPd0YsU0FBUCxDQURxQyxDQUNuQjtBQUNuQjs7QUFFRFYsT0FBSyxDQUFDUSxPQUFELEVBQVU7QUFDYjNILFFBQUksRUFBRXFILGtCQURPO0FBRWJPLE9BQUcsRUFBRVIsTUFGUTtBQUdiL0UsWUFBUSxFQUFFbUY7QUFIRyxHQUFWLENBQUw7O0FBTUEsUUFBTXhILElBQUksR0FBR0ssUUFBUSxDQUFDNEQsZ0JBQVQsQ0FBMEIwRCxPQUFPLENBQUMzSCxJQUFsQyxDQUFiOztBQUNBLE1BQUksQ0FBQ0EsSUFBTCxFQUFXO0FBQ1R5RCxlQUFXLENBQUMsZ0JBQUQsQ0FBWDtBQUNELEdBZGtELENBZ0JuRDtBQUNBOzs7QUFDQSxNQUFJekQsSUFBSSxDQUFDc0QsUUFBTCxJQUFpQnRELElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQS9CLElBQTJDckMsSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBZCxDQUF1QmYsTUFBdEUsRUFBOEU7QUFDNUUsV0FBT3VDLGFBQWEsQ0FBQzdELElBQUQsRUFBTzJILE9BQU8sQ0FBQ3RGLFFBQWYsQ0FBcEI7QUFDRDs7QUFFRCxNQUFJLEVBQUVyQyxJQUFJLENBQUNzRCxRQUFMLElBQWlCdEQsSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBL0IsSUFBMkNyQyxJQUFJLENBQUNzRCxRQUFMLENBQWNqQixRQUFkLENBQXVCdUYsR0FBcEUsQ0FBSixFQUE4RTtBQUM1RW5FLGVBQVcsQ0FBQywwQkFBRCxDQUFYO0FBQ0Q7O0FBRUQsUUFBTThFLEVBQUUsR0FBR3ZJLElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJ1RixHQUF2QixDQUEyQkUsUUFBdEM7QUFDQSxRQUFNVSxFQUFFLEdBQUdSLEdBQUcsQ0FBQ0MsZ0JBQUosQ0FDVCxJQURTLEVBRVQ7QUFDRVEsNkJBQXlCLEVBQUVkLE9BQU8sQ0FBQ0MsR0FEckM7QUFFRU8sUUFBSSxFQUFFbkksSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBZCxDQUF1QnVGLEdBQXZCLENBQTJCTztBQUZuQyxHQUZTLEVBTVRMLFFBTkY7O0FBT0EsTUFBSVMsRUFBRSxLQUFLQyxFQUFYLEVBQWU7QUFDYixXQUFPO0FBQ0xyRixZQUFNLEVBQUU5QyxRQUFRLENBQUM2QixRQUFULENBQWtCOEIsc0JBQWxCLEdBQTJDLElBQTNDLEdBQWtEaEUsSUFBSSxDQUFDb0QsR0FEMUQ7QUFFTEksV0FBSyxFQUFFQyxXQUFXLENBQUMsb0JBQUQsRUFBdUIsS0FBdkI7QUFGYixLQUFQO0FBSUQsR0F2Q2tELENBeUNuRDs7O0FBQ0EsUUFBTWlGLE1BQU0sR0FBR2hHLFlBQVksQ0FBQ2lGLE9BQU8sQ0FBQ3RGLFFBQVQsQ0FBM0I7QUFDQTVCLFFBQU0sQ0FBQ3NCLEtBQVAsQ0FBYTRCLE1BQWIsQ0FDRTNELElBQUksQ0FBQ29ELEdBRFAsRUFFRTtBQUNFdUYsVUFBTSxFQUFFO0FBQUUsK0JBQXlCO0FBQTNCLEtBRFY7QUFFRS9FLFFBQUksRUFBRTtBQUFFLGtDQUE0QjhFO0FBQTlCO0FBRlIsR0FGRjtBQVFBLFNBQU87QUFBQ3ZGLFVBQU0sRUFBRW5ELElBQUksQ0FBQ29EO0FBQWQsR0FBUDtBQUNELENBcERELEUsQ0F1REE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQS9DLFFBQVEsQ0FBQ3VJLFdBQVQsR0FBdUIsQ0FBQ3pGLE1BQUQsRUFBUzBGLFdBQVQsS0FBeUI7QUFDOUMxQixPQUFLLENBQUNoRSxNQUFELEVBQVM0RCxjQUFULENBQUw7QUFDQUksT0FBSyxDQUFDMEIsV0FBRCxFQUFjOUIsY0FBZCxDQUFMO0FBRUEsUUFBTS9HLElBQUksR0FBRzZCLFdBQVcsQ0FBQ3NCLE1BQUQsQ0FBeEI7O0FBQ0EsTUFBSSxDQUFDbkQsSUFBTCxFQUFXO0FBQ1R5RCxlQUFXLENBQUMsZ0JBQUQsQ0FBWDtBQUNEOztBQUVELFFBQU1xRixXQUFXLEdBQUc5SSxJQUFJLENBQUNxRSxRQUF6QixDQVQ4QyxDQVc5Qzs7QUFDQWdDLG1DQUFpQyxDQUFDLFVBQUQsRUFBYSxVQUFiLEVBQXlCd0MsV0FBekIsRUFBc0M3SSxJQUFJLENBQUNvRCxHQUEzQyxDQUFqQztBQUVBM0MsUUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUFvQjtBQUFDUCxPQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFYLEdBQXBCLEVBQXFDO0FBQUNRLFFBQUksRUFBRTtBQUFDUyxjQUFRLEVBQUV3RTtBQUFYO0FBQVAsR0FBckMsRUFkOEMsQ0FnQjlDO0FBQ0E7O0FBQ0EsTUFBSTtBQUNGeEMscUNBQWlDLENBQUMsVUFBRCxFQUFhLFVBQWIsRUFBeUJ3QyxXQUF6QixFQUFzQzdJLElBQUksQ0FBQ29ELEdBQTNDLENBQWpDO0FBQ0QsR0FGRCxDQUVFLE9BQU8yRixFQUFQLEVBQVc7QUFDWDtBQUNBdEksVUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUFvQjtBQUFDUCxTQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFYLEtBQXBCLEVBQXFDO0FBQUNRLFVBQUksRUFBRTtBQUFDUyxnQkFBUSxFQUFFeUU7QUFBWDtBQUFQLEtBQXJDO0FBQ0EsVUFBTUMsRUFBTjtBQUNEO0FBQ0YsQ0F6QkQsQyxDQTJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdEksTUFBTSxDQUFDdUksT0FBUCxDQUFlO0FBQUNDLGdCQUFjLEVBQUUsVUFBVUMsV0FBVixFQUF1QkMsV0FBdkIsRUFBb0M7QUFDbEVoQyxTQUFLLENBQUMrQixXQUFELEVBQWMxQixpQkFBZCxDQUFMO0FBQ0FMLFNBQUssQ0FBQ2dDLFdBQUQsRUFBYzNCLGlCQUFkLENBQUw7O0FBRUEsUUFBSSxDQUFDLEtBQUtyRSxNQUFWLEVBQWtCO0FBQ2hCLFlBQU0sSUFBSTFDLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsbUJBQXRCLENBQU47QUFDRDs7QUFFRCxVQUFNeEMsSUFBSSxHQUFHNkIsV0FBVyxDQUFDLEtBQUtzQixNQUFOLENBQXhCOztBQUNBLFFBQUksQ0FBQ25ELElBQUwsRUFBVztBQUNUeUQsaUJBQVcsQ0FBQyxnQkFBRCxDQUFYO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDekQsSUFBSSxDQUFDc0QsUUFBTixJQUFrQixDQUFDdEQsSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBakMsSUFDQyxDQUFDckMsSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBZCxDQUF1QmYsTUFBeEIsSUFBa0MsQ0FBQ3RCLElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJ1RixHQUQvRCxFQUNxRTtBQUNuRW5FLGlCQUFXLENBQUMsMEJBQUQsQ0FBWDtBQUNEOztBQUVELFFBQUksQ0FBRXpELElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJmLE1BQTdCLEVBQXFDO0FBQ25DLFlBQU0sSUFBSWIsTUFBTSxDQUFDK0IsS0FBWCxDQUFpQixHQUFqQixFQUFzQixxQkFBdEIsRUFBNkM0RixLQUFLLENBQUNDLFNBQU4sQ0FBZ0I7QUFDakVDLGNBQU0sRUFBRSxLQUR5RDtBQUVqRUosZ0JBQVEsRUFBRWxJLElBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsQ0FBdUJ1RixHQUF2QixDQUEyQk07QUFGNEIsT0FBaEIsQ0FBN0MsQ0FBTjtBQUlEOztBQUVELFVBQU1oRixNQUFNLEdBQUdXLGFBQWEsQ0FBQzdELElBQUQsRUFBT2tKLFdBQVAsQ0FBNUI7O0FBQ0EsUUFBSWhHLE1BQU0sQ0FBQ00sS0FBWCxFQUFrQjtBQUNoQixZQUFNTixNQUFNLENBQUNNLEtBQWI7QUFDRDs7QUFFRCxVQUFNNEYsTUFBTSxHQUFHMUcsWUFBWSxDQUFDeUcsV0FBRCxDQUEzQixDQTlCa0UsQ0FnQ2xFO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1FLFlBQVksR0FBR2hKLFFBQVEsQ0FBQ2lKLGNBQVQsQ0FBd0IsS0FBS0MsVUFBTCxDQUFnQnpILEVBQXhDLENBQXJCOztBQUNBckIsVUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUNFO0FBQUVQLFNBQUcsRUFBRSxLQUFLRDtBQUFaLEtBREYsRUFFRTtBQUNFUyxVQUFJLEVBQUU7QUFBRSxvQ0FBNEJ3RjtBQUE5QixPQURSO0FBRUVJLFdBQUssRUFBRTtBQUNMLHVDQUErQjtBQUFFQyxxQkFBVyxFQUFFO0FBQUVDLGVBQUcsRUFBRUw7QUFBUDtBQUFmO0FBRDFCLE9BRlQ7QUFLRVYsWUFBTSxFQUFFO0FBQUUsbUNBQTJCO0FBQTdCO0FBTFYsS0FGRjtBQVdBLFdBQU87QUFBQ2dCLHFCQUFlLEVBQUU7QUFBbEIsS0FBUDtBQUNEO0FBakRjLENBQWYsRSxDQW9EQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0F0SixRQUFRLENBQUN1SixXQUFULEdBQXVCLENBQUN6RyxNQUFELEVBQVMwRyxvQkFBVCxFQUErQmxDLE9BQS9CLEtBQTJDO0FBQ2hFQSxTQUFPO0FBQUttQyxVQUFNLEVBQUU7QUFBYixLQUF1Qm5DLE9BQXZCLENBQVA7QUFFQSxRQUFNM0gsSUFBSSxHQUFHNkIsV0FBVyxDQUFDc0IsTUFBRCxDQUF4Qjs7QUFDQSxNQUFJLENBQUNuRCxJQUFMLEVBQVc7QUFDVCxVQUFNLElBQUlTLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZ0JBQXRCLENBQU47QUFDRDs7QUFFRCxRQUFNbUIsTUFBTSxHQUFHO0FBQ2JnRixVQUFNLEVBQUU7QUFDTiwrQkFBeUIsQ0FEbkI7QUFDc0I7QUFDNUIsaUNBQTJCO0FBRnJCLEtBREs7QUFLYi9FLFFBQUksRUFBRTtBQUFDLGtDQUE0QmxCLFlBQVksQ0FBQ21ILG9CQUFEO0FBQXpDO0FBTE8sR0FBZjs7QUFRQSxNQUFJbEMsT0FBTyxDQUFDbUMsTUFBWixFQUFvQjtBQUNsQm5HLFVBQU0sQ0FBQ2dGLE1BQVAsQ0FBYyw2QkFBZCxJQUErQyxDQUEvQztBQUNEOztBQUVEbEksUUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUFvQjtBQUFDUCxPQUFHLEVBQUVwRCxJQUFJLENBQUNvRDtBQUFYLEdBQXBCLEVBQXFDTyxNQUFyQztBQUNELENBckJELEMsQ0F3QkE7QUFDQTtBQUNBO0FBRUE7OztBQUNBLE1BQU1vRyxjQUFjLEdBQUc7QUFBQSxNQUFDQyxNQUFELHVFQUFVLEVBQVY7QUFBQSxTQUFpQkEsTUFBTSxDQUFDM0UsR0FBUCxDQUFXZixLQUFLLElBQUlBLEtBQUssQ0FBQzJGLE9BQTFCLENBQWpCO0FBQUEsQ0FBdkIsQyxDQUVBO0FBQ0E7OztBQUNBeEosTUFBTSxDQUFDdUksT0FBUCxDQUFlO0FBQUNrQixnQkFBYyxFQUFFdkMsT0FBTyxJQUFJO0FBQ3pDUixTQUFLLENBQUNRLE9BQUQsRUFBVTtBQUFDckQsV0FBSyxFQUFFOEM7QUFBUixLQUFWLENBQUw7QUFFQSxVQUFNcEgsSUFBSSxHQUFHSyxRQUFRLENBQUN3RSxlQUFULENBQXlCOEMsT0FBTyxDQUFDckQsS0FBakMsQ0FBYjs7QUFDQSxRQUFJLENBQUN0RSxJQUFMLEVBQVc7QUFDVHlELGlCQUFXLENBQUMsZ0JBQUQsQ0FBWDtBQUNEOztBQUVELFVBQU11RyxNQUFNLEdBQUdELGNBQWMsQ0FBQy9KLElBQUksQ0FBQ2dLLE1BQU4sQ0FBN0I7QUFDQSxVQUFNRyxrQkFBa0IsR0FBR0gsTUFBTSxDQUFDdEYsSUFBUCxDQUN6QkosS0FBSyxJQUFJQSxLQUFLLENBQUM0QixXQUFOLE9BQXdCeUIsT0FBTyxDQUFDckQsS0FBUixDQUFjNEIsV0FBZCxFQURSLENBQTNCO0FBSUE3RixZQUFRLENBQUMrSixzQkFBVCxDQUFnQ3BLLElBQUksQ0FBQ29ELEdBQXJDLEVBQTBDK0csa0JBQTFDO0FBQ0Q7QUFkYyxDQUFmO0FBZ0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBOUosUUFBUSxDQUFDZ0ssa0JBQVQsR0FBOEIsQ0FBQ2xILE1BQUQsRUFBU21CLEtBQVQsRUFBZ0JnRyxNQUFoQixFQUF3QkMsY0FBeEIsS0FBMkM7QUFDdkU7QUFDQSxRQUFNdkssSUFBSSxHQUFHNkIsV0FBVyxDQUFDc0IsTUFBRCxDQUF4Qjs7QUFDQSxNQUFJLENBQUNuRCxJQUFMLEVBQVc7QUFDVHlELGVBQVcsQ0FBQyxpQkFBRCxDQUFYO0FBQ0QsR0FMc0UsQ0FPdkU7OztBQUNBLE1BQUksQ0FBQ2EsS0FBRCxJQUFVdEUsSUFBSSxDQUFDZ0ssTUFBZixJQUF5QmhLLElBQUksQ0FBQ2dLLE1BQUwsQ0FBWSxDQUFaLENBQTdCLEVBQTZDO0FBQzNDMUYsU0FBSyxHQUFHdEUsSUFBSSxDQUFDZ0ssTUFBTCxDQUFZLENBQVosRUFBZUMsT0FBdkI7QUFDRCxHQVZzRSxDQVl2RTs7O0FBQ0EsTUFBSSxDQUFDM0YsS0FBRCxJQUNGLENBQUV5RixjQUFjLENBQUMvSixJQUFJLENBQUNnSyxNQUFOLENBQWQsQ0FBNEJRLFFBQTVCLENBQXFDbEcsS0FBckMsQ0FESixFQUNrRDtBQUNoRGIsZUFBVyxDQUFDLHlCQUFELENBQVg7QUFDRDs7QUFFRCxRQUFNZ0gsS0FBSyxHQUFHQyxNQUFNLENBQUNDLE1BQVAsRUFBZDtBQUNBLFFBQU1DLFdBQVcsR0FBRztBQUNsQkgsU0FEa0I7QUFFbEJuRyxTQUZrQjtBQUdsQnVHLFFBQUksRUFBRSxJQUFJQyxJQUFKO0FBSFksR0FBcEI7O0FBTUEsTUFBSVIsTUFBTSxLQUFLLGVBQWYsRUFBZ0M7QUFDOUJNLGVBQVcsQ0FBQ04sTUFBWixHQUFxQixPQUFyQjtBQUNELEdBRkQsTUFFTyxJQUFJQSxNQUFNLEtBQUssZUFBZixFQUFnQztBQUNyQ00sZUFBVyxDQUFDTixNQUFaLEdBQXFCLFFBQXJCO0FBQ0QsR0FGTSxNQUVBLElBQUlBLE1BQUosRUFBWTtBQUNqQjtBQUNBTSxlQUFXLENBQUNOLE1BQVosR0FBcUJBLE1BQXJCO0FBQ0Q7O0FBRUQsTUFBSUMsY0FBSixFQUFvQjtBQUNsQjlELFVBQU0sQ0FBQ3NFLE1BQVAsQ0FBY0gsV0FBZCxFQUEyQkwsY0FBM0I7QUFDRDs7QUFFRDlKLFFBQU0sQ0FBQ3NCLEtBQVAsQ0FBYTRCLE1BQWIsQ0FBb0I7QUFBQ1AsT0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFBWCxHQUFwQixFQUFxQztBQUFDUSxRQUFJLEVBQUU7QUFDMUMsaUNBQTJCZ0g7QUFEZTtBQUFQLEdBQXJDLEVBdEN1RSxDQTBDdkU7O0FBQ0FuSyxRQUFNLENBQUN1SyxPQUFQLENBQWVoTCxJQUFmLEVBQXFCLFVBQXJCLEVBQWlDLFVBQWpDLEVBQTZDaUwsS0FBN0MsR0FBcURMLFdBQXJEO0FBRUEsU0FBTztBQUFDdEcsU0FBRDtBQUFRdEUsUUFBUjtBQUFjeUs7QUFBZCxHQUFQO0FBQ0QsQ0E5Q0Q7QUFnREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQXBLLFFBQVEsQ0FBQzZLLHlCQUFULEdBQXFDLENBQUMvSCxNQUFELEVBQVNtQixLQUFULEVBQWdCaUcsY0FBaEIsS0FBbUM7QUFDdEU7QUFDQSxRQUFNdkssSUFBSSxHQUFHNkIsV0FBVyxDQUFDc0IsTUFBRCxDQUF4Qjs7QUFDQSxNQUFJLENBQUNuRCxJQUFMLEVBQVc7QUFDVHlELGVBQVcsQ0FBQyxpQkFBRCxDQUFYO0FBQ0QsR0FMcUUsQ0FPdEU7OztBQUNBLE1BQUksQ0FBQ2EsS0FBTCxFQUFZO0FBQ1YsVUFBTTZHLFdBQVcsR0FBRyxDQUFDbkwsSUFBSSxDQUFDZ0ssTUFBTCxJQUFlLEVBQWhCLEVBQW9CdEYsSUFBcEIsQ0FBeUIwRyxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxDQUFDQyxRQUFqQyxDQUFwQjtBQUNBL0csU0FBSyxHQUFHLENBQUM2RyxXQUFXLElBQUksRUFBaEIsRUFBb0JsQixPQUE1Qjs7QUFFQSxRQUFJLENBQUMzRixLQUFMLEVBQVk7QUFDVmIsaUJBQVcsQ0FBQyw4Q0FBRCxDQUFYO0FBQ0Q7QUFDRixHQWZxRSxDQWlCdEU7OztBQUNBLE1BQUksQ0FBQ2EsS0FBRCxJQUNGLENBQUV5RixjQUFjLENBQUMvSixJQUFJLENBQUNnSyxNQUFOLENBQWQsQ0FBNEJRLFFBQTVCLENBQXFDbEcsS0FBckMsQ0FESixFQUNrRDtBQUNoRGIsZUFBVyxDQUFDLHlCQUFELENBQVg7QUFDRDs7QUFFRCxRQUFNZ0gsS0FBSyxHQUFHQyxNQUFNLENBQUNDLE1BQVAsRUFBZDtBQUNBLFFBQU1DLFdBQVcsR0FBRztBQUNsQkgsU0FEa0I7QUFFbEI7QUFDQVIsV0FBTyxFQUFFM0YsS0FIUztBQUlsQnVHLFFBQUksRUFBRSxJQUFJQyxJQUFKO0FBSlksR0FBcEI7O0FBT0EsTUFBSVAsY0FBSixFQUFvQjtBQUNsQjlELFVBQU0sQ0FBQ3NFLE1BQVAsQ0FBY0gsV0FBZCxFQUEyQkwsY0FBM0I7QUFDRDs7QUFFRDlKLFFBQU0sQ0FBQ3NCLEtBQVAsQ0FBYTRCLE1BQWIsQ0FBb0I7QUFBQ1AsT0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFBWCxHQUFwQixFQUFxQztBQUFDa0ksU0FBSyxFQUFFO0FBQzNDLDJDQUFxQ1Y7QUFETTtBQUFSLEdBQXJDLEVBbkNzRSxDQXVDdEU7O0FBQ0FuSyxRQUFNLENBQUN1SyxPQUFQLENBQWVoTCxJQUFmLEVBQXFCLFVBQXJCLEVBQWlDLE9BQWpDOztBQUNBLE1BQUksQ0FBQ0EsSUFBSSxDQUFDc0QsUUFBTCxDQUFjZ0IsS0FBZCxDQUFvQmlILGtCQUF6QixFQUE2QztBQUMzQ3ZMLFFBQUksQ0FBQ3NELFFBQUwsQ0FBY2dCLEtBQWQsQ0FBb0JpSCxrQkFBcEIsR0FBeUMsRUFBekM7QUFDRDs7QUFDRHZMLE1BQUksQ0FBQ3NELFFBQUwsQ0FBY2dCLEtBQWQsQ0FBb0JpSCxrQkFBcEIsQ0FBdUNDLElBQXZDLENBQTRDWixXQUE1QztBQUVBLFNBQU87QUFBQ3RHLFNBQUQ7QUFBUXRFLFFBQVI7QUFBY3lLO0FBQWQsR0FBUDtBQUNELENBL0NEO0FBaURBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBcEssUUFBUSxDQUFDb0wsdUJBQVQsR0FBbUMsQ0FBQ25ILEtBQUQsRUFBUXRFLElBQVIsRUFBY0MsR0FBZCxFQUFtQnFLLE1BQW5CLEtBQThCO0FBQy9ELFFBQU0zQyxPQUFPLEdBQUc7QUFDZCtELE1BQUUsRUFBRXBILEtBRFU7QUFFZC9ELFFBQUksRUFBRUYsUUFBUSxDQUFDQyxjQUFULENBQXdCZ0ssTUFBeEIsRUFBZ0MvSixJQUFoQyxHQUNGRixRQUFRLENBQUNDLGNBQVQsQ0FBd0JnSyxNQUF4QixFQUFnQy9KLElBQWhDLENBQXFDUCxJQUFyQyxDQURFLEdBRUZLLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QkMsSUFKZDtBQUtkTSxXQUFPLEVBQUVSLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QmdLLE1BQXhCLEVBQWdDekosT0FBaEMsQ0FBd0NiLElBQXhDO0FBTEssR0FBaEI7O0FBUUEsTUFBSSxPQUFPSyxRQUFRLENBQUNDLGNBQVQsQ0FBd0JnSyxNQUF4QixFQUFnQ3hKLElBQXZDLEtBQWdELFVBQXBELEVBQWdFO0FBQzlENkcsV0FBTyxDQUFDN0csSUFBUixHQUFlVCxRQUFRLENBQUNDLGNBQVQsQ0FBd0JnSyxNQUF4QixFQUFnQ3hKLElBQWhDLENBQXFDZCxJQUFyQyxFQUEyQ0MsR0FBM0MsQ0FBZjtBQUNEOztBQUVELE1BQUksT0FBT0ksUUFBUSxDQUFDQyxjQUFULENBQXdCZ0ssTUFBeEIsRUFBZ0NxQixJQUF2QyxLQUFnRCxVQUFwRCxFQUFnRTtBQUM5RGhFLFdBQU8sQ0FBQ2dFLElBQVIsR0FBZXRMLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QmdLLE1BQXhCLEVBQWdDcUIsSUFBaEMsQ0FBcUMzTCxJQUFyQyxFQUEyQ0MsR0FBM0MsQ0FBZjtBQUNEOztBQUVELE1BQUksT0FBT0ksUUFBUSxDQUFDQyxjQUFULENBQXdCc0wsT0FBL0IsS0FBMkMsUUFBL0MsRUFBeUQ7QUFDdkRqRSxXQUFPLENBQUNpRSxPQUFSLEdBQWtCdkwsUUFBUSxDQUFDQyxjQUFULENBQXdCc0wsT0FBMUM7QUFDRDs7QUFFRCxTQUFPakUsT0FBUDtBQUNELENBdEJELEMsQ0F3QkE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdEgsUUFBUSxDQUFDK0osc0JBQVQsR0FBa0MsQ0FBQ2pILE1BQUQsRUFBU21CLEtBQVQsRUFBZ0JpRyxjQUFoQixLQUFtQztBQUNuRSxRQUFNO0FBQUNqRyxTQUFLLEVBQUV1SCxTQUFSO0FBQW1CN0wsUUFBbkI7QUFBeUJ5SztBQUF6QixNQUNKcEssUUFBUSxDQUFDZ0ssa0JBQVQsQ0FBNEJsSCxNQUE1QixFQUFvQ21CLEtBQXBDLEVBQTJDLGVBQTNDLEVBQTREaUcsY0FBNUQsQ0FERjtBQUVBLFFBQU10SyxHQUFHLEdBQUdJLFFBQVEsQ0FBQ3lMLElBQVQsQ0FBY2xMLGFBQWQsQ0FBNEI2SixLQUE1QixDQUFaO0FBQ0EsUUFBTTlDLE9BQU8sR0FBR3RILFFBQVEsQ0FBQ29MLHVCQUFULENBQWlDSSxTQUFqQyxFQUE0QzdMLElBQTVDLEVBQWtEQyxHQUFsRCxFQUF1RCxlQUF2RCxDQUFoQjtBQUNBOEwsT0FBSyxDQUFDQyxJQUFOLENBQVdyRSxPQUFYO0FBQ0EsU0FBTztBQUFDckQsU0FBSyxFQUFFdUgsU0FBUjtBQUFtQjdMLFFBQW5CO0FBQXlCeUssU0FBekI7QUFBZ0N4SyxPQUFoQztBQUFxQzBIO0FBQXJDLEdBQVA7QUFDRCxDQVBELEMsQ0FTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdEgsUUFBUSxDQUFDNEwsbUJBQVQsR0FBK0IsQ0FBQzlJLE1BQUQsRUFBU21CLEtBQVQsRUFBZ0JpRyxjQUFoQixLQUFtQztBQUNoRSxRQUFNO0FBQUNqRyxTQUFLLEVBQUV1SCxTQUFSO0FBQW1CN0wsUUFBbkI7QUFBeUJ5SztBQUF6QixNQUNKcEssUUFBUSxDQUFDZ0ssa0JBQVQsQ0FBNEJsSCxNQUE1QixFQUFvQ21CLEtBQXBDLEVBQTJDLGVBQTNDLEVBQTREaUcsY0FBNUQsQ0FERjtBQUVBLFFBQU10SyxHQUFHLEdBQUdJLFFBQVEsQ0FBQ3lMLElBQVQsQ0FBYzlLLGFBQWQsQ0FBNEJ5SixLQUE1QixDQUFaO0FBQ0EsUUFBTTlDLE9BQU8sR0FBR3RILFFBQVEsQ0FBQ29MLHVCQUFULENBQWlDSSxTQUFqQyxFQUE0QzdMLElBQTVDLEVBQWtEQyxHQUFsRCxFQUF1RCxlQUF2RCxDQUFoQjtBQUNBOEwsT0FBSyxDQUFDQyxJQUFOLENBQVdyRSxPQUFYO0FBQ0EsU0FBTztBQUFDckQsU0FBSyxFQUFFdUgsU0FBUjtBQUFtQjdMLFFBQW5CO0FBQXlCeUssU0FBekI7QUFBZ0N4SyxPQUFoQztBQUFxQzBIO0FBQXJDLEdBQVA7QUFDRCxDQVBELEMsQ0FVQTtBQUNBOzs7QUFDQWxILE1BQU0sQ0FBQ3VJLE9BQVAsQ0FBZTtBQUFDcEksZUFBYSxFQUFFLFlBQW1CO0FBQUEsc0NBQU5zTCxJQUFNO0FBQU5BLFVBQU07QUFBQTs7QUFDaEQsVUFBTXpCLEtBQUssR0FBR3lCLElBQUksQ0FBQyxDQUFELENBQWxCO0FBQ0EsVUFBTS9DLFdBQVcsR0FBRytDLElBQUksQ0FBQyxDQUFELENBQXhCO0FBQ0EsV0FBTzdMLFFBQVEsQ0FBQzhMLFlBQVQsQ0FDTCxJQURLLEVBRUwsZUFGSyxFQUdMRCxJQUhLLEVBSUwsVUFKSyxFQUtMLE1BQU07QUFDSi9FLFdBQUssQ0FBQ3NELEtBQUQsRUFBUXJELE1BQVIsQ0FBTDtBQUNBRCxXQUFLLENBQUNnQyxXQUFELEVBQWMzQixpQkFBZCxDQUFMO0FBRUEsWUFBTXhILElBQUksR0FBR1MsTUFBTSxDQUFDc0IsS0FBUCxDQUFhQyxPQUFiLENBQXFCO0FBQ2hDLHlDQUFpQ3lJO0FBREQsT0FBckIsQ0FBYjs7QUFFQSxVQUFJLENBQUN6SyxJQUFMLEVBQVc7QUFDVCxjQUFNLElBQUlTLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZUFBdEIsQ0FBTjtBQUNEOztBQUNELFlBQU07QUFBRXFJLFlBQUY7QUFBUVAsY0FBUjtBQUFnQmhHO0FBQWhCLFVBQTBCdEUsSUFBSSxDQUFDc0QsUUFBTCxDQUFjakIsUUFBZCxDQUF1QjRJLEtBQXZEOztBQUNBLFVBQUltQixlQUFlLEdBQUcvTCxRQUFRLENBQUNnTSxnQ0FBVCxFQUF0Qjs7QUFDQSxVQUFJL0IsTUFBTSxLQUFLLFFBQWYsRUFBeUI7QUFDdkI4Qix1QkFBZSxHQUFHL0wsUUFBUSxDQUFDaU0saUNBQVQsRUFBbEI7QUFDRDs7QUFDRCxZQUFNQyxhQUFhLEdBQUd6QixJQUFJLENBQUMwQixHQUFMLEVBQXRCO0FBQ0EsVUFBS0QsYUFBYSxHQUFHMUIsSUFBakIsR0FBeUJ1QixlQUE3QixFQUNFLE1BQU0sSUFBSTNMLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsZUFBdEIsQ0FBTjtBQUNGLFVBQUksQ0FBRXVILGNBQWMsQ0FBQy9KLElBQUksQ0FBQ2dLLE1BQU4sQ0FBZCxDQUE0QlEsUUFBNUIsQ0FBcUNsRyxLQUFyQyxDQUFOLEVBQ0UsT0FBTztBQUNMbkIsY0FBTSxFQUFFbkQsSUFBSSxDQUFDb0QsR0FEUjtBQUVMSSxhQUFLLEVBQUUsSUFBSS9DLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsaUNBQXRCO0FBRkYsT0FBUDtBQUtGLFlBQU00RyxNQUFNLEdBQUcxRyxZQUFZLENBQUN5RyxXQUFELENBQTNCLENBdkJJLENBeUJKO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFlBQU1zRCxRQUFRLEdBQUdwTSxRQUFRLENBQUNpSixjQUFULENBQXdCLEtBQUtDLFVBQUwsQ0FBZ0J6SCxFQUF4QyxDQUFqQjs7QUFDQXpCLGNBQVEsQ0FBQ3FNLGNBQVQsQ0FBd0IxTSxJQUFJLENBQUNvRCxHQUE3QixFQUFrQyxLQUFLbUcsVUFBdkMsRUFBbUQsSUFBbkQ7O0FBQ0EsWUFBTW9ELGVBQWUsR0FBRyxNQUN0QnRNLFFBQVEsQ0FBQ3FNLGNBQVQsQ0FBd0IxTSxJQUFJLENBQUNvRCxHQUE3QixFQUFrQyxLQUFLbUcsVUFBdkMsRUFBbURrRCxRQUFuRCxDQURGOztBQUdBLFVBQUk7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQU1HLGVBQWUsR0FBR25NLE1BQU0sQ0FBQ3NCLEtBQVAsQ0FBYTRCLE1BQWIsQ0FDdEI7QUFDRVAsYUFBRyxFQUFFcEQsSUFBSSxDQUFDb0QsR0FEWjtBQUVFLDRCQUFrQmtCLEtBRnBCO0FBR0UsMkNBQWlDbUc7QUFIbkMsU0FEc0IsRUFNdEI7QUFBQzdHLGNBQUksRUFBRTtBQUFDLHdDQUE0QndGLE1BQTdCO0FBQ0MsaUNBQXFCO0FBRHRCLFdBQVA7QUFFQ1QsZ0JBQU0sRUFBRTtBQUFDLHVDQUEyQixDQUE1QjtBQUNDLHFDQUF5QjtBQUQxQjtBQUZULFNBTnNCLENBQXhCO0FBVUEsWUFBSWlFLGVBQWUsS0FBSyxDQUF4QixFQUNFLE9BQU87QUFDTHpKLGdCQUFNLEVBQUVuRCxJQUFJLENBQUNvRCxHQURSO0FBRUxJLGVBQUssRUFBRSxJQUFJL0MsTUFBTSxDQUFDK0IsS0FBWCxDQUFpQixHQUFqQixFQUFzQixlQUF0QjtBQUZGLFNBQVA7QUFJSCxPQXBCRCxDQW9CRSxPQUFPcUssR0FBUCxFQUFZO0FBQ1pGLHVCQUFlO0FBQ2YsY0FBTUUsR0FBTjtBQUNELE9BekRHLENBMkRKO0FBQ0E7OztBQUNBeE0sY0FBUSxDQUFDeU0sb0JBQVQsQ0FBOEI5TSxJQUFJLENBQUNvRCxHQUFuQzs7QUFFQSxhQUFPO0FBQUNELGNBQU0sRUFBRW5ELElBQUksQ0FBQ29EO0FBQWQsT0FBUDtBQUNELEtBckVJLENBQVA7QUF1RUQ7QUExRWMsQ0FBZixFLENBNEVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBL0MsUUFBUSxDQUFDME0scUJBQVQsR0FBaUMsQ0FBQzVKLE1BQUQsRUFBU21CLEtBQVQsRUFBZ0JpRyxjQUFoQixLQUFtQztBQUNsRTtBQUNBO0FBQ0E7QUFFQSxRQUFNO0FBQUNqRyxTQUFLLEVBQUV1SCxTQUFSO0FBQW1CN0wsUUFBbkI7QUFBeUJ5SztBQUF6QixNQUNKcEssUUFBUSxDQUFDNksseUJBQVQsQ0FBbUMvSCxNQUFuQyxFQUEyQ21CLEtBQTNDLEVBQWtEaUcsY0FBbEQsQ0FERjtBQUVBLFFBQU10SyxHQUFHLEdBQUdJLFFBQVEsQ0FBQ3lMLElBQVQsQ0FBYy9LLFdBQWQsQ0FBMEIwSixLQUExQixDQUFaO0FBQ0EsUUFBTTlDLE9BQU8sR0FBR3RILFFBQVEsQ0FBQ29MLHVCQUFULENBQWlDSSxTQUFqQyxFQUE0QzdMLElBQTVDLEVBQWtEQyxHQUFsRCxFQUF1RCxhQUF2RCxDQUFoQjtBQUNBOEwsT0FBSyxDQUFDQyxJQUFOLENBQVdyRSxPQUFYO0FBQ0EsU0FBTztBQUFDckQsU0FBSyxFQUFFdUgsU0FBUjtBQUFtQjdMLFFBQW5CO0FBQXlCeUssU0FBekI7QUFBZ0N4SyxPQUFoQztBQUFxQzBIO0FBQXJDLEdBQVA7QUFDRCxDQVhELEMsQ0FhQTtBQUNBOzs7QUFDQWxILE1BQU0sQ0FBQ3VJLE9BQVAsQ0FBZTtBQUFDakksYUFBVyxFQUFFLFlBQW1CO0FBQUEsdUNBQU5tTCxJQUFNO0FBQU5BLFVBQU07QUFBQTs7QUFDOUMsVUFBTXpCLEtBQUssR0FBR3lCLElBQUksQ0FBQyxDQUFELENBQWxCO0FBQ0EsV0FBTzdMLFFBQVEsQ0FBQzhMLFlBQVQsQ0FDTCxJQURLLEVBRUwsYUFGSyxFQUdMRCxJQUhLLEVBSUwsVUFKSyxFQUtMLE1BQU07QUFDSi9FLFdBQUssQ0FBQ3NELEtBQUQsRUFBUXJELE1BQVIsQ0FBTDtBQUVBLFlBQU1wSCxJQUFJLEdBQUdTLE1BQU0sQ0FBQ3NCLEtBQVAsQ0FBYUMsT0FBYixDQUNYO0FBQUMsbURBQTJDeUk7QUFBNUMsT0FEVyxDQUFiO0FBRUEsVUFBSSxDQUFDekssSUFBTCxFQUNFLE1BQU0sSUFBSVMsTUFBTSxDQUFDK0IsS0FBWCxDQUFpQixHQUFqQixFQUFzQiwyQkFBdEIsQ0FBTjtBQUVBLFlBQU1vSSxXQUFXLEdBQUc1SyxJQUFJLENBQUNzRCxRQUFMLENBQWNnQixLQUFkLENBQW9CaUgsa0JBQXBCLENBQXVDN0csSUFBdkMsQ0FDbEJzSSxDQUFDLElBQUlBLENBQUMsQ0FBQ3ZDLEtBQUYsSUFBV0EsS0FERSxDQUFwQjtBQUdGLFVBQUksQ0FBQ0csV0FBTCxFQUNFLE9BQU87QUFDTHpILGNBQU0sRUFBRW5ELElBQUksQ0FBQ29ELEdBRFI7QUFFTEksYUFBSyxFQUFFLElBQUkvQyxNQUFNLENBQUMrQixLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDJCQUF0QjtBQUZGLE9BQVA7QUFLRixZQUFNeUssWUFBWSxHQUFHak4sSUFBSSxDQUFDZ0ssTUFBTCxDQUFZdEYsSUFBWixDQUNuQjBHLENBQUMsSUFBSUEsQ0FBQyxDQUFDbkIsT0FBRixJQUFhVyxXQUFXLENBQUNYLE9BRFgsQ0FBckI7QUFHQSxVQUFJLENBQUNnRCxZQUFMLEVBQ0UsT0FBTztBQUNMOUosY0FBTSxFQUFFbkQsSUFBSSxDQUFDb0QsR0FEUjtBQUVMSSxhQUFLLEVBQUUsSUFBSS9DLE1BQU0sQ0FBQytCLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsMENBQXRCO0FBRkYsT0FBUCxDQXJCRSxDQTBCSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBL0IsWUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUNFO0FBQUNQLFdBQUcsRUFBRXBELElBQUksQ0FBQ29ELEdBQVg7QUFDQywwQkFBa0J3SCxXQUFXLENBQUNYO0FBRC9CLE9BREYsRUFHRTtBQUFDckcsWUFBSSxFQUFFO0FBQUMsK0JBQXFCO0FBQXRCLFNBQVA7QUFDQzRGLGFBQUssRUFBRTtBQUFDLCtDQUFxQztBQUFDUyxtQkFBTyxFQUFFVyxXQUFXLENBQUNYO0FBQXRCO0FBQXRDO0FBRFIsT0FIRjtBQU1BLGFBQU87QUFBQzlHLGNBQU0sRUFBRW5ELElBQUksQ0FBQ29EO0FBQWQsT0FBUDtBQUNELEtBM0NJLENBQVA7QUE2Q0Q7QUEvQ2MsQ0FBZjtBQWlEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EvQyxRQUFRLENBQUM2TSxRQUFULEdBQW9CLENBQUMvSixNQUFELEVBQVNnSyxRQUFULEVBQW1COUIsUUFBbkIsS0FBZ0M7QUFDbERsRSxPQUFLLENBQUNoRSxNQUFELEVBQVM0RCxjQUFULENBQUw7QUFDQUksT0FBSyxDQUFDZ0csUUFBRCxFQUFXcEcsY0FBWCxDQUFMO0FBQ0FJLE9BQUssQ0FBQ2tFLFFBQUQsRUFBV3JFLEtBQUssQ0FBQ00sUUFBTixDQUFlOEYsT0FBZixDQUFYLENBQUw7O0FBRUEsTUFBSS9CLFFBQVEsS0FBSyxLQUFLLENBQXRCLEVBQXlCO0FBQ3ZCQSxZQUFRLEdBQUcsS0FBWDtBQUNEOztBQUVELFFBQU1yTCxJQUFJLEdBQUc2QixXQUFXLENBQUNzQixNQUFELENBQXhCO0FBQ0EsTUFBSSxDQUFDbkQsSUFBTCxFQUNFLE1BQU0sSUFBSVMsTUFBTSxDQUFDK0IsS0FBWCxDQUFpQixHQUFqQixFQUFzQixnQkFBdEIsQ0FBTixDQVhnRCxDQWFsRDtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxRQUFNNksscUJBQXFCLEdBQ3pCLElBQUk5SCxNQUFKLFlBQWU5RSxNQUFNLENBQUMrRSxhQUFQLENBQXFCMkgsUUFBckIsQ0FBZixRQUFrRCxHQUFsRCxDQURGO0FBR0EsUUFBTUcsaUJBQWlCLEdBQUcsQ0FBQ3ROLElBQUksQ0FBQ2dLLE1BQUwsSUFBZSxFQUFoQixFQUFvQnVELE1BQXBCLENBQ3hCLENBQUNDLElBQUQsRUFBT2xKLEtBQVAsS0FBaUI7QUFDZixRQUFJK0kscUJBQXFCLENBQUNJLElBQXRCLENBQTJCbkosS0FBSyxDQUFDMkYsT0FBakMsQ0FBSixFQUErQztBQUM3Q3hKLFlBQU0sQ0FBQ3NCLEtBQVAsQ0FBYTRCLE1BQWIsQ0FBb0I7QUFDbEJQLFdBQUcsRUFBRXBELElBQUksQ0FBQ29ELEdBRFE7QUFFbEIsMEJBQWtCa0IsS0FBSyxDQUFDMkY7QUFGTixPQUFwQixFQUdHO0FBQUNyRyxZQUFJLEVBQUU7QUFDUiw4QkFBb0J1SixRQURaO0FBRVIsK0JBQXFCOUI7QUFGYjtBQUFQLE9BSEg7QUFPQSxhQUFPLElBQVA7QUFDRCxLQVRELE1BU087QUFDTCxhQUFPbUMsSUFBUDtBQUNEO0FBQ0YsR0FkdUIsRUFleEIsS0Fmd0IsQ0FBMUIsQ0F4QmtELENBMENsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBSUYsaUJBQUosRUFBdUI7QUFDckI7QUFDRCxHQW5EaUQsQ0FxRGxEOzs7QUFDQWpILG1DQUFpQyxDQUFDLGdCQUFELEVBQW1CLE9BQW5CLEVBQTRCOEcsUUFBNUIsRUFBc0NuTixJQUFJLENBQUNvRCxHQUEzQyxDQUFqQztBQUVBM0MsUUFBTSxDQUFDc0IsS0FBUCxDQUFhNEIsTUFBYixDQUFvQjtBQUNsQlAsT0FBRyxFQUFFcEQsSUFBSSxDQUFDb0Q7QUFEUSxHQUFwQixFQUVHO0FBQ0RzSyxhQUFTLEVBQUU7QUFDVDFELFlBQU0sRUFBRTtBQUNOQyxlQUFPLEVBQUVrRCxRQURIO0FBRU45QixnQkFBUSxFQUFFQTtBQUZKO0FBREM7QUFEVixHQUZILEVBeERrRCxDQW1FbEQ7QUFDQTs7QUFDQSxNQUFJO0FBQ0ZoRixxQ0FBaUMsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QjhHLFFBQTVCLEVBQXNDbk4sSUFBSSxDQUFDb0QsR0FBM0MsQ0FBakM7QUFDRCxHQUZELENBRUUsT0FBTzJGLEVBQVAsRUFBVztBQUNYO0FBQ0F0SSxVQUFNLENBQUNzQixLQUFQLENBQWE0QixNQUFiLENBQW9CO0FBQUNQLFNBQUcsRUFBRXBELElBQUksQ0FBQ29EO0FBQVgsS0FBcEIsRUFDRTtBQUFDb0csV0FBSyxFQUFFO0FBQUNRLGNBQU0sRUFBRTtBQUFDQyxpQkFBTyxFQUFFa0Q7QUFBVjtBQUFUO0FBQVIsS0FERjtBQUVBLFVBQU1wRSxFQUFOO0FBQ0Q7QUFDRixDQTdFRDtBQStFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTFJLFFBQVEsQ0FBQ3NOLFdBQVQsR0FBdUIsQ0FBQ3hLLE1BQUQsRUFBU21CLEtBQVQsS0FBbUI7QUFDeEM2QyxPQUFLLENBQUNoRSxNQUFELEVBQVM0RCxjQUFULENBQUw7QUFDQUksT0FBSyxDQUFDN0MsS0FBRCxFQUFReUMsY0FBUixDQUFMO0FBRUEsUUFBTS9HLElBQUksR0FBRzZCLFdBQVcsQ0FBQ3NCLE1BQUQsQ0FBeEI7QUFDQSxNQUFJLENBQUNuRCxJQUFMLEVBQ0UsTUFBTSxJQUFJUyxNQUFNLENBQUMrQixLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGdCQUF0QixDQUFOO0FBRUYvQixRQUFNLENBQUNzQixLQUFQLENBQWE0QixNQUFiLENBQW9CO0FBQUNQLE9BQUcsRUFBRXBELElBQUksQ0FBQ29EO0FBQVgsR0FBcEIsRUFDRTtBQUFDb0csU0FBSyxFQUFFO0FBQUNRLFlBQU0sRUFBRTtBQUFDQyxlQUFPLEVBQUUzRjtBQUFWO0FBQVQ7QUFBUixHQURGO0FBRUQsQ0FWRCxDLENBWUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTXNKLFVBQVUsR0FBR2pHLE9BQU8sSUFBSTtBQUM1QjtBQUNBO0FBQ0FSLE9BQUssQ0FBQ1EsT0FBRCxFQUFVWCxLQUFLLENBQUM2RyxlQUFOLENBQXNCO0FBQ25DeEosWUFBUSxFQUFFMkMsS0FBSyxDQUFDTSxRQUFOLENBQWVGLE1BQWYsQ0FEeUI7QUFFbkM5QyxTQUFLLEVBQUUwQyxLQUFLLENBQUNNLFFBQU4sQ0FBZUYsTUFBZixDQUY0QjtBQUduQy9FLFlBQVEsRUFBRTJFLEtBQUssQ0FBQ00sUUFBTixDQUFlRSxpQkFBZjtBQUh5QixHQUF0QixDQUFWLENBQUw7QUFNQSxRQUFNO0FBQUVuRCxZQUFGO0FBQVlDLFNBQVo7QUFBbUJqQztBQUFuQixNQUFnQ3NGLE9BQXRDO0FBQ0EsTUFBSSxDQUFDdEQsUUFBRCxJQUFhLENBQUNDLEtBQWxCLEVBQ0UsTUFBTSxJQUFJN0QsTUFBTSxDQUFDK0IsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpQ0FBdEIsQ0FBTjtBQUVGLFFBQU14QyxJQUFJLEdBQUc7QUFBQ3NELFlBQVEsRUFBRTtBQUFYLEdBQWI7O0FBQ0EsTUFBSWpCLFFBQUosRUFBYztBQUNaLFVBQU0rRyxNQUFNLEdBQUcxRyxZQUFZLENBQUNMLFFBQUQsQ0FBM0I7QUFDQXJDLFFBQUksQ0FBQ3NELFFBQUwsQ0FBY2pCLFFBQWQsR0FBeUI7QUFBRWYsWUFBTSxFQUFFOEg7QUFBVixLQUF6QjtBQUNEOztBQUVELE1BQUkvRSxRQUFKLEVBQ0VyRSxJQUFJLENBQUNxRSxRQUFMLEdBQWdCQSxRQUFoQjtBQUNGLE1BQUlDLEtBQUosRUFDRXRFLElBQUksQ0FBQ2dLLE1BQUwsR0FBYyxDQUFDO0FBQUNDLFdBQU8sRUFBRTNGLEtBQVY7QUFBaUIrRyxZQUFRLEVBQUU7QUFBM0IsR0FBRCxDQUFkLENBdEIwQixDQXdCNUI7O0FBQ0FoRixtQ0FBaUMsQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QmhDLFFBQXpCLENBQWpDO0FBQ0FnQyxtQ0FBaUMsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0Qi9CLEtBQTVCLENBQWpDO0FBRUEsUUFBTW5CLE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ3lOLGFBQVQsQ0FBdUJuRyxPQUF2QixFQUFnQzNILElBQWhDLENBQWYsQ0E1QjRCLENBNkI1QjtBQUNBOztBQUNBLE1BQUk7QUFDRnFHLHFDQUFpQyxDQUFDLFVBQUQsRUFBYSxVQUFiLEVBQXlCaEMsUUFBekIsRUFBbUNsQixNQUFuQyxDQUFqQztBQUNBa0QscUNBQWlDLENBQUMsZ0JBQUQsRUFBbUIsT0FBbkIsRUFBNEIvQixLQUE1QixFQUFtQ25CLE1BQW5DLENBQWpDO0FBQ0QsR0FIRCxDQUdFLE9BQU80RixFQUFQLEVBQVc7QUFDWDtBQUNBdEksVUFBTSxDQUFDc0IsS0FBUCxDQUFhZ00sTUFBYixDQUFvQjVLLE1BQXBCO0FBQ0EsVUFBTTRGLEVBQU47QUFDRDs7QUFDRCxTQUFPNUYsTUFBUDtBQUNELENBeENELEMsQ0EwQ0E7OztBQUNBMUMsTUFBTSxDQUFDdUksT0FBUCxDQUFlO0FBQUM0RSxZQUFVLEVBQUUsWUFBbUI7QUFBQSx1Q0FBTjFCLElBQU07QUFBTkEsVUFBTTtBQUFBOztBQUM3QyxVQUFNdkUsT0FBTyxHQUFHdUUsSUFBSSxDQUFDLENBQUQsQ0FBcEI7QUFDQSxXQUFPN0wsUUFBUSxDQUFDOEwsWUFBVCxDQUNMLElBREssRUFFTCxZQUZLLEVBR0xELElBSEssRUFJTCxVQUpLLEVBS0wsTUFBTTtBQUNKO0FBQ0EvRSxXQUFLLENBQUNRLE9BQUQsRUFBVWxCLE1BQVYsQ0FBTDtBQUNBLFVBQUlwRyxRQUFRLENBQUM2QixRQUFULENBQWtCOEwsMkJBQXRCLEVBQ0UsT0FBTztBQUNMeEssYUFBSyxFQUFFLElBQUkvQyxNQUFNLENBQUMrQixLQUFYLENBQWlCLEdBQWpCLEVBQXNCLG1CQUF0QjtBQURGLE9BQVAsQ0FKRSxDQVFKOztBQUNBLFlBQU1XLE1BQU0sR0FBR3lLLFVBQVUsQ0FBQ2pHLE9BQUQsQ0FBekIsQ0FUSSxDQVVKO0FBQ0E7O0FBQ0EsVUFBSSxDQUFFeEUsTUFBTixFQUNFLE1BQU0sSUFBSVgsS0FBSixDQUFVLHNDQUFWLENBQU4sQ0FiRSxDQWVKO0FBQ0E7QUFDQTs7QUFDQSxVQUFJbUYsT0FBTyxDQUFDckQsS0FBUixJQUFpQmpFLFFBQVEsQ0FBQzZCLFFBQVQsQ0FBa0I2SyxxQkFBdkMsRUFDRTFNLFFBQVEsQ0FBQzBNLHFCQUFULENBQStCNUosTUFBL0IsRUFBdUN3RSxPQUFPLENBQUNyRCxLQUEvQyxFQW5CRSxDQXFCSjs7QUFDQSxhQUFPO0FBQUNuQixjQUFNLEVBQUVBO0FBQVQsT0FBUDtBQUNELEtBNUJJLENBQVA7QUE4QkQ7QUFoQ2MsQ0FBZixFLENBa0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTlDLFFBQVEsQ0FBQ3VOLFVBQVQsR0FBc0IsQ0FBQ2pHLE9BQUQsRUFBVXNHLFFBQVYsS0FBdUI7QUFDM0N0RyxTQUFPLHFCQUFRQSxPQUFSLENBQVAsQ0FEMkMsQ0FHM0M7O0FBQ0EsTUFBSXNHLFFBQUosRUFBYztBQUNaLFVBQU0sSUFBSXpMLEtBQUosQ0FBVSxvRUFBVixDQUFOO0FBQ0Q7O0FBRUQsU0FBT29MLFVBQVUsQ0FBQ2pHLE9BQUQsQ0FBakI7QUFDRCxDQVRELEMsQ0FXQTtBQUNBO0FBQ0E7OztBQUNBbEgsTUFBTSxDQUFDc0IsS0FBUCxDQUFhbU0sWUFBYixDQUEwQix5Q0FBMUIsRUFDMEI7QUFBQ0MsUUFBTSxFQUFFLENBQVQ7QUFBWUMsUUFBTSxFQUFFO0FBQXBCLENBRDFCOztBQUVBM04sTUFBTSxDQUFDc0IsS0FBUCxDQUFhbU0sWUFBYixDQUEwQiwrQkFBMUIsRUFDMEI7QUFBQ0MsUUFBTSxFQUFFLENBQVQ7QUFBWUMsUUFBTSxFQUFFO0FBQXBCLENBRDFCLEUiLCJmaWxlIjoiL3BhY2thZ2VzL2FjY291bnRzLXBhc3N3b3JkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZ3JlZXQgPSB3ZWxjb21lTXNnID0+ICh1c2VyLCB1cmwpID0+IHtcbiAgICAgIGNvbnN0IGdyZWV0aW5nID0gKHVzZXIucHJvZmlsZSAmJiB1c2VyLnByb2ZpbGUubmFtZSkgP1xuICAgICAgICAgICAgKGBIZWxsbyAke3VzZXIucHJvZmlsZS5uYW1lfSxgKSA6IFwiSGVsbG8sXCI7XG4gICAgICByZXR1cm4gYCR7Z3JlZXRpbmd9XG5cbiR7d2VsY29tZU1zZ30sIHNpbXBseSBjbGljayB0aGUgbGluayBiZWxvdy5cblxuJHt1cmx9XG5cblRoYW5rcy5cbmA7XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IE9wdGlvbnMgdG8gY3VzdG9taXplIGVtYWlscyBzZW50IGZyb20gdGhlIEFjY291bnRzIHN5c3RlbS5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmVtYWlsVGVtcGxhdGVzID0ge1xuICBmcm9tOiBcIkFjY291bnRzIEV4YW1wbGUgPG5vLXJlcGx5QGV4YW1wbGUuY29tPlwiLFxuICBzaXRlTmFtZTogTWV0ZW9yLmFic29sdXRlVXJsKCkucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCAnJykucmVwbGFjZSgvXFwvJC8sICcnKSxcblxuICByZXNldFBhc3N3b3JkOiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEhvdyB0byByZXNldCB5b3VyIHBhc3N3b3JkIG9uICR7QWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWV9YCxcbiAgICB0ZXh0OiBncmVldChcIlRvIHJlc2V0IHlvdXIgcGFzc3dvcmRcIiksXG4gIH0sXG4gIHZlcmlmeUVtYWlsOiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEhvdyB0byB2ZXJpZnkgZW1haWwgYWRkcmVzcyBvbiAke0FjY291bnRzLmVtYWlsVGVtcGxhdGVzLnNpdGVOYW1lfWAsXG4gICAgdGV4dDogZ3JlZXQoXCJUbyB2ZXJpZnkgeW91ciBhY2NvdW50IGVtYWlsXCIpLFxuICB9LFxuICBlbnJvbGxBY2NvdW50OiB7XG4gICAgc3ViamVjdDogKCkgPT4gYEFuIGFjY291bnQgaGFzIGJlZW4gY3JlYXRlZCBmb3IgeW91IG9uICR7QWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWV9YCxcbiAgICB0ZXh0OiBncmVldChcIlRvIHN0YXJ0IHVzaW5nIHRoZSBzZXJ2aWNlXCIpLFxuICB9LFxufTtcbiIsIi8vLyBCQ1JZUFRcblxuY29uc3QgYmNyeXB0ID0gTnBtTW9kdWxlQmNyeXB0O1xuY29uc3QgYmNyeXB0SGFzaCA9IE1ldGVvci53cmFwQXN5bmMoYmNyeXB0Lmhhc2gpO1xuY29uc3QgYmNyeXB0Q29tcGFyZSA9IE1ldGVvci53cmFwQXN5bmMoYmNyeXB0LmNvbXBhcmUpO1xuXG4vLyBVdGlsaXR5IGZvciBncmFiYmluZyB1c2VyXG5jb25zdCBnZXRVc2VyQnlJZCA9IGlkID0+IE1ldGVvci51c2Vycy5maW5kT25lKGlkKTtcblxuLy8gVXNlciByZWNvcmRzIGhhdmUgYSAnc2VydmljZXMucGFzc3dvcmQuYmNyeXB0JyBmaWVsZCBvbiB0aGVtIHRvIGhvbGRcbi8vIHRoZWlyIGhhc2hlZCBwYXNzd29yZHMgKHVubGVzcyB0aGV5IGhhdmUgYSAnc2VydmljZXMucGFzc3dvcmQuc3JwJ1xuLy8gZmllbGQsIGluIHdoaWNoIGNhc2UgdGhleSB3aWxsIGJlIHVwZ3JhZGVkIHRvIGJjcnlwdCB0aGUgbmV4dCB0aW1lXG4vLyB0aGV5IGxvZyBpbikuXG4vL1xuLy8gV2hlbiB0aGUgY2xpZW50IHNlbmRzIGEgcGFzc3dvcmQgdG8gdGhlIHNlcnZlciwgaXQgY2FuIGVpdGhlciBiZSBhXG4vLyBzdHJpbmcgKHRoZSBwbGFpbnRleHQgcGFzc3dvcmQpIG9yIGFuIG9iamVjdCB3aXRoIGtleXMgJ2RpZ2VzdCcgYW5kXG4vLyAnYWxnb3JpdGhtJyAobXVzdCBiZSBcInNoYS0yNTZcIiBmb3Igbm93KS4gVGhlIE1ldGVvciBjbGllbnQgYWx3YXlzIHNlbmRzXG4vLyBwYXNzd29yZCBvYmplY3RzIHsgZGlnZXN0OiAqLCBhbGdvcml0aG06IFwic2hhLTI1NlwiIH0sIGJ1dCBERFAgY2xpZW50c1xuLy8gdGhhdCBkb24ndCBoYXZlIGFjY2VzcyB0byBTSEEgY2FuIGp1c3Qgc2VuZCBwbGFpbnRleHQgcGFzc3dvcmRzIGFzXG4vLyBzdHJpbmdzLlxuLy9cbi8vIFdoZW4gdGhlIHNlcnZlciByZWNlaXZlcyBhIHBsYWludGV4dCBwYXNzd29yZCBhcyBhIHN0cmluZywgaXQgYWx3YXlzXG4vLyBoYXNoZXMgaXQgd2l0aCBTSEEyNTYgYmVmb3JlIHBhc3NpbmcgaXQgaW50byBiY3J5cHQuIFdoZW4gdGhlIHNlcnZlclxuLy8gcmVjZWl2ZXMgYSBwYXNzd29yZCBhcyBhbiBvYmplY3QsIGl0IGFzc2VydHMgdGhhdCB0aGUgYWxnb3JpdGhtIGlzXG4vLyBcInNoYS0yNTZcIiBhbmQgdGhlbiBwYXNzZXMgdGhlIGRpZ2VzdCB0byBiY3J5cHQuXG5cblxuQWNjb3VudHMuX2JjcnlwdFJvdW5kcyA9ICgpID0+IEFjY291bnRzLl9vcHRpb25zLmJjcnlwdFJvdW5kcyB8fCAxMDtcblxuLy8gR2l2ZW4gYSAncGFzc3dvcmQnIGZyb20gdGhlIGNsaWVudCwgZXh0cmFjdCB0aGUgc3RyaW5nIHRoYXQgd2Ugc2hvdWxkXG4vLyBiY3J5cHQuICdwYXNzd29yZCcgY2FuIGJlIG9uZSBvZjpcbi8vICAtIFN0cmluZyAodGhlIHBsYWludGV4dCBwYXNzd29yZClcbi8vICAtIE9iamVjdCB3aXRoICdkaWdlc3QnIGFuZCAnYWxnb3JpdGhtJyBrZXlzLiAnYWxnb3JpdGhtJyBtdXN0IGJlIFwic2hhLTI1NlwiLlxuLy9cbmNvbnN0IGdldFBhc3N3b3JkU3RyaW5nID0gcGFzc3dvcmQgPT4ge1xuICBpZiAodHlwZW9mIHBhc3N3b3JkID09PSBcInN0cmluZ1wiKSB7XG4gICAgcGFzc3dvcmQgPSBTSEEyNTYocGFzc3dvcmQpO1xuICB9IGVsc2UgeyAvLyAncGFzc3dvcmQnIGlzIGFuIG9iamVjdFxuICAgIGlmIChwYXNzd29yZC5hbGdvcml0aG0gIT09IFwic2hhLTI1NlwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHBhc3N3b3JkIGhhc2ggYWxnb3JpdGhtLiBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgXCJPbmx5ICdzaGEtMjU2JyBpcyBhbGxvd2VkLlwiKTtcbiAgICB9XG4gICAgcGFzc3dvcmQgPSBwYXNzd29yZC5kaWdlc3Q7XG4gIH1cbiAgcmV0dXJuIHBhc3N3b3JkO1xufTtcblxuLy8gVXNlIGJjcnlwdCB0byBoYXNoIHRoZSBwYXNzd29yZCBmb3Igc3RvcmFnZSBpbiB0aGUgZGF0YWJhc2UuXG4vLyBgcGFzc3dvcmRgIGNhbiBiZSBhIHN0cmluZyAoaW4gd2hpY2ggY2FzZSBpdCB3aWxsIGJlIHJ1biB0aHJvdWdoXG4vLyBTSEEyNTYgYmVmb3JlIGJjcnlwdCkgb3IgYW4gb2JqZWN0IHdpdGggcHJvcGVydGllcyBgZGlnZXN0YCBhbmRcbi8vIGBhbGdvcml0aG1gIChpbiB3aGljaCBjYXNlIHdlIGJjcnlwdCBgcGFzc3dvcmQuZGlnZXN0YCkuXG4vL1xuY29uc3QgaGFzaFBhc3N3b3JkID0gcGFzc3dvcmQgPT4ge1xuICBwYXNzd29yZCA9IGdldFBhc3N3b3JkU3RyaW5nKHBhc3N3b3JkKTtcbiAgcmV0dXJuIGJjcnlwdEhhc2gocGFzc3dvcmQsIEFjY291bnRzLl9iY3J5cHRSb3VuZHMoKSk7XG59O1xuXG4vLyBFeHRyYWN0IHRoZSBudW1iZXIgb2Ygcm91bmRzIHVzZWQgaW4gdGhlIHNwZWNpZmllZCBiY3J5cHQgaGFzaC5cbmNvbnN0IGdldFJvdW5kc0Zyb21CY3J5cHRIYXNoID0gaGFzaCA9PiB7XG4gIGxldCByb3VuZHM7XG4gIGlmIChoYXNoKSB7XG4gICAgY29uc3QgaGFzaFNlZ21lbnRzID0gaGFzaC5zcGxpdCgnJCcpO1xuICAgIGlmIChoYXNoU2VnbWVudHMubGVuZ3RoID4gMikge1xuICAgICAgcm91bmRzID0gcGFyc2VJbnQoaGFzaFNlZ21lbnRzWzJdLCAxMCk7XG4gICAgfVxuICB9XG4gIHJldHVybiByb3VuZHM7XG59O1xuXG4vLyBDaGVjayB3aGV0aGVyIHRoZSBwcm92aWRlZCBwYXNzd29yZCBtYXRjaGVzIHRoZSBiY3J5cHQnZWQgcGFzc3dvcmQgaW5cbi8vIHRoZSBkYXRhYmFzZSB1c2VyIHJlY29yZC4gYHBhc3N3b3JkYCBjYW4gYmUgYSBzdHJpbmcgKGluIHdoaWNoIGNhc2Vcbi8vIGl0IHdpbGwgYmUgcnVuIHRocm91Z2ggU0hBMjU2IGJlZm9yZSBiY3J5cHQpIG9yIGFuIG9iamVjdCB3aXRoXG4vLyBwcm9wZXJ0aWVzIGBkaWdlc3RgIGFuZCBgYWxnb3JpdGhtYCAoaW4gd2hpY2ggY2FzZSB3ZSBiY3J5cHRcbi8vIGBwYXNzd29yZC5kaWdlc3RgKS5cbi8vXG5BY2NvdW50cy5fY2hlY2tQYXNzd29yZCA9ICh1c2VyLCBwYXNzd29yZCkgPT4ge1xuICBjb25zdCByZXN1bHQgPSB7XG4gICAgdXNlcklkOiB1c2VyLl9pZFxuICB9O1xuXG4gIGNvbnN0IGZvcm1hdHRlZFBhc3N3b3JkID0gZ2V0UGFzc3dvcmRTdHJpbmcocGFzc3dvcmQpO1xuICBjb25zdCBoYXNoID0gdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQ7XG4gIGNvbnN0IGhhc2hSb3VuZHMgPSBnZXRSb3VuZHNGcm9tQmNyeXB0SGFzaChoYXNoKTtcblxuICBpZiAoISBiY3J5cHRDb21wYXJlKGZvcm1hdHRlZFBhc3N3b3JkLCBoYXNoKSkge1xuICAgIHJlc3VsdC5lcnJvciA9IGhhbmRsZUVycm9yKFwiSW5jb3JyZWN0IHBhc3N3b3JkXCIsIGZhbHNlKTtcbiAgfSBlbHNlIGlmIChoYXNoICYmIEFjY291bnRzLl9iY3J5cHRSb3VuZHMoKSAhPSBoYXNoUm91bmRzKSB7XG4gICAgLy8gVGhlIHBhc3N3b3JkIGNoZWNrcyBvdXQsIGJ1dCB0aGUgdXNlcidzIGJjcnlwdCBoYXNoIG5lZWRzIHRvIGJlIHVwZGF0ZWQuXG4gICAgTWV0ZW9yLmRlZmVyKCgpID0+IHtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6IHVzZXIuX2lkIH0sIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgICdzZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQnOlxuICAgICAgICAgICAgYmNyeXB0SGFzaChmb3JtYXR0ZWRQYXNzd29yZCwgQWNjb3VudHMuX2JjcnlwdFJvdW5kcygpKVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuY29uc3QgY2hlY2tQYXNzd29yZCA9IEFjY291bnRzLl9jaGVja1Bhc3N3b3JkO1xuXG4vLy9cbi8vLyBFUlJPUiBIQU5ETEVSXG4vLy9cbmNvbnN0IGhhbmRsZUVycm9yID0gKG1zZywgdGhyb3dFcnJvciA9IHRydWUpID0+IHtcbiAgY29uc3QgZXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKFxuICAgIDQwMyxcbiAgICBBY2NvdW50cy5fb3B0aW9ucy5hbWJpZ3VvdXNFcnJvck1lc3NhZ2VzXG4gICAgICA/IFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuIFBsZWFzZSBjaGVjayB5b3VyIGNyZWRlbnRpYWxzLlwiXG4gICAgICA6IG1zZ1xuICApO1xuICBpZiAodGhyb3dFcnJvcikge1xuICAgIHRocm93IGVycm9yO1xuICB9XG4gIHJldHVybiBlcnJvcjtcbn07XG5cbi8vL1xuLy8vIExPR0lOXG4vLy9cblxuQWNjb3VudHMuX2ZpbmRVc2VyQnlRdWVyeSA9IHF1ZXJ5ID0+IHtcbiAgbGV0IHVzZXIgPSBudWxsO1xuXG4gIGlmIChxdWVyeS5pZCkge1xuICAgIHVzZXIgPSBnZXRVc2VyQnlJZChxdWVyeS5pZCk7XG4gIH0gZWxzZSB7XG4gICAgbGV0IGZpZWxkTmFtZTtcbiAgICBsZXQgZmllbGRWYWx1ZTtcbiAgICBpZiAocXVlcnkudXNlcm5hbWUpIHtcbiAgICAgIGZpZWxkTmFtZSA9ICd1c2VybmFtZSc7XG4gICAgICBmaWVsZFZhbHVlID0gcXVlcnkudXNlcm5hbWU7XG4gICAgfSBlbHNlIGlmIChxdWVyeS5lbWFpbCkge1xuICAgICAgZmllbGROYW1lID0gJ2VtYWlscy5hZGRyZXNzJztcbiAgICAgIGZpZWxkVmFsdWUgPSBxdWVyeS5lbWFpbDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwic2hvdWxkbid0IGhhcHBlbiAodmFsaWRhdGlvbiBtaXNzZWQgc29tZXRoaW5nKVwiKTtcbiAgICB9XG4gICAgbGV0IHNlbGVjdG9yID0ge307XG4gICAgc2VsZWN0b3JbZmllbGROYW1lXSA9IGZpZWxkVmFsdWU7XG4gICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHNlbGVjdG9yKTtcbiAgICAvLyBJZiB1c2VyIGlzIG5vdCBmb3VuZCwgdHJ5IGEgY2FzZSBpbnNlbnNpdGl2ZSBsb29rdXBcbiAgICBpZiAoIXVzZXIpIHtcbiAgICAgIHNlbGVjdG9yID0gc2VsZWN0b3JGb3JGYXN0Q2FzZUluc2Vuc2l0aXZlTG9va3VwKGZpZWxkTmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICBjb25zdCBjYW5kaWRhdGVVc2VycyA9IE1ldGVvci51c2Vycy5maW5kKHNlbGVjdG9yKS5mZXRjaCgpO1xuICAgICAgLy8gTm8gbWF0Y2ggaWYgbXVsdGlwbGUgY2FuZGlkYXRlcyBhcmUgZm91bmRcbiAgICAgIGlmIChjYW5kaWRhdGVVc2Vycy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgdXNlciA9IGNhbmRpZGF0ZVVzZXJzWzBdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB1c2VyO1xufTtcblxuLyoqXG4gKiBAc3VtbWFyeSBGaW5kcyB0aGUgdXNlciB3aXRoIHRoZSBzcGVjaWZpZWQgdXNlcm5hbWUuXG4gKiBGaXJzdCB0cmllcyB0byBtYXRjaCB1c2VybmFtZSBjYXNlIHNlbnNpdGl2ZWx5OyBpZiB0aGF0IGZhaWxzLCBpdFxuICogdHJpZXMgY2FzZSBpbnNlbnNpdGl2ZWx5OyBidXQgaWYgbW9yZSB0aGFuIG9uZSB1c2VyIG1hdGNoZXMgdGhlIGNhc2VcbiAqIGluc2Vuc2l0aXZlIHNlYXJjaCwgaXQgcmV0dXJucyBudWxsLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJuYW1lIFRoZSB1c2VybmFtZSB0byBsb29rIGZvclxuICogQHJldHVybnMge09iamVjdH0gQSB1c2VyIGlmIGZvdW5kLCBlbHNlIG51bGxcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZSA9IFxuICB1c2VybmFtZSA9PiBBY2NvdW50cy5fZmluZFVzZXJCeVF1ZXJ5KHsgdXNlcm5hbWUgfSk7XG5cbi8qKlxuICogQHN1bW1hcnkgRmluZHMgdGhlIHVzZXIgd2l0aCB0aGUgc3BlY2lmaWVkIGVtYWlsLlxuICogRmlyc3QgdHJpZXMgdG8gbWF0Y2ggZW1haWwgY2FzZSBzZW5zaXRpdmVseTsgaWYgdGhhdCBmYWlscywgaXRcbiAqIHRyaWVzIGNhc2UgaW5zZW5zaXRpdmVseTsgYnV0IGlmIG1vcmUgdGhhbiBvbmUgdXNlciBtYXRjaGVzIHRoZSBjYXNlXG4gKiBpbnNlbnNpdGl2ZSBzZWFyY2gsIGl0IHJldHVybnMgbnVsbC5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7U3RyaW5nfSBlbWFpbCBUaGUgZW1haWwgYWRkcmVzcyB0byBsb29rIGZvclxuICogQHJldHVybnMge09iamVjdH0gQSB1c2VyIGlmIGZvdW5kLCBlbHNlIG51bGxcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmZpbmRVc2VyQnlFbWFpbCA9IGVtYWlsID0+IEFjY291bnRzLl9maW5kVXNlckJ5UXVlcnkoeyBlbWFpbCB9KTtcblxuLy8gR2VuZXJhdGVzIGEgTW9uZ29EQiBzZWxlY3RvciB0aGF0IGNhbiBiZSB1c2VkIHRvIHBlcmZvcm0gYSBmYXN0IGNhc2Vcbi8vIGluc2Vuc2l0aXZlIGxvb2t1cCBmb3IgdGhlIGdpdmVuIGZpZWxkTmFtZSBhbmQgc3RyaW5nLiBTaW5jZSBNb25nb0RCIGRvZXNcbi8vIG5vdCBzdXBwb3J0IGNhc2UgaW5zZW5zaXRpdmUgaW5kZXhlcywgYW5kIGNhc2UgaW5zZW5zaXRpdmUgcmVnZXggcXVlcmllc1xuLy8gYXJlIHNsb3csIHdlIGNvbnN0cnVjdCBhIHNldCBvZiBwcmVmaXggc2VsZWN0b3JzIGZvciBhbGwgcGVybXV0YXRpb25zIG9mXG4vLyB0aGUgZmlyc3QgNCBjaGFyYWN0ZXJzIG91cnNlbHZlcy4gV2UgZmlyc3QgYXR0ZW1wdCB0byBtYXRjaGluZyBhZ2FpbnN0XG4vLyB0aGVzZSwgYW5kIGJlY2F1c2UgJ3ByZWZpeCBleHByZXNzaW9uJyByZWdleCBxdWVyaWVzIGRvIHVzZSBpbmRleGVzIChzZWVcbi8vIGh0dHA6Ly9kb2NzLm1vbmdvZGIub3JnL3YyLjYvcmVmZXJlbmNlL29wZXJhdG9yL3F1ZXJ5L3JlZ2V4LyNpbmRleC11c2UpLFxuLy8gdGhpcyBoYXMgYmVlbiBmb3VuZCB0byBncmVhdGx5IGltcHJvdmUgcGVyZm9ybWFuY2UgKGZyb20gMTIwMG1zIHRvIDVtcyBpbiBhXG4vLyB0ZXN0IHdpdGggMS4wMDAuMDAwIHVzZXJzKS5cbmNvbnN0IHNlbGVjdG9yRm9yRmFzdENhc2VJbnNlbnNpdGl2ZUxvb2t1cCA9IChmaWVsZE5hbWUsIHN0cmluZykgPT4ge1xuICAvLyBQZXJmb3JtYW5jZSBzZWVtcyB0byBpbXByb3ZlIHVwIHRvIDQgcHJlZml4IGNoYXJhY3RlcnNcbiAgY29uc3QgcHJlZml4ID0gc3RyaW5nLnN1YnN0cmluZygwLCBNYXRoLm1pbihzdHJpbmcubGVuZ3RoLCA0KSk7XG4gIGNvbnN0IG9yQ2xhdXNlID0gZ2VuZXJhdGVDYXNlUGVybXV0YXRpb25zRm9yU3RyaW5nKHByZWZpeCkubWFwKFxuICAgIHByZWZpeFBlcm11dGF0aW9uID0+IHtcbiAgICAgIGNvbnN0IHNlbGVjdG9yID0ge307XG4gICAgICBzZWxlY3RvcltmaWVsZE5hbWVdID1cbiAgICAgICAgbmV3IFJlZ0V4cChgXiR7TWV0ZW9yLl9lc2NhcGVSZWdFeHAocHJlZml4UGVybXV0YXRpb24pfWApO1xuICAgICAgcmV0dXJuIHNlbGVjdG9yO1xuICAgIH0pO1xuICBjb25zdCBjYXNlSW5zZW5zaXRpdmVDbGF1c2UgPSB7fTtcbiAgY2FzZUluc2Vuc2l0aXZlQ2xhdXNlW2ZpZWxkTmFtZV0gPVxuICAgIG5ldyBSZWdFeHAoYF4ke01ldGVvci5fZXNjYXBlUmVnRXhwKHN0cmluZyl9JGAsICdpJylcbiAgcmV0dXJuIHskYW5kOiBbeyRvcjogb3JDbGF1c2V9LCBjYXNlSW5zZW5zaXRpdmVDbGF1c2VdfTtcbn1cblxuLy8gR2VuZXJhdGVzIHBlcm11dGF0aW9ucyBvZiBhbGwgY2FzZSB2YXJpYXRpb25zIG9mIGEgZ2l2ZW4gc3RyaW5nLlxuY29uc3QgZ2VuZXJhdGVDYXNlUGVybXV0YXRpb25zRm9yU3RyaW5nID0gc3RyaW5nID0+IHtcbiAgbGV0IHBlcm11dGF0aW9ucyA9IFsnJ107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyaW5nLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgY2ggPSBzdHJpbmcuY2hhckF0KGkpO1xuICAgIHBlcm11dGF0aW9ucyA9IFtdLmNvbmNhdCguLi4ocGVybXV0YXRpb25zLm1hcChwcmVmaXggPT4ge1xuICAgICAgY29uc3QgbG93ZXJDYXNlQ2hhciA9IGNoLnRvTG93ZXJDYXNlKCk7XG4gICAgICBjb25zdCB1cHBlckNhc2VDaGFyID0gY2gudG9VcHBlckNhc2UoKTtcbiAgICAgIC8vIERvbid0IGFkZCB1bm5lY2Nlc2FyeSBwZXJtdXRhdGlvbnMgd2hlbiBjaCBpcyBub3QgYSBsZXR0ZXJcbiAgICAgIGlmIChsb3dlckNhc2VDaGFyID09PSB1cHBlckNhc2VDaGFyKSB7XG4gICAgICAgIHJldHVybiBbcHJlZml4ICsgY2hdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFtwcmVmaXggKyBsb3dlckNhc2VDaGFyLCBwcmVmaXggKyB1cHBlckNhc2VDaGFyXTtcbiAgICAgIH1cbiAgICB9KSkpO1xuICB9XG4gIHJldHVybiBwZXJtdXRhdGlvbnM7XG59XG5cbmNvbnN0IGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcyA9IChmaWVsZE5hbWUsIGRpc3BsYXlOYW1lLCBmaWVsZFZhbHVlLCBvd25Vc2VySWQpID0+IHtcbiAgLy8gU29tZSB0ZXN0cyBuZWVkIHRoZSBhYmlsaXR5IHRvIGFkZCB1c2VycyB3aXRoIHRoZSBzYW1lIGNhc2UgaW5zZW5zaXRpdmVcbiAgLy8gdmFsdWUsIGhlbmNlIHRoZSBfc2tpcENhc2VJbnNlbnNpdGl2ZUNoZWNrc0ZvclRlc3QgY2hlY2tcbiAgY29uc3Qgc2tpcENoZWNrID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKEFjY291bnRzLl9za2lwQ2FzZUluc2Vuc2l0aXZlQ2hlY2tzRm9yVGVzdCwgZmllbGRWYWx1ZSk7XG5cbiAgaWYgKGZpZWxkVmFsdWUgJiYgIXNraXBDaGVjaykge1xuICAgIGNvbnN0IG1hdGNoZWRVc2VycyA9IE1ldGVvci51c2Vycy5maW5kKFxuICAgICAgc2VsZWN0b3JGb3JGYXN0Q2FzZUluc2Vuc2l0aXZlTG9va3VwKGZpZWxkTmFtZSwgZmllbGRWYWx1ZSkpLmZldGNoKCk7XG5cbiAgICBpZiAobWF0Y2hlZFVzZXJzLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhIHVzZXJJZCB5ZXQsIGFueSBtYXRjaCB3ZSBmaW5kIGlzIGEgZHVwbGljYXRlXG4gICAgICAgICghb3duVXNlcklkIHx8XG4gICAgICAgIC8vIE90aGVyd2lzZSwgY2hlY2sgdG8gc2VlIGlmIHRoZXJlIGFyZSBtdWx0aXBsZSBtYXRjaGVzIG9yIGEgbWF0Y2hcbiAgICAgICAgLy8gdGhhdCBpcyBub3QgdXNcbiAgICAgICAgKG1hdGNoZWRVc2Vycy5sZW5ndGggPiAxIHx8IG1hdGNoZWRVc2Vyc1swXS5faWQgIT09IG93blVzZXJJZCkpKSB7XG4gICAgICBoYW5kbGVFcnJvcihgJHtkaXNwbGF5TmFtZX0gYWxyZWFkeSBleGlzdHMuYCk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBYWFggbWF5YmUgdGhpcyBiZWxvbmdzIGluIHRoZSBjaGVjayBwYWNrYWdlXG5jb25zdCBOb25FbXB0eVN0cmluZyA9IE1hdGNoLldoZXJlKHggPT4ge1xuICBjaGVjayh4LCBTdHJpbmcpO1xuICByZXR1cm4geC5sZW5ndGggPiAwO1xufSk7XG5cbmNvbnN0IHVzZXJRdWVyeVZhbGlkYXRvciA9IE1hdGNoLldoZXJlKHVzZXIgPT4ge1xuICBjaGVjayh1c2VyLCB7XG4gICAgaWQ6IE1hdGNoLk9wdGlvbmFsKE5vbkVtcHR5U3RyaW5nKSxcbiAgICB1c2VybmFtZTogTWF0Y2guT3B0aW9uYWwoTm9uRW1wdHlTdHJpbmcpLFxuICAgIGVtYWlsOiBNYXRjaC5PcHRpb25hbChOb25FbXB0eVN0cmluZylcbiAgfSk7XG4gIGlmIChPYmplY3Qua2V5cyh1c2VyKS5sZW5ndGggIT09IDEpXG4gICAgdGhyb3cgbmV3IE1hdGNoLkVycm9yKFwiVXNlciBwcm9wZXJ0eSBtdXN0IGhhdmUgZXhhY3RseSBvbmUgZmllbGRcIik7XG4gIHJldHVybiB0cnVlO1xufSk7XG5cbmNvbnN0IHBhc3N3b3JkVmFsaWRhdG9yID0gTWF0Y2guT25lT2YoXG4gIFN0cmluZyxcbiAgeyBkaWdlc3Q6IFN0cmluZywgYWxnb3JpdGhtOiBTdHJpbmcgfVxuKTtcblxuLy8gSGFuZGxlciB0byBsb2dpbiB3aXRoIGEgcGFzc3dvcmQuXG4vL1xuLy8gVGhlIE1ldGVvciBjbGllbnQgc2V0cyBvcHRpb25zLnBhc3N3b3JkIHRvIGFuIG9iamVjdCB3aXRoIGtleXNcbi8vICdkaWdlc3QnIChzZXQgdG8gU0hBMjU2KHBhc3N3b3JkKSkgYW5kICdhbGdvcml0aG0nIChcInNoYS0yNTZcIikuXG4vL1xuLy8gRm9yIG90aGVyIEREUCBjbGllbnRzIHdoaWNoIGRvbid0IGhhdmUgYWNjZXNzIHRvIFNIQSwgdGhlIGhhbmRsZXJcbi8vIGFsc28gYWNjZXB0cyB0aGUgcGxhaW50ZXh0IHBhc3N3b3JkIGluIG9wdGlvbnMucGFzc3dvcmQgYXMgYSBzdHJpbmcuXG4vL1xuLy8gKEl0IG1pZ2h0IGJlIG5pY2UgaWYgc2VydmVycyBjb3VsZCB0dXJuIHRoZSBwbGFpbnRleHQgcGFzc3dvcmRcbi8vIG9wdGlvbiBvZmYuIE9yIG1heWJlIGl0IHNob3VsZCBiZSBvcHQtaW4sIG5vdCBvcHQtb3V0P1xuLy8gQWNjb3VudHMuY29uZmlnIG9wdGlvbj8pXG4vL1xuLy8gTm90ZSB0aGF0IG5laXRoZXIgcGFzc3dvcmQgb3B0aW9uIGlzIHNlY3VyZSB3aXRob3V0IFNTTC5cbi8vXG5BY2NvdW50cy5yZWdpc3RlckxvZ2luSGFuZGxlcihcInBhc3N3b3JkXCIsIG9wdGlvbnMgPT4ge1xuICBpZiAoISBvcHRpb25zLnBhc3N3b3JkIHx8IG9wdGlvbnMuc3JwKVxuICAgIHJldHVybiB1bmRlZmluZWQ7IC8vIGRvbid0IGhhbmRsZVxuXG4gIGNoZWNrKG9wdGlvbnMsIHtcbiAgICB1c2VyOiB1c2VyUXVlcnlWYWxpZGF0b3IsXG4gICAgcGFzc3dvcmQ6IHBhc3N3b3JkVmFsaWRhdG9yXG4gIH0pO1xuXG5cbiAgY29uc3QgdXNlciA9IEFjY291bnRzLl9maW5kVXNlckJ5UXVlcnkob3B0aW9ucy51c2VyKTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGlmICghdXNlci5zZXJ2aWNlcyB8fCAhdXNlci5zZXJ2aWNlcy5wYXNzd29yZCB8fFxuICAgICAgISh1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCB8fCB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLnNycCkpIHtcbiAgICBoYW5kbGVFcnJvcihcIlVzZXIgaGFzIG5vIHBhc3N3b3JkIHNldFwiKTtcbiAgfVxuXG4gIGlmICghdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQpIHtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMucGFzc3dvcmQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIC8vIFRoZSBjbGllbnQgaGFzIHByZXNlbnRlZCBhIHBsYWludGV4dCBwYXNzd29yZCwgYW5kIHRoZSB1c2VyIGlzXG4gICAgICAvLyBub3QgdXBncmFkZWQgdG8gYmNyeXB0IHlldC4gV2UgZG9uJ3QgYXR0ZW1wdCB0byB0ZWxsIHRoZSBjbGllbnRcbiAgICAgIC8vIHRvIHVwZ3JhZGUgdG8gYmNyeXB0LCBiZWNhdXNlIGl0IG1pZ2h0IGJlIGEgc3RhbmRhbG9uZSBERFBcbiAgICAgIC8vIGNsaWVudCBkb2Vzbid0IGtub3cgaG93IHRvIGRvIHN1Y2ggYSB0aGluZy5cbiAgICAgIGNvbnN0IHZlcmlmaWVyID0gdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnA7XG4gICAgICBjb25zdCBuZXdWZXJpZmllciA9IFNSUC5nZW5lcmF0ZVZlcmlmaWVyKG9wdGlvbnMucGFzc3dvcmQsIHtcbiAgICAgICAgaWRlbnRpdHk6IHZlcmlmaWVyLmlkZW50aXR5LCBzYWx0OiB2ZXJpZmllci5zYWx0fSk7XG5cbiAgICAgIGlmICh2ZXJpZmllci52ZXJpZmllciAhPT0gbmV3VmVyaWZpZXIudmVyaWZpZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1c2VySWQ6IEFjY291bnRzLl9vcHRpb25zLmFtYmlndW91c0Vycm9yTWVzc2FnZXMgPyBudWxsIDogdXNlci5faWQsXG4gICAgICAgICAgZXJyb3I6IGhhbmRsZUVycm9yKFwiSW5jb3JyZWN0IHBhc3N3b3JkXCIsIGZhbHNlKVxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4ge3VzZXJJZDogdXNlci5faWR9O1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBUZWxsIHRoZSBjbGllbnQgdG8gdXNlIHRoZSBTUlAgdXBncmFkZSBwcm9jZXNzLlxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsIFwib2xkIHBhc3N3b3JkIGZvcm1hdFwiLCBFSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBmb3JtYXQ6ICdzcnAnLFxuICAgICAgICBpZGVudGl0eTogdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnAuaWRlbnRpdHlcbiAgICAgIH0pKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gY2hlY2tQYXNzd29yZChcbiAgICB1c2VyLFxuICAgIG9wdGlvbnMucGFzc3dvcmRcbiAgKTtcbn0pO1xuXG4vLyBIYW5kbGVyIHRvIGxvZ2luIHVzaW5nIHRoZSBTUlAgdXBncmFkZSBwYXRoLiBUbyB1c2UgdGhpcyBsb2dpblxuLy8gaGFuZGxlciwgdGhlIGNsaWVudCBtdXN0IHByb3ZpZGU6XG4vLyAgIC0gc3JwOiBIKGlkZW50aXR5ICsgXCI6XCIgKyBwYXNzd29yZClcbi8vICAgLSBwYXNzd29yZDogYSBzdHJpbmcgb3IgYW4gb2JqZWN0IHdpdGggcHJvcGVydGllcyAnZGlnZXN0JyBhbmQgJ2FsZ29yaXRobSdcbi8vXG4vLyBXZSB1c2UgYG9wdGlvbnMuc3JwYCB0byB2ZXJpZnkgdGhhdCB0aGUgY2xpZW50IGtub3dzIHRoZSBjb3JyZWN0XG4vLyBwYXNzd29yZCB3aXRob3V0IGRvaW5nIGEgZnVsbCBTUlAgZmxvdy4gT25jZSB3ZSd2ZSBjaGVja2VkIHRoYXQsIHdlXG4vLyB1cGdyYWRlIHRoZSB1c2VyIHRvIGJjcnlwdCBhbmQgcmVtb3ZlIHRoZSBTUlAgaW5mb3JtYXRpb24gZnJvbSB0aGVcbi8vIHVzZXIgZG9jdW1lbnQuXG4vL1xuLy8gVGhlIGNsaWVudCBlbmRzIHVwIHVzaW5nIHRoaXMgbG9naW4gaGFuZGxlciBhZnRlciB0cnlpbmcgdGhlIG5vcm1hbFxuLy8gbG9naW4gaGFuZGxlciAoYWJvdmUpLCB3aGljaCB0aHJvd3MgYW4gZXJyb3IgdGVsbGluZyB0aGUgY2xpZW50IHRvXG4vLyB0cnkgdGhlIFNSUCB1cGdyYWRlIHBhdGguXG4vL1xuLy8gWFhYIENPTVBBVCBXSVRIIDAuOC4xLjNcbkFjY291bnRzLnJlZ2lzdGVyTG9naW5IYW5kbGVyKFwicGFzc3dvcmRcIiwgb3B0aW9ucyA9PiB7XG4gIGlmICghb3B0aW9ucy5zcnAgfHwgIW9wdGlvbnMucGFzc3dvcmQpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkOyAvLyBkb24ndCBoYW5kbGVcbiAgfVxuXG4gIGNoZWNrKG9wdGlvbnMsIHtcbiAgICB1c2VyOiB1c2VyUXVlcnlWYWxpZGF0b3IsXG4gICAgc3JwOiBTdHJpbmcsXG4gICAgcGFzc3dvcmQ6IHBhc3N3b3JkVmFsaWRhdG9yXG4gIH0pO1xuXG4gIGNvbnN0IHVzZXIgPSBBY2NvdW50cy5fZmluZFVzZXJCeVF1ZXJ5KG9wdGlvbnMudXNlcik7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiVXNlciBub3QgZm91bmRcIik7XG4gIH1cblxuICAvLyBDaGVjayB0byBzZWUgaWYgYW5vdGhlciBzaW11bHRhbmVvdXMgbG9naW4gaGFzIGFscmVhZHkgdXBncmFkZWRcbiAgLy8gdGhlIHVzZXIgcmVjb3JkIHRvIGJjcnlwdC5cbiAgaWYgKHVzZXIuc2VydmljZXMgJiYgdXNlci5zZXJ2aWNlcy5wYXNzd29yZCAmJiB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCkge1xuICAgIHJldHVybiBjaGVja1Bhc3N3b3JkKHVzZXIsIG9wdGlvbnMucGFzc3dvcmQpO1xuICB9XG5cbiAgaWYgKCEodXNlci5zZXJ2aWNlcyAmJiB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkICYmIHVzZXIuc2VydmljZXMucGFzc3dvcmQuc3JwKSkge1xuICAgIGhhbmRsZUVycm9yKFwiVXNlciBoYXMgbm8gcGFzc3dvcmQgc2V0XCIpO1xuICB9XG5cbiAgY29uc3QgdjEgPSB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLnNycC52ZXJpZmllcjtcbiAgY29uc3QgdjIgPSBTUlAuZ2VuZXJhdGVWZXJpZmllcihcbiAgICBudWxsLFxuICAgIHtcbiAgICAgIGhhc2hlZElkZW50aXR5QW5kUGFzc3dvcmQ6IG9wdGlvbnMuc3JwLFxuICAgICAgc2FsdDogdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnAuc2FsdFxuICAgIH1cbiAgKS52ZXJpZmllcjtcbiAgaWYgKHYxICE9PSB2Mikge1xuICAgIHJldHVybiB7XG4gICAgICB1c2VySWQ6IEFjY291bnRzLl9vcHRpb25zLmFtYmlndW91c0Vycm9yTWVzc2FnZXMgPyBudWxsIDogdXNlci5faWQsXG4gICAgICBlcnJvcjogaGFuZGxlRXJyb3IoXCJJbmNvcnJlY3QgcGFzc3dvcmRcIiwgZmFsc2UpXG4gICAgfTtcbiAgfVxuXG4gIC8vIFVwZ3JhZGUgdG8gYmNyeXB0IG9uIHN1Y2Nlc3NmdWwgbG9naW4uXG4gIGNvbnN0IHNhbHRlZCA9IGhhc2hQYXNzd29yZChvcHRpb25zLnBhc3N3b3JkKTtcbiAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICB1c2VyLl9pZCxcbiAgICB7XG4gICAgICAkdW5zZXQ6IHsgJ3NlcnZpY2VzLnBhc3N3b3JkLnNycCc6IDEgfSxcbiAgICAgICRzZXQ6IHsgJ3NlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCc6IHNhbHRlZCB9XG4gICAgfVxuICApO1xuXG4gIHJldHVybiB7dXNlcklkOiB1c2VyLl9pZH07XG59KTtcblxuXG4vLy9cbi8vLyBDSEFOR0lOR1xuLy8vXG5cbi8qKlxuICogQHN1bW1hcnkgQ2hhbmdlIGEgdXNlcidzIHVzZXJuYW1lLiBVc2UgdGhpcyBpbnN0ZWFkIG9mIHVwZGF0aW5nIHRoZVxuICogZGF0YWJhc2UgZGlyZWN0bHkuIFRoZSBvcGVyYXRpb24gd2lsbCBmYWlsIGlmIHRoZXJlIGlzIGFuIGV4aXN0aW5nIHVzZXJcbiAqIHdpdGggYSB1c2VybmFtZSBvbmx5IGRpZmZlcmluZyBpbiBjYXNlLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgSUQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IG5ld1VzZXJuYW1lIEEgbmV3IHVzZXJuYW1lIGZvciB0aGUgdXNlci5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNldFVzZXJuYW1lID0gKHVzZXJJZCwgbmV3VXNlcm5hbWUpID0+IHtcbiAgY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG4gIGNoZWNrKG5ld1VzZXJuYW1lLCBOb25FbXB0eVN0cmluZyk7XG5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCk7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiVXNlciBub3QgZm91bmRcIik7XG4gIH1cblxuICBjb25zdCBvbGRVc2VybmFtZSA9IHVzZXIudXNlcm5hbWU7XG5cbiAgLy8gUGVyZm9ybSBhIGNhc2UgaW5zZW5zaXRpdmUgY2hlY2sgZm9yIGR1cGxpY2F0ZXMgYmVmb3JlIHVwZGF0ZVxuICBjaGVja0ZvckNhc2VJbnNlbnNpdGl2ZUR1cGxpY2F0ZXMoJ3VzZXJuYW1lJywgJ1VzZXJuYW1lJywgbmV3VXNlcm5hbWUsIHVzZXIuX2lkKTtcblxuICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXIuX2lkfSwgeyRzZXQ6IHt1c2VybmFtZTogbmV3VXNlcm5hbWV9fSk7XG5cbiAgLy8gUGVyZm9ybSBhbm90aGVyIGNoZWNrIGFmdGVyIHVwZGF0ZSwgaW4gY2FzZSBhIG1hdGNoaW5nIHVzZXIgaGFzIGJlZW5cbiAgLy8gaW5zZXJ0ZWQgaW4gdGhlIG1lYW50aW1lXG4gIHRyeSB7XG4gICAgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzKCd1c2VybmFtZScsICdVc2VybmFtZScsIG5ld1VzZXJuYW1lLCB1c2VyLl9pZCk7XG4gIH0gY2F0Y2ggKGV4KSB7XG4gICAgLy8gVW5kbyB1cGRhdGUgaWYgdGhlIGNoZWNrIGZhaWxzXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiB1c2VyLl9pZH0sIHskc2V0OiB7dXNlcm5hbWU6IG9sZFVzZXJuYW1lfX0pO1xuICAgIHRocm93IGV4O1xuICB9XG59O1xuXG4vLyBMZXQgdGhlIHVzZXIgY2hhbmdlIHRoZWlyIG93biBwYXNzd29yZCBpZiB0aGV5IGtub3cgdGhlIG9sZFxuLy8gcGFzc3dvcmQuIGBvbGRQYXNzd29yZGAgYW5kIGBuZXdQYXNzd29yZGAgc2hvdWxkIGJlIG9iamVjdHMgd2l0aCBrZXlzXG4vLyBgZGlnZXN0YCBhbmQgYGFsZ29yaXRobWAgKHJlcHJlc2VudGluZyB0aGUgU0hBMjU2IG9mIHRoZSBwYXNzd29yZCkuXG4vL1xuLy8gWFhYIENPTVBBVCBXSVRIIDAuOC4xLjNcbi8vIExpa2UgdGhlIGxvZ2luIG1ldGhvZCwgaWYgdGhlIHVzZXIgaGFzbid0IGJlZW4gdXBncmFkZWQgZnJvbSBTUlAgdG9cbi8vIGJjcnlwdCB5ZXQsIHRoZW4gdGhpcyBtZXRob2Qgd2lsbCB0aHJvdyBhbiAnb2xkIHBhc3N3b3JkIGZvcm1hdCdcbi8vIGVycm9yLiBUaGUgY2xpZW50IHNob3VsZCBjYWxsIHRoZSBTUlAgdXBncmFkZSBsb2dpbiBoYW5kbGVyIGFuZCB0aGVuXG4vLyByZXRyeSB0aGlzIG1ldGhvZCBhZ2Fpbi5cbi8vXG4vLyBVTkxJS0UgdGhlIGxvZ2luIG1ldGhvZCwgdGhlcmUgaXMgbm8gd2F5IHRvIGF2b2lkIGdldHRpbmcgU1JQIHVwZ3JhZGVcbi8vIGVycm9ycyB0aHJvd24uIFRoZSByZWFzb25pbmcgZm9yIHRoaXMgaXMgdGhhdCBjbGllbnRzIHVzaW5nIHRoaXNcbi8vIG1ldGhvZCBkaXJlY3RseSB3aWxsIG5lZWQgdG8gYmUgdXBkYXRlZCBhbnl3YXkgYmVjYXVzZSB3ZSBubyBsb25nZXJcbi8vIHN1cHBvcnQgdGhlIFNSUCBmbG93IHRoYXQgdGhleSB3b3VsZCBoYXZlIGJlZW4gZG9pbmcgdG8gdXNlIHRoaXNcbi8vIG1ldGhvZCBwcmV2aW91c2x5LlxuTWV0ZW9yLm1ldGhvZHMoe2NoYW5nZVBhc3N3b3JkOiBmdW5jdGlvbiAob2xkUGFzc3dvcmQsIG5ld1Bhc3N3b3JkKSB7XG4gIGNoZWNrKG9sZFBhc3N3b3JkLCBwYXNzd29yZFZhbGlkYXRvcik7XG4gIGNoZWNrKG5ld1Bhc3N3b3JkLCBwYXNzd29yZFZhbGlkYXRvcik7XG5cbiAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAxLCBcIk11c3QgYmUgbG9nZ2VkIGluXCIpO1xuICB9XG5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHRoaXMudXNlcklkKTtcbiAgaWYgKCF1c2VyKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGlmICghdXNlci5zZXJ2aWNlcyB8fCAhdXNlci5zZXJ2aWNlcy5wYXNzd29yZCB8fFxuICAgICAgKCF1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCAmJiAhdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnApKSB7XG4gICAgaGFuZGxlRXJyb3IoXCJVc2VyIGhhcyBubyBwYXNzd29yZCBzZXRcIik7XG4gIH1cblxuICBpZiAoISB1c2VyLnNlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCkge1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBcIm9sZCBwYXNzd29yZCBmb3JtYXRcIiwgRUpTT04uc3RyaW5naWZ5KHtcbiAgICAgIGZvcm1hdDogJ3NycCcsXG4gICAgICBpZGVudGl0eTogdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5zcnAuaWRlbnRpdHlcbiAgICB9KSk7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBjaGVja1Bhc3N3b3JkKHVzZXIsIG9sZFBhc3N3b3JkKTtcbiAgaWYgKHJlc3VsdC5lcnJvcikge1xuICAgIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgfVxuXG4gIGNvbnN0IGhhc2hlZCA9IGhhc2hQYXNzd29yZChuZXdQYXNzd29yZCk7XG5cbiAgLy8gSXQgd291bGQgYmUgYmV0dGVyIGlmIHRoaXMgcmVtb3ZlZCBBTEwgZXhpc3RpbmcgdG9rZW5zIGFuZCByZXBsYWNlZFxuICAvLyB0aGUgdG9rZW4gZm9yIHRoZSBjdXJyZW50IGNvbm5lY3Rpb24gd2l0aCBhIG5ldyBvbmUsIGJ1dCB0aGF0IHdvdWxkXG4gIC8vIGJlIHRyaWNreSwgc28gd2UnbGwgc2V0dGxlIGZvciBqdXN0IHJlcGxhY2luZyBhbGwgdG9rZW5zIG90aGVyIHRoYW5cbiAgLy8gdGhlIG9uZSBmb3IgdGhlIGN1cnJlbnQgY29ubmVjdGlvbi5cbiAgY29uc3QgY3VycmVudFRva2VuID0gQWNjb3VudHMuX2dldExvZ2luVG9rZW4odGhpcy5jb25uZWN0aW9uLmlkKTtcbiAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICB7IF9pZDogdGhpcy51c2VySWQgfSxcbiAgICB7XG4gICAgICAkc2V0OiB7ICdzZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQnOiBoYXNoZWQgfSxcbiAgICAgICRwdWxsOiB7XG4gICAgICAgICdzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMnOiB7IGhhc2hlZFRva2VuOiB7ICRuZTogY3VycmVudFRva2VuIH0gfVxuICAgICAgfSxcbiAgICAgICR1bnNldDogeyAnc2VydmljZXMucGFzc3dvcmQucmVzZXQnOiAxIH1cbiAgICB9XG4gICk7XG5cbiAgcmV0dXJuIHtwYXNzd29yZENoYW5nZWQ6IHRydWV9O1xufX0pO1xuXG5cbi8vIEZvcmNlIGNoYW5nZSB0aGUgdXNlcnMgcGFzc3dvcmQuXG5cbi8qKlxuICogQHN1bW1hcnkgRm9yY2libHkgY2hhbmdlIHRoZSBwYXNzd29yZCBmb3IgYSB1c2VyLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgaWQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IG5ld1Bhc3N3b3JkIEEgbmV3IHBhc3N3b3JkIGZvciB0aGUgdXNlci5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zLmxvZ291dCBMb2dvdXQgYWxsIGN1cnJlbnQgY29ubmVjdGlvbnMgd2l0aCB0aGlzIHVzZXJJZCAoZGVmYXVsdDogdHJ1ZSlcbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNldFBhc3N3b3JkID0gKHVzZXJJZCwgbmV3UGxhaW50ZXh0UGFzc3dvcmQsIG9wdGlvbnMpID0+IHtcbiAgb3B0aW9ucyA9IHsgbG9nb3V0OiB0cnVlICwgLi4ub3B0aW9ucyB9O1xuXG4gIGNvbnN0IHVzZXIgPSBnZXRVc2VyQnlJZCh1c2VySWQpO1xuICBpZiAoIXVzZXIpIHtcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGNvbnN0IHVwZGF0ZSA9IHtcbiAgICAkdW5zZXQ6IHtcbiAgICAgICdzZXJ2aWNlcy5wYXNzd29yZC5zcnAnOiAxLCAvLyBYWFggQ09NUEFUIFdJVEggMC44LjEuM1xuICAgICAgJ3NlcnZpY2VzLnBhc3N3b3JkLnJlc2V0JzogMVxuICAgIH0sXG4gICAgJHNldDogeydzZXJ2aWNlcy5wYXNzd29yZC5iY3J5cHQnOiBoYXNoUGFzc3dvcmQobmV3UGxhaW50ZXh0UGFzc3dvcmQpfVxuICB9O1xuXG4gIGlmIChvcHRpb25zLmxvZ291dCkge1xuICAgIHVwZGF0ZS4kdW5zZXRbJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2VucyddID0gMTtcbiAgfVxuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB1cGRhdGUpO1xufTtcblxuXG4vLy9cbi8vLyBSRVNFVFRJTkcgVklBIEVNQUlMXG4vLy9cblxuLy8gVXRpbGl0eSBmb3IgcGx1Y2tpbmcgYWRkcmVzc2VzIGZyb20gZW1haWxzXG5jb25zdCBwbHVja0FkZHJlc3NlcyA9IChlbWFpbHMgPSBbXSkgPT4gZW1haWxzLm1hcChlbWFpbCA9PiBlbWFpbC5hZGRyZXNzKTtcblxuLy8gTWV0aG9kIGNhbGxlZCBieSBhIHVzZXIgdG8gcmVxdWVzdCBhIHBhc3N3b3JkIHJlc2V0IGVtYWlsLiBUaGlzIGlzXG4vLyB0aGUgc3RhcnQgb2YgdGhlIHJlc2V0IHByb2Nlc3MuXG5NZXRlb3IubWV0aG9kcyh7Zm9yZ290UGFzc3dvcmQ6IG9wdGlvbnMgPT4ge1xuICBjaGVjayhvcHRpb25zLCB7ZW1haWw6IFN0cmluZ30pO1xuXG4gIGNvbnN0IHVzZXIgPSBBY2NvdW50cy5maW5kVXNlckJ5RW1haWwob3B0aW9ucy5lbWFpbCk7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiVXNlciBub3QgZm91bmRcIik7XG4gIH1cblxuICBjb25zdCBlbWFpbHMgPSBwbHVja0FkZHJlc3Nlcyh1c2VyLmVtYWlscyk7XG4gIGNvbnN0IGNhc2VTZW5zaXRpdmVFbWFpbCA9IGVtYWlscy5maW5kKFxuICAgIGVtYWlsID0+IGVtYWlsLnRvTG93ZXJDYXNlKCkgPT09IG9wdGlvbnMuZW1haWwudG9Mb3dlckNhc2UoKVxuICApO1xuXG4gIEFjY291bnRzLnNlbmRSZXNldFBhc3N3b3JkRW1haWwodXNlci5faWQsIGNhc2VTZW5zaXRpdmVFbWFpbCk7XG59fSk7XG5cbi8qKlxuICogQHN1bW1hcnkgR2VuZXJhdGVzIGEgcmVzZXQgdG9rZW4gYW5kIHNhdmVzIGl0IGludG8gdGhlIGRhdGFiYXNlLlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgaWQgb2YgdGhlIHVzZXIgdG8gZ2VuZXJhdGUgdGhlIHJlc2V0IHRva2VuIGZvci5cbiAqIEBwYXJhbSB7U3RyaW5nfSBlbWFpbCBXaGljaCBhZGRyZXNzIG9mIHRoZSB1c2VyIHRvIGdlbmVyYXRlIHRoZSByZXNldCB0b2tlbiBmb3IuIFRoaXMgYWRkcmVzcyBtdXN0IGJlIGluIHRoZSB1c2VyJ3MgYGVtYWlsc2AgbGlzdC4gSWYgYG51bGxgLCBkZWZhdWx0cyB0byB0aGUgZmlyc3QgZW1haWwgaW4gdGhlIGxpc3QuXG4gKiBAcGFyYW0ge1N0cmluZ30gcmVhc29uIGByZXNldFBhc3N3b3JkYCBvciBgZW5yb2xsQWNjb3VudGAuXG4gKiBAcGFyYW0ge09iamVjdH0gW2V4dHJhVG9rZW5EYXRhXSBPcHRpb25hbCBhZGRpdGlvbmFsIGRhdGEgdG8gYmUgYWRkZWQgaW50byB0aGUgdG9rZW4gcmVjb3JkLlxuICogQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGgge2VtYWlsLCB1c2VyLCB0b2tlbn0gdmFsdWVzLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuZ2VuZXJhdGVSZXNldFRva2VuID0gKHVzZXJJZCwgZW1haWwsIHJlYXNvbiwgZXh0cmFUb2tlbkRhdGEpID0+IHtcbiAgLy8gTWFrZSBzdXJlIHRoZSB1c2VyIGV4aXN0cywgYW5kIGVtYWlsIGlzIG9uZSBvZiB0aGVpciBhZGRyZXNzZXMuXG4gIGNvbnN0IHVzZXIgPSBnZXRVc2VyQnlJZCh1c2VySWQpO1xuICBpZiAoIXVzZXIpIHtcbiAgICBoYW5kbGVFcnJvcihcIkNhbid0IGZpbmQgdXNlclwiKTtcbiAgfVxuXG4gIC8vIHBpY2sgdGhlIGZpcnN0IGVtYWlsIGlmIHdlIHdlcmVuJ3QgcGFzc2VkIGFuIGVtYWlsLlxuICBpZiAoIWVtYWlsICYmIHVzZXIuZW1haWxzICYmIHVzZXIuZW1haWxzWzBdKSB7XG4gICAgZW1haWwgPSB1c2VyLmVtYWlsc1swXS5hZGRyZXNzO1xuICB9XG5cbiAgLy8gbWFrZSBzdXJlIHdlIGhhdmUgYSB2YWxpZCBlbWFpbFxuICBpZiAoIWVtYWlsIHx8IFxuICAgICEocGx1Y2tBZGRyZXNzZXModXNlci5lbWFpbHMpLmluY2x1ZGVzKGVtYWlsKSkpIHtcbiAgICBoYW5kbGVFcnJvcihcIk5vIHN1Y2ggZW1haWwgZm9yIHVzZXIuXCIpO1xuICB9XG5cbiAgY29uc3QgdG9rZW4gPSBSYW5kb20uc2VjcmV0KCk7XG4gIGNvbnN0IHRva2VuUmVjb3JkID0ge1xuICAgIHRva2VuLFxuICAgIGVtYWlsLFxuICAgIHdoZW46IG5ldyBEYXRlKClcbiAgfTtcblxuICBpZiAocmVhc29uID09PSAncmVzZXRQYXNzd29yZCcpIHtcbiAgICB0b2tlblJlY29yZC5yZWFzb24gPSAncmVzZXQnO1xuICB9IGVsc2UgaWYgKHJlYXNvbiA9PT0gJ2Vucm9sbEFjY291bnQnKSB7XG4gICAgdG9rZW5SZWNvcmQucmVhc29uID0gJ2Vucm9sbCc7XG4gIH0gZWxzZSBpZiAocmVhc29uKSB7XG4gICAgLy8gZmFsbGJhY2sgc28gdGhhdCB0aGlzIGZ1bmN0aW9uIGNhbiBiZSB1c2VkIGZvciB1bmtub3duIHJlYXNvbnMgYXMgd2VsbFxuICAgIHRva2VuUmVjb3JkLnJlYXNvbiA9IHJlYXNvbjtcbiAgfVxuXG4gIGlmIChleHRyYVRva2VuRGF0YSkge1xuICAgIE9iamVjdC5hc3NpZ24odG9rZW5SZWNvcmQsIGV4dHJhVG9rZW5EYXRhKTtcbiAgfVxuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LCB7JHNldDoge1xuICAgICdzZXJ2aWNlcy5wYXNzd29yZC5yZXNldCc6IHRva2VuUmVjb3JkXG4gIH19KTtcblxuICAvLyBiZWZvcmUgcGFzc2luZyB0byB0ZW1wbGF0ZSwgdXBkYXRlIHVzZXIgb2JqZWN0IHdpdGggbmV3IHRva2VuXG4gIE1ldGVvci5fZW5zdXJlKHVzZXIsICdzZXJ2aWNlcycsICdwYXNzd29yZCcpLnJlc2V0ID0gdG9rZW5SZWNvcmQ7XG5cbiAgcmV0dXJuIHtlbWFpbCwgdXNlciwgdG9rZW59O1xufTtcblxuLyoqXG4gKiBAc3VtbWFyeSBHZW5lcmF0ZXMgYW4gZS1tYWlsIHZlcmlmaWNhdGlvbiB0b2tlbiBhbmQgc2F2ZXMgaXQgaW50byB0aGUgZGF0YWJhc2UuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge1N0cmluZ30gdXNlcklkIFRoZSBpZCBvZiB0aGUgdXNlciB0byBnZW5lcmF0ZSB0aGUgIGUtbWFpbCB2ZXJpZmljYXRpb24gdG9rZW4gZm9yLlxuICogQHBhcmFtIHtTdHJpbmd9IGVtYWlsIFdoaWNoIGFkZHJlc3Mgb2YgdGhlIHVzZXIgdG8gZ2VuZXJhdGUgdGhlIGUtbWFpbCB2ZXJpZmljYXRpb24gdG9rZW4gZm9yLiBUaGlzIGFkZHJlc3MgbXVzdCBiZSBpbiB0aGUgdXNlcidzIGBlbWFpbHNgIGxpc3QuIElmIGBudWxsYCwgZGVmYXVsdHMgdG8gdGhlIGZpcnN0IHVudmVyaWZpZWQgZW1haWwgaW4gdGhlIGxpc3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW2V4dHJhVG9rZW5EYXRhXSBPcHRpb25hbCBhZGRpdGlvbmFsIGRhdGEgdG8gYmUgYWRkZWQgaW50byB0aGUgdG9rZW4gcmVjb3JkLlxuICogQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGgge2VtYWlsLCB1c2VyLCB0b2tlbn0gdmFsdWVzLlxuICogQGltcG9ydEZyb21QYWNrYWdlIGFjY291bnRzLWJhc2VcbiAqL1xuQWNjb3VudHMuZ2VuZXJhdGVWZXJpZmljYXRpb25Ub2tlbiA9ICh1c2VySWQsIGVtYWlsLCBleHRyYVRva2VuRGF0YSkgPT4ge1xuICAvLyBNYWtlIHN1cmUgdGhlIHVzZXIgZXhpc3RzLCBhbmQgZW1haWwgaXMgb25lIG9mIHRoZWlyIGFkZHJlc3Nlcy5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCk7XG4gIGlmICghdXNlcikge1xuICAgIGhhbmRsZUVycm9yKFwiQ2FuJ3QgZmluZCB1c2VyXCIpO1xuICB9XG5cbiAgLy8gcGljayB0aGUgZmlyc3QgdW52ZXJpZmllZCBlbWFpbCBpZiB3ZSB3ZXJlbid0IHBhc3NlZCBhbiBlbWFpbC5cbiAgaWYgKCFlbWFpbCkge1xuICAgIGNvbnN0IGVtYWlsUmVjb3JkID0gKHVzZXIuZW1haWxzIHx8IFtdKS5maW5kKGUgPT4gIWUudmVyaWZpZWQpO1xuICAgIGVtYWlsID0gKGVtYWlsUmVjb3JkIHx8IHt9KS5hZGRyZXNzO1xuXG4gICAgaWYgKCFlbWFpbCkge1xuICAgICAgaGFuZGxlRXJyb3IoXCJUaGF0IHVzZXIgaGFzIG5vIHVudmVyaWZpZWQgZW1haWwgYWRkcmVzc2VzLlwiKTtcbiAgICB9XG4gIH1cblxuICAvLyBtYWtlIHN1cmUgd2UgaGF2ZSBhIHZhbGlkIGVtYWlsXG4gIGlmICghZW1haWwgfHwgXG4gICAgIShwbHVja0FkZHJlc3Nlcyh1c2VyLmVtYWlscykuaW5jbHVkZXMoZW1haWwpKSkge1xuICAgIGhhbmRsZUVycm9yKFwiTm8gc3VjaCBlbWFpbCBmb3IgdXNlci5cIik7XG4gIH1cblxuICBjb25zdCB0b2tlbiA9IFJhbmRvbS5zZWNyZXQoKTtcbiAgY29uc3QgdG9rZW5SZWNvcmQgPSB7XG4gICAgdG9rZW4sXG4gICAgLy8gVE9ETzogVGhpcyBzaG91bGQgcHJvYmFibHkgYmUgcmVuYW1lZCB0byBcImVtYWlsXCIgdG8gbWF0Y2ggcmVzZXQgdG9rZW4gcmVjb3JkLlxuICAgIGFkZHJlc3M6IGVtYWlsLFxuICAgIHdoZW46IG5ldyBEYXRlKClcbiAgfTtcblxuICBpZiAoZXh0cmFUb2tlbkRhdGEpIHtcbiAgICBPYmplY3QuYXNzaWduKHRva2VuUmVjb3JkLCBleHRyYVRva2VuRGF0YSk7XG4gIH1cblxuICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXIuX2lkfSwgeyRwdXNoOiB7XG4gICAgJ3NlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2Vucyc6IHRva2VuUmVjb3JkXG4gIH19KTtcblxuICAvLyBiZWZvcmUgcGFzc2luZyB0byB0ZW1wbGF0ZSwgdXBkYXRlIHVzZXIgb2JqZWN0IHdpdGggbmV3IHRva2VuXG4gIE1ldGVvci5fZW5zdXJlKHVzZXIsICdzZXJ2aWNlcycsICdlbWFpbCcpO1xuICBpZiAoIXVzZXIuc2VydmljZXMuZW1haWwudmVyaWZpY2F0aW9uVG9rZW5zKSB7XG4gICAgdXNlci5zZXJ2aWNlcy5lbWFpbC52ZXJpZmljYXRpb25Ub2tlbnMgPSBbXTtcbiAgfVxuICB1c2VyLnNlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2Vucy5wdXNoKHRva2VuUmVjb3JkKTtcblxuICByZXR1cm4ge2VtYWlsLCB1c2VyLCB0b2tlbn07XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IENyZWF0ZXMgb3B0aW9ucyBmb3IgZW1haWwgc2VuZGluZyBmb3IgcmVzZXQgcGFzc3dvcmQgYW5kIGVucm9sbCBhY2NvdW50IGVtYWlscy5cbiAqIFlvdSBjYW4gdXNlIHRoaXMgZnVuY3Rpb24gd2hlbiBjdXN0b21pemluZyBhIHJlc2V0IHBhc3N3b3JkIG9yIGVucm9sbCBhY2NvdW50IGVtYWlsIHNlbmRpbmcuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge09iamVjdH0gZW1haWwgV2hpY2ggYWRkcmVzcyBvZiB0aGUgdXNlcidzIHRvIHNlbmQgdGhlIGVtYWlsIHRvLlxuICogQHBhcmFtIHtPYmplY3R9IHVzZXIgVGhlIHVzZXIgb2JqZWN0IHRvIGdlbmVyYXRlIG9wdGlvbnMgZm9yLlxuICogQHBhcmFtIHtTdHJpbmd9IHVybCBVUkwgdG8gd2hpY2ggdXNlciBpcyBkaXJlY3RlZCB0byBjb25maXJtIHRoZSBlbWFpbC5cbiAqIEBwYXJhbSB7U3RyaW5nfSByZWFzb24gYHJlc2V0UGFzc3dvcmRgIG9yIGBlbnJvbGxBY2NvdW50YC5cbiAqIEByZXR1cm5zIHtPYmplY3R9IE9wdGlvbnMgd2hpY2ggY2FuIGJlIHBhc3NlZCB0byBgRW1haWwuc2VuZGAuXG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgYWNjb3VudHMtYmFzZVxuICovXG5BY2NvdW50cy5nZW5lcmF0ZU9wdGlvbnNGb3JFbWFpbCA9IChlbWFpbCwgdXNlciwgdXJsLCByZWFzb24pID0+IHtcbiAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICB0bzogZW1haWwsXG4gICAgZnJvbTogQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS5mcm9tXG4gICAgICA/IEFjY291bnRzLmVtYWlsVGVtcGxhdGVzW3JlYXNvbl0uZnJvbSh1c2VyKVxuICAgICAgOiBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5mcm9tLFxuICAgIHN1YmplY3Q6IEFjY291bnRzLmVtYWlsVGVtcGxhdGVzW3JlYXNvbl0uc3ViamVjdCh1c2VyKVxuICB9O1xuXG4gIGlmICh0eXBlb2YgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS50ZXh0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgb3B0aW9ucy50ZXh0ID0gQWNjb3VudHMuZW1haWxUZW1wbGF0ZXNbcmVhc29uXS50ZXh0KHVzZXIsIHVybCk7XG4gIH1cblxuICBpZiAodHlwZW9mIEFjY291bnRzLmVtYWlsVGVtcGxhdGVzW3JlYXNvbl0uaHRtbCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIG9wdGlvbnMuaHRtbCA9IEFjY291bnRzLmVtYWlsVGVtcGxhdGVzW3JlYXNvbl0uaHRtbCh1c2VyLCB1cmwpO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5oZWFkZXJzID09PSAnb2JqZWN0Jykge1xuICAgIG9wdGlvbnMuaGVhZGVycyA9IEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmhlYWRlcnM7XG4gIH1cblxuICByZXR1cm4gb3B0aW9ucztcbn07XG5cbi8vIHNlbmQgdGhlIHVzZXIgYW4gZW1haWwgd2l0aCBhIGxpbmsgdGhhdCB3aGVuIG9wZW5lZCBhbGxvd3MgdGhlIHVzZXJcbi8vIHRvIHNldCBhIG5ldyBwYXNzd29yZCwgd2l0aG91dCB0aGUgb2xkIHBhc3N3b3JkLlxuXG4vKipcbiAqIEBzdW1tYXJ5IFNlbmQgYW4gZW1haWwgd2l0aCBhIGxpbmsgdGhlIHVzZXIgY2FuIHVzZSB0byByZXNldCB0aGVpciBwYXNzd29yZC5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7U3RyaW5nfSB1c2VySWQgVGhlIGlkIG9mIHRoZSB1c2VyIHRvIHNlbmQgZW1haWwgdG8uXG4gKiBAcGFyYW0ge1N0cmluZ30gW2VtYWlsXSBPcHRpb25hbC4gV2hpY2ggYWRkcmVzcyBvZiB0aGUgdXNlcidzIHRvIHNlbmQgdGhlIGVtYWlsIHRvLiBUaGlzIGFkZHJlc3MgbXVzdCBiZSBpbiB0aGUgdXNlcidzIGBlbWFpbHNgIGxpc3QuIERlZmF1bHRzIHRvIHRoZSBmaXJzdCBlbWFpbCBpbiB0aGUgbGlzdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbZXh0cmFUb2tlbkRhdGFdIE9wdGlvbmFsIGFkZGl0aW9uYWwgZGF0YSB0byBiZSBhZGRlZCBpbnRvIHRoZSB0b2tlbiByZWNvcmQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3Qgd2l0aCB7ZW1haWwsIHVzZXIsIHRva2VuLCB1cmwsIG9wdGlvbnN9IHZhbHVlcy5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNlbmRSZXNldFBhc3N3b3JkRW1haWwgPSAodXNlcklkLCBlbWFpbCwgZXh0cmFUb2tlbkRhdGEpID0+IHtcbiAgY29uc3Qge2VtYWlsOiByZWFsRW1haWwsIHVzZXIsIHRva2VufSA9XG4gICAgQWNjb3VudHMuZ2VuZXJhdGVSZXNldFRva2VuKHVzZXJJZCwgZW1haWwsICdyZXNldFBhc3N3b3JkJywgZXh0cmFUb2tlbkRhdGEpO1xuICBjb25zdCB1cmwgPSBBY2NvdW50cy51cmxzLnJlc2V0UGFzc3dvcmQodG9rZW4pO1xuICBjb25zdCBvcHRpb25zID0gQWNjb3VudHMuZ2VuZXJhdGVPcHRpb25zRm9yRW1haWwocmVhbEVtYWlsLCB1c2VyLCB1cmwsICdyZXNldFBhc3N3b3JkJyk7XG4gIEVtYWlsLnNlbmQob3B0aW9ucyk7XG4gIHJldHVybiB7ZW1haWw6IHJlYWxFbWFpbCwgdXNlciwgdG9rZW4sIHVybCwgb3B0aW9uc307XG59O1xuXG4vLyBzZW5kIHRoZSB1c2VyIGFuIGVtYWlsIGluZm9ybWluZyB0aGVtIHRoYXQgdGhlaXIgYWNjb3VudCB3YXMgY3JlYXRlZCwgd2l0aFxuLy8gYSBsaW5rIHRoYXQgd2hlbiBvcGVuZWQgYm90aCBtYXJrcyB0aGVpciBlbWFpbCBhcyB2ZXJpZmllZCBhbmQgZm9yY2VzIHRoZW1cbi8vIHRvIGNob29zZSB0aGVpciBwYXNzd29yZC4gVGhlIGVtYWlsIG11c3QgYmUgb25lIG9mIHRoZSBhZGRyZXNzZXMgaW4gdGhlXG4vLyB1c2VyJ3MgZW1haWxzIGZpZWxkLCBvciB1bmRlZmluZWQgdG8gcGljayB0aGUgZmlyc3QgZW1haWwgYXV0b21hdGljYWxseS5cbi8vXG4vLyBUaGlzIGlzIG5vdCBjYWxsZWQgYXV0b21hdGljYWxseS4gSXQgbXVzdCBiZSBjYWxsZWQgbWFudWFsbHkgaWYgeW91XG4vLyB3YW50IHRvIHVzZSBlbnJvbGxtZW50IGVtYWlscy5cblxuLyoqXG4gKiBAc3VtbWFyeSBTZW5kIGFuIGVtYWlsIHdpdGggYSBsaW5rIHRoZSB1c2VyIGNhbiB1c2UgdG8gc2V0IHRoZWlyIGluaXRpYWwgcGFzc3dvcmQuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge1N0cmluZ30gdXNlcklkIFRoZSBpZCBvZiB0aGUgdXNlciB0byBzZW5kIGVtYWlsIHRvLlxuICogQHBhcmFtIHtTdHJpbmd9IFtlbWFpbF0gT3B0aW9uYWwuIFdoaWNoIGFkZHJlc3Mgb2YgdGhlIHVzZXIncyB0byBzZW5kIHRoZSBlbWFpbCB0by4gVGhpcyBhZGRyZXNzIG11c3QgYmUgaW4gdGhlIHVzZXIncyBgZW1haWxzYCBsaXN0LiBEZWZhdWx0cyB0byB0aGUgZmlyc3QgZW1haWwgaW4gdGhlIGxpc3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW2V4dHJhVG9rZW5EYXRhXSBPcHRpb25hbCBhZGRpdGlvbmFsIGRhdGEgdG8gYmUgYWRkZWQgaW50byB0aGUgdG9rZW4gcmVjb3JkLlxuICogQHJldHVybnMge09iamVjdH0gT2JqZWN0IHdpdGgge2VtYWlsLCB1c2VyLCB0b2tlbiwgdXJsLCBvcHRpb25zfSB2YWx1ZXMuXG4gKiBAaW1wb3J0RnJvbVBhY2thZ2UgYWNjb3VudHMtYmFzZVxuICovXG5BY2NvdW50cy5zZW5kRW5yb2xsbWVudEVtYWlsID0gKHVzZXJJZCwgZW1haWwsIGV4dHJhVG9rZW5EYXRhKSA9PiB7XG4gIGNvbnN0IHtlbWFpbDogcmVhbEVtYWlsLCB1c2VyLCB0b2tlbn0gPVxuICAgIEFjY291bnRzLmdlbmVyYXRlUmVzZXRUb2tlbih1c2VySWQsIGVtYWlsLCAnZW5yb2xsQWNjb3VudCcsIGV4dHJhVG9rZW5EYXRhKTtcbiAgY29uc3QgdXJsID0gQWNjb3VudHMudXJscy5lbnJvbGxBY2NvdW50KHRva2VuKTtcbiAgY29uc3Qgb3B0aW9ucyA9IEFjY291bnRzLmdlbmVyYXRlT3B0aW9uc0ZvckVtYWlsKHJlYWxFbWFpbCwgdXNlciwgdXJsLCAnZW5yb2xsQWNjb3VudCcpO1xuICBFbWFpbC5zZW5kKG9wdGlvbnMpO1xuICByZXR1cm4ge2VtYWlsOiByZWFsRW1haWwsIHVzZXIsIHRva2VuLCB1cmwsIG9wdGlvbnN9O1xufTtcblxuXG4vLyBUYWtlIHRva2VuIGZyb20gc2VuZFJlc2V0UGFzc3dvcmRFbWFpbCBvciBzZW5kRW5yb2xsbWVudEVtYWlsLCBjaGFuZ2Vcbi8vIHRoZSB1c2VycyBwYXNzd29yZCwgYW5kIGxvZyB0aGVtIGluLlxuTWV0ZW9yLm1ldGhvZHMoe3Jlc2V0UGFzc3dvcmQ6IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gIGNvbnN0IHRva2VuID0gYXJnc1swXTtcbiAgY29uc3QgbmV3UGFzc3dvcmQgPSBhcmdzWzFdO1xuICByZXR1cm4gQWNjb3VudHMuX2xvZ2luTWV0aG9kKFxuICAgIHRoaXMsXG4gICAgXCJyZXNldFBhc3N3b3JkXCIsXG4gICAgYXJncyxcbiAgICBcInBhc3N3b3JkXCIsXG4gICAgKCkgPT4ge1xuICAgICAgY2hlY2sodG9rZW4sIFN0cmluZyk7XG4gICAgICBjaGVjayhuZXdQYXNzd29yZCwgcGFzc3dvcmRWYWxpZGF0b3IpO1xuXG4gICAgICBjb25zdCB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoe1xuICAgICAgICBcInNlcnZpY2VzLnBhc3N3b3JkLnJlc2V0LnRva2VuXCI6IHRva2VufSk7XG4gICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiVG9rZW4gZXhwaXJlZFwiKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgd2hlbiwgcmVhc29uLCBlbWFpbCB9ID0gdXNlci5zZXJ2aWNlcy5wYXNzd29yZC5yZXNldDtcbiAgICAgIGxldCB0b2tlbkxpZmV0aW1lTXMgPSBBY2NvdW50cy5fZ2V0UGFzc3dvcmRSZXNldFRva2VuTGlmZXRpbWVNcygpO1xuICAgICAgaWYgKHJlYXNvbiA9PT0gXCJlbnJvbGxcIikge1xuICAgICAgICB0b2tlbkxpZmV0aW1lTXMgPSBBY2NvdW50cy5fZ2V0UGFzc3dvcmRFbnJvbGxUb2tlbkxpZmV0aW1lTXMoKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN1cnJlbnRUaW1lTXMgPSBEYXRlLm5vdygpO1xuICAgICAgaWYgKChjdXJyZW50VGltZU1zIC0gd2hlbikgPiB0b2tlbkxpZmV0aW1lTXMpXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlRva2VuIGV4cGlyZWRcIik7XG4gICAgICBpZiAoIShwbHVja0FkZHJlc3Nlcyh1c2VyLmVtYWlscykuaW5jbHVkZXMoZW1haWwpKSlcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1c2VySWQ6IHVzZXIuX2lkLFxuICAgICAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJUb2tlbiBoYXMgaW52YWxpZCBlbWFpbCBhZGRyZXNzXCIpXG4gICAgICAgIH07XG5cbiAgICAgIGNvbnN0IGhhc2hlZCA9IGhhc2hQYXNzd29yZChuZXdQYXNzd29yZCk7XG5cbiAgICAgIC8vIE5PVEU6IFdlJ3JlIGFib3V0IHRvIGludmFsaWRhdGUgdG9rZW5zIG9uIHRoZSB1c2VyLCB3aG8gd2UgbWlnaHQgYmVcbiAgICAgIC8vIGxvZ2dlZCBpbiBhcy4gTWFrZSBzdXJlIHRvIGF2b2lkIGxvZ2dpbmcgb3Vyc2VsdmVzIG91dCBpZiB0aGlzXG4gICAgICAvLyBoYXBwZW5zLiBCdXQgYWxzbyBtYWtlIHN1cmUgbm90IHRvIGxlYXZlIHRoZSBjb25uZWN0aW9uIGluIGEgc3RhdGVcbiAgICAgIC8vIG9mIGhhdmluZyBhIGJhZCB0b2tlbiBzZXQgaWYgdGhpbmdzIGZhaWwuXG4gICAgICBjb25zdCBvbGRUb2tlbiA9IEFjY291bnRzLl9nZXRMb2dpblRva2VuKHRoaXMuY29ubmVjdGlvbi5pZCk7XG4gICAgICBBY2NvdW50cy5fc2V0TG9naW5Ub2tlbih1c2VyLl9pZCwgdGhpcy5jb25uZWN0aW9uLCBudWxsKTtcbiAgICAgIGNvbnN0IHJlc2V0VG9PbGRUb2tlbiA9ICgpID0+XG4gICAgICAgIEFjY291bnRzLl9zZXRMb2dpblRva2VuKHVzZXIuX2lkLCB0aGlzLmNvbm5lY3Rpb24sIG9sZFRva2VuKTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gVXBkYXRlIHRoZSB1c2VyIHJlY29yZCBieTpcbiAgICAgICAgLy8gLSBDaGFuZ2luZyB0aGUgcGFzc3dvcmQgdG8gdGhlIG5ldyBvbmVcbiAgICAgICAgLy8gLSBGb3JnZXR0aW5nIGFib3V0IHRoZSByZXNldCB0b2tlbiB0aGF0IHdhcyBqdXN0IHVzZWRcbiAgICAgICAgLy8gLSBWZXJpZnlpbmcgdGhlaXIgZW1haWwsIHNpbmNlIHRoZXkgZ290IHRoZSBwYXNzd29yZCByZXNldCB2aWEgZW1haWwuXG4gICAgICAgIGNvbnN0IGFmZmVjdGVkUmVjb3JkcyA9IE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAge1xuICAgICAgICAgICAgX2lkOiB1c2VyLl9pZCxcbiAgICAgICAgICAgICdlbWFpbHMuYWRkcmVzcyc6IGVtYWlsLFxuICAgICAgICAgICAgJ3NlcnZpY2VzLnBhc3N3b3JkLnJlc2V0LnRva2VuJzogdG9rZW5cbiAgICAgICAgICB9LFxuICAgICAgICAgIHskc2V0OiB7J3NlcnZpY2VzLnBhc3N3b3JkLmJjcnlwdCc6IGhhc2hlZCxcbiAgICAgICAgICAgICAgICAgICdlbWFpbHMuJC52ZXJpZmllZCc6IHRydWV9LFxuICAgICAgICAgICAkdW5zZXQ6IHsnc2VydmljZXMucGFzc3dvcmQucmVzZXQnOiAxLFxuICAgICAgICAgICAgICAgICAgICAnc2VydmljZXMucGFzc3dvcmQuc3JwJzogMX19KTtcbiAgICAgICAgaWYgKGFmZmVjdGVkUmVjb3JkcyAhPT0gMSlcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdXNlcklkOiB1c2VyLl9pZCxcbiAgICAgICAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJJbnZhbGlkIGVtYWlsXCIpXG4gICAgICAgICAgfTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZXNldFRvT2xkVG9rZW4oKTtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuXG4gICAgICAvLyBSZXBsYWNlIGFsbCB2YWxpZCBsb2dpbiB0b2tlbnMgd2l0aCBuZXcgb25lcyAoY2hhbmdpbmdcbiAgICAgIC8vIHBhc3N3b3JkIHNob3VsZCBpbnZhbGlkYXRlIGV4aXN0aW5nIHNlc3Npb25zKS5cbiAgICAgIEFjY291bnRzLl9jbGVhckFsbExvZ2luVG9rZW5zKHVzZXIuX2lkKTtcblxuICAgICAgcmV0dXJuIHt1c2VySWQ6IHVzZXIuX2lkfTtcbiAgICB9XG4gICk7XG59fSk7XG5cbi8vL1xuLy8vIEVNQUlMIFZFUklGSUNBVElPTlxuLy8vXG5cblxuLy8gc2VuZCB0aGUgdXNlciBhbiBlbWFpbCB3aXRoIGEgbGluayB0aGF0IHdoZW4gb3BlbmVkIG1hcmtzIHRoYXRcbi8vIGFkZHJlc3MgYXMgdmVyaWZpZWRcblxuLyoqXG4gKiBAc3VtbWFyeSBTZW5kIGFuIGVtYWlsIHdpdGggYSBsaW5rIHRoZSB1c2VyIGNhbiB1c2UgdmVyaWZ5IHRoZWlyIGVtYWlsIGFkZHJlc3MuXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge1N0cmluZ30gdXNlcklkIFRoZSBpZCBvZiB0aGUgdXNlciB0byBzZW5kIGVtYWlsIHRvLlxuICogQHBhcmFtIHtTdHJpbmd9IFtlbWFpbF0gT3B0aW9uYWwuIFdoaWNoIGFkZHJlc3Mgb2YgdGhlIHVzZXIncyB0byBzZW5kIHRoZSBlbWFpbCB0by4gVGhpcyBhZGRyZXNzIG11c3QgYmUgaW4gdGhlIHVzZXIncyBgZW1haWxzYCBsaXN0LiBEZWZhdWx0cyB0byB0aGUgZmlyc3QgdW52ZXJpZmllZCBlbWFpbCBpbiB0aGUgbGlzdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbZXh0cmFUb2tlbkRhdGFdIE9wdGlvbmFsIGFkZGl0aW9uYWwgZGF0YSB0byBiZSBhZGRlZCBpbnRvIHRoZSB0b2tlbiByZWNvcmQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3Qgd2l0aCB7ZW1haWwsIHVzZXIsIHRva2VuLCB1cmwsIG9wdGlvbnN9IHZhbHVlcy5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbCA9ICh1c2VySWQsIGVtYWlsLCBleHRyYVRva2VuRGF0YSkgPT4ge1xuICAvLyBYWFggQWxzbyBnZW5lcmF0ZSBhIGxpbmsgdXNpbmcgd2hpY2ggc29tZW9uZSBjYW4gZGVsZXRlIHRoaXNcbiAgLy8gYWNjb3VudCBpZiB0aGV5IG93biBzYWlkIGFkZHJlc3MgYnV0IHdlcmVuJ3QgdGhvc2Ugd2hvIGNyZWF0ZWRcbiAgLy8gdGhpcyBhY2NvdW50LlxuXG4gIGNvbnN0IHtlbWFpbDogcmVhbEVtYWlsLCB1c2VyLCB0b2tlbn0gPVxuICAgIEFjY291bnRzLmdlbmVyYXRlVmVyaWZpY2F0aW9uVG9rZW4odXNlcklkLCBlbWFpbCwgZXh0cmFUb2tlbkRhdGEpO1xuICBjb25zdCB1cmwgPSBBY2NvdW50cy51cmxzLnZlcmlmeUVtYWlsKHRva2VuKTtcbiAgY29uc3Qgb3B0aW9ucyA9IEFjY291bnRzLmdlbmVyYXRlT3B0aW9uc0ZvckVtYWlsKHJlYWxFbWFpbCwgdXNlciwgdXJsLCAndmVyaWZ5RW1haWwnKTtcbiAgRW1haWwuc2VuZChvcHRpb25zKTtcbiAgcmV0dXJuIHtlbWFpbDogcmVhbEVtYWlsLCB1c2VyLCB0b2tlbiwgdXJsLCBvcHRpb25zfTtcbn07XG5cbi8vIFRha2UgdG9rZW4gZnJvbSBzZW5kVmVyaWZpY2F0aW9uRW1haWwsIG1hcmsgdGhlIGVtYWlsIGFzIHZlcmlmaWVkLFxuLy8gYW5kIGxvZyB0aGVtIGluLlxuTWV0ZW9yLm1ldGhvZHMoe3ZlcmlmeUVtYWlsOiBmdW5jdGlvbiAoLi4uYXJncykge1xuICBjb25zdCB0b2tlbiA9IGFyZ3NbMF07XG4gIHJldHVybiBBY2NvdW50cy5fbG9naW5NZXRob2QoXG4gICAgdGhpcyxcbiAgICBcInZlcmlmeUVtYWlsXCIsXG4gICAgYXJncyxcbiAgICBcInBhc3N3b3JkXCIsXG4gICAgKCkgPT4ge1xuICAgICAgY2hlY2sodG9rZW4sIFN0cmluZyk7XG5cbiAgICAgIGNvbnN0IHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZShcbiAgICAgICAgeydzZXJ2aWNlcy5lbWFpbC52ZXJpZmljYXRpb25Ub2tlbnMudG9rZW4nOiB0b2tlbn0pO1xuICAgICAgaWYgKCF1c2VyKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJWZXJpZnkgZW1haWwgbGluayBleHBpcmVkXCIpO1xuXG4gICAgICAgIGNvbnN0IHRva2VuUmVjb3JkID0gdXNlci5zZXJ2aWNlcy5lbWFpbC52ZXJpZmljYXRpb25Ub2tlbnMuZmluZChcbiAgICAgICAgICB0ID0+IHQudG9rZW4gPT0gdG9rZW5cbiAgICAgICAgKTtcbiAgICAgIGlmICghdG9rZW5SZWNvcmQpXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdXNlcklkOiB1c2VyLl9pZCxcbiAgICAgICAgICBlcnJvcjogbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiVmVyaWZ5IGVtYWlsIGxpbmsgZXhwaXJlZFwiKVxuICAgICAgICB9O1xuXG4gICAgICBjb25zdCBlbWFpbHNSZWNvcmQgPSB1c2VyLmVtYWlscy5maW5kKFxuICAgICAgICBlID0+IGUuYWRkcmVzcyA9PSB0b2tlblJlY29yZC5hZGRyZXNzXG4gICAgICApO1xuICAgICAgaWYgKCFlbWFpbHNSZWNvcmQpXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdXNlcklkOiB1c2VyLl9pZCxcbiAgICAgICAgICBlcnJvcjogbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiVmVyaWZ5IGVtYWlsIGxpbmsgaXMgZm9yIHVua25vd24gYWRkcmVzc1wiKVxuICAgICAgICB9O1xuXG4gICAgICAvLyBCeSBpbmNsdWRpbmcgdGhlIGFkZHJlc3MgaW4gdGhlIHF1ZXJ5LCB3ZSBjYW4gdXNlICdlbWFpbHMuJCcgaW4gdGhlXG4gICAgICAvLyBtb2RpZmllciB0byBnZXQgYSByZWZlcmVuY2UgdG8gdGhlIHNwZWNpZmljIG9iamVjdCBpbiB0aGUgZW1haWxzXG4gICAgICAvLyBhcnJheS4gU2VlXG4gICAgICAvLyBodHRwOi8vd3d3Lm1vbmdvZGIub3JnL2Rpc3BsYXkvRE9DUy9VcGRhdGluZy8jVXBkYXRpbmctVGhlJTI0cG9zaXRpb25hbG9wZXJhdG9yKVxuICAgICAgLy8gaHR0cDovL3d3dy5tb25nb2RiLm9yZy9kaXNwbGF5L0RPQ1MvVXBkYXRpbmcjVXBkYXRpbmctJTI0cHVsbFxuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAge19pZDogdXNlci5faWQsXG4gICAgICAgICAnZW1haWxzLmFkZHJlc3MnOiB0b2tlblJlY29yZC5hZGRyZXNzfSxcbiAgICAgICAgeyRzZXQ6IHsnZW1haWxzLiQudmVyaWZpZWQnOiB0cnVlfSxcbiAgICAgICAgICRwdWxsOiB7J3NlcnZpY2VzLmVtYWlsLnZlcmlmaWNhdGlvblRva2Vucyc6IHthZGRyZXNzOiB0b2tlblJlY29yZC5hZGRyZXNzfX19KTtcblxuICAgICAgcmV0dXJuIHt1c2VySWQ6IHVzZXIuX2lkfTtcbiAgICB9XG4gICk7XG59fSk7XG5cbi8qKlxuICogQHN1bW1hcnkgQWRkIGFuIGVtYWlsIGFkZHJlc3MgZm9yIGEgdXNlci4gVXNlIHRoaXMgaW5zdGVhZCBvZiBkaXJlY3RseVxuICogdXBkYXRpbmcgdGhlIGRhdGFiYXNlLiBUaGUgb3BlcmF0aW9uIHdpbGwgZmFpbCBpZiB0aGVyZSBpcyBhIGRpZmZlcmVudCB1c2VyXG4gKiB3aXRoIGFuIGVtYWlsIG9ubHkgZGlmZmVyaW5nIGluIGNhc2UuIElmIHRoZSBzcGVjaWZpZWQgdXNlciBoYXMgYW4gZXhpc3RpbmdcbiAqIGVtYWlsIG9ubHkgZGlmZmVyaW5nIGluIGNhc2UgaG93ZXZlciwgd2UgcmVwbGFjZSBpdC5cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7U3RyaW5nfSB1c2VySWQgVGhlIElEIG9mIHRoZSB1c2VyIHRvIHVwZGF0ZS5cbiAqIEBwYXJhbSB7U3RyaW5nfSBuZXdFbWFpbCBBIG5ldyBlbWFpbCBhZGRyZXNzIGZvciB0aGUgdXNlci5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW3ZlcmlmaWVkXSBPcHRpb25hbCAtIHdoZXRoZXIgdGhlIG5ldyBlbWFpbCBhZGRyZXNzIHNob3VsZFxuICogYmUgbWFya2VkIGFzIHZlcmlmaWVkLiBEZWZhdWx0cyB0byBmYWxzZS5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLmFkZEVtYWlsID0gKHVzZXJJZCwgbmV3RW1haWwsIHZlcmlmaWVkKSA9PiB7XG4gIGNoZWNrKHVzZXJJZCwgTm9uRW1wdHlTdHJpbmcpO1xuICBjaGVjayhuZXdFbWFpbCwgTm9uRW1wdHlTdHJpbmcpO1xuICBjaGVjayh2ZXJpZmllZCwgTWF0Y2guT3B0aW9uYWwoQm9vbGVhbikpO1xuXG4gIGlmICh2ZXJpZmllZCA9PT0gdm9pZCAwKSB7XG4gICAgdmVyaWZpZWQgPSBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IHVzZXIgPSBnZXRVc2VyQnlJZCh1c2VySWQpO1xuICBpZiAoIXVzZXIpXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiVXNlciBub3QgZm91bmRcIik7XG5cbiAgLy8gQWxsb3cgdXNlcnMgdG8gY2hhbmdlIHRoZWlyIG93biBlbWFpbCB0byBhIHZlcnNpb24gd2l0aCBhIGRpZmZlcmVudCBjYXNlXG5cbiAgLy8gV2UgZG9uJ3QgaGF2ZSB0byBjYWxsIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcyB0byBkbyBhIGNhc2VcbiAgLy8gaW5zZW5zaXRpdmUgY2hlY2sgYWNyb3NzIGFsbCBlbWFpbHMgaW4gdGhlIGRhdGFiYXNlIGhlcmUgYmVjYXVzZTogKDEpIGlmXG4gIC8vIHRoZXJlIGlzIG5vIGNhc2UtaW5zZW5zaXRpdmUgZHVwbGljYXRlIGJldHdlZW4gdGhpcyB1c2VyIGFuZCBvdGhlciB1c2VycyxcbiAgLy8gdGhlbiB3ZSBhcmUgT0sgYW5kICgyKSBpZiB0aGlzIHdvdWxkIGNyZWF0ZSBhIGNvbmZsaWN0IHdpdGggb3RoZXIgdXNlcnNcbiAgLy8gdGhlbiB0aGVyZSB3b3VsZCBhbHJlYWR5IGJlIGEgY2FzZS1pbnNlbnNpdGl2ZSBkdXBsaWNhdGUgYW5kIHdlIGNhbid0IGZpeFxuICAvLyB0aGF0IGluIHRoaXMgY29kZSBhbnl3YXkuXG4gIGNvbnN0IGNhc2VJbnNlbnNpdGl2ZVJlZ0V4cCA9XG4gICAgbmV3IFJlZ0V4cChgXiR7TWV0ZW9yLl9lc2NhcGVSZWdFeHAobmV3RW1haWwpfSRgLCAnaScpO1xuXG4gIGNvbnN0IGRpZFVwZGF0ZU93bkVtYWlsID0gKHVzZXIuZW1haWxzIHx8IFtdKS5yZWR1Y2UoXG4gICAgKHByZXYsIGVtYWlsKSA9PiB7XG4gICAgICBpZiAoY2FzZUluc2Vuc2l0aXZlUmVnRXhwLnRlc3QoZW1haWwuYWRkcmVzcykpIHtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7XG4gICAgICAgICAgX2lkOiB1c2VyLl9pZCxcbiAgICAgICAgICAnZW1haWxzLmFkZHJlc3MnOiBlbWFpbC5hZGRyZXNzXG4gICAgICAgIH0sIHskc2V0OiB7XG4gICAgICAgICAgJ2VtYWlscy4kLmFkZHJlc3MnOiBuZXdFbWFpbCxcbiAgICAgICAgICAnZW1haWxzLiQudmVyaWZpZWQnOiB2ZXJpZmllZFxuICAgICAgICB9fSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICB9XG4gICAgfSwgXG4gICAgZmFsc2VcbiAgKTtcblxuICAvLyBJbiB0aGUgb3RoZXIgdXBkYXRlcyBiZWxvdywgd2UgaGF2ZSB0byBkbyBhbm90aGVyIGNhbGwgdG9cbiAgLy8gY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzIHRvIG1ha2Ugc3VyZSB0aGF0IG5vIGNvbmZsaWN0aW5nIHZhbHVlc1xuICAvLyB3ZXJlIGFkZGVkIHRvIHRoZSBkYXRhYmFzZSBpbiB0aGUgbWVhbnRpbWUuIFdlIGRvbid0IGhhdmUgdG8gZG8gdGhpcyBmb3JcbiAgLy8gdGhlIGNhc2Ugd2hlcmUgdGhlIHVzZXIgaXMgdXBkYXRpbmcgdGhlaXIgZW1haWwgYWRkcmVzcyB0byBvbmUgdGhhdCBpcyB0aGVcbiAgLy8gc2FtZSBhcyBiZWZvcmUsIGJ1dCBvbmx5IGRpZmZlcmVudCBiZWNhdXNlIG9mIGNhcGl0YWxpemF0aW9uLiBSZWFkIHRoZVxuICAvLyBiaWcgY29tbWVudCBhYm92ZSB0byB1bmRlcnN0YW5kIHdoeS5cblxuICBpZiAoZGlkVXBkYXRlT3duRW1haWwpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBQZXJmb3JtIGEgY2FzZSBpbnNlbnNpdGl2ZSBjaGVjayBmb3IgZHVwbGljYXRlcyBiZWZvcmUgdXBkYXRlXG4gIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBuZXdFbWFpbCwgdXNlci5faWQpO1xuXG4gIE1ldGVvci51c2Vycy51cGRhdGUoe1xuICAgIF9pZDogdXNlci5faWRcbiAgfSwge1xuICAgICRhZGRUb1NldDoge1xuICAgICAgZW1haWxzOiB7XG4gICAgICAgIGFkZHJlc3M6IG5ld0VtYWlsLFxuICAgICAgICB2ZXJpZmllZDogdmVyaWZpZWRcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIC8vIFBlcmZvcm0gYW5vdGhlciBjaGVjayBhZnRlciB1cGRhdGUsIGluIGNhc2UgYSBtYXRjaGluZyB1c2VyIGhhcyBiZWVuXG4gIC8vIGluc2VydGVkIGluIHRoZSBtZWFudGltZVxuICB0cnkge1xuICAgIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBuZXdFbWFpbCwgdXNlci5faWQpO1xuICB9IGNhdGNoIChleCkge1xuICAgIC8vIFVuZG8gdXBkYXRlIGlmIHRoZSBjaGVjayBmYWlsc1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogdXNlci5faWR9LFxuICAgICAgeyRwdWxsOiB7ZW1haWxzOiB7YWRkcmVzczogbmV3RW1haWx9fX0pO1xuICAgIHRocm93IGV4O1xuICB9XG59XG5cbi8qKlxuICogQHN1bW1hcnkgUmVtb3ZlIGFuIGVtYWlsIGFkZHJlc3MgZm9yIGEgdXNlci4gVXNlIHRoaXMgaW5zdGVhZCBvZiB1cGRhdGluZ1xuICogdGhlIGRhdGFiYXNlIGRpcmVjdGx5LlxuICogQGxvY3VzIFNlcnZlclxuICogQHBhcmFtIHtTdHJpbmd9IHVzZXJJZCBUaGUgSUQgb2YgdGhlIHVzZXIgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IGVtYWlsIFRoZSBlbWFpbCBhZGRyZXNzIHRvIHJlbW92ZS5cbiAqIEBpbXBvcnRGcm9tUGFja2FnZSBhY2NvdW50cy1iYXNlXG4gKi9cbkFjY291bnRzLnJlbW92ZUVtYWlsID0gKHVzZXJJZCwgZW1haWwpID0+IHtcbiAgY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG4gIGNoZWNrKGVtYWlsLCBOb25FbXB0eVN0cmluZyk7XG5cbiAgY29uc3QgdXNlciA9IGdldFVzZXJCeUlkKHVzZXJJZCk7XG4gIGlmICghdXNlcilcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJVc2VyIG5vdCBmb3VuZFwiKTtcblxuICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXIuX2lkfSxcbiAgICB7JHB1bGw6IHtlbWFpbHM6IHthZGRyZXNzOiBlbWFpbH19fSk7XG59XG5cbi8vL1xuLy8vIENSRUFUSU5HIFVTRVJTXG4vLy9cblxuLy8gU2hhcmVkIGNyZWF0ZVVzZXIgZnVuY3Rpb24gY2FsbGVkIGZyb20gdGhlIGNyZWF0ZVVzZXIgbWV0aG9kLCBib3RoXG4vLyBpZiBvcmlnaW5hdGVzIGluIGNsaWVudCBvciBzZXJ2ZXIgY29kZS4gQ2FsbHMgdXNlciBwcm92aWRlZCBob29rcyxcbi8vIGRvZXMgdGhlIGFjdHVhbCB1c2VyIGluc2VydGlvbi5cbi8vXG4vLyByZXR1cm5zIHRoZSB1c2VyIGlkXG5jb25zdCBjcmVhdGVVc2VyID0gb3B0aW9ucyA9PiB7XG4gIC8vIFVua25vd24ga2V5cyBhbGxvd2VkLCBiZWNhdXNlIGEgb25DcmVhdGVVc2VySG9vayBjYW4gdGFrZSBhcmJpdHJhcnlcbiAgLy8gb3B0aW9ucy5cbiAgY2hlY2sob3B0aW9ucywgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHtcbiAgICB1c2VybmFtZTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICBlbWFpbDogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICBwYXNzd29yZDogTWF0Y2guT3B0aW9uYWwocGFzc3dvcmRWYWxpZGF0b3IpXG4gIH0pKTtcblxuICBjb25zdCB7IHVzZXJuYW1lLCBlbWFpbCwgcGFzc3dvcmQgfSA9IG9wdGlvbnM7XG4gIGlmICghdXNlcm5hbWUgJiYgIWVtYWlsKVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBcIk5lZWQgdG8gc2V0IGEgdXNlcm5hbWUgb3IgZW1haWxcIik7XG5cbiAgY29uc3QgdXNlciA9IHtzZXJ2aWNlczoge319O1xuICBpZiAocGFzc3dvcmQpIHtcbiAgICBjb25zdCBoYXNoZWQgPSBoYXNoUGFzc3dvcmQocGFzc3dvcmQpO1xuICAgIHVzZXIuc2VydmljZXMucGFzc3dvcmQgPSB7IGJjcnlwdDogaGFzaGVkIH07XG4gIH1cblxuICBpZiAodXNlcm5hbWUpXG4gICAgdXNlci51c2VybmFtZSA9IHVzZXJuYW1lO1xuICBpZiAoZW1haWwpXG4gICAgdXNlci5lbWFpbHMgPSBbe2FkZHJlc3M6IGVtYWlsLCB2ZXJpZmllZDogZmFsc2V9XTtcblxuICAvLyBQZXJmb3JtIGEgY2FzZSBpbnNlbnNpdGl2ZSBjaGVjayBiZWZvcmUgaW5zZXJ0XG4gIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygndXNlcm5hbWUnLCAnVXNlcm5hbWUnLCB1c2VybmFtZSk7XG4gIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBlbWFpbCk7XG5cbiAgY29uc3QgdXNlcklkID0gQWNjb3VudHMuaW5zZXJ0VXNlckRvYyhvcHRpb25zLCB1c2VyKTtcbiAgLy8gUGVyZm9ybSBhbm90aGVyIGNoZWNrIGFmdGVyIGluc2VydCwgaW4gY2FzZSBhIG1hdGNoaW5nIHVzZXIgaGFzIGJlZW5cbiAgLy8gaW5zZXJ0ZWQgaW4gdGhlIG1lYW50aW1lXG4gIHRyeSB7XG4gICAgY2hlY2tGb3JDYXNlSW5zZW5zaXRpdmVEdXBsaWNhdGVzKCd1c2VybmFtZScsICdVc2VybmFtZScsIHVzZXJuYW1lLCB1c2VySWQpO1xuICAgIGNoZWNrRm9yQ2FzZUluc2Vuc2l0aXZlRHVwbGljYXRlcygnZW1haWxzLmFkZHJlc3MnLCAnRW1haWwnLCBlbWFpbCwgdXNlcklkKTtcbiAgfSBjYXRjaCAoZXgpIHtcbiAgICAvLyBSZW1vdmUgaW5zZXJ0ZWQgdXNlciBpZiB0aGUgY2hlY2sgZmFpbHNcbiAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHVzZXJJZCk7XG4gICAgdGhyb3cgZXg7XG4gIH1cbiAgcmV0dXJuIHVzZXJJZDtcbn07XG5cbi8vIG1ldGhvZCBmb3IgY3JlYXRlIHVzZXIuIFJlcXVlc3RzIGNvbWUgZnJvbSB0aGUgY2xpZW50LlxuTWV0ZW9yLm1ldGhvZHMoe2NyZWF0ZVVzZXI6IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gIGNvbnN0IG9wdGlvbnMgPSBhcmdzWzBdO1xuICByZXR1cm4gQWNjb3VudHMuX2xvZ2luTWV0aG9kKFxuICAgIHRoaXMsXG4gICAgXCJjcmVhdGVVc2VyXCIsXG4gICAgYXJncyxcbiAgICBcInBhc3N3b3JkXCIsXG4gICAgKCkgPT4ge1xuICAgICAgLy8gY3JlYXRlVXNlcigpIGFib3ZlIGRvZXMgbW9yZSBjaGVja2luZy5cbiAgICAgIGNoZWNrKG9wdGlvbnMsIE9iamVjdCk7XG4gICAgICBpZiAoQWNjb3VudHMuX29wdGlvbnMuZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uKVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGVycm9yOiBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJTaWdudXBzIGZvcmJpZGRlblwiKVxuICAgICAgICB9O1xuXG4gICAgICAvLyBDcmVhdGUgdXNlci4gcmVzdWx0IGNvbnRhaW5zIGlkIGFuZCB0b2tlbi5cbiAgICAgIGNvbnN0IHVzZXJJZCA9IGNyZWF0ZVVzZXIob3B0aW9ucyk7XG4gICAgICAvLyBzYWZldHkgYmVsdC4gY3JlYXRlVXNlciBpcyBzdXBwb3NlZCB0byB0aHJvdyBvbiBlcnJvci4gc2VuZCA1MDAgZXJyb3JcbiAgICAgIC8vIGluc3RlYWQgb2Ygc2VuZGluZyBhIHZlcmlmaWNhdGlvbiBlbWFpbCB3aXRoIGVtcHR5IHVzZXJpZC5cbiAgICAgIGlmICghIHVzZXJJZClcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY3JlYXRlVXNlciBmYWlsZWQgdG8gaW5zZXJ0IG5ldyB1c2VyXCIpO1xuXG4gICAgICAvLyBJZiBgQWNjb3VudHMuX29wdGlvbnMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsYCBpcyBzZXQsIHJlZ2lzdGVyXG4gICAgICAvLyBhIHRva2VuIHRvIHZlcmlmeSB0aGUgdXNlcidzIHByaW1hcnkgZW1haWwsIGFuZCBzZW5kIGl0IHRvXG4gICAgICAvLyB0aGF0IGFkZHJlc3MuXG4gICAgICBpZiAob3B0aW9ucy5lbWFpbCAmJiBBY2NvdW50cy5fb3B0aW9ucy5zZW5kVmVyaWZpY2F0aW9uRW1haWwpXG4gICAgICAgIEFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbCh1c2VySWQsIG9wdGlvbnMuZW1haWwpO1xuXG4gICAgICAvLyBjbGllbnQgZ2V0cyBsb2dnZWQgaW4gYXMgdGhlIG5ldyB1c2VyIGFmdGVyd2FyZHMuXG4gICAgICByZXR1cm4ge3VzZXJJZDogdXNlcklkfTtcbiAgICB9XG4gICk7XG59fSk7XG5cbi8vIENyZWF0ZSB1c2VyIGRpcmVjdGx5IG9uIHRoZSBzZXJ2ZXIuXG4vL1xuLy8gVW5saWtlIHRoZSBjbGllbnQgdmVyc2lvbiwgdGhpcyBkb2VzIG5vdCBsb2cgeW91IGluIGFzIHRoaXMgdXNlclxuLy8gYWZ0ZXIgY3JlYXRpb24uXG4vL1xuLy8gcmV0dXJucyB1c2VySWQgb3IgdGhyb3dzIGFuIGVycm9yIGlmIGl0IGNhbid0IGNyZWF0ZVxuLy9cbi8vIFhYWCBhZGQgYW5vdGhlciBhcmd1bWVudCAoXCJzZXJ2ZXIgb3B0aW9uc1wiKSB0aGF0IGdldHMgc2VudCB0byBvbkNyZWF0ZVVzZXIsXG4vLyB3aGljaCBpcyBhbHdheXMgZW1wdHkgd2hlbiBjYWxsZWQgZnJvbSB0aGUgY3JlYXRlVXNlciBtZXRob2Q/IGVnLCBcImFkbWluOlxuLy8gdHJ1ZVwiLCB3aGljaCB3ZSB3YW50IHRvIHByZXZlbnQgdGhlIGNsaWVudCBmcm9tIHNldHRpbmcsIGJ1dCB3aGljaCBhIGN1c3RvbVxuLy8gbWV0aG9kIGNhbGxpbmcgQWNjb3VudHMuY3JlYXRlVXNlciBjb3VsZCBzZXQ/XG4vL1xuQWNjb3VudHMuY3JlYXRlVXNlciA9IChvcHRpb25zLCBjYWxsYmFjaykgPT4ge1xuICBvcHRpb25zID0geyAuLi5vcHRpb25zIH07XG5cbiAgLy8gWFhYIGFsbG93IGFuIG9wdGlvbmFsIGNhbGxiYWNrP1xuICBpZiAoY2FsbGJhY2spIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJBY2NvdW50cy5jcmVhdGVVc2VyIHdpdGggY2FsbGJhY2sgbm90IHN1cHBvcnRlZCBvbiB0aGUgc2VydmVyIHlldC5cIik7XG4gIH1cblxuICByZXR1cm4gY3JlYXRlVXNlcihvcHRpb25zKTtcbn07XG5cbi8vL1xuLy8vIFBBU1NXT1JELVNQRUNJRklDIElOREVYRVMgT04gVVNFUlNcbi8vL1xuTWV0ZW9yLnVzZXJzLl9lbnN1cmVJbmRleCgnc2VydmljZXMuZW1haWwudmVyaWZpY2F0aW9uVG9rZW5zLnRva2VuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VuaXF1ZTogMSwgc3BhcnNlOiAxfSk7XG5NZXRlb3IudXNlcnMuX2Vuc3VyZUluZGV4KCdzZXJ2aWNlcy5wYXNzd29yZC5yZXNldC50b2tlbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1bmlxdWU6IDEsIHNwYXJzZTogMX0pO1xuIl19
