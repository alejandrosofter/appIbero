(function () {



/* Exports */
Package._define("aldeed:autoform-select2");

})();
