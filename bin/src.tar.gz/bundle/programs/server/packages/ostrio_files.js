(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var debug, schema, public, strict, chunkSize, protected, collection, permissions, cacheControl, downloadRoute, onAfterUpload, onAfterRemove, disableUpload, onBeforeRemove, integrityCheck, collectionName, onBeforeUpload, namingFunction, responseHeaders, disableDownload, allowedOrigins, allowClientCode, downloadCallback, onInitiateUpload, interceptRequest, interceptDownload, continueUploadTTL, parentDirPermissions, allowQueryStringCookies, _preCollection, _preCollectionName, FilesCollection;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:files":{"server.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/server.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FilesCollection: () => FilesCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let WebApp;
module.link("meteor/webapp", {
  WebApp(v) {
    WebApp = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 3);
let Cookies;
module.link("meteor/ostrio:cookies", {
  Cookies(v) {
    Cookies = v;
  }

}, 4);
let WriteStream;
module.link("./write-stream.js", {
  default(v) {
    WriteStream = v;
  }

}, 5);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 6);
let FilesCollectionCore;
module.link("./core.js", {
  default(v) {
    FilesCollectionCore = v;
  }

}, 7);
let fixJSONParse, fixJSONStringify, helpers;
module.link("./lib.js", {
  fixJSONParse(v) {
    fixJSONParse = v;
  },

  fixJSONStringify(v) {
    fixJSONStringify = v;
  },

  helpers(v) {
    helpers = v;
  }

}, 8);
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 9);
let nodeQs;
module.link("querystring", {
  default(v) {
    nodeQs = v;
  }

}, 10);
let request;
module.link("request-libcurl", {
  default(v) {
    request = v;
  }

}, 11);
let fileType;
module.link("file-type", {
  default(v) {
    fileType = v;
  }

}, 12);
let nodePath;
module.link("path", {
  default(v) {
    nodePath = v;
  }

}, 13);

/*
 * @const {Object} bound  - Meteor.bindEnvironment (Fiber wrapper)
 * @const {Function} NOOP - No Operation function, placeholder for required callbacks
 */
const bound = Meteor.bindEnvironment(callback => callback());

const NOOP = () => {};
/*
 * @locus Anywhere
 * @class FilesCollection
 * @param config           {Object}   - [Both]   Configuration object with next properties:
 * @param config.debug     {Boolean}  - [Both]   Turn on/of debugging and extra logging
 * @param config.schema    {Object}   - [Both]   Collection Schema
 * @param config.public    {Boolean}  - [Both]   Store files in folder accessible for proxy servers, for limits, and more - read docs
 * @param config.strict    {Boolean}  - [Server] Strict mode for partial content, if is `true` server will return `416` response code, when `range` is not specified, otherwise server return `206`
 * @param config.protected {Function} - [Server] If `true` - files will be served only to authorized users, if `function()` - you're able to check visitor's permissions in your own way function's context has:
 *  - `request`
 *  - `response`
 *  - `user()`
 *  - `userId`
 * @param config.chunkSize      {Number}  - [Both] Upload chunk size, default: 524288 bytes (0,5 Mb)
 * @param config.permissions    {Number}  - [Server] Permissions which will be set to uploaded files (octal), like: `511` or `0o755`. Default: 0644
 * @param config.parentDirPermissions {Number}  - [Server] Permissions which will be set to parent directory of uploaded files (octal), like: `611` or `0o777`. Default: 0755
 * @param config.storagePath    {String|Function}  - [Server] Storage path on file system
 * @param config.cacheControl   {String}  - [Server] Default `Cache-Control` header
 * @param config.responseHeaders {Object|Function} - [Server] Custom response headers, if function is passed, must return Object
 * @param config.throttle       {Number}  - [Server] DEPRECATED bps throttle threshold
 * @param config.downloadRoute  {String}  - [Both]   Server Route used to retrieve files
 * @param config.collection     {Mongo.Collection} - [Both] Mongo Collection Instance
 * @param config.collectionName {String}  - [Both]   Collection name
 * @param config.namingFunction {Function}- [Both]   Function which returns `String`
 * @param config.integrityCheck {Boolean} - [Server] Check file's integrity before serving to users
 * @param config.onAfterUpload  {Function}- [Server] Called right after file is ready on FS. Use to transfer file somewhere else, or do other thing with file directly
 * @param config.onAfterRemove  {Function} - [Server] Called right after file is removed. Removed objects is passed to callback
 * @param config.continueUploadTTL {Number} - [Server] Time in seconds, during upload may be continued, default 3 hours (10800 seconds)
 * @param config.onBeforeUpload {Function}- [Both]   Function which executes on server after receiving each chunk and on client right before beginning upload. Function context is `File` - so you are able to check for extension, mime-type, size and etc.:
 *  - return `true` to continue
 *  - return `false` or `String` to abort upload
 * @param config.onInitiateUpload {Function} - [Server] Function which executes on server right before upload is begin and right after `onBeforeUpload` hook. This hook is fully asynchronous.
 * @param config.onBeforeRemove {Function} - [Server] Executes before removing file on server, so you can check permissions. Return `true` to allow action and `false` to deny.
 * @param config.allowClientCode  {Boolean}  - [Both]   Allow to run `remove` from client
 * @param config.downloadCallback {Function} - [Server] Callback triggered each time file is requested, return truthy value to continue download, or falsy to abort
  * @param config.interceptRequest {Function} - [Server] Intercept incoming HTTP request, so you can whatever you want, no checks or preprocessing, arguments {http: {request: {...}, response: {...}}, params: {...}}
 * @param config.interceptDownload {Function} - [Server] Intercept download request, so you can serve file from third-party resource, arguments {http: {request: {...}, response: {...}}, fileRef: {...}}
 * @param config.disableUpload {Boolean} - Disable file upload, useful for server only solutions
 * @param config.disableDownload {Boolean} - Disable file download (serving), useful for file management only solutions
 * @param config.allowedOrigins  {Regex|Boolean}  - [Server]   Regex of Origins that are allowed CORS access or `false` to disable completely. Defaults to `/^http:\/\/localhost:12[0-9]{3}$/` for allowing Meteor-Cordova builds access
 * @param config.allowQueryStringCookies {Boolean} - Allow passing Cookies in a query string (in URL). Primary should be used only in Cordova environment. Note: this option will be used only on Cordova. Default: `false`
 * @param config._preCollection  {Mongo.Collection} - [Server] Mongo preCollection Instance
 * @param config._preCollectionName {String}  - [Server]  preCollection name
 * @summary Create new instance of FilesCollection
 */


class FilesCollection extends FilesCollectionCore {
  constructor(config) {
    super();
    let storagePath;

    if (config) {
      ({
        storagePath,
        debug: this.debug,
        schema: this.schema,
        public: this.public,
        strict: this.strict,
        chunkSize: this.chunkSize,
        protected: this.protected,
        collection: this.collection,
        permissions: this.permissions,
        cacheControl: this.cacheControl,
        downloadRoute: this.downloadRoute,
        onAfterUpload: this.onAfterUpload,
        onAfterRemove: this.onAfterRemove,
        disableUpload: this.disableUpload,
        onBeforeRemove: this.onBeforeRemove,
        integrityCheck: this.integrityCheck,
        collectionName: this.collectionName,
        onBeforeUpload: this.onBeforeUpload,
        namingFunction: this.namingFunction,
        responseHeaders: this.responseHeaders,
        disableDownload: this.disableDownload,
        allowedOrigins: this.allowedOrigins,
        allowClientCode: this.allowClientCode,
        downloadCallback: this.downloadCallback,
        onInitiateUpload: this.onInitiateUpload,
        interceptRequest: this.interceptRequest,
        interceptDownload: this.interceptDownload,
        continueUploadTTL: this.continueUploadTTL,
        parentDirPermissions: this.parentDirPermissions,
        allowQueryStringCookies: this.allowQueryStringCookies,
        _preCollection: this._preCollection,
        _preCollectionName: this._preCollectionName
      } = config);
    }

    const self = this;

    if (!helpers.isBoolean(this.debug)) {
      this.debug = false;
    }

    if (!helpers.isBoolean(this.public)) {
      this.public = false;
    }

    if (!this.protected) {
      this.protected = false;
    }

    if (!this.chunkSize) {
      this.chunkSize = 1024 * 512;
    }

    this.chunkSize = Math.floor(this.chunkSize / 8) * 8;

    if (!helpers.isString(this.collectionName) && !this.collection) {
      this.collectionName = 'MeteorUploadFiles';
    }

    if (!this.collection) {
      this.collection = new Mongo.Collection(this.collectionName);
    } else {
      this.collectionName = this.collection._name;
    }

    this.collection.filesCollection = this;
    check(this.collectionName, String);

    if (this.public && !this.downloadRoute) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "]: \"downloadRoute\" must be precisely provided on \"public\" collections! Note: \"downloadRoute\" must be equal or be inside of your web/proxy-server (relative) root."));
    }

    if (!helpers.isString(this.downloadRoute)) {
      this.downloadRoute = '/cdn/storage';
    }

    this.downloadRoute = this.downloadRoute.replace(/\/$/, '');

    if (!helpers.isFunction(this.namingFunction)) {
      this.namingFunction = false;
    }

    if (!helpers.isFunction(this.onBeforeUpload)) {
      this.onBeforeUpload = false;
    }

    if (!helpers.isBoolean(this.allowClientCode)) {
      this.allowClientCode = true;
    }

    if (!helpers.isFunction(this.onInitiateUpload)) {
      this.onInitiateUpload = false;
    }

    if (!helpers.isFunction(this.interceptRequest)) {
      this.interceptRequest = false;
    }

    if (!helpers.isFunction(this.interceptDownload)) {
      this.interceptDownload = false;
    }

    if (!helpers.isBoolean(this.strict)) {
      this.strict = true;
    }

    if (!helpers.isBoolean(this.allowQueryStringCookies)) {
      this.allowQueryStringCookies = false;
    }

    if (!helpers.isNumber(this.permissions)) {
      this.permissions = parseInt('644', 8);
    }

    if (!helpers.isNumber(this.parentDirPermissions)) {
      this.parentDirPermissions = parseInt('755', 8);
    }

    if (!helpers.isString(this.cacheControl)) {
      this.cacheControl = 'public, max-age=31536000, s-maxage=31536000';
    }

    if (!helpers.isFunction(this.onAfterUpload)) {
      this.onAfterUpload = false;
    }

    if (!helpers.isBoolean(this.disableUpload)) {
      this.disableUpload = false;
    }

    if (!helpers.isFunction(this.onAfterRemove)) {
      this.onAfterRemove = false;
    }

    if (!helpers.isFunction(this.onBeforeRemove)) {
      this.onBeforeRemove = false;
    }

    if (!helpers.isBoolean(this.integrityCheck)) {
      this.integrityCheck = true;
    }

    if (!helpers.isBoolean(this.disableDownload)) {
      this.disableDownload = false;
    }

    if (!helpers.isBoolean(this.allowedOrigins) || this.allowedOrigins === true) {
      this.allowedOrigins = /^http:\/\/localhost:12[0-9]{3}$/;
    }

    if (!helpers.isObject(this._currentUploads)) {
      this._currentUploads = {};
    }

    if (!helpers.isFunction(this.downloadCallback)) {
      this.downloadCallback = false;
    }

    if (!helpers.isNumber(this.continueUploadTTL)) {
      this.continueUploadTTL = 10800;
    }

    if (!helpers.isFunction(this.responseHeaders)) {
      this.responseHeaders = (responseCode, fileRef, versionRef) => {
        const headers = {};

        switch (responseCode) {
          case '206':
            headers.Pragma = 'private';
            headers['Transfer-Encoding'] = 'chunked';
            break;

          case '400':
            headers['Cache-Control'] = 'no-cache';
            break;

          case '416':
            headers['Content-Range'] = "bytes */".concat(versionRef.size);
            break;

          default:
            break;
        }

        headers.Connection = 'keep-alive';
        headers['Content-Type'] = versionRef.type || 'application/octet-stream';
        headers['Accept-Ranges'] = 'bytes';
        return headers;
      };
    }

    if (this.public && !storagePath) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "] \"storagePath\" must be set on \"public\" collections! Note: \"storagePath\" must be equal on be inside of your web/proxy-server (absolute) root."));
    }

    if (!storagePath) {
      storagePath = function () {
        return "assets".concat(nodePath.sep, "app").concat(nodePath.sep, "uploads").concat(nodePath.sep).concat(self.collectionName);
      };
    }

    if (helpers.isString(storagePath)) {
      this.storagePath = () => storagePath;
    } else {
      this.storagePath = function () {
        let sp = storagePath.apply(self, arguments);

        if (!helpers.isString(sp)) {
          throw new Meteor.Error(400, "[FilesCollection.".concat(self.collectionName, "] \"storagePath\" function must return a String!"));
        }

        sp = sp.replace(/\/$/, '');
        return nodePath.normalize(sp);
      };
    }

    this._debug('[FilesCollection.storagePath] Set to:', this.storagePath({}));

    fs.mkdirs(this.storagePath({}), {
      mode: this.parentDirPermissions
    }, error => {
      if (error) {
        throw new Meteor.Error(401, "[FilesCollection.".concat(self.collectionName, "] Path \"").concat(this.storagePath({}), "\" is not writable! ").concat(error));
      }
    });
    check(this.strict, Boolean);
    check(this.permissions, Number);
    check(this.storagePath, Function);
    check(this.cacheControl, String);
    check(this.onAfterRemove, Match.OneOf(false, Function));
    check(this.onAfterUpload, Match.OneOf(false, Function));
    check(this.disableUpload, Boolean);
    check(this.integrityCheck, Boolean);
    check(this.onBeforeRemove, Match.OneOf(false, Function));
    check(this.disableDownload, Boolean);
    check(this.downloadCallback, Match.OneOf(false, Function));
    check(this.interceptRequest, Match.OneOf(false, Function));
    check(this.interceptDownload, Match.OneOf(false, Function));
    check(this.continueUploadTTL, Number);
    check(this.responseHeaders, Match.OneOf(Object, Function));
    check(this.allowQueryStringCookies, Boolean);
    new Cookies({
      allowQueryStringCookies: this.allowQueryStringCookies,
      allowedCordovaOrigins: this.allowedOrigins
    });

    if (!this.disableUpload) {
      if (!helpers.isString(this._preCollectionName) && !this._preCollection) {
        this._preCollectionName = "__pre_".concat(this.collectionName);
      }

      if (!this._preCollection) {
        this._preCollection = new Mongo.Collection(this._preCollectionName);
      } else {
        this._preCollectionName = this._preCollection._name;
      }

      check(this._preCollectionName, String);

      this._preCollection._ensureIndex({
        createdAt: 1
      }, {
        expireAfterSeconds: this.continueUploadTTL,
        background: true
      });

      const _preCollectionCursor = this._preCollection.find({}, {
        fields: {
          _id: 1,
          isFinished: 1
        }
      });

      _preCollectionCursor.observe({
        changed(doc) {
          if (doc.isFinished) {
            self._debug("[FilesCollection] [_preCollectionCursor.observe] [changed]: ".concat(doc._id));

            self._preCollection.remove({
              _id: doc._id
            }, NOOP);
          }
        },

        removed(doc) {
          // Free memory after upload is done
          // Or if upload is unfinished
          self._debug("[FilesCollection] [_preCollectionCursor.observe] [removed]: ".concat(doc._id));

          if (helpers.isObject(self._currentUploads[doc._id])) {
            self._currentUploads[doc._id].stop();

            self._currentUploads[doc._id].end(); // We can be unlucky to run into a race condition where another server removed this document before the change of `isFinished` is registered on this server.
            // Therefore it's better to double-check with the main collection if the file is referenced there. Issue: https://github.com/VeliovGroup/Meteor-Files/issues/672


            if (!doc.isFinished && self.collection.find({
              _id: doc._id
            }).count() === 0) {
              self._debug("[FilesCollection] [_preCollectionCursor.observe] [removeUnfinishedUpload]: ".concat(doc._id));

              self._currentUploads[doc._id].abort();
            }

            delete self._currentUploads[doc._id];
          }
        }

      });

      this._createStream = (_id, path, opts) => {
        this._currentUploads[_id] = new WriteStream(path, opts.fileLength, opts, this.permissions);
      }; // This little function allows to continue upload
      // even after server is restarted (*not on dev-stage*)


      this._continueUpload = _id => {
        if (this._currentUploads[_id] && this._currentUploads[_id].file) {
          if (!this._currentUploads[_id].aborted && !this._currentUploads[_id].ended) {
            return this._currentUploads[_id].file;
          }

          this._createStream(_id, this._currentUploads[_id].file.file.path, this._currentUploads[_id].file);

          return this._currentUploads[_id].file;
        }

        const contUpld = this._preCollection.findOne({
          _id
        });

        if (contUpld) {
          this._createStream(_id, contUpld.file.path, contUpld);

          return this._currentUploads[_id].file;
        }

        return false;
      };
    }

    if (!this.schema) {
      this.schema = FilesCollectionCore.schema;
    }

    check(this.debug, Boolean);
    check(this.schema, Object);
    check(this.public, Boolean);
    check(this.protected, Match.OneOf(Boolean, Function));
    check(this.chunkSize, Number);
    check(this.downloadRoute, String);
    check(this.namingFunction, Match.OneOf(false, Function));
    check(this.onBeforeUpload, Match.OneOf(false, Function));
    check(this.onInitiateUpload, Match.OneOf(false, Function));
    check(this.allowClientCode, Boolean);

    if (this.public && this.protected) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "]: Files can not be public and protected at the same time!"));
    }

    this._checkAccess = http => {
      if (this.protected) {
        let result;

        const {
          user,
          userId
        } = this._getUser(http);

        if (helpers.isFunction(this.protected)) {
          let fileRef;

          if (helpers.isObject(http.params) && http.params._id) {
            fileRef = this.collection.findOne(http.params._id);
          }

          result = http ? this.protected.call(Object.assign(http, {
            user,
            userId
          }), fileRef || null) : this.protected.call({
            user,
            userId
          }, fileRef || null);
        } else {
          result = !!userId;
        }

        if (http && result === true || !http) {
          return true;
        }

        const rc = helpers.isNumber(result) ? result : 401;

        this._debug('[FilesCollection._checkAccess] WARN: Access denied!');

        if (http) {
          const text = 'Access denied!';

          if (!http.response.headersSent) {
            http.response.writeHead(rc, {
              'Content-Type': 'text/plain',
              'Content-Length': text.length
            });
          }

          if (!http.response.finished) {
            http.response.end(text);
          }
        }

        return false;
      }

      return true;
    };

    this._methodNames = {
      _Abort: "_FilesCollectionAbort_".concat(this.collectionName),
      _Write: "_FilesCollectionWrite_".concat(this.collectionName),
      _Start: "_FilesCollectionStart_".concat(this.collectionName),
      _Remove: "_FilesCollectionRemove_".concat(this.collectionName)
    };
    this.on('_handleUpload', this._handleUpload);
    this.on('_finishUpload', this._finishUpload);
    this._handleUploadSync = Meteor.wrapAsync(this._handleUpload.bind(this));

    if (this.disableUpload && this.disableDownload) {
      return;
    }

    WebApp.connectHandlers.use((httpReq, httpResp, next) => {
      if (this.allowedOrigins && httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/")) && !httpResp.headersSent) {
        if (this.allowedOrigins.test(httpReq.headers.origin)) {
          httpResp.setHeader('Access-Control-Allow-Credentials', 'true');
          httpResp.setHeader('Access-Control-Allow-Origin', httpReq.headers.origin);
        }

        if (httpReq.method === 'OPTIONS') {
          httpResp.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
          httpResp.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type, x-mtok, x-start, x-chunkid, x-fileid, x-eof');
          httpResp.setHeader('Access-Control-Expose-Headers', 'Accept-Ranges, Content-Encoding, Content-Length, Content-Range');
          httpResp.setHeader('Allow', 'GET, POST, OPTIONS');
          httpResp.writeHead(200);
          httpResp.end();
          return;
        }
      }

      if (!this.disableUpload && httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/").concat(this.collectionName, "/__upload"))) {
        if (httpReq.method !== 'POST') {
          next();
          return;
        }

        const handleError = _error => {
          let error = _error;
          console.warn('[FilesCollection] [Upload] [HTTP] Exception:', error);
          console.trace();

          if (!httpResp.headersSent) {
            httpResp.writeHead(500);
          }

          if (!httpResp.finished) {
            if (helpers.isObject(error) && helpers.isFunction(error.toString)) {
              error = error.toString();
            }

            if (!helpers.isString(error)) {
              error = 'Unexpected error!';
            }

            httpResp.end(JSON.stringify({
              error
            }));
          }
        };

        let body = '';

        const handleData = () => {
          try {
            let opts;
            let result;
            let user;

            if (httpReq.headers['x-mtok'] && this._getUserId(httpReq.headers['x-mtok'])) {
              user = {
                userId: this._getUserId(httpReq.headers['x-mtok'])
              };
            } else {
              user = this._getUser({
                request: httpReq,
                response: httpResp
              });
            }

            if (httpReq.headers['x-start'] !== '1') {
              opts = {
                fileId: httpReq.headers['x-fileid']
              };

              if (httpReq.headers['x-eof'] === '1') {
                opts.eof = true;
              } else {
                opts.binData = Buffer.from(body, 'base64');
                opts.chunkId = parseInt(httpReq.headers['x-chunkid']);
              }

              const _continueUpload = this._continueUpload(opts.fileId);

              if (!_continueUpload) {
                throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');
              }

              ({
                result,
                opts
              } = this._prepareUpload(Object.assign(opts, _continueUpload), user.userId, 'HTTP'));

              if (opts.eof) {
                this._handleUpload(result, opts, _error => {
                  let error = _error;

                  if (error) {
                    if (!httpResp.headersSent) {
                      httpResp.writeHead(500);
                    }

                    if (!httpResp.finished) {
                      if (helpers.isObject(error) && helpers.isFunction(error.toString)) {
                        error = error.toString();
                      }

                      if (!helpers.isString(error)) {
                        error = 'Unexpected error!';
                      }

                      httpResp.end(JSON.stringify({
                        error
                      }));
                    }
                  }

                  if (!httpResp.headersSent) {
                    httpResp.writeHead(200);
                  }

                  if (helpers.isObject(result.file) && result.file.meta) {
                    result.file.meta = fixJSONStringify(result.file.meta);
                  }

                  if (!httpResp.finished) {
                    httpResp.end(JSON.stringify(result));
                  }
                });

                return;
              }

              this.emit('_handleUpload', result, opts, NOOP);

              if (!httpResp.headersSent) {
                httpResp.writeHead(204);
              }

              if (!httpResp.finished) {
                httpResp.end();
              }
            } else {
              try {
                opts = JSON.parse(body);
              } catch (jsonErr) {
                console.error('Can\'t parse incoming JSON from Client on [.insert() | upload], something went wrong!', jsonErr);
                opts = {
                  file: {}
                };
              }

              if (!helpers.isObject(opts.file)) {
                opts.file = {};
              }

              opts.___s = true;

              this._debug("[FilesCollection] [File Start HTTP] ".concat(opts.file.name || '[no-name]', " - ").concat(opts.fileId));

              if (helpers.isObject(opts.file) && opts.file.meta) {
                opts.file.meta = fixJSONParse(opts.file.meta);
              }

              ({
                result
              } = this._prepareUpload(helpers.clone(opts), user.userId, 'HTTP Start Method'));

              if (this.collection.findOne(result._id)) {
                throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');
              }

              opts._id = opts.fileId;
              opts.createdAt = new Date();
              opts.maxLength = opts.fileLength;

              this._preCollection.insert(helpers.omit(opts, '___s'));

              this._createStream(result._id, result.path, helpers.omit(opts, '___s'));

              if (opts.returnMeta) {
                if (!httpResp.headersSent) {
                  httpResp.writeHead(200);
                }

                if (!httpResp.finished) {
                  httpResp.end(JSON.stringify({
                    uploadRoute: "".concat(this.downloadRoute, "/").concat(this.collectionName, "/__upload"),
                    file: result
                  }));
                }
              } else {
                if (!httpResp.headersSent) {
                  httpResp.writeHead(204);
                }

                if (!httpResp.finished) {
                  httpResp.end();
                }
              }
            }
          } catch (httpRespErr) {
            handleError(httpRespErr);
          }
        };

        httpReq.setTimeout(20000, handleError);

        if (typeof httpReq.body === 'object' && Object.keys(httpReq.body).length !== 0) {
          body = JSON.stringify(httpReq.body);
          handleData();
        } else {
          httpReq.on('data', data => bound(() => {
            body += data;
          }));
          httpReq.on('end', () => bound(() => {
            handleData();
          }));
        }

        return;
      }

      if (!this.disableDownload) {
        let uri;

        if (!this.public) {
          if (httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/").concat(this.collectionName))) {
            uri = httpReq._parsedUrl.path.replace("".concat(this.downloadRoute, "/").concat(this.collectionName), '');

            if (uri.indexOf('/') === 0) {
              uri = uri.substring(1);
            }

            const uris = uri.split('/');

            if (uris.length === 3) {
              const params = {
                _id: uris[0],
                query: httpReq._parsedUrl.query ? nodeQs.parse(httpReq._parsedUrl.query) : {},
                name: uris[2].split('?')[0],
                version: uris[1]
              };
              const http = {
                request: httpReq,
                response: httpResp,
                params
              };

              if (this.interceptRequest && helpers.isFunction(this.interceptRequest) && this.interceptRequest(http) === true) {
                return;
              }

              if (this._checkAccess(http)) {
                this.download(http, uris[1], this.collection.findOne(uris[0]));
              }
            } else {
              next();
            }
          } else {
            next();
          }
        } else {
          if (httpReq._parsedUrl.path.includes("".concat(this.downloadRoute))) {
            uri = httpReq._parsedUrl.path.replace("".concat(this.downloadRoute), '');

            if (uri.indexOf('/') === 0) {
              uri = uri.substring(1);
            }

            const uris = uri.split('/');
            let _file = uris[uris.length - 1];

            if (_file) {
              let version;

              if (_file.includes('-')) {
                version = _file.split('-')[0];
                _file = _file.split('-')[1].split('?')[0];
              } else {
                version = 'original';
                _file = _file.split('?')[0];
              }

              const params = {
                query: httpReq._parsedUrl.query ? nodeQs.parse(httpReq._parsedUrl.query) : {},
                file: _file,
                _id: _file.split('.')[0],
                version,
                name: _file
              };
              const http = {
                request: httpReq,
                response: httpResp,
                params
              };

              if (this.interceptRequest && helpers.isFunction(this.interceptRequest) && this.interceptRequest(http) === true) {
                return;
              }

              this.download(http, version, this.collection.findOne(params._id));
            } else {
              next();
            }
          } else {
            next();
          }
        }

        return;
      }

      next();
    });

    if (!this.disableUpload) {
      const _methods = {}; // Method used to remove file
      // from Client side

      _methods[this._methodNames._Remove] = function (selector) {
        check(selector, Match.OneOf(String, Object));

        self._debug("[FilesCollection] [Unlink Method] [.remove(".concat(selector, ")]"));

        if (self.allowClientCode) {
          if (self.onBeforeRemove && helpers.isFunction(self.onBeforeRemove)) {
            const userId = this.userId;
            const userFuncs = {
              userId: this.userId,

              user() {
                if (Meteor.users) {
                  return Meteor.users.findOne(userId);
                }

                return null;
              }

            };

            if (!self.onBeforeRemove.call(userFuncs, self.find(selector) || null)) {
              throw new Meteor.Error(403, '[FilesCollection] [remove] Not permitted!');
            }
          }

          const cursor = self.find(selector);

          if (cursor.count() > 0) {
            self.remove(selector);
            return true;
          }

          throw new Meteor.Error(404, 'Cursor is empty, no files is removed');
        } else {
          throw new Meteor.Error(401, '[FilesCollection] [remove] Run code from client is not allowed!');
        }
      }; // Method used to receive "first byte" of upload
      // and all file's meta-data, so
      // it won't be transferred with every chunk
      // Basically it prepares everything
      // So user can pause/disconnect and
      // continue upload later, during `continueUploadTTL`


      _methods[this._methodNames._Start] = function (opts, returnMeta) {
        check(opts, {
          file: Object,
          fileId: String,
          FSName: Match.Optional(String),
          chunkSize: Number,
          fileLength: Number
        });
        check(returnMeta, Match.Optional(Boolean));

        self._debug("[FilesCollection] [File Start Method] ".concat(opts.file.name, " - ").concat(opts.fileId));

        opts.___s = true;

        const {
          result
        } = self._prepareUpload(helpers.clone(opts), this.userId, 'DDP Start Method');

        if (self.collection.findOne(result._id)) {
          throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');
        }

        opts._id = opts.fileId;
        opts.createdAt = new Date();
        opts.maxLength = opts.fileLength;

        try {
          self._preCollection.insert(helpers.omit(opts, '___s'));

          self._createStream(result._id, result.path, helpers.omit(opts, '___s'));
        } catch (e) {
          self._debug("[FilesCollection] [File Start Method] [EXCEPTION:] ".concat(opts.file.name, " - ").concat(opts.fileId), e);

          throw new Meteor.Error(500, 'Can\'t start');
        }

        if (returnMeta) {
          return {
            uploadRoute: "".concat(self.downloadRoute, "/").concat(self.collectionName, "/__upload"),
            file: result
          };
        }

        return true;
      }; // Method used to write file chunks
      // it receives very limited amount of meta-data
      // This method also responsible for EOF


      _methods[this._methodNames._Write] = function (_opts) {
        let opts = _opts;
        let result;
        check(opts, {
          eof: Match.Optional(Boolean),
          fileId: String,
          binData: Match.Optional(String),
          chunkId: Match.Optional(Number)
        });

        if (opts.binData) {
          opts.binData = Buffer.from(opts.binData, 'base64');
        }

        const _continueUpload = self._continueUpload(opts.fileId);

        if (!_continueUpload) {
          throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');
        }

        this.unblock();
        ({
          result,
          opts
        } = self._prepareUpload(Object.assign(opts, _continueUpload), this.userId, 'DDP'));

        if (opts.eof) {
          try {
            return self._handleUploadSync(result, opts);
          } catch (handleUploadErr) {
            self._debug('[FilesCollection] [Write Method] [DDP] Exception:', handleUploadErr);

            throw handleUploadErr;
          }
        } else {
          self.emit('_handleUpload', result, opts, NOOP);
        }

        return true;
      }; // Method used to Abort upload
      // - Feeing memory by .end()ing writableStreams
      // - Removing temporary record from @_preCollection
      // - Removing record from @collection
      // - .unlink()ing chunks from FS


      _methods[this._methodNames._Abort] = function (_id) {
        check(_id, String);

        const _continueUpload = self._continueUpload(_id);

        self._debug("[FilesCollection] [Abort Method]: ".concat(_id, " - ").concat(helpers.isObject(_continueUpload.file) ? _continueUpload.file.path : ''));

        if (self._currentUploads && self._currentUploads[_id]) {
          self._currentUploads[_id].stop();

          self._currentUploads[_id].abort();
        }

        if (_continueUpload) {
          self._preCollection.remove({
            _id
          });

          self.remove({
            _id
          });

          if (helpers.isObject(_continueUpload.file) && _continueUpload.file.path) {
            self.unlink({
              _id,
              path: _continueUpload.file.path
            });
          }
        }

        return true;
      };

      Meteor.methods(_methods);
    }
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _prepareUpload
   * @summary Internal method. Used to optimize received data and check upload permission
   * @returns {Object}
   */


  _prepareUpload() {
    let opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let userId = arguments.length > 1 ? arguments[1] : undefined;
    let transport = arguments.length > 2 ? arguments[2] : undefined;
    let ctx;

    if (!helpers.isBoolean(opts.eof)) {
      opts.eof = false;
    }

    if (!opts.binData) {
      opts.binData = 'EOF';
    }

    if (!helpers.isNumber(opts.chunkId)) {
      opts.chunkId = -1;
    }

    if (!helpers.isString(opts.FSName)) {
      opts.FSName = opts.fileId;
    }

    this._debug("[FilesCollection] [Upload] [".concat(transport, "] Got #").concat(opts.chunkId, "/").concat(opts.fileLength, " chunks, dst: ").concat(opts.file.name || opts.file.fileName));

    const fileName = this._getFileName(opts.file);

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    if (!helpers.isObject(opts.file.meta)) {
      opts.file.meta = {};
    }

    let result = opts.file;
    result.name = fileName;
    result.meta = opts.file.meta;
    result.extension = extension;
    result.ext = extension;
    result._id = opts.fileId;
    result.userId = userId || null;
    opts.FSName = opts.FSName.replace(/([^a-z0-9\-\_]+)/gi, '-');
    result.path = "".concat(this.storagePath(result)).concat(nodePath.sep).concat(opts.FSName).concat(extensionWithDot);
    result = Object.assign(result, this._dataToSchema(result));

    if (this.onBeforeUpload && helpers.isFunction(this.onBeforeUpload)) {
      ctx = Object.assign({
        file: opts.file
      }, {
        chunkId: opts.chunkId,
        userId: result.userId,

        user() {
          if (Meteor.users && result.userId) {
            return Meteor.users.findOne(result.userId);
          }

          return null;
        },

        eof: opts.eof
      });
      const isUploadAllowed = this.onBeforeUpload.call(ctx, result);

      if (isUploadAllowed !== true) {
        throw new Meteor.Error(403, helpers.isString(isUploadAllowed) ? isUploadAllowed : '@onBeforeUpload() returned false');
      } else {
        if (opts.___s === true && this.onInitiateUpload && helpers.isFunction(this.onInitiateUpload)) {
          this.onInitiateUpload.call(ctx, result);
        }
      }
    } else if (opts.___s === true && this.onInitiateUpload && helpers.isFunction(this.onInitiateUpload)) {
      ctx = Object.assign({
        file: opts.file
      }, {
        chunkId: opts.chunkId,
        userId: result.userId,

        user() {
          if (Meteor.users && result.userId) {
            return Meteor.users.findOne(result.userId);
          }

          return null;
        },

        eof: opts.eof
      });
      this.onInitiateUpload.call(ctx, result);
    }

    return {
      result,
      opts
    };
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _finishUpload
   * @summary Internal method. Finish upload, close Writable stream, add record to MongoDB and flush used memory
   * @returns {undefined}
   */


  _finishUpload(result, opts, cb) {
    this._debug("[FilesCollection] [Upload] [finish(ing)Upload] -> ".concat(result.path));

    fs.chmod(result.path, this.permissions, NOOP);
    result.type = this._getMimeType(opts.file);
    result.public = this.public;

    this._updateFileTypes(result);

    this.collection.insert(helpers.clone(result), (colInsert, _id) => {
      if (colInsert) {
        cb && cb(colInsert);

        this._debug('[FilesCollection] [Upload] [_finishUpload] [insert] Error:', colInsert);
      } else {
        this._preCollection.update({
          _id: opts.fileId
        }, {
          $set: {
            isFinished: true
          }
        }, preUpdateError => {
          if (preUpdateError) {
            cb && cb(preUpdateError);

            this._debug('[FilesCollection] [Upload] [_finishUpload] [update] Error:', preUpdateError);
          } else {
            result._id = _id;

            this._debug("[FilesCollection] [Upload] [finish(ed)Upload] -> ".concat(result.path));

            this.onAfterUpload && this.onAfterUpload.call(this, result);
            this.emit('afterUpload', result);
            cb && cb(null, result);
          }
        });
      }
    });
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _handleUpload
   * @summary Internal method to handle upload process, pipe incoming data to Writable stream
   * @returns {undefined}
   */


  _handleUpload(result, opts, cb) {
    try {
      if (opts.eof) {
        this._currentUploads[result._id].end(() => {
          this.emit('_finishUpload', result, opts, cb);
        });
      } else {
        this._currentUploads[result._id].write(opts.chunkId, opts.binData, cb);
      }
    } catch (e) {
      this._debug('[_handleUpload] [EXCEPTION:]', e);

      cb && cb(e);
    }
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getMimeType
   * @param {Object} fileData - File Object
   * @summary Returns file's mime-type
   * @returns {String}
   */


  _getMimeType(fileData) {
    let mime;
    check(fileData, Object);

    if (helpers.isObject(fileData) && fileData.type) {
      mime = fileData.type;
    }

    if (fileData.path && (!mime || !helpers.isString(mime))) {
      try {
        let buf = Buffer.alloc(262);
        const fd = fs.openSync(fileData.path, 'r');
        const br = fs.readSync(fd, buf, 0, 262, 0);
        fs.close(fd, NOOP);

        if (br < 262) {
          buf = buf.slice(0, br);
        }

        ({
          mime
        } = fileType(buf));
      } catch (e) {// We're good
      }
    }

    if (!mime || !helpers.isString(mime)) {
      mime = 'application/octet-stream';
    }

    return mime;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getUserId
   * @summary Returns `userId` matching the xmtok token derived from Meteor.server.sessions
   * @returns {String}
   */


  _getUserId(xmtok) {
    if (!xmtok) return null; // throw an error upon an unexpected type of Meteor.server.sessions in order to identify breaking changes

    if (!Meteor.server.sessions instanceof Map || !helpers.isObject(Meteor.server.sessions)) {
      throw new Error('Received incompatible type of Meteor.server.sessions');
    }

    if (Meteor.server.sessions instanceof Map && Meteor.server.sessions.has(xmtok) && helpers.isObject(Meteor.server.sessions.get(xmtok))) {
      // to be used with >= Meteor 1.8.1 where Meteor.server.sessions is a Map
      return Meteor.server.sessions.get(xmtok).userId;
    } else if (helpers.isObject(Meteor.server.sessions) && xmtok in Meteor.server.sessions && helpers.isObject(Meteor.server.sessions[xmtok])) {
      // to be used with < Meteor 1.8.1 where Meteor.server.sessions is an Object
      return Meteor.server.sessions[xmtok].userId;
    }

    return null;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getUser
   * @summary Returns object with `userId` and `user()` method which return user's object
   * @returns {Object}
   */


  _getUser(http) {
    const result = {
      user() {
        return null;
      },

      userId: null
    };

    if (http) {
      let mtok = null;

      if (http.request.headers['x-mtok']) {
        mtok = http.request.headers['x-mtok'];
      } else {
        const cookie = http.request.Cookies;

        if (cookie.has('x_mtok')) {
          mtok = cookie.get('x_mtok');
        }
      }

      if (mtok) {
        const userId = this._getUserId(mtok);

        if (userId) {
          result.user = () => Meteor.users.findOne(userId);

          result.userId = userId;
        }
      }
    }

    return result;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name write
   * @param {Buffer} buffer - Binary File's Buffer
   * @param {Object} opts - Object with file-data
   * @param {String} opts.name - File name, alias: `fileName`
   * @param {String} opts.type - File mime-type
   * @param {Object} opts.meta - File additional meta-data
   * @param {String} opts.userId - UserId, default *null*
   * @param {String} opts.fileId - _id, default *null*
   * @param {Function} callback - function(error, fileObj){...}
   * @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook
   * @summary Write buffer to FS and add to FilesCollection Collection
   * @returns {FilesCollection} Instance
   */


  write(buffer) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 ? arguments[3] : undefined;

    this._debug('[FilesCollection] [write()]');

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));
    const fileId = opts.fileId || Random.id();
    const FSName = this.namingFunction ? this.namingFunction(opts) : fileId;
    const fileName = opts.name || opts.fileName ? opts.name || opts.fileName : FSName;

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    opts.path = "".concat(this.storagePath(opts)).concat(nodePath.sep).concat(FSName).concat(extensionWithDot);
    opts.type = this._getMimeType(opts);

    if (!helpers.isObject(opts.meta)) {
      opts.meta = {};
    }

    if (!helpers.isNumber(opts.size)) {
      opts.size = buffer.length;
    }

    const result = this._dataToSchema({
      name: fileName,
      path: opts.path,
      meta: opts.meta,
      type: opts.type,
      size: opts.size,
      userId: opts.userId,
      extension
    });

    result._id = fileId;
    fs.ensureFile(opts.path, efError => {
      bound(() => {
        if (efError) {
          callback && callback(efError);

          this._debug("[FilesCollection] [write] [ensureFile] [Error:] ".concat(fileName, " -> ").concat(opts.path), efError);
        } else {
          const stream = fs.createWriteStream(opts.path, {
            flags: 'w',
            mode: this.permissions
          });
          stream.end(buffer, streamErr => {
            bound(() => {
              if (streamErr) {
                callback && callback(streamErr);
              } else {
                this.collection.insert(result, (insertErr, _id) => {
                  if (insertErr) {
                    callback && callback(insertErr);

                    this._debug("[FilesCollection] [write] [insert] Error: ".concat(fileName, " -> ").concat(this.collectionName), insertErr);
                  } else {
                    const fileRef = this.collection.findOne(_id);
                    callback && callback(null, fileRef);

                    if (proceedAfterUpload === true) {
                      this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
                      this.emit('afterUpload', fileRef);
                    }

                    this._debug("[FilesCollection] [write]: ".concat(fileName, " -> ").concat(this.collectionName));
                  }
                });
              }
            });
          });
        }
      });
    });
    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name load
   * @param {String} url - URL to file
   * @param {Object} opts - Object with file-data
   * @param {Object} opts.headers - HTTP headers to use when requesting the file
   * @param {String} opts.name - File name, alias: `fileName`
   * @param {String} opts.type - File mime-type
   * @param {Object} opts.meta - File additional meta-data
   * @param {String} opts.userId - UserId, default *null*
   * @param {String} opts.fileId - _id, default *null*
   * @param {Function} callback - function(error, fileObj){...}
   * @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook
   * @summary Download file, write stream to FS and add to FilesCollection Collection
   * @returns {FilesCollection} Instance
   */


  load(url) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 ? arguments[3] : undefined;

    this._debug("[FilesCollection] [load(".concat(url, ", ").concat(JSON.stringify(_opts), ", callback)]"));

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    check(url, String);
    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));

    if (!helpers.isObject(opts)) {
      opts = {};
    }

    const fileId = opts.fileId || Random.id();
    const FSName = this.namingFunction ? this.namingFunction(opts) : fileId;
    const pathParts = url.split('/');
    const fileName = opts.name || opts.fileName ? opts.name || opts.fileName : pathParts[pathParts.length - 1] || FSName;

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    opts.path = "".concat(this.storagePath(opts)).concat(nodePath.sep).concat(FSName).concat(extensionWithDot);

    const storeResult = (result, cb) => {
      result._id = fileId;
      this.collection.insert(result, (error, _id) => {
        if (error) {
          cb && cb(error);

          this._debug("[FilesCollection] [load] [insert] Error: ".concat(fileName, " -> ").concat(this.collectionName), error);
        } else {
          const fileRef = this.collection.findOne(_id);
          cb && cb(null, fileRef);

          if (proceedAfterUpload === true) {
            this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
            this.emit('afterUpload', fileRef);
          }

          this._debug("[FilesCollection] [load] [insert] ".concat(fileName, " -> ").concat(this.collectionName));
        }
      });
    };

    fs.ensureFile(opts.path, efError => {
      bound(() => {
        if (efError) {
          callback && callback(efError);

          this._debug("[FilesCollection] [load] [ensureFile] [Error:] ".concat(fileName, " -> ").concat(opts.path), efError);
        } else {
          request({
            url,
            headers: opts.headers || {},
            wait: true
          }, (reqError, response) => bound(() => {
            if (reqError) {
              callback && callback(reqError);

              this._debug("[FilesCollection] [load] [request.get(".concat(url, ")] Error:"), reqError);
            } else {
              this._debug("[FilesCollection] [load] Received: ".concat(url));

              const result = this._dataToSchema({
                name: fileName,
                path: opts.path,
                meta: opts.meta,
                type: opts.type || response.headers['content-type'] || this._getMimeType({
                  path: opts.path
                }),
                size: opts.size || parseInt(response.headers['content-length'] || 0),
                userId: opts.userId,
                extension
              });

              if (!result.size) {
                fs.stat(opts.path, (error, stats) => bound(() => {
                  if (error) {
                    callback && callback(error);
                  } else {
                    result.versions.original.size = result.size = stats.size;
                    storeResult(result, callback);
                  }
                }));
              } else {
                storeResult(result, callback);
              }
            }
          })).pipe(fs.createWriteStream(opts.path, {
            flags: 'w',
            mode: this.permissions
          })).send();
        }
      });
    });
    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name addFile
   * @param {String} path          - Path to file
   * @param {String} opts          - [Optional] Object with file-data
   * @param {String} opts.type     - [Optional] File mime-type
   * @param {Object} opts.meta     - [Optional] File additional meta-data
   * @param {String} opts.fileId   - _id, default *null*
   * @param {Object} opts.fileName - [Optional] File name, if not specified file name and extension will be taken from path
   * @param {String} opts.userId   - [Optional] UserId, default *null*
   * @param {Function} callback    - [Optional] function(error, fileObj){...}
   * @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook
   * @summary Add file from FS to FilesCollection
   * @returns {FilesCollection} Instance
   */


  addFile(path) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 ? arguments[3] : undefined;

    this._debug("[FilesCollection] [addFile(".concat(path, ")]"));

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    if (this.public) {
      throw new Meteor.Error(403, 'Can not run [addFile] on public collection! Just Move file to root of your server, then add record to Collection');
    }

    check(path, String);
    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));
    fs.stat(path, (statErr, stats) => bound(() => {
      if (statErr) {
        callback && callback(statErr);
      } else if (stats.isFile()) {
        if (!helpers.isObject(opts)) {
          opts = {};
        }

        opts.path = path;

        if (!opts.fileName) {
          const pathParts = path.split(nodePath.sep);
          opts.fileName = path.split(nodePath.sep)[pathParts.length - 1];
        }

        const {
          extension
        } = this._getExt(opts.fileName);

        if (!helpers.isString(opts.type)) {
          opts.type = this._getMimeType(opts);
        }

        if (!helpers.isObject(opts.meta)) {
          opts.meta = {};
        }

        if (!helpers.isNumber(opts.size)) {
          opts.size = stats.size;
        }

        const result = this._dataToSchema({
          name: opts.fileName,
          path,
          meta: opts.meta,
          type: opts.type,
          size: opts.size,
          userId: opts.userId,
          extension,
          _storagePath: path.replace("".concat(nodePath.sep).concat(opts.fileName), ''),
          fileId: opts.fileId || null
        });

        this.collection.insert(result, (insertErr, _id) => {
          if (insertErr) {
            callback && callback(insertErr);

            this._debug("[FilesCollection] [addFile] [insert] Error: ".concat(result.name, " -> ").concat(this.collectionName), insertErr);
          } else {
            const fileRef = this.collection.findOne(_id);
            callback && callback(null, fileRef);

            if (proceedAfterUpload === true) {
              this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
              this.emit('afterUpload', fileRef);
            }

            this._debug("[FilesCollection] [addFile]: ".concat(result.name, " -> ").concat(this.collectionName));
          }
        });
      } else {
        callback && callback(new Meteor.Error(400, "[FilesCollection] [addFile(".concat(path, ")]: File does not exist")));
      }
    }));
    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name remove
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Function} callback - Callback with one `error` argument
   * @summary Remove documents from the collection
   * @returns {FilesCollection} Instance
   */


  remove(selector, callback) {
    this._debug("[FilesCollection] [remove(".concat(JSON.stringify(selector), ")]"));

    if (selector === void 0) {
      return 0;
    }

    check(callback, Match.Optional(Function));
    const files = this.collection.find(selector);

    if (files.count() > 0) {
      files.forEach(file => {
        this.unlink(file);
      });
    } else {
      callback && callback(new Meteor.Error(404, 'Cursor is empty, no files is removed'));
      return this;
    }

    if (this.onAfterRemove) {
      const docs = files.fetch();
      const self = this;
      this.collection.remove(selector, function () {
        callback && callback.apply(this, arguments);
        self.onAfterRemove(docs);
      });
    } else {
      this.collection.remove(selector, callback || NOOP);
    }

    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name deny
   * @param {Object} rules
   * @see  https://docs.meteor.com/api/collections.html#Mongo-Collection-deny
   * @summary link Mongo.Collection deny methods
   * @returns {Mongo.Collection} Instance
   */


  deny(rules) {
    this.collection.deny(rules);
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name allow
   * @param {Object} rules
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow
   * @summary link Mongo.Collection allow methods
   * @returns {Mongo.Collection} Instance
   */


  allow(rules) {
    this.collection.allow(rules);
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name denyClient
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-deny
   * @summary Shorthands for Mongo.Collection deny method
   * @returns {Mongo.Collection} Instance
   */


  denyClient() {
    this.collection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name allowClient
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow
   * @summary Shorthands for Mongo.Collection allow method
   * @returns {Mongo.Collection} Instance
   */


  allowClient() {
    this.collection.allow({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name unlink
   * @param {Object} fileRef - fileObj
   * @param {String} version - [Optional] file's version
   * @param {Function} callback - [Optional] callback function
   * @summary Unlink files and it's versions from FS
   * @returns {FilesCollection} Instance
   */


  unlink(fileRef, version, callback) {
    this._debug("[FilesCollection] [unlink(".concat(fileRef._id, ", ").concat(version, ")]"));

    if (version) {
      if (helpers.isObject(fileRef.versions) && helpers.isObject(fileRef.versions[version]) && fileRef.versions[version].path) {
        fs.unlink(fileRef.versions[version].path, callback || NOOP);
      }
    } else {
      if (helpers.isObject(fileRef.versions)) {
        for (let vKey in fileRef.versions) {
          if (fileRef.versions[vKey] && fileRef.versions[vKey].path) {
            fs.unlink(fileRef.versions[vKey].path, callback || NOOP);
          }
        }
      } else {
        fs.unlink(fileRef.path, callback || NOOP);
      }
    }

    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _404
   * @summary Internal method, used to return 404 error
   * @returns {undefined}
   */


  _404(http) {
    this._debug("[FilesCollection] [download(".concat(http.request.originalUrl, ")] [_404] File not found"));

    const text = 'File Not Found :(';

    if (!http.response.headersSent) {
      http.response.writeHead(404, {
        'Content-Type': 'text/plain',
        'Content-Length': text.length
      });
    }

    if (!http.response.finished) {
      http.response.end(text);
    }
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name download
   * @param {Object} http    - Server HTTP object
   * @param {String} version - Requested file version
   * @param {Object} fileRef - Requested file Object
   * @summary Initiates the HTTP response
   * @returns {undefined}
   */


  download(http) {
    let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';
    let fileRef = arguments.length > 2 ? arguments[2] : undefined;
    let vRef;

    this._debug("[FilesCollection] [download(".concat(http.request.originalUrl, ", ").concat(version, ")]"));

    if (fileRef) {
      if (helpers.has(fileRef, 'versions') && helpers.has(fileRef.versions, version)) {
        vRef = fileRef.versions[version];
        vRef._id = fileRef._id;
      } else {
        vRef = fileRef;
      }
    } else {
      vRef = false;
    }

    if (!vRef || !helpers.isObject(vRef)) {
      return this._404(http);
    } else if (fileRef) {
      if (this.downloadCallback) {
        if (!this.downloadCallback.call(Object.assign(http, this._getUser(http)), fileRef)) {
          return this._404(http);
        }
      }

      if (this.interceptDownload && helpers.isFunction(this.interceptDownload) && this.interceptDownload(http, fileRef, version) === true) {
        return void 0;
      }

      fs.stat(vRef.path, (statErr, stats) => bound(() => {
        let responseType;

        if (statErr || !stats.isFile()) {
          return this._404(http);
        }

        if (stats.size !== vRef.size && !this.integrityCheck) {
          vRef.size = stats.size;
        }

        if (stats.size !== vRef.size && this.integrityCheck) {
          responseType = '400';
        }

        return this.serve(http, fileRef, vRef, version, null, responseType || '200');
      }));
      return void 0;
    }

    return this._404(http);
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name serve
   * @param {Object} http    - Server HTTP object
   * @param {Object} fileRef - Requested file Object
   * @param {Object} vRef    - Requested file version Object
   * @param {String} version - Requested file version
   * @param {stream.Readable|null} readableStream - Readable stream, which serves binary file data
   * @param {String} responseType - Response code
   * @param {Boolean} force200 - Force 200 response code over 206
   * @summary Handle and reply to incoming request
   * @returns {undefined}
   */


  serve(http, fileRef, vRef) {
    let version = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'original';
    let readableStream = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;

    let _responseType = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : '200';

    let force200 = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;
    let partiral = false;
    let reqRange = false;
    let dispositionType = '';
    let start;
    let end;
    let take;
    let responseType = _responseType;

    if (http.params.query.download && http.params.query.download === 'true') {
      dispositionType = 'attachment; ';
    } else {
      dispositionType = 'inline; ';
    }

    const dispositionName = "filename=\"".concat(encodeURI(vRef.name || fileRef.name).replace(/\,/g, '%2C'), "\"; filename*=UTF-8''").concat(encodeURIComponent(vRef.name || fileRef.name), "; ");
    const dispositionEncoding = 'charset=UTF-8';

    if (!http.response.headersSent) {
      http.response.setHeader('Content-Disposition', dispositionType + dispositionName + dispositionEncoding);
    }

    if (http.request.headers.range && !force200) {
      partiral = true;
      const array = http.request.headers.range.split(/bytes=([0-9]*)-([0-9]*)/);
      start = parseInt(array[1]);
      end = parseInt(array[2]);

      if (isNaN(end)) {
        end = vRef.size - 1;
      }

      take = end - start;
    } else {
      start = 0;
      end = vRef.size - 1;
      take = vRef.size;
    }

    if (partiral || http.params.query.play && http.params.query.play === 'true') {
      reqRange = {
        start,
        end
      };

      if (isNaN(start) && !isNaN(end)) {
        reqRange.start = end - take;
        reqRange.end = end;
      }

      if (!isNaN(start) && isNaN(end)) {
        reqRange.start = start;
        reqRange.end = start + take;
      }

      if (start + take >= vRef.size) {
        reqRange.end = vRef.size - 1;
      }

      if (this.strict && (reqRange.start >= vRef.size - 1 || reqRange.end > vRef.size - 1)) {
        responseType = '416';
      } else {
        responseType = '206';
      }
    } else {
      responseType = '200';
    }

    const streamErrorHandler = error => {
      this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [500]"), error);

      if (!http.response.finished) {
        http.response.end(error.toString());
      }
    };

    const headers = helpers.isFunction(this.responseHeaders) ? this.responseHeaders(responseType, fileRef, vRef, version, http) : this.responseHeaders;

    if (!headers['Cache-Control']) {
      if (!http.response.headersSent) {
        http.response.setHeader('Cache-Control', this.cacheControl);
      }
    }

    for (let key in headers) {
      if (!http.response.headersSent) {
        http.response.setHeader(key, headers[key]);
      }
    }

    const respond = (stream, code) => {
      stream._isEnded = false;

      const closeStreamCb = closeError => {
        if (!closeError) {
          stream._isEnded = true;
        } else {
          this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [respond] [closeStreamCb] Error:"), closeError);
        }
      };

      const closeStream = () => {
        if (!stream._isEnded) {
          if (typeof stream.close === 'function') {
            stream.close(closeStreamCb);
          } else if (typeof stream.end === 'function') {
            stream.end(closeStreamCb);
          } else if (typeof stream.destroy === 'function') {
            stream.destroy('Got to close this stream', closeStreamCb);
          }
        }
      };

      if (!http.response.headersSent && readableStream) {
        http.response.writeHead(code);
      }

      http.response.on('close', closeStream);
      http.request.on('aborted', () => {
        http.request.aborted = true;
        closeStream();
      });
      stream.on('open', () => {
        if (!http.response.headersSent) {
          http.response.writeHead(code);
        }
      }).on('abort', () => {
        closeStream();

        if (!http.response.finished) {
          http.response.end();
        }

        if (!http.request.aborted) {
          http.request.destroy();
        }
      }).on('error', err => {
        closeStream();
        streamErrorHandler(err);
      }).on('end', () => {
        closeStream();

        if (!http.response.finished) {
          http.response.end();
        }
      }).pipe(http.response);
    };

    switch (responseType) {
      case '400':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [400] Content-Length mismatch!"));

        var text = 'Content-Length mismatch!';

        if (!http.response.headersSent) {
          http.response.writeHead(400, {
            'Content-Type': 'text/plain',
            'Content-Length': text.length
          });
        }

        if (!http.response.finished) {
          http.response.end(text);
        }

        break;

      case '404':
        this._404(http);

        break;

      case '416':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [416] Content-Range is not specified!"));

        if (!http.response.headersSent) {
          http.response.writeHead(416);
        }

        if (!http.response.finished) {
          http.response.end();
        }

        break;

      case '206':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [206]"));

        if (!http.response.headersSent) {
          http.response.setHeader('Content-Range', "bytes ".concat(reqRange.start, "-").concat(reqRange.end, "/").concat(vRef.size));
        }

        respond(readableStream || fs.createReadStream(vRef.path, {
          start: reqRange.start,
          end: reqRange.end
        }), 206);
        break;

      default:
        if (!http.response.headersSent) {
          http.response.setHeader('Content-Length', "".concat(vRef.size));
        }

        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [200]"));

        respond(readableStream || fs.createReadStream(vRef.path), 200);
        break;
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"core.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/core.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => FilesCollectionCore
});
let EventEmitter;
module.link("eventemitter3", {
  EventEmitter(v) {
    EventEmitter = v;
  }

}, 0);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 1);
let formatFleURL, helpers;
module.link("./lib.js", {
  formatFleURL(v) {
    formatFleURL = v;
  },

  helpers(v) {
    helpers = v;
  }

}, 2);
let FilesCursor, FileCursor;
module.link("./cursor.js", {
  FilesCursor(v) {
    FilesCursor = v;
  },

  FileCursor(v) {
    FileCursor = v;
  }

}, 3);

class FilesCollectionCore extends EventEmitter {
  constructor() {
    super();
  }

  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _debug
   * @summary Print logs in debug mode
   * @returns {void}
   */
  _debug() {
    if (this.debug) {
      (console.info || console.log || function () {}).apply(void 0, arguments);
    }
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _getFileName
   * @param {Object} fileData - File Object
   * @summary Returns file's name
   * @returns {String}
   */


  _getFileName(fileData) {
    const fileName = fileData.name || fileData.fileName;

    if (helpers.isString(fileName) && fileName.length > 0) {
      return (fileData.name || fileData.fileName).replace(/^\.\.+/, '').replace(/\.{2,}/g, '.').replace(/\//g, '');
    }

    return '';
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _getExt
   * @param {String} FileName - File name
   * @summary Get extension from FileName
   * @returns {Object}
   */


  _getExt(fileName) {
    if (fileName.includes('.')) {
      const extension = (fileName.split('.').pop().split('?')[0] || '').toLowerCase();
      return {
        ext: extension,
        extension,
        extensionWithDot: ".".concat(extension)
      };
    }

    return {
      ext: '',
      extension: '',
      extensionWithDot: ''
    };
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _updateFileTypes
   * @param {Object} data - File data
   * @summary Internal method. Classify file based on 'type' field
   */


  _updateFileTypes(data) {
    data.isVideo = /^video\//i.test(data.type);
    data.isAudio = /^audio\//i.test(data.type);
    data.isImage = /^image\//i.test(data.type);
    data.isText = /^text\//i.test(data.type);
    data.isJSON = /^application\/json$/i.test(data.type);
    data.isPDF = /^application\/(x-)?pdf$/i.test(data.type);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _dataToSchema
   * @param {Object} data - File data
   * @summary Internal method. Build object in accordance with default schema from File data
   * @returns {Object}
   */


  _dataToSchema(data) {
    const ds = {
      name: data.name,
      extension: data.extension,
      ext: data.extension,
      extensionWithDot: '.' + data.extension,
      path: data.path,
      meta: data.meta,
      type: data.type,
      mime: data.type,
      'mime-type': data.type,
      size: data.size,
      userId: data.userId || null,
      versions: {
        original: {
          path: data.path,
          size: data.size,
          type: data.type,
          extension: data.extension
        }
      },
      _downloadRoute: data._downloadRoute || this.downloadRoute,
      _collectionName: data._collectionName || this.collectionName
    }; //Optional fileId

    if (data.fileId) {
      ds._id = data.fileId;
    }

    this._updateFileTypes(ds);

    ds._storagePath = data._storagePath || this.storagePath(Object.assign({}, data, ds));
    return ds;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name findOne
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Object} options - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)
   * @summary Find and return Cursor for matching document Object
   * @returns {FileCursor} Instance
   */


  findOne() {
    let selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let options = arguments.length > 1 ? arguments[1] : undefined;

    this._debug("[FilesCollection] [findOne(".concat(JSON.stringify(selector), ", ").concat(JSON.stringify(options), ")]"));

    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));
    check(options, Match.Optional(Object));
    const doc = this.collection.findOne(selector, options);

    if (doc) {
      return new FileCursor(doc, this);
    }

    return doc;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name find
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Object}        options  - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)
   * @summary Find and return Cursor for matching documents
   * @returns {FilesCursor} Instance
   */


  find() {
    let selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let options = arguments.length > 1 ? arguments[1] : undefined;

    this._debug("[FilesCollection] [find(".concat(JSON.stringify(selector), ", ").concat(JSON.stringify(options), ")]"));

    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));
    check(options, Match.Optional(Object));
    return new FilesCursor(selector, options, this);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name update
   * @see http://docs.meteor.com/#/full/update
   * @summary link Mongo.Collection update method
   * @returns {Mongo.Collection} Instance
   */


  update() {
    this.collection.update.apply(this.collection, arguments);
    return this.collection;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name link
   * @param {Object} fileRef - File reference object
   * @param {String} version - Version of file you would like to request
   * @param {String} URIBase - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
   * @summary Returns downloadable URL
   * @returns {String} Empty string returned in case if file not found in DB
   */


  link(fileRef) {
    let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';
    let URIBase = arguments.length > 2 ? arguments[2] : undefined;

    this._debug("[FilesCollection] [link(".concat(helpers.isObject(fileRef) ? fileRef._id : void 0, ", ").concat(version, ")]"));

    check(fileRef, Object);

    if (!fileRef) {
      return '';
    }

    return formatFleURL(fileRef, version, URIBase);
  }

}

FilesCollectionCore.__helpers = helpers;
FilesCollectionCore.schema = {
  _id: {
    type: String
  },
  size: {
    type: Number
  },
  name: {
    type: String
  },
  type: {
    type: String
  },
  path: {
    type: String
  },
  isVideo: {
    type: Boolean
  },
  isAudio: {
    type: Boolean
  },
  isImage: {
    type: Boolean
  },
  isText: {
    type: Boolean
  },
  isJSON: {
    type: Boolean
  },
  isPDF: {
    type: Boolean
  },
  extension: {
    type: String,
    optional: true
  },
  ext: {
    type: String,
    optional: true
  },
  extensionWithDot: {
    type: String,
    optional: true
  },
  mime: {
    type: String,
    optional: true
  },
  'mime-type': {
    type: String,
    optional: true
  },
  _storagePath: {
    type: String
  },
  _downloadRoute: {
    type: String
  },
  _collectionName: {
    type: String
  },
  public: {
    type: Boolean,
    optional: true
  },
  meta: {
    type: Object,
    blackbox: true,
    optional: true
  },
  userId: {
    type: String,
    optional: true
  },
  updatedAt: {
    type: Date,
    optional: true
  },
  versions: {
    type: Object,
    blackbox: true
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/cursor.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FileCursor: () => FileCursor,
  FilesCursor: () => FilesCursor
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

class FileCursor {
  constructor(_fileRef, _collection) {
    this._fileRef = _fileRef;
    this._collection = _collection;
    Object.assign(this, _fileRef);
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name remove
   * @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed
   * @summary Remove document
   * @returns {FileCursor}
   */


  remove(callback) {
    this._collection._debug('[FilesCollection] [FileCursor] [remove()]');

    if (this._fileRef) {
      this._collection.remove(this._fileRef._id, callback);
    } else {
      callback && callback(new Meteor.Error(404, 'No such file'));
    }

    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name link
   * @param version {String} - Name of file's subversion
   * @param URIBase {String} - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
   * @summary Returns downloadable URL to File
   * @returns {String}
   */


  link() {
    let version = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'original';
    let URIBase = arguments.length > 1 ? arguments[1] : undefined;

    this._collection._debug("[FilesCollection] [FileCursor] [link(".concat(version, ")]"));

    if (this._fileRef) {
      return this._collection.link(this._fileRef, version, URIBase);
    }

    return '';
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name get
   * @param property {String} - Name of sub-object property
   * @summary Returns current document as a plain Object, if `property` is specified - returns value of sub-object property
   * @returns {Object|mix}
   */


  get(property) {
    this._collection._debug("[FilesCollection] [FileCursor] [get(".concat(property, ")]"));

    if (property) {
      return this._fileRef[property];
    }

    return this._fileRef;
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name fetch
   * @summary Returns document as plain Object in Array
   * @returns {[Object]}
   */


  fetch() {
    this._collection._debug('[FilesCollection] [FileCursor] [fetch()]');

    return [this._fileRef];
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name with
   * @summary Returns reactive version of current FileCursor, useful to use with `{{#with}}...{{/with}}` block template helper
   * @returns {[Object]}
   */


  with() {
    this._collection._debug('[FilesCollection] [FileCursor] [with()]');

    return Object.assign(this, this._collection.collection.findOne(this._fileRef._id));
  }

}

class FilesCursor {
  constructor() {
    let _selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    let options = arguments.length > 1 ? arguments[1] : undefined;

    let _collection = arguments.length > 2 ? arguments[2] : undefined;

    this._collection = _collection;
    this._selector = _selector;
    this._current = -1;
    this.cursor = this._collection.collection.find(this._selector, options);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name get
   * @summary Returns all matching document(s) as an Array. Alias of `.fetch()`
   * @returns {[Object]}
   */


  get() {
    this._collection._debug('[FilesCollection] [FilesCursor] [get()]');

    return this.cursor.fetch();
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name hasNext
   * @summary Returns `true` if there is next item available on Cursor
   * @returns {Boolean}
   */


  hasNext() {
    this._collection._debug('[FilesCollection] [FilesCursor] [hasNext()]');

    return this._current < this.cursor.count() - 1;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name next
   * @summary Returns next item on Cursor, if available
   * @returns {Object|undefined}
   */


  next() {
    this._collection._debug('[FilesCollection] [FilesCursor] [next()]');

    this.cursor.fetch()[++this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name hasPrevious
   * @summary Returns `true` if there is previous item available on Cursor
   * @returns {Boolean}
   */


  hasPrevious() {
    this._collection._debug('[FilesCollection] [FilesCursor] [hasPrevious()]');

    return this._current !== -1;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name previous
   * @summary Returns previous item on Cursor, if available
   * @returns {Object|undefined}
   */


  previous() {
    this._collection._debug('[FilesCollection] [FilesCursor] [previous()]');

    this.cursor.fetch()[--this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name fetch
   * @summary Returns all matching document(s) as an Array.
   * @returns {[Object]}
   */


  fetch() {
    this._collection._debug('[FilesCollection] [FilesCursor] [fetch()]');

    return this.cursor.fetch() || [];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name first
   * @summary Returns first item on Cursor, if available
   * @returns {Object|undefined}
   */


  first() {
    this._collection._debug('[FilesCollection] [FilesCursor] [first()]');

    this._current = 0;
    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name last
   * @summary Returns last item on Cursor, if available
   * @returns {Object|undefined}
   */


  last() {
    this._collection._debug('[FilesCollection] [FilesCursor] [last()]');

    this._current = this.count() - 1;
    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name count
   * @summary Returns the number of documents that match a query
   * @returns {Number}
   */


  count() {
    this._collection._debug('[FilesCollection] [FilesCursor] [count()]');

    return this.cursor.count();
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name remove
   * @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed
   * @summary Removes all documents that match a query
   * @returns {FilesCursor}
   */


  remove(callback) {
    this._collection._debug('[FilesCollection] [FilesCursor] [remove()]');

    this._collection.remove(this._selector, callback);

    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name forEach
   * @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
   * @param context {Object} - An object which will be the value of `this` inside `callback`
   * @summary Call `callback` once for each matching document, sequentially and synchronously.
   * @returns {undefined}
   */


  forEach(callback) {
    let context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    this._collection._debug('[FilesCollection] [FilesCursor] [forEach()]');

    this.cursor.forEach(callback, context);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name each
   * @summary Returns an Array of FileCursor made for each document on current cursor
   *          Useful when using in {{#each FilesCursor#each}}...{{/each}} block template helper
   * @returns {[FileCursor]}
   */


  each() {
    return this.map(file => {
      return new FileCursor(file, this._collection);
    });
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name map
   * @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
   * @param context {Object} - An object which will be the value of `this` inside `callback`
   * @summary Map `callback` over all matching documents. Returns an Array.
   * @returns {Array}
   */


  map(callback) {
    let context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    this._collection._debug('[FilesCollection] [FilesCursor] [map()]');

    return this.cursor.map(callback, context);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name current
   * @summary Returns current item on Cursor, if available
   * @returns {Object|undefined}
   */


  current() {
    this._collection._debug('[FilesCollection] [FilesCursor] [current()]');

    if (this._current < 0) {
      this._current = 0;
    }

    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name observe
   * @param callbacks {Object} - Functions to call to deliver the result set as it changes
   * @summary Watch a query. Receive callbacks as the result set changes.
   * @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observe
   * @returns {Object} - live query handle
   */


  observe(callbacks) {
    this._collection._debug('[FilesCollection] [FilesCursor] [observe()]');

    return this.cursor.observe(callbacks);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name observeChanges
   * @param callbacks {Object} - Functions to call to deliver the result set as it changes
   * @summary Watch a query. Receive callbacks as the result set changes. Only the differences between the old and new documents are passed to the callbacks.
   * @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observeChanges
   * @returns {Object} - live query handle
   */


  observeChanges(callbacks) {
    this._collection._debug('[FilesCollection] [FilesCursor] [observeChanges()]');

    return this.cursor.observeChanges(callbacks);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/lib.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  fixJSONParse: () => fixJSONParse,
  fixJSONStringify: () => fixJSONStringify,
  formatFleURL: () => formatFleURL,
  helpers: () => helpers
});
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 0);
const helpers = {
  isUndefined(obj) {
    return obj === void 0;
  },

  isObject(obj) {
    if (this.isArray(obj) || this.isFunction(obj)) {
      return false;
    }

    return obj === Object(obj);
  },

  isArray(obj) {
    return Array.isArray(obj);
  },

  isBoolean(obj) {
    return obj === true || obj === false || Object.prototype.toString.call(obj) === '[object Boolean]';
  },

  isFunction(obj) {
    return typeof obj === 'function' || false;
  },

  isEmpty(obj) {
    if (this.isDate(obj)) {
      return false;
    }

    if (this.isObject(obj)) {
      return !Object.keys(obj).length;
    }

    if (this.isArray(obj) || this.isString(obj)) {
      return !obj.length;
    }

    return false;
  },

  clone(obj) {
    if (!this.isObject(obj)) return obj;
    return this.isArray(obj) ? obj.slice() : Object.assign({}, obj);
  },

  has(_obj, path) {
    let obj = _obj;

    if (!this.isObject(obj)) {
      return false;
    }

    if (!this.isArray(path)) {
      return this.isObject(obj) && Object.prototype.hasOwnProperty.call(obj, path);
    }

    const length = path.length;

    for (let i = 0; i < length; i++) {
      if (!Object.prototype.hasOwnProperty.call(obj, path[i])) {
        return false;
      }

      obj = obj[path[i]];
    }

    return !!length;
  },

  omit(obj) {
    const clear = Object.assign({}, obj);

    for (var _len = arguments.length, keys = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      keys[_key - 1] = arguments[_key];
    }

    for (let i = keys.length - 1; i >= 0; i--) {
      delete clear[keys[i]];
    }

    return clear;
  },

  now: Date.now,

  throttle(func, wait) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    let previous = 0;
    let timeout = null;
    let result;
    const that = this;
    let self;
    let args;

    const later = () => {
      previous = options.leading === false ? 0 : that.now();
      timeout = null;
      result = func.apply(self, args);

      if (!timeout) {
        self = args = null;
      }
    };

    const throttled = function () {
      const now = that.now();
      if (!previous && options.leading === false) previous = now;
      const remaining = wait - (now - previous);
      self = this;
      args = arguments;

      if (remaining <= 0 || remaining > wait) {
        if (timeout) {
          clearTimeout(timeout);
          timeout = null;
        }

        previous = now;
        result = func.apply(self, args);

        if (!timeout) {
          self = args = null;
        }
      } else if (!timeout && options.trailing !== false) {
        timeout = setTimeout(later, remaining);
      }

      return result;
    };

    throttled.cancel = () => {
      clearTimeout(timeout);
      previous = 0;
      timeout = self = args = null;
    };

    return throttled;
  }

};
const _helpers = ['String', 'Number', 'Date'];

for (let i = 0; i < _helpers.length; i++) {
  helpers['is' + _helpers[i]] = function (obj) {
    return Object.prototype.toString.call(obj) === '[object ' + _helpers[i] + ']';
  };
}
/*
 * @const {Function} fixJSONParse - Fix issue with Date parse
 */


const fixJSONParse = function (obj) {
  for (let key in obj) {
    if (helpers.isString(obj[key]) && obj[key].includes('=--JSON-DATE--=')) {
      obj[key] = obj[key].replace('=--JSON-DATE--=', '');
      obj[key] = new Date(parseInt(obj[key]));
    } else if (helpers.isObject(obj[key])) {
      obj[key] = fixJSONParse(obj[key]);
    } else if (helpers.isArray(obj[key])) {
      let v;

      for (let i = 0; i < obj[key].length; i++) {
        v = obj[key][i];

        if (helpers.isObject(v)) {
          obj[key][i] = fixJSONParse(v);
        } else if (helpers.isString(v) && v.includes('=--JSON-DATE--=')) {
          v = v.replace('=--JSON-DATE--=', '');
          obj[key][i] = new Date(parseInt(v));
        }
      }
    }
  }

  return obj;
};
/*
 * @const {Function} fixJSONStringify - Fix issue with Date stringify
 */


const fixJSONStringify = function (obj) {
  for (let key in obj) {
    if (helpers.isDate(obj[key])) {
      obj[key] = "=--JSON-DATE--=".concat(+obj[key]);
    } else if (helpers.isObject(obj[key])) {
      obj[key] = fixJSONStringify(obj[key]);
    } else if (helpers.isArray(obj[key])) {
      let v;

      for (let i = 0; i < obj[key].length; i++) {
        v = obj[key][i];

        if (helpers.isObject(v)) {
          obj[key][i] = fixJSONStringify(v);
        } else if (helpers.isDate(v)) {
          obj[key][i] = "=--JSON-DATE--=".concat(+v);
        }
      }
    }
  }

  return obj;
};
/*
 * @locus Anywhere
 * @private
 * @name formatFleURL
 * @param {Object} fileRef - File reference object
 * @param {String} version - [Optional] Version of file you would like build URL for
 * @param {String} URIBase - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
 * @summary Returns formatted URL for file
 * @returns {String} Downloadable link
 */


const formatFleURL = function (fileRef) {
  let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';

  let _URIBase = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : (__meteor_runtime_config__ || {}).ROOT_URL;

  check(fileRef, Object);
  check(version, String);
  let URIBase = _URIBase;

  if (!helpers.isString(URIBase)) {
    URIBase = (__meteor_runtime_config__ || {}).ROOT_URL || '/';
  }

  const _root = URIBase.replace(/\/+$/, '');

  const vRef = fileRef.versions && fileRef.versions[version] || fileRef || {};
  let ext;

  if (helpers.isString(vRef.extension)) {
    ext = ".".concat(vRef.extension.replace(/^\./, ''));
  } else {
    ext = '';
  }

  if (fileRef.public === true) {
    return _root + (version === 'original' ? "".concat(fileRef._downloadRoute, "/").concat(fileRef._id).concat(ext) : "".concat(fileRef._downloadRoute, "/").concat(version, "-").concat(fileRef._id).concat(ext));
  }

  return _root + "".concat(fileRef._downloadRoute, "/").concat(fileRef._collectionName, "/").concat(fileRef._id, "/").concat(version, "/").concat(fileRef._id).concat(ext);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"write-stream.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/write-stream.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => WriteStream
});
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let helpers;
module.link("./lib.js", {
  helpers(v) {
    helpers = v;
  }

}, 2);

const NOOP = () => {};
/*
 * @const {Object} bound   - Meteor.bindEnvironment (Fiber wrapper)
 * @const {Object} fdCache - File Descriptors Cache
 */


const bound = Meteor.bindEnvironment(callback => callback());
const fdCache = {};
/*
 * @private
 * @locus Server
 * @class WriteStream
 * @param path        {String} - Path to file on FS
 * @param maxLength   {Number} - Max amount of chunks in stream
 * @param file        {Object} - fileRef Object
 * @param permissions {String} - Permissions which will be set to open descriptor (octal), like: `611` or `0o777`. Default: 0755
 * @summary writableStream wrapper class, makes sure chunks is written in given order. Implementation of queue stream.
 */

class WriteStream {
  constructor(path, maxLength, file, permissions) {
    this.path = path;
    this.maxLength = maxLength;
    this.file = file;
    this.permissions = permissions;

    if (!this.path || !helpers.isString(this.path)) {
      return;
    }

    this.fd = null;
    this.writtenChunks = 0;
    this.ended = false;
    this.aborted = false;

    if (fdCache[this.path] && !fdCache[this.path].ended && !fdCache[this.path].aborted) {
      this.fd = fdCache[this.path].fd;
      this.writtenChunks = fdCache[this.path].writtenChunks;
    } else {
      fs.ensureFile(this.path, efError => {
        bound(() => {
          if (efError) {
            this.abort();
            throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [Error:] ' + efError);
          } else {
            fs.open(this.path, 'r+', this.permissions, (oError, fd) => {
              bound(() => {
                if (oError) {
                  this.abort();
                  throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [open] [Error:] ' + oError);
                } else {
                  this.fd = fd;
                  fdCache[this.path] = this;
                }
              });
            });
          }
        });
      });
    }
  }
  /*
   * @memberOf writeStream
   * @name write
   * @param {Number} num - Chunk position in a stream
   * @param {Buffer} chunk - Buffer (chunk binary data)
   * @param {Function} callback - Callback
   * @summary Write chunk in given order
   * @returns {Boolean} - True if chunk is sent to stream, false if chunk is set into queue
   */


  write(num, chunk, callback) {
    if (!this.aborted && !this.ended) {
      if (this.fd) {
        fs.write(this.fd, chunk, 0, chunk.length, (num - 1) * this.file.chunkSize, (error, written, buffer) => {
          bound(() => {
            callback && callback(error, written, buffer);

            if (error) {
              console.warn('[FilesCollection] [writeStream] [write] [Error:]', error);
              this.abort();
            } else {
              ++this.writtenChunks;
            }
          });
        });
      } else {
        Meteor.setTimeout(() => {
          this.write(num, chunk, callback);
        }, 25);
      }
    }

    return false;
  }
  /*
   * @memberOf writeStream
   * @name end
   * @param {Function} callback - Callback
   * @summary Finishes writing to writableStream, only after all chunks in queue is written
   * @returns {Boolean} - True if stream is fulfilled, false if queue is in progress
   */


  end(callback) {
    if (!this.aborted && !this.ended) {
      if (this.writtenChunks === this.maxLength) {
        fs.close(this.fd, () => {
          bound(() => {
            delete fdCache[this.path];
            this.ended = true;
            callback && callback(void 0, true);
          });
        });
        return true;
      }

      fs.stat(this.path, (error, stat) => {
        bound(() => {
          if (!error && stat) {
            this.writtenChunks = Math.ceil(stat.size / this.file.chunkSize);
          }

          return Meteor.setTimeout(() => {
            this.end(callback);
          }, 25);
        });
      });
    } else {
      callback && callback(void 0, this.ended);
    }

    return false;
  }
  /*
   * @memberOf writeStream
   * @name abort
   * @param {Function} callback - Callback
   * @summary Aborts writing to writableStream, removes created file
   * @returns {Boolean} - True
   */


  abort(callback) {
    this.aborted = true;
    delete fdCache[this.path];
    fs.unlink(this.path, callback || NOOP);
    return true;
  }
  /*
   * @memberOf writeStream
   * @name stop
   * @summary Stop writing to writableStream
   * @returns {Boolean} - True
   */


  stop() {
    this.aborted = true;
    delete fdCache[this.path];
    return true;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"fs-extra":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/fs-extra/package.json                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "fs-extra",
  "version": "9.0.1",
  "main": "./lib/index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/fs-extra/lib/index.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"eventemitter3":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/eventemitter3/package.json                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "eventemitter3",
  "version": "4.0.7",
  "main": "index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/eventemitter3/index.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"request-libcurl":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/request-libcurl/package.json                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "request-libcurl",
  "version": "2.2.1",
  "main": "index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/request-libcurl/index.js                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"file-type":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/file-type/package.json                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "file-type",
  "version": "16.0.0"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/file-type/index.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/ostrio:files/server.js");

/* Exports */
Package._define("ostrio:files", exports, {
  FilesCollection: FilesCollection
});

})();

//# sourceURL=meteor://💻app/packages/ostrio_files.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZpbGVzL3NlcnZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZpbGVzL2NvcmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy9jdXJzb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy9saWIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy93cml0ZS1zdHJlYW0uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRmlsZXNDb2xsZWN0aW9uIiwiTW9uZ28iLCJsaW5rIiwidiIsIldlYkFwcCIsIk1ldGVvciIsIlJhbmRvbSIsIkNvb2tpZXMiLCJXcml0ZVN0cmVhbSIsImRlZmF1bHQiLCJjaGVjayIsIk1hdGNoIiwiRmlsZXNDb2xsZWN0aW9uQ29yZSIsImZpeEpTT05QYXJzZSIsImZpeEpTT05TdHJpbmdpZnkiLCJoZWxwZXJzIiwiZnMiLCJub2RlUXMiLCJyZXF1ZXN0IiwiZmlsZVR5cGUiLCJub2RlUGF0aCIsImJvdW5kIiwiYmluZEVudmlyb25tZW50IiwiY2FsbGJhY2siLCJOT09QIiwiY29uc3RydWN0b3IiLCJjb25maWciLCJzdG9yYWdlUGF0aCIsImRlYnVnIiwic2NoZW1hIiwicHVibGljIiwic3RyaWN0IiwiY2h1bmtTaXplIiwicHJvdGVjdGVkIiwiY29sbGVjdGlvbiIsInBlcm1pc3Npb25zIiwiY2FjaGVDb250cm9sIiwiZG93bmxvYWRSb3V0ZSIsIm9uQWZ0ZXJVcGxvYWQiLCJvbkFmdGVyUmVtb3ZlIiwiZGlzYWJsZVVwbG9hZCIsIm9uQmVmb3JlUmVtb3ZlIiwiaW50ZWdyaXR5Q2hlY2siLCJjb2xsZWN0aW9uTmFtZSIsIm9uQmVmb3JlVXBsb2FkIiwibmFtaW5nRnVuY3Rpb24iLCJyZXNwb25zZUhlYWRlcnMiLCJkaXNhYmxlRG93bmxvYWQiLCJhbGxvd2VkT3JpZ2lucyIsImFsbG93Q2xpZW50Q29kZSIsImRvd25sb2FkQ2FsbGJhY2siLCJvbkluaXRpYXRlVXBsb2FkIiwiaW50ZXJjZXB0UmVxdWVzdCIsImludGVyY2VwdERvd25sb2FkIiwiY29udGludWVVcGxvYWRUVEwiLCJwYXJlbnREaXJQZXJtaXNzaW9ucyIsImFsbG93UXVlcnlTdHJpbmdDb29raWVzIiwiX3ByZUNvbGxlY3Rpb24iLCJfcHJlQ29sbGVjdGlvbk5hbWUiLCJzZWxmIiwiaXNCb29sZWFuIiwiTWF0aCIsImZsb29yIiwiaXNTdHJpbmciLCJDb2xsZWN0aW9uIiwiX25hbWUiLCJmaWxlc0NvbGxlY3Rpb24iLCJTdHJpbmciLCJFcnJvciIsInJlcGxhY2UiLCJpc0Z1bmN0aW9uIiwiaXNOdW1iZXIiLCJwYXJzZUludCIsImlzT2JqZWN0IiwiX2N1cnJlbnRVcGxvYWRzIiwicmVzcG9uc2VDb2RlIiwiZmlsZVJlZiIsInZlcnNpb25SZWYiLCJoZWFkZXJzIiwiUHJhZ21hIiwic2l6ZSIsIkNvbm5lY3Rpb24iLCJ0eXBlIiwic2VwIiwic3AiLCJhcHBseSIsImFyZ3VtZW50cyIsIm5vcm1hbGl6ZSIsIl9kZWJ1ZyIsIm1rZGlycyIsIm1vZGUiLCJlcnJvciIsIkJvb2xlYW4iLCJOdW1iZXIiLCJGdW5jdGlvbiIsIk9uZU9mIiwiT2JqZWN0IiwiYWxsb3dlZENvcmRvdmFPcmlnaW5zIiwiX2Vuc3VyZUluZGV4IiwiY3JlYXRlZEF0IiwiZXhwaXJlQWZ0ZXJTZWNvbmRzIiwiYmFja2dyb3VuZCIsIl9wcmVDb2xsZWN0aW9uQ3Vyc29yIiwiZmluZCIsImZpZWxkcyIsIl9pZCIsImlzRmluaXNoZWQiLCJvYnNlcnZlIiwiY2hhbmdlZCIsImRvYyIsInJlbW92ZSIsInJlbW92ZWQiLCJzdG9wIiwiZW5kIiwiY291bnQiLCJhYm9ydCIsIl9jcmVhdGVTdHJlYW0iLCJwYXRoIiwib3B0cyIsImZpbGVMZW5ndGgiLCJfY29udGludWVVcGxvYWQiLCJmaWxlIiwiYWJvcnRlZCIsImVuZGVkIiwiY29udFVwbGQiLCJmaW5kT25lIiwiX2NoZWNrQWNjZXNzIiwiaHR0cCIsInJlc3VsdCIsInVzZXIiLCJ1c2VySWQiLCJfZ2V0VXNlciIsInBhcmFtcyIsImNhbGwiLCJhc3NpZ24iLCJyYyIsInRleHQiLCJyZXNwb25zZSIsImhlYWRlcnNTZW50Iiwid3JpdGVIZWFkIiwibGVuZ3RoIiwiZmluaXNoZWQiLCJfbWV0aG9kTmFtZXMiLCJfQWJvcnQiLCJfV3JpdGUiLCJfU3RhcnQiLCJfUmVtb3ZlIiwib24iLCJfaGFuZGxlVXBsb2FkIiwiX2ZpbmlzaFVwbG9hZCIsIl9oYW5kbGVVcGxvYWRTeW5jIiwid3JhcEFzeW5jIiwiYmluZCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsImh0dHBSZXEiLCJodHRwUmVzcCIsIm5leHQiLCJfcGFyc2VkVXJsIiwiaW5jbHVkZXMiLCJ0ZXN0Iiwib3JpZ2luIiwic2V0SGVhZGVyIiwibWV0aG9kIiwiaGFuZGxlRXJyb3IiLCJfZXJyb3IiLCJjb25zb2xlIiwid2FybiIsInRyYWNlIiwidG9TdHJpbmciLCJKU09OIiwic3RyaW5naWZ5IiwiYm9keSIsImhhbmRsZURhdGEiLCJfZ2V0VXNlcklkIiwiZmlsZUlkIiwiZW9mIiwiYmluRGF0YSIsIkJ1ZmZlciIsImZyb20iLCJjaHVua0lkIiwiX3ByZXBhcmVVcGxvYWQiLCJtZXRhIiwiZW1pdCIsInBhcnNlIiwianNvbkVyciIsIl9fX3MiLCJuYW1lIiwiY2xvbmUiLCJEYXRlIiwibWF4TGVuZ3RoIiwiaW5zZXJ0Iiwib21pdCIsInJldHVybk1ldGEiLCJ1cGxvYWRSb3V0ZSIsImh0dHBSZXNwRXJyIiwic2V0VGltZW91dCIsImtleXMiLCJkYXRhIiwidXJpIiwiaW5kZXhPZiIsInN1YnN0cmluZyIsInVyaXMiLCJzcGxpdCIsInF1ZXJ5IiwidmVyc2lvbiIsImRvd25sb2FkIiwiX2ZpbGUiLCJfbWV0aG9kcyIsInNlbGVjdG9yIiwidXNlckZ1bmNzIiwidXNlcnMiLCJjdXJzb3IiLCJGU05hbWUiLCJPcHRpb25hbCIsImUiLCJfb3B0cyIsInVuYmxvY2siLCJoYW5kbGVVcGxvYWRFcnIiLCJ1bmxpbmsiLCJtZXRob2RzIiwidHJhbnNwb3J0IiwiY3R4IiwiZmlsZU5hbWUiLCJfZ2V0RmlsZU5hbWUiLCJleHRlbnNpb24iLCJleHRlbnNpb25XaXRoRG90IiwiX2dldEV4dCIsImV4dCIsIl9kYXRhVG9TY2hlbWEiLCJpc1VwbG9hZEFsbG93ZWQiLCJjYiIsImNobW9kIiwiX2dldE1pbWVUeXBlIiwiX3VwZGF0ZUZpbGVUeXBlcyIsImNvbEluc2VydCIsInVwZGF0ZSIsIiRzZXQiLCJwcmVVcGRhdGVFcnJvciIsIndyaXRlIiwiZmlsZURhdGEiLCJtaW1lIiwiYnVmIiwiYWxsb2MiLCJmZCIsIm9wZW5TeW5jIiwiYnIiLCJyZWFkU3luYyIsImNsb3NlIiwic2xpY2UiLCJ4bXRvayIsInNlcnZlciIsInNlc3Npb25zIiwiTWFwIiwiaGFzIiwiZ2V0IiwibXRvayIsImNvb2tpZSIsImJ1ZmZlciIsIl9jYWxsYmFjayIsIl9wcm9jZWVkQWZ0ZXJVcGxvYWQiLCJwcm9jZWVkQWZ0ZXJVcGxvYWQiLCJpZCIsImVuc3VyZUZpbGUiLCJlZkVycm9yIiwic3RyZWFtIiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJmbGFncyIsInN0cmVhbUVyciIsImluc2VydEVyciIsImxvYWQiLCJ1cmwiLCJwYXRoUGFydHMiLCJzdG9yZVJlc3VsdCIsIndhaXQiLCJyZXFFcnJvciIsInN0YXQiLCJzdGF0cyIsInZlcnNpb25zIiwib3JpZ2luYWwiLCJwaXBlIiwic2VuZCIsImFkZEZpbGUiLCJzdGF0RXJyIiwiaXNGaWxlIiwiX3N0b3JhZ2VQYXRoIiwiZmlsZXMiLCJmb3JFYWNoIiwiZG9jcyIsImZldGNoIiwiZGVueSIsInJ1bGVzIiwiYWxsb3ciLCJkZW55Q2xpZW50IiwiYWxsb3dDbGllbnQiLCJ2S2V5IiwiXzQwNCIsIm9yaWdpbmFsVXJsIiwidlJlZiIsInJlc3BvbnNlVHlwZSIsInNlcnZlIiwicmVhZGFibGVTdHJlYW0iLCJfcmVzcG9uc2VUeXBlIiwiZm9yY2UyMDAiLCJwYXJ0aXJhbCIsInJlcVJhbmdlIiwiZGlzcG9zaXRpb25UeXBlIiwic3RhcnQiLCJ0YWtlIiwiZGlzcG9zaXRpb25OYW1lIiwiZW5jb2RlVVJJIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZGlzcG9zaXRpb25FbmNvZGluZyIsInJhbmdlIiwiYXJyYXkiLCJpc05hTiIsInBsYXkiLCJzdHJlYW1FcnJvckhhbmRsZXIiLCJrZXkiLCJyZXNwb25kIiwiY29kZSIsIl9pc0VuZGVkIiwiY2xvc2VTdHJlYW1DYiIsImNsb3NlRXJyb3IiLCJjbG9zZVN0cmVhbSIsImRlc3Ryb3kiLCJlcnIiLCJjcmVhdGVSZWFkU3RyZWFtIiwiRXZlbnRFbWl0dGVyIiwiZm9ybWF0RmxlVVJMIiwiRmlsZXNDdXJzb3IiLCJGaWxlQ3Vyc29yIiwiaW5mbyIsImxvZyIsInBvcCIsInRvTG93ZXJDYXNlIiwiaXNWaWRlbyIsImlzQXVkaW8iLCJpc0ltYWdlIiwiaXNUZXh0IiwiaXNKU09OIiwiaXNQREYiLCJkcyIsIl9kb3dubG9hZFJvdXRlIiwiX2NvbGxlY3Rpb25OYW1lIiwib3B0aW9ucyIsIlVSSUJhc2UiLCJfX2hlbHBlcnMiLCJvcHRpb25hbCIsImJsYWNrYm94IiwidXBkYXRlZEF0IiwiX2ZpbGVSZWYiLCJfY29sbGVjdGlvbiIsInByb3BlcnR5Iiwid2l0aCIsIl9zZWxlY3RvciIsIl9jdXJyZW50IiwiaGFzTmV4dCIsImhhc1ByZXZpb3VzIiwicHJldmlvdXMiLCJmaXJzdCIsImxhc3QiLCJjb250ZXh0IiwiZWFjaCIsIm1hcCIsImN1cnJlbnQiLCJjYWxsYmFja3MiLCJvYnNlcnZlQ2hhbmdlcyIsImlzVW5kZWZpbmVkIiwib2JqIiwiaXNBcnJheSIsIkFycmF5IiwicHJvdG90eXBlIiwiaXNFbXB0eSIsImlzRGF0ZSIsIl9vYmoiLCJoYXNPd25Qcm9wZXJ0eSIsImkiLCJjbGVhciIsIm5vdyIsInRocm90dGxlIiwiZnVuYyIsInRpbWVvdXQiLCJ0aGF0IiwiYXJncyIsImxhdGVyIiwibGVhZGluZyIsInRocm90dGxlZCIsInJlbWFpbmluZyIsImNsZWFyVGltZW91dCIsInRyYWlsaW5nIiwiY2FuY2VsIiwiX2hlbHBlcnMiLCJfVVJJQmFzZSIsIl9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18iLCJST09UX1VSTCIsIl9yb290IiwiZmRDYWNoZSIsIndyaXR0ZW5DaHVua3MiLCJvcGVuIiwib0Vycm9yIiwibnVtIiwiY2h1bmsiLCJ3cml0dGVuIiwiY2VpbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsaUJBQWUsRUFBQyxNQUFJQTtBQUFyQixDQUFkO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUMsTUFBSjtBQUFXTixNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxNQUFKO0FBQVdQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0csUUFBTSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsVUFBTSxHQUFDRixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlHLE1BQUo7QUFBV1IsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSSxRQUFNLENBQUNILENBQUQsRUFBRztBQUFDRyxVQUFNLEdBQUNILENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUksT0FBSjtBQUFZVCxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDSyxTQUFPLENBQUNKLENBQUQsRUFBRztBQUFDSSxXQUFPLEdBQUNKLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUssV0FBSjtBQUFnQlYsTUFBTSxDQUFDSSxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ0ssZUFBVyxHQUFDTCxDQUFaO0FBQWM7O0FBQTFCLENBQWhDLEVBQTRELENBQTVEO0FBQStELElBQUlPLEtBQUosRUFBVUMsS0FBVjtBQUFnQmIsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUSxHQUFsQjs7QUFBbUJRLE9BQUssQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLFNBQUssR0FBQ1IsQ0FBTjtBQUFROztBQUFwQyxDQUEzQixFQUFpRSxDQUFqRTtBQUFvRSxJQUFJUyxtQkFBSjtBQUF3QmQsTUFBTSxDQUFDSSxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDUyx1QkFBbUIsR0FBQ1QsQ0FBcEI7QUFBc0I7O0FBQWxDLENBQXhCLEVBQTRELENBQTVEO0FBQStELElBQUlVLFlBQUosRUFBaUJDLGdCQUFqQixFQUFrQ0MsT0FBbEM7QUFBMENqQixNQUFNLENBQUNJLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNXLGNBQVksQ0FBQ1YsQ0FBRCxFQUFHO0FBQUNVLGdCQUFZLEdBQUNWLENBQWI7QUFBZSxHQUFoQzs7QUFBaUNXLGtCQUFnQixDQUFDWCxDQUFELEVBQUc7QUFBQ1csb0JBQWdCLEdBQUNYLENBQWpCO0FBQW1CLEdBQXhFOztBQUF5RVksU0FBTyxDQUFDWixDQUFELEVBQUc7QUFBQ1ksV0FBTyxHQUFDWixDQUFSO0FBQVU7O0FBQTlGLENBQXZCLEVBQXVILENBQXZIO0FBQTBILElBQUlhLEVBQUo7QUFBT2xCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ2EsTUFBRSxHQUFDYixDQUFIO0FBQUs7O0FBQWpCLENBQXZCLEVBQTBDLENBQTFDO0FBQTZDLElBQUljLE1BQUo7QUFBV25CLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ2MsVUFBTSxHQUFDZCxDQUFQO0FBQVM7O0FBQXJCLENBQTFCLEVBQWlELEVBQWpEO0FBQXFELElBQUllLE9BQUo7QUFBWXBCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGlCQUFaLEVBQThCO0FBQUNPLFNBQU8sQ0FBQ04sQ0FBRCxFQUFHO0FBQUNlLFdBQU8sR0FBQ2YsQ0FBUjtBQUFVOztBQUF0QixDQUE5QixFQUFzRCxFQUF0RDtBQUEwRCxJQUFJZ0IsUUFBSjtBQUFhckIsTUFBTSxDQUFDSSxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDZ0IsWUFBUSxHQUFDaEIsQ0FBVDtBQUFXOztBQUF2QixDQUF4QixFQUFpRCxFQUFqRDtBQUFxRCxJQUFJaUIsUUFBSjtBQUFhdEIsTUFBTSxDQUFDSSxJQUFQLENBQVksTUFBWixFQUFtQjtBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDaUIsWUFBUSxHQUFDakIsQ0FBVDtBQUFXOztBQUF2QixDQUFuQixFQUE0QyxFQUE1Qzs7QUFnQm5pQztBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1rQixLQUFLLEdBQUdoQixNQUFNLENBQUNpQixlQUFQLENBQXVCQyxRQUFRLElBQUlBLFFBQVEsRUFBM0MsQ0FBZDs7QUFDQSxNQUFNQyxJQUFJLEdBQUksTUFBTSxDQUFJLENBQXhCO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDTyxNQUFNeEIsZUFBTixTQUE4QlksbUJBQTlCLENBQWtEO0FBQ3ZEYSxhQUFXLENBQUNDLE1BQUQsRUFBUztBQUNsQjtBQUNBLFFBQUlDLFdBQUo7O0FBQ0EsUUFBSUQsTUFBSixFQUFZO0FBQ1YsT0FBQztBQUNDQyxtQkFERDtBQUVDQyxhQUFLLEVBQUUsS0FBS0EsS0FGYjtBQUdDQyxjQUFNLEVBQUUsS0FBS0EsTUFIZDtBQUlDQyxjQUFNLEVBQUUsS0FBS0EsTUFKZDtBQUtDQyxjQUFNLEVBQUUsS0FBS0EsTUFMZDtBQU1DQyxpQkFBUyxFQUFFLEtBQUtBLFNBTmpCO0FBT0NDLGlCQUFTLEVBQUUsS0FBS0EsU0FQakI7QUFRQ0Msa0JBQVUsRUFBRSxLQUFLQSxVQVJsQjtBQVNDQyxtQkFBVyxFQUFFLEtBQUtBLFdBVG5CO0FBVUNDLG9CQUFZLEVBQUUsS0FBS0EsWUFWcEI7QUFXQ0MscUJBQWEsRUFBRSxLQUFLQSxhQVhyQjtBQVlDQyxxQkFBYSxFQUFFLEtBQUtBLGFBWnJCO0FBYUNDLHFCQUFhLEVBQUUsS0FBS0EsYUFickI7QUFjQ0MscUJBQWEsRUFBRSxLQUFLQSxhQWRyQjtBQWVDQyxzQkFBYyxFQUFFLEtBQUtBLGNBZnRCO0FBZ0JDQyxzQkFBYyxFQUFFLEtBQUtBLGNBaEJ0QjtBQWlCQ0Msc0JBQWMsRUFBRSxLQUFLQSxjQWpCdEI7QUFrQkNDLHNCQUFjLEVBQUUsS0FBS0EsY0FsQnRCO0FBbUJDQyxzQkFBYyxFQUFFLEtBQUtBLGNBbkJ0QjtBQW9CQ0MsdUJBQWUsRUFBRSxLQUFLQSxlQXBCdkI7QUFxQkNDLHVCQUFlLEVBQUUsS0FBS0EsZUFyQnZCO0FBc0JDQyxzQkFBYyxFQUFFLEtBQUtBLGNBdEJ0QjtBQXVCQ0MsdUJBQWUsRUFBRSxLQUFLQSxlQXZCdkI7QUF3QkNDLHdCQUFnQixFQUFFLEtBQUtBLGdCQXhCeEI7QUF5QkNDLHdCQUFnQixFQUFFLEtBQUtBLGdCQXpCeEI7QUEwQkNDLHdCQUFnQixFQUFFLEtBQUtBLGdCQTFCeEI7QUEyQkNDLHlCQUFpQixFQUFFLEtBQUtBLGlCQTNCekI7QUE0QkNDLHlCQUFpQixFQUFFLEtBQUtBLGlCQTVCekI7QUE2QkNDLDRCQUFvQixFQUFFLEtBQUtBLG9CQTdCNUI7QUE4QkNDLCtCQUF1QixFQUFFLEtBQUtBLHVCQTlCL0I7QUErQkNDLHNCQUFjLEVBQUUsS0FBS0EsY0EvQnRCO0FBZ0NDQywwQkFBa0IsRUFBRSxLQUFLQTtBQWhDMUIsVUFpQ0doQyxNQWpDSjtBQWtDRDs7QUFFRCxVQUFNaUMsSUFBSSxHQUFHLElBQWI7O0FBRUEsUUFBSSxDQUFDNUMsT0FBTyxDQUFDNkMsU0FBUixDQUFrQixLQUFLaEMsS0FBdkIsQ0FBTCxFQUFvQztBQUNsQyxXQUFLQSxLQUFMLEdBQWEsS0FBYjtBQUNEOztBQUVELFFBQUksQ0FBQ2IsT0FBTyxDQUFDNkMsU0FBUixDQUFrQixLQUFLOUIsTUFBdkIsQ0FBTCxFQUFxQztBQUNuQyxXQUFLQSxNQUFMLEdBQWMsS0FBZDtBQUNEOztBQUVELFFBQUksQ0FBQyxLQUFLRyxTQUFWLEVBQXFCO0FBQ25CLFdBQUtBLFNBQUwsR0FBaUIsS0FBakI7QUFDRDs7QUFFRCxRQUFJLENBQUMsS0FBS0QsU0FBVixFQUFxQjtBQUNuQixXQUFLQSxTQUFMLEdBQWlCLE9BQU8sR0FBeEI7QUFDRDs7QUFFRCxTQUFLQSxTQUFMLEdBQWlCNkIsSUFBSSxDQUFDQyxLQUFMLENBQVcsS0FBSzlCLFNBQUwsR0FBaUIsQ0FBNUIsSUFBaUMsQ0FBbEQ7O0FBRUEsUUFBSSxDQUFDakIsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLcEIsY0FBdEIsQ0FBRCxJQUEwQyxDQUFDLEtBQUtULFVBQXBELEVBQWdFO0FBQzlELFdBQUtTLGNBQUwsR0FBc0IsbUJBQXRCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDLEtBQUtULFVBQVYsRUFBc0I7QUFDcEIsV0FBS0EsVUFBTCxHQUFrQixJQUFJakMsS0FBSyxDQUFDK0QsVUFBVixDQUFxQixLQUFLckIsY0FBMUIsQ0FBbEI7QUFDRCxLQUZELE1BRU87QUFDTCxXQUFLQSxjQUFMLEdBQXNCLEtBQUtULFVBQUwsQ0FBZ0IrQixLQUF0QztBQUNEOztBQUVELFNBQUsvQixVQUFMLENBQWdCZ0MsZUFBaEIsR0FBa0MsSUFBbEM7QUFDQXhELFNBQUssQ0FBQyxLQUFLaUMsY0FBTixFQUFzQndCLE1BQXRCLENBQUw7O0FBRUEsUUFBSSxLQUFLckMsTUFBTCxJQUFlLENBQUMsS0FBS08sYUFBekIsRUFBd0M7QUFDdEMsWUFBTSxJQUFJaEMsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQiw2QkFBMEMsS0FBS3pCLGNBQS9DLDZLQUFOO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDNUIsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLMUIsYUFBdEIsQ0FBTCxFQUEyQztBQUN6QyxXQUFLQSxhQUFMLEdBQXFCLGNBQXJCO0FBQ0Q7O0FBRUQsU0FBS0EsYUFBTCxHQUFxQixLQUFLQSxhQUFMLENBQW1CZ0MsT0FBbkIsQ0FBMkIsS0FBM0IsRUFBa0MsRUFBbEMsQ0FBckI7O0FBRUEsUUFBSSxDQUFDdEQsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLekIsY0FBeEIsQ0FBTCxFQUE4QztBQUM1QyxXQUFLQSxjQUFMLEdBQXNCLEtBQXRCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDOUIsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLMUIsY0FBeEIsQ0FBTCxFQUE4QztBQUM1QyxXQUFLQSxjQUFMLEdBQXNCLEtBQXRCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDN0IsT0FBTyxDQUFDNkMsU0FBUixDQUFrQixLQUFLWCxlQUF2QixDQUFMLEVBQThDO0FBQzVDLFdBQUtBLGVBQUwsR0FBdUIsSUFBdkI7QUFDRDs7QUFFRCxRQUFJLENBQUNsQyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtuQixnQkFBeEIsQ0FBTCxFQUFnRDtBQUM5QyxXQUFLQSxnQkFBTCxHQUF3QixLQUF4QjtBQUNEOztBQUVELFFBQUksQ0FBQ3BDLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS2xCLGdCQUF4QixDQUFMLEVBQWdEO0FBQzlDLFdBQUtBLGdCQUFMLEdBQXdCLEtBQXhCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDckMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLakIsaUJBQXhCLENBQUwsRUFBaUQ7QUFDL0MsV0FBS0EsaUJBQUwsR0FBeUIsS0FBekI7QUFDRDs7QUFFRCxRQUFJLENBQUN0QyxPQUFPLENBQUM2QyxTQUFSLENBQWtCLEtBQUs3QixNQUF2QixDQUFMLEVBQXFDO0FBQ25DLFdBQUtBLE1BQUwsR0FBYyxJQUFkO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDaEIsT0FBTyxDQUFDNkMsU0FBUixDQUFrQixLQUFLSix1QkFBdkIsQ0FBTCxFQUFzRDtBQUNwRCxXQUFLQSx1QkFBTCxHQUErQixLQUEvQjtBQUNEOztBQUVELFFBQUksQ0FBQ3pDLE9BQU8sQ0FBQ3dELFFBQVIsQ0FBaUIsS0FBS3BDLFdBQXRCLENBQUwsRUFBeUM7QUFDdkMsV0FBS0EsV0FBTCxHQUFtQnFDLFFBQVEsQ0FBQyxLQUFELEVBQVEsQ0FBUixDQUEzQjtBQUNEOztBQUVELFFBQUksQ0FBQ3pELE9BQU8sQ0FBQ3dELFFBQVIsQ0FBaUIsS0FBS2hCLG9CQUF0QixDQUFMLEVBQWtEO0FBQ2hELFdBQUtBLG9CQUFMLEdBQTRCaUIsUUFBUSxDQUFDLEtBQUQsRUFBUSxDQUFSLENBQXBDO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDekQsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLM0IsWUFBdEIsQ0FBTCxFQUEwQztBQUN4QyxXQUFLQSxZQUFMLEdBQW9CLDZDQUFwQjtBQUNEOztBQUVELFFBQUksQ0FBQ3JCLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS2hDLGFBQXhCLENBQUwsRUFBNkM7QUFDM0MsV0FBS0EsYUFBTCxHQUFxQixLQUFyQjtBQUNEOztBQUVELFFBQUksQ0FBQ3ZCLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS3BCLGFBQXZCLENBQUwsRUFBNEM7QUFDMUMsV0FBS0EsYUFBTCxHQUFxQixLQUFyQjtBQUNEOztBQUVELFFBQUksQ0FBQ3pCLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBSy9CLGFBQXhCLENBQUwsRUFBNkM7QUFDM0MsV0FBS0EsYUFBTCxHQUFxQixLQUFyQjtBQUNEOztBQUVELFFBQUksQ0FBQ3hCLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBSzdCLGNBQXhCLENBQUwsRUFBOEM7QUFDNUMsV0FBS0EsY0FBTCxHQUFzQixLQUF0QjtBQUNEOztBQUVELFFBQUksQ0FBQzFCLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS2xCLGNBQXZCLENBQUwsRUFBNkM7QUFDM0MsV0FBS0EsY0FBTCxHQUFzQixJQUF0QjtBQUNEOztBQUVELFFBQUksQ0FBQzNCLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS2IsZUFBdkIsQ0FBTCxFQUE4QztBQUM1QyxXQUFLQSxlQUFMLEdBQXVCLEtBQXZCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDaEMsT0FBTyxDQUFDNkMsU0FBUixDQUFrQixLQUFLWixjQUF2QixDQUFELElBQTJDLEtBQUtBLGNBQUwsS0FBd0IsSUFBdkUsRUFBNkU7QUFDM0UsV0FBS0EsY0FBTCxHQUFzQixpQ0FBdEI7QUFDRDs7QUFFRCxRQUFJLENBQUNqQyxPQUFPLENBQUMwRCxRQUFSLENBQWlCLEtBQUtDLGVBQXRCLENBQUwsRUFBNkM7QUFDM0MsV0FBS0EsZUFBTCxHQUF1QixFQUF2QjtBQUNEOztBQUVELFFBQUksQ0FBQzNELE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS3BCLGdCQUF4QixDQUFMLEVBQWdEO0FBQzlDLFdBQUtBLGdCQUFMLEdBQXdCLEtBQXhCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDbkMsT0FBTyxDQUFDd0QsUUFBUixDQUFpQixLQUFLakIsaUJBQXRCLENBQUwsRUFBK0M7QUFDN0MsV0FBS0EsaUJBQUwsR0FBeUIsS0FBekI7QUFDRDs7QUFFRCxRQUFJLENBQUN2QyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUt4QixlQUF4QixDQUFMLEVBQStDO0FBQzdDLFdBQUtBLGVBQUwsR0FBdUIsQ0FBQzZCLFlBQUQsRUFBZUMsT0FBZixFQUF3QkMsVUFBeEIsS0FBdUM7QUFDNUQsY0FBTUMsT0FBTyxHQUFHLEVBQWhCOztBQUNBLGdCQUFRSCxZQUFSO0FBQ0EsZUFBSyxLQUFMO0FBQ0VHLG1CQUFPLENBQUNDLE1BQVIsR0FBK0IsU0FBL0I7QUFDQUQsbUJBQU8sQ0FBQyxtQkFBRCxDQUFQLEdBQStCLFNBQS9CO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0VBLG1CQUFPLENBQUMsZUFBRCxDQUFQLEdBQStCLFVBQS9CO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0VBLG1CQUFPLENBQUMsZUFBRCxDQUFQLHFCQUEwQ0QsVUFBVSxDQUFDRyxJQUFyRDtBQUNBOztBQUNGO0FBQ0U7QUFaRjs7QUFlQUYsZUFBTyxDQUFDRyxVQUFSLEdBQTJCLFlBQTNCO0FBQ0FILGVBQU8sQ0FBQyxjQUFELENBQVAsR0FBMkJELFVBQVUsQ0FBQ0ssSUFBWCxJQUFtQiwwQkFBOUM7QUFDQUosZUFBTyxDQUFDLGVBQUQsQ0FBUCxHQUEyQixPQUEzQjtBQUNBLGVBQU9BLE9BQVA7QUFDRCxPQXJCRDtBQXNCRDs7QUFFRCxRQUFJLEtBQUtoRCxNQUFMLElBQWUsQ0FBQ0gsV0FBcEIsRUFBaUM7QUFDL0IsWUFBTSxJQUFJdEIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQiw2QkFBMEMsS0FBS3pCLGNBQS9DLHlKQUFOO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDaEIsV0FBTCxFQUFrQjtBQUNoQkEsaUJBQVcsR0FBRyxZQUFZO0FBQ3hCLCtCQUFnQlAsUUFBUSxDQUFDK0QsR0FBekIsZ0JBQWtDL0QsUUFBUSxDQUFDK0QsR0FBM0Msb0JBQXdEL0QsUUFBUSxDQUFDK0QsR0FBakUsU0FBdUV4QixJQUFJLENBQUNoQixjQUE1RTtBQUNELE9BRkQ7QUFHRDs7QUFFRCxRQUFJNUIsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQnBDLFdBQWpCLENBQUosRUFBbUM7QUFDakMsV0FBS0EsV0FBTCxHQUFtQixNQUFNQSxXQUF6QjtBQUNELEtBRkQsTUFFTztBQUNMLFdBQUtBLFdBQUwsR0FBbUIsWUFBWTtBQUM3QixZQUFJeUQsRUFBRSxHQUFHekQsV0FBVyxDQUFDMEQsS0FBWixDQUFrQjFCLElBQWxCLEVBQXdCMkIsU0FBeEIsQ0FBVDs7QUFDQSxZQUFJLENBQUN2RSxPQUFPLENBQUNnRCxRQUFSLENBQWlCcUIsRUFBakIsQ0FBTCxFQUEyQjtBQUN6QixnQkFBTSxJQUFJL0UsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQiw2QkFBMENULElBQUksQ0FBQ2hCLGNBQS9DLHNEQUFOO0FBQ0Q7O0FBQ0R5QyxVQUFFLEdBQUdBLEVBQUUsQ0FBQ2YsT0FBSCxDQUFXLEtBQVgsRUFBa0IsRUFBbEIsQ0FBTDtBQUNBLGVBQU9qRCxRQUFRLENBQUNtRSxTQUFULENBQW1CSCxFQUFuQixDQUFQO0FBQ0QsT0FQRDtBQVFEOztBQUVELFNBQUtJLE1BQUwsQ0FBWSx1Q0FBWixFQUFxRCxLQUFLN0QsV0FBTCxDQUFpQixFQUFqQixDQUFyRDs7QUFFQVgsTUFBRSxDQUFDeUUsTUFBSCxDQUFVLEtBQUs5RCxXQUFMLENBQWlCLEVBQWpCLENBQVYsRUFBZ0M7QUFBRStELFVBQUksRUFBRSxLQUFLbkM7QUFBYixLQUFoQyxFQUFzRW9DLEtBQUQsSUFBVztBQUM5RSxVQUFJQSxLQUFKLEVBQVc7QUFDVCxjQUFNLElBQUl0RixNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLDZCQUEwQ1QsSUFBSSxDQUFDaEIsY0FBL0Msc0JBQXdFLEtBQUtoQixXQUFMLENBQWlCLEVBQWpCLENBQXhFLGlDQUFrSGdFLEtBQWxILEVBQU47QUFDRDtBQUNGLEtBSkQ7QUFNQWpGLFNBQUssQ0FBQyxLQUFLcUIsTUFBTixFQUFjNkQsT0FBZCxDQUFMO0FBQ0FsRixTQUFLLENBQUMsS0FBS3lCLFdBQU4sRUFBbUIwRCxNQUFuQixDQUFMO0FBQ0FuRixTQUFLLENBQUMsS0FBS2lCLFdBQU4sRUFBbUJtRSxRQUFuQixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBSzBCLFlBQU4sRUFBb0IrQixNQUFwQixDQUFMO0FBQ0F6RCxTQUFLLENBQUMsS0FBSzZCLGFBQU4sRUFBcUI1QixLQUFLLENBQUNvRixLQUFOLENBQVksS0FBWixFQUFtQkQsUUFBbkIsQ0FBckIsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUs0QixhQUFOLEVBQXFCM0IsS0FBSyxDQUFDb0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXJCLENBQUw7QUFDQXBGLFNBQUssQ0FBQyxLQUFLOEIsYUFBTixFQUFxQm9ELE9BQXJCLENBQUw7QUFDQWxGLFNBQUssQ0FBQyxLQUFLZ0MsY0FBTixFQUFzQmtELE9BQXRCLENBQUw7QUFDQWxGLFNBQUssQ0FBQyxLQUFLK0IsY0FBTixFQUFzQjlCLEtBQUssQ0FBQ29GLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUF0QixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBS3FDLGVBQU4sRUFBdUI2QyxPQUF2QixDQUFMO0FBQ0FsRixTQUFLLENBQUMsS0FBS3dDLGdCQUFOLEVBQXdCdkMsS0FBSyxDQUFDb0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXhCLENBQUw7QUFDQXBGLFNBQUssQ0FBQyxLQUFLMEMsZ0JBQU4sRUFBd0J6QyxLQUFLLENBQUNvRixLQUFOLENBQVksS0FBWixFQUFtQkQsUUFBbkIsQ0FBeEIsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUsyQyxpQkFBTixFQUF5QjFDLEtBQUssQ0FBQ29GLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUF6QixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBSzRDLGlCQUFOLEVBQXlCdUMsTUFBekIsQ0FBTDtBQUNBbkYsU0FBSyxDQUFDLEtBQUtvQyxlQUFOLEVBQXVCbkMsS0FBSyxDQUFDb0YsS0FBTixDQUFZQyxNQUFaLEVBQW9CRixRQUFwQixDQUF2QixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBSzhDLHVCQUFOLEVBQStCb0MsT0FBL0IsQ0FBTDtBQUVBLFFBQUlyRixPQUFKLENBQVk7QUFDVmlELDZCQUF1QixFQUFFLEtBQUtBLHVCQURwQjtBQUVWeUMsMkJBQXFCLEVBQUUsS0FBS2pEO0FBRmxCLEtBQVo7O0FBS0EsUUFBSSxDQUFDLEtBQUtSLGFBQVYsRUFBeUI7QUFDdkIsVUFBSSxDQUFDekIsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLTCxrQkFBdEIsQ0FBRCxJQUE4QyxDQUFDLEtBQUtELGNBQXhELEVBQXdFO0FBQ3RFLGFBQUtDLGtCQUFMLG1CQUFtQyxLQUFLZixjQUF4QztBQUNEOztBQUVELFVBQUksQ0FBQyxLQUFLYyxjQUFWLEVBQTBCO0FBQ3hCLGFBQUtBLGNBQUwsR0FBc0IsSUFBSXhELEtBQUssQ0FBQytELFVBQVYsQ0FBcUIsS0FBS04sa0JBQTFCLENBQXRCO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsYUFBS0Esa0JBQUwsR0FBMEIsS0FBS0QsY0FBTCxDQUFvQlEsS0FBOUM7QUFDRDs7QUFDRHZELFdBQUssQ0FBQyxLQUFLZ0Qsa0JBQU4sRUFBMEJTLE1BQTFCLENBQUw7O0FBRUEsV0FBS1YsY0FBTCxDQUFvQnlDLFlBQXBCLENBQWlDO0FBQUVDLGlCQUFTLEVBQUU7QUFBYixPQUFqQyxFQUFtRDtBQUFFQywwQkFBa0IsRUFBRSxLQUFLOUMsaUJBQTNCO0FBQThDK0Msa0JBQVUsRUFBRTtBQUExRCxPQUFuRDs7QUFDQSxZQUFNQyxvQkFBb0IsR0FBRyxLQUFLN0MsY0FBTCxDQUFvQjhDLElBQXBCLENBQXlCLEVBQXpCLEVBQTZCO0FBQ3hEQyxjQUFNLEVBQUU7QUFDTkMsYUFBRyxFQUFFLENBREM7QUFFTkMsb0JBQVUsRUFBRTtBQUZOO0FBRGdELE9BQTdCLENBQTdCOztBQU9BSiwwQkFBb0IsQ0FBQ0ssT0FBckIsQ0FBNkI7QUFDM0JDLGVBQU8sQ0FBQ0MsR0FBRCxFQUFNO0FBQ1gsY0FBSUEsR0FBRyxDQUFDSCxVQUFSLEVBQW9CO0FBQ2xCL0MsZ0JBQUksQ0FBQzZCLE1BQUwsdUVBQTJFcUIsR0FBRyxDQUFDSixHQUEvRTs7QUFDQTlDLGdCQUFJLENBQUNGLGNBQUwsQ0FBb0JxRCxNQUFwQixDQUEyQjtBQUFDTCxpQkFBRyxFQUFFSSxHQUFHLENBQUNKO0FBQVYsYUFBM0IsRUFBMkNqRixJQUEzQztBQUNEO0FBQ0YsU0FOMEI7O0FBTzNCdUYsZUFBTyxDQUFDRixHQUFELEVBQU07QUFDWDtBQUNBO0FBQ0FsRCxjQUFJLENBQUM2QixNQUFMLHVFQUEyRXFCLEdBQUcsQ0FBQ0osR0FBL0U7O0FBQ0EsY0FBSTFGLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJkLElBQUksQ0FBQ2UsZUFBTCxDQUFxQm1DLEdBQUcsQ0FBQ0osR0FBekIsQ0FBakIsQ0FBSixFQUFxRDtBQUNuRDlDLGdCQUFJLENBQUNlLGVBQUwsQ0FBcUJtQyxHQUFHLENBQUNKLEdBQXpCLEVBQThCTyxJQUE5Qjs7QUFDQXJELGdCQUFJLENBQUNlLGVBQUwsQ0FBcUJtQyxHQUFHLENBQUNKLEdBQXpCLEVBQThCUSxHQUE5QixHQUZtRCxDQUluRDtBQUNBOzs7QUFDQSxnQkFBSSxDQUFDSixHQUFHLENBQUNILFVBQUwsSUFBbUIvQyxJQUFJLENBQUN6QixVQUFMLENBQWdCcUUsSUFBaEIsQ0FBcUI7QUFBRUUsaUJBQUcsRUFBRUksR0FBRyxDQUFDSjtBQUFYLGFBQXJCLEVBQXVDUyxLQUF2QyxPQUFtRCxDQUExRSxFQUE2RTtBQUMzRXZELGtCQUFJLENBQUM2QixNQUFMLHNGQUEwRnFCLEdBQUcsQ0FBQ0osR0FBOUY7O0FBQ0E5QyxrQkFBSSxDQUFDZSxlQUFMLENBQXFCbUMsR0FBRyxDQUFDSixHQUF6QixFQUE4QlUsS0FBOUI7QUFDRDs7QUFFRCxtQkFBT3hELElBQUksQ0FBQ2UsZUFBTCxDQUFxQm1DLEdBQUcsQ0FBQ0osR0FBekIsQ0FBUDtBQUNEO0FBQ0Y7O0FBeEIwQixPQUE3Qjs7QUEyQkEsV0FBS1csYUFBTCxHQUFxQixDQUFDWCxHQUFELEVBQU1ZLElBQU4sRUFBWUMsSUFBWixLQUFxQjtBQUN4QyxhQUFLNUMsZUFBTCxDQUFxQitCLEdBQXJCLElBQTRCLElBQUlqRyxXQUFKLENBQWdCNkcsSUFBaEIsRUFBc0JDLElBQUksQ0FBQ0MsVUFBM0IsRUFBdUNELElBQXZDLEVBQTZDLEtBQUtuRixXQUFsRCxDQUE1QjtBQUNELE9BRkQsQ0EvQ3VCLENBbUR2QjtBQUNBOzs7QUFDQSxXQUFLcUYsZUFBTCxHQUF3QmYsR0FBRCxJQUFTO0FBQzlCLFlBQUksS0FBSy9CLGVBQUwsQ0FBcUIrQixHQUFyQixLQUE2QixLQUFLL0IsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCZ0IsSUFBM0QsRUFBaUU7QUFDL0QsY0FBSSxDQUFDLEtBQUsvQyxlQUFMLENBQXFCK0IsR0FBckIsRUFBMEJpQixPQUEzQixJQUFzQyxDQUFDLEtBQUtoRCxlQUFMLENBQXFCK0IsR0FBckIsRUFBMEJrQixLQUFyRSxFQUE0RTtBQUMxRSxtQkFBTyxLQUFLakQsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCZ0IsSUFBakM7QUFDRDs7QUFDRCxlQUFLTCxhQUFMLENBQW1CWCxHQUFuQixFQUF3QixLQUFLL0IsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCZ0IsSUFBMUIsQ0FBK0JBLElBQS9CLENBQW9DSixJQUE1RCxFQUFrRSxLQUFLM0MsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCZ0IsSUFBNUY7O0FBQ0EsaUJBQU8sS0FBSy9DLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQWpDO0FBQ0Q7O0FBQ0QsY0FBTUcsUUFBUSxHQUFHLEtBQUtuRSxjQUFMLENBQW9Cb0UsT0FBcEIsQ0FBNEI7QUFBQ3BCO0FBQUQsU0FBNUIsQ0FBakI7O0FBQ0EsWUFBSW1CLFFBQUosRUFBYztBQUNaLGVBQUtSLGFBQUwsQ0FBbUJYLEdBQW5CLEVBQXdCbUIsUUFBUSxDQUFDSCxJQUFULENBQWNKLElBQXRDLEVBQTRDTyxRQUE1Qzs7QUFDQSxpQkFBTyxLQUFLbEQsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCZ0IsSUFBakM7QUFDRDs7QUFDRCxlQUFPLEtBQVA7QUFDRCxPQWREO0FBZUQ7O0FBRUQsUUFBSSxDQUFDLEtBQUs1RixNQUFWLEVBQWtCO0FBQ2hCLFdBQUtBLE1BQUwsR0FBY2pCLG1CQUFtQixDQUFDaUIsTUFBbEM7QUFDRDs7QUFFRG5CLFNBQUssQ0FBQyxLQUFLa0IsS0FBTixFQUFhZ0UsT0FBYixDQUFMO0FBQ0FsRixTQUFLLENBQUMsS0FBS21CLE1BQU4sRUFBY21FLE1BQWQsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUtvQixNQUFOLEVBQWM4RCxPQUFkLENBQUw7QUFDQWxGLFNBQUssQ0FBQyxLQUFLdUIsU0FBTixFQUFpQnRCLEtBQUssQ0FBQ29GLEtBQU4sQ0FBWUgsT0FBWixFQUFxQkUsUUFBckIsQ0FBakIsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUtzQixTQUFOLEVBQWlCNkQsTUFBakIsQ0FBTDtBQUNBbkYsU0FBSyxDQUFDLEtBQUsyQixhQUFOLEVBQXFCOEIsTUFBckIsQ0FBTDtBQUNBekQsU0FBSyxDQUFDLEtBQUttQyxjQUFOLEVBQXNCbEMsS0FBSyxDQUFDb0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXRCLENBQUw7QUFDQXBGLFNBQUssQ0FBQyxLQUFLa0MsY0FBTixFQUFzQmpDLEtBQUssQ0FBQ29GLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUF0QixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBS3lDLGdCQUFOLEVBQXdCeEMsS0FBSyxDQUFDb0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXhCLENBQUw7QUFDQXBGLFNBQUssQ0FBQyxLQUFLdUMsZUFBTixFQUF1QjJDLE9BQXZCLENBQUw7O0FBRUEsUUFBSSxLQUFLOUQsTUFBTCxJQUFlLEtBQUtHLFNBQXhCLEVBQW1DO0FBQ2pDLFlBQU0sSUFBSTVCLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsNkJBQTBDLEtBQUt6QixjQUEvQyxnRUFBTjtBQUNEOztBQUVELFNBQUttRixZQUFMLEdBQXFCQyxJQUFELElBQVU7QUFDNUIsVUFBSSxLQUFLOUYsU0FBVCxFQUFvQjtBQUNsQixZQUFJK0YsTUFBSjs7QUFDQSxjQUFNO0FBQUNDLGNBQUQ7QUFBT0M7QUFBUCxZQUFpQixLQUFLQyxRQUFMLENBQWNKLElBQWQsQ0FBdkI7O0FBRUEsWUFBSWhILE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS3JDLFNBQXhCLENBQUosRUFBd0M7QUFDdEMsY0FBSTJDLE9BQUo7O0FBQ0EsY0FBSTdELE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJzRCxJQUFJLENBQUNLLE1BQXRCLEtBQWtDTCxJQUFJLENBQUNLLE1BQUwsQ0FBWTNCLEdBQWxELEVBQXVEO0FBQ3JEN0IsbUJBQU8sR0FBRyxLQUFLMUMsVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCRSxJQUFJLENBQUNLLE1BQUwsQ0FBWTNCLEdBQXBDLENBQVY7QUFDRDs7QUFFRHVCLGdCQUFNLEdBQUdELElBQUksR0FBRyxLQUFLOUYsU0FBTCxDQUFlb0csSUFBZixDQUFvQnJDLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBY1AsSUFBZCxFQUFvQjtBQUFDRSxnQkFBRDtBQUFPQztBQUFQLFdBQXBCLENBQXBCLEVBQTBEdEQsT0FBTyxJQUFJLElBQXJFLENBQUgsR0FBaUYsS0FBSzNDLFNBQUwsQ0FBZW9HLElBQWYsQ0FBb0I7QUFBQ0osZ0JBQUQ7QUFBT0M7QUFBUCxXQUFwQixFQUFxQ3RELE9BQU8sSUFBSSxJQUFoRCxDQUE5RjtBQUNELFNBUEQsTUFPTztBQUNMb0QsZ0JBQU0sR0FBRyxDQUFDLENBQUNFLE1BQVg7QUFDRDs7QUFFRCxZQUFLSCxJQUFJLElBQUtDLE1BQU0sS0FBSyxJQUFyQixJQUErQixDQUFDRCxJQUFwQyxFQUEwQztBQUN4QyxpQkFBTyxJQUFQO0FBQ0Q7O0FBRUQsY0FBTVEsRUFBRSxHQUFHeEgsT0FBTyxDQUFDd0QsUUFBUixDQUFpQnlELE1BQWpCLElBQTJCQSxNQUEzQixHQUFvQyxHQUEvQzs7QUFDQSxhQUFLeEMsTUFBTCxDQUFZLHFEQUFaOztBQUNBLFlBQUl1QyxJQUFKLEVBQVU7QUFDUixnQkFBTVMsSUFBSSxHQUFHLGdCQUFiOztBQUNBLGNBQUksQ0FBQ1QsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxnQkFBSSxDQUFDVSxRQUFMLENBQWNFLFNBQWQsQ0FBd0JKLEVBQXhCLEVBQTRCO0FBQzFCLDhCQUFnQixZQURVO0FBRTFCLGdDQUFrQkMsSUFBSSxDQUFDSTtBQUZHLGFBQTVCO0FBSUQ7O0FBRUQsY0FBSSxDQUFDYixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGdCQUFJLENBQUNVLFFBQUwsQ0FBY3hCLEdBQWQsQ0FBa0J1QixJQUFsQjtBQUNEO0FBQ0Y7O0FBRUQsZUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsYUFBTyxJQUFQO0FBQ0QsS0F2Q0Q7O0FBeUNBLFNBQUtNLFlBQUwsR0FBb0I7QUFDbEJDLFlBQU0sa0NBQTJCLEtBQUtwRyxjQUFoQyxDQURZO0FBRWxCcUcsWUFBTSxrQ0FBMkIsS0FBS3JHLGNBQWhDLENBRlk7QUFHbEJzRyxZQUFNLGtDQUEyQixLQUFLdEcsY0FBaEMsQ0FIWTtBQUlsQnVHLGFBQU8sbUNBQTRCLEtBQUt2RyxjQUFqQztBQUpXLEtBQXBCO0FBT0EsU0FBS3dHLEVBQUwsQ0FBUSxlQUFSLEVBQXlCLEtBQUtDLGFBQTlCO0FBQ0EsU0FBS0QsRUFBTCxDQUFRLGVBQVIsRUFBeUIsS0FBS0UsYUFBOUI7QUFDQSxTQUFLQyxpQkFBTCxHQUF5QmpKLE1BQU0sQ0FBQ2tKLFNBQVAsQ0FBaUIsS0FBS0gsYUFBTCxDQUFtQkksSUFBbkIsQ0FBd0IsSUFBeEIsQ0FBakIsQ0FBekI7O0FBRUEsUUFBSSxLQUFLaEgsYUFBTCxJQUFzQixLQUFLTyxlQUEvQixFQUFnRDtBQUM5QztBQUNEOztBQUNEM0MsVUFBTSxDQUFDcUosZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsQ0FBQ0MsT0FBRCxFQUFVQyxRQUFWLEVBQW9CQyxJQUFwQixLQUE2QjtBQUN0RCxVQUFJLEtBQUs3RyxjQUFMLElBQXVCMkcsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0IwQyxRQUF4QixXQUFvQyxLQUFLMUgsYUFBekMsT0FBdkIsSUFBcUYsQ0FBQ3VILFFBQVEsQ0FBQ2xCLFdBQW5HLEVBQWdIO0FBQzlHLFlBQUksS0FBSzFGLGNBQUwsQ0FBb0JnSCxJQUFwQixDQUF5QkwsT0FBTyxDQUFDN0UsT0FBUixDQUFnQm1GLE1BQXpDLENBQUosRUFBc0Q7QUFDcERMLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsa0NBQW5CLEVBQXVELE1BQXZEO0FBQ0FOLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsNkJBQW5CLEVBQWtEUCxPQUFPLENBQUM3RSxPQUFSLENBQWdCbUYsTUFBbEU7QUFDRDs7QUFFRCxZQUFJTixPQUFPLENBQUNRLE1BQVIsS0FBbUIsU0FBdkIsRUFBa0M7QUFDaENQLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsOEJBQW5CLEVBQW1ELG9CQUFuRDtBQUNBTixrQkFBUSxDQUFDTSxTQUFULENBQW1CLDhCQUFuQixFQUFtRCxrRUFBbkQ7QUFDQU4sa0JBQVEsQ0FBQ00sU0FBVCxDQUFtQiwrQkFBbkIsRUFBb0QsZ0VBQXBEO0FBQ0FOLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsT0FBbkIsRUFBNEIsb0JBQTVCO0FBQ0FOLGtCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0FpQixrQkFBUSxDQUFDM0MsR0FBVDtBQUNBO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJLENBQUMsS0FBS3pFLGFBQU4sSUFBdUJtSCxPQUFPLENBQUNHLFVBQVIsQ0FBbUJ6QyxJQUFuQixDQUF3QjBDLFFBQXhCLFdBQW9DLEtBQUsxSCxhQUF6QyxjQUEwRCxLQUFLTSxjQUEvRCxlQUEzQixFQUFzSDtBQUNwSCxZQUFJZ0gsT0FBTyxDQUFDUSxNQUFSLEtBQW1CLE1BQXZCLEVBQStCO0FBQzdCTixjQUFJO0FBQ0o7QUFDRDs7QUFFRCxjQUFNTyxXQUFXLEdBQUlDLE1BQUQsSUFBWTtBQUM5QixjQUFJMUUsS0FBSyxHQUFHMEUsTUFBWjtBQUNBQyxpQkFBTyxDQUFDQyxJQUFSLENBQWEsOENBQWIsRUFBNkQ1RSxLQUE3RDtBQUNBMkUsaUJBQU8sQ0FBQ0UsS0FBUjs7QUFFQSxjQUFJLENBQUNaLFFBQVEsQ0FBQ2xCLFdBQWQsRUFBMkI7QUFDekJrQixvQkFBUSxDQUFDakIsU0FBVCxDQUFtQixHQUFuQjtBQUNEOztBQUVELGNBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QixnQkFBSTlILE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJrQixLQUFqQixLQUEyQjVFLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJxQixLQUFLLENBQUM4RSxRQUF6QixDQUEvQixFQUFtRTtBQUNqRTlFLG1CQUFLLEdBQUdBLEtBQUssQ0FBQzhFLFFBQU4sRUFBUjtBQUNEOztBQUVELGdCQUFJLENBQUMxSixPQUFPLENBQUNnRCxRQUFSLENBQWlCNEIsS0FBakIsQ0FBTCxFQUE4QjtBQUM1QkEsbUJBQUssR0FBRyxtQkFBUjtBQUNEOztBQUVEaUUsb0JBQVEsQ0FBQzNDLEdBQVQsQ0FBYXlELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQUVoRjtBQUFGLGFBQWYsQ0FBYjtBQUNEO0FBQ0YsU0FwQkQ7O0FBc0JBLFlBQUlpRixJQUFJLEdBQUcsRUFBWDs7QUFDQSxjQUFNQyxVQUFVLEdBQUcsTUFBTTtBQUN2QixjQUFJO0FBQ0YsZ0JBQUl2RCxJQUFKO0FBQ0EsZ0JBQUlVLE1BQUo7QUFDQSxnQkFBSUMsSUFBSjs7QUFFQSxnQkFBSTBCLE9BQU8sQ0FBQzdFLE9BQVIsQ0FBZ0IsUUFBaEIsS0FBNkIsS0FBS2dHLFVBQUwsQ0FBZ0JuQixPQUFPLENBQUM3RSxPQUFSLENBQWdCLFFBQWhCLENBQWhCLENBQWpDLEVBQTZFO0FBQzNFbUQsa0JBQUksR0FBRztBQUNMQyxzQkFBTSxFQUFFLEtBQUs0QyxVQUFMLENBQWdCbkIsT0FBTyxDQUFDN0UsT0FBUixDQUFnQixRQUFoQixDQUFoQjtBQURILGVBQVA7QUFHRCxhQUpELE1BSU87QUFDTG1ELGtCQUFJLEdBQUcsS0FBS0UsUUFBTCxDQUFjO0FBQUNqSCx1QkFBTyxFQUFFeUksT0FBVjtBQUFtQmxCLHdCQUFRLEVBQUVtQjtBQUE3QixlQUFkLENBQVA7QUFDRDs7QUFFRCxnQkFBSUQsT0FBTyxDQUFDN0UsT0FBUixDQUFnQixTQUFoQixNQUErQixHQUFuQyxFQUF3QztBQUN0Q3dDLGtCQUFJLEdBQUc7QUFDTHlELHNCQUFNLEVBQUVwQixPQUFPLENBQUM3RSxPQUFSLENBQWdCLFVBQWhCO0FBREgsZUFBUDs7QUFJQSxrQkFBSTZFLE9BQU8sQ0FBQzdFLE9BQVIsQ0FBZ0IsT0FBaEIsTUFBNkIsR0FBakMsRUFBc0M7QUFDcEN3QyxvQkFBSSxDQUFDMEQsR0FBTCxHQUFXLElBQVg7QUFDRCxlQUZELE1BRU87QUFDTDFELG9CQUFJLENBQUMyRCxPQUFMLEdBQWVDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZUCxJQUFaLEVBQWtCLFFBQWxCLENBQWY7QUFDQXRELG9CQUFJLENBQUM4RCxPQUFMLEdBQWU1RyxRQUFRLENBQUNtRixPQUFPLENBQUM3RSxPQUFSLENBQWdCLFdBQWhCLENBQUQsQ0FBdkI7QUFDRDs7QUFFRCxvQkFBTTBDLGVBQWUsR0FBRyxLQUFLQSxlQUFMLENBQXFCRixJQUFJLENBQUN5RCxNQUExQixDQUF4Qjs7QUFDQSxrQkFBSSxDQUFDdkQsZUFBTCxFQUFzQjtBQUNwQixzQkFBTSxJQUFJbkgsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQiw4REFBdEIsQ0FBTjtBQUNEOztBQUVELGVBQUM7QUFBQzRELHNCQUFEO0FBQVNWO0FBQVQsa0JBQWtCLEtBQUsrRCxjQUFMLENBQW9CckYsTUFBTSxDQUFDc0MsTUFBUCxDQUFjaEIsSUFBZCxFQUFvQkUsZUFBcEIsQ0FBcEIsRUFBMERTLElBQUksQ0FBQ0MsTUFBL0QsRUFBdUUsTUFBdkUsQ0FBbkI7O0FBRUEsa0JBQUlaLElBQUksQ0FBQzBELEdBQVQsRUFBYztBQUNaLHFCQUFLNUIsYUFBTCxDQUFtQnBCLE1BQW5CLEVBQTJCVixJQUEzQixFQUFrQytDLE1BQUQsSUFBWTtBQUMzQyxzQkFBSTFFLEtBQUssR0FBRzBFLE1BQVo7O0FBQ0Esc0JBQUkxRSxLQUFKLEVBQVc7QUFDVCx3QkFBSSxDQUFDaUUsUUFBUSxDQUFDbEIsV0FBZCxFQUEyQjtBQUN6QmtCLDhCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0Q7O0FBRUQsd0JBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QiwwQkFBSTlILE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJrQixLQUFqQixLQUEyQjVFLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJxQixLQUFLLENBQUM4RSxRQUF6QixDQUEvQixFQUFtRTtBQUNqRTlFLDZCQUFLLEdBQUdBLEtBQUssQ0FBQzhFLFFBQU4sRUFBUjtBQUNEOztBQUVELDBCQUFJLENBQUMxSixPQUFPLENBQUNnRCxRQUFSLENBQWlCNEIsS0FBakIsQ0FBTCxFQUE4QjtBQUM1QkEsNkJBQUssR0FBRyxtQkFBUjtBQUNEOztBQUVEaUUsOEJBQVEsQ0FBQzNDLEdBQVQsQ0FBYXlELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQUVoRjtBQUFGLHVCQUFmLENBQWI7QUFDRDtBQUNGOztBQUVELHNCQUFJLENBQUNpRSxRQUFRLENBQUNsQixXQUFkLEVBQTJCO0FBQ3pCa0IsNEJBQVEsQ0FBQ2pCLFNBQVQsQ0FBbUIsR0FBbkI7QUFDRDs7QUFFRCxzQkFBSTVILE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJ1RCxNQUFNLENBQUNQLElBQXhCLEtBQWlDTyxNQUFNLENBQUNQLElBQVAsQ0FBWTZELElBQWpELEVBQXVEO0FBQ3JEdEQsMEJBQU0sQ0FBQ1AsSUFBUCxDQUFZNkQsSUFBWixHQUFtQnhLLGdCQUFnQixDQUFDa0gsTUFBTSxDQUFDUCxJQUFQLENBQVk2RCxJQUFiLENBQW5DO0FBQ0Q7O0FBRUQsc0JBQUksQ0FBQzFCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QmUsNEJBQVEsQ0FBQzNDLEdBQVQsQ0FBYXlELElBQUksQ0FBQ0MsU0FBTCxDQUFlM0MsTUFBZixDQUFiO0FBQ0Q7QUFDRixpQkEvQkQ7O0FBZ0NBO0FBQ0Q7O0FBRUQsbUJBQUt1RCxJQUFMLENBQVUsZUFBVixFQUEyQnZELE1BQTNCLEVBQW1DVixJQUFuQyxFQUF5QzlGLElBQXpDOztBQUVBLGtCQUFJLENBQUNvSSxRQUFRLENBQUNsQixXQUFkLEVBQTJCO0FBQ3pCa0Isd0JBQVEsQ0FBQ2pCLFNBQVQsQ0FBbUIsR0FBbkI7QUFDRDs7QUFDRCxrQkFBSSxDQUFDaUIsUUFBUSxDQUFDZixRQUFkLEVBQXdCO0FBQ3RCZSx3QkFBUSxDQUFDM0MsR0FBVDtBQUNEO0FBQ0YsYUEvREQsTUErRE87QUFDTCxrQkFBSTtBQUNGSyxvQkFBSSxHQUFHb0QsSUFBSSxDQUFDYyxLQUFMLENBQVdaLElBQVgsQ0FBUDtBQUNELGVBRkQsQ0FFRSxPQUFPYSxPQUFQLEVBQWdCO0FBQ2hCbkIsdUJBQU8sQ0FBQzNFLEtBQVIsQ0FBYyx1RkFBZCxFQUF1RzhGLE9BQXZHO0FBQ0FuRSxvQkFBSSxHQUFHO0FBQUNHLHNCQUFJLEVBQUU7QUFBUCxpQkFBUDtBQUNEOztBQUVELGtCQUFJLENBQUMxRyxPQUFPLENBQUMwRCxRQUFSLENBQWlCNkMsSUFBSSxDQUFDRyxJQUF0QixDQUFMLEVBQWtDO0FBQ2hDSCxvQkFBSSxDQUFDRyxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVESCxrQkFBSSxDQUFDb0UsSUFBTCxHQUFZLElBQVo7O0FBQ0EsbUJBQUtsRyxNQUFMLCtDQUFtRDhCLElBQUksQ0FBQ0csSUFBTCxDQUFVa0UsSUFBVixJQUFrQixXQUFyRSxnQkFBc0ZyRSxJQUFJLENBQUN5RCxNQUEzRjs7QUFDQSxrQkFBSWhLLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFJLENBQUNHLElBQXRCLEtBQStCSCxJQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQTdDLEVBQW1EO0FBQ2pEaEUsb0JBQUksQ0FBQ0csSUFBTCxDQUFVNkQsSUFBVixHQUFpQnpLLFlBQVksQ0FBQ3lHLElBQUksQ0FBQ0csSUFBTCxDQUFVNkQsSUFBWCxDQUE3QjtBQUNEOztBQUVELGVBQUM7QUFBQ3REO0FBQUQsa0JBQVcsS0FBS3FELGNBQUwsQ0FBb0J0SyxPQUFPLENBQUM2SyxLQUFSLENBQWN0RSxJQUFkLENBQXBCLEVBQXlDVyxJQUFJLENBQUNDLE1BQTlDLEVBQXNELG1CQUF0RCxDQUFaOztBQUVBLGtCQUFJLEtBQUtoRyxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JHLE1BQU0sQ0FBQ3ZCLEdBQS9CLENBQUosRUFBeUM7QUFDdkMsc0JBQU0sSUFBSXBHLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0Isa0RBQXRCLENBQU47QUFDRDs7QUFFRGtELGtCQUFJLENBQUNiLEdBQUwsR0FBaUJhLElBQUksQ0FBQ3lELE1BQXRCO0FBQ0F6RCxrQkFBSSxDQUFDbkIsU0FBTCxHQUFpQixJQUFJMEYsSUFBSixFQUFqQjtBQUNBdkUsa0JBQUksQ0FBQ3dFLFNBQUwsR0FBaUJ4RSxJQUFJLENBQUNDLFVBQXRCOztBQUNBLG1CQUFLOUQsY0FBTCxDQUFvQnNJLE1BQXBCLENBQTJCaEwsT0FBTyxDQUFDaUwsSUFBUixDQUFhMUUsSUFBYixFQUFtQixNQUFuQixDQUEzQjs7QUFDQSxtQkFBS0YsYUFBTCxDQUFtQlksTUFBTSxDQUFDdkIsR0FBMUIsRUFBK0J1QixNQUFNLENBQUNYLElBQXRDLEVBQTRDdEcsT0FBTyxDQUFDaUwsSUFBUixDQUFhMUUsSUFBYixFQUFtQixNQUFuQixDQUE1Qzs7QUFFQSxrQkFBSUEsSUFBSSxDQUFDMkUsVUFBVCxFQUFxQjtBQUNuQixvQkFBSSxDQUFDckMsUUFBUSxDQUFDbEIsV0FBZCxFQUEyQjtBQUN6QmtCLDBCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0Q7O0FBRUQsb0JBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QmUsMEJBQVEsQ0FBQzNDLEdBQVQsQ0FBYXlELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCdUIsK0JBQVcsWUFBSyxLQUFLN0osYUFBVixjQUEyQixLQUFLTSxjQUFoQyxjQURlO0FBRTFCOEUsd0JBQUksRUFBRU87QUFGb0IsbUJBQWYsQ0FBYjtBQUlEO0FBQ0YsZUFYRCxNQVdPO0FBQ0wsb0JBQUksQ0FBQzRCLFFBQVEsQ0FBQ2xCLFdBQWQsRUFBMkI7QUFDekJrQiwwQkFBUSxDQUFDakIsU0FBVCxDQUFtQixHQUFuQjtBQUNEOztBQUVELG9CQUFJLENBQUNpQixRQUFRLENBQUNmLFFBQWQsRUFBd0I7QUFDdEJlLDBCQUFRLENBQUMzQyxHQUFUO0FBQ0Q7QUFDRjtBQUNGO0FBQ0YsV0EvSEQsQ0ErSEUsT0FBT2tGLFdBQVAsRUFBb0I7QUFDcEIvQix1QkFBVyxDQUFDK0IsV0FBRCxDQUFYO0FBQ0Q7QUFDRixTQW5JRDs7QUFxSUF4QyxlQUFPLENBQUN5QyxVQUFSLENBQW1CLEtBQW5CLEVBQTBCaEMsV0FBMUI7O0FBQ0EsWUFBSSxPQUFPVCxPQUFPLENBQUNpQixJQUFmLEtBQXdCLFFBQXhCLElBQW9DNUUsTUFBTSxDQUFDcUcsSUFBUCxDQUFZMUMsT0FBTyxDQUFDaUIsSUFBcEIsRUFBMEJoQyxNQUExQixLQUFxQyxDQUE3RSxFQUFnRjtBQUM5RWdDLGNBQUksR0FBR0YsSUFBSSxDQUFDQyxTQUFMLENBQWVoQixPQUFPLENBQUNpQixJQUF2QixDQUFQO0FBQ0FDLG9CQUFVO0FBQ1gsU0FIRCxNQUdPO0FBQ0xsQixpQkFBTyxDQUFDUixFQUFSLENBQVcsTUFBWCxFQUFvQm1ELElBQUQsSUFBVWpMLEtBQUssQ0FBQyxNQUFNO0FBQ3ZDdUosZ0JBQUksSUFBSTBCLElBQVI7QUFDRCxXQUZpQyxDQUFsQztBQUlBM0MsaUJBQU8sQ0FBQ1IsRUFBUixDQUFXLEtBQVgsRUFBa0IsTUFBTTlILEtBQUssQ0FBQyxNQUFNO0FBQ2xDd0osc0JBQVU7QUFDWCxXQUY0QixDQUE3QjtBQUdEOztBQUNEO0FBQ0Q7O0FBRUQsVUFBSSxDQUFDLEtBQUs5SCxlQUFWLEVBQTJCO0FBQ3pCLFlBQUl3SixHQUFKOztBQUVBLFlBQUksQ0FBQyxLQUFLekssTUFBVixFQUFrQjtBQUNoQixjQUFJNkgsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0IwQyxRQUF4QixXQUFvQyxLQUFLMUgsYUFBekMsY0FBMEQsS0FBS00sY0FBL0QsRUFBSixFQUFzRjtBQUNwRjRKLGVBQUcsR0FBRzVDLE9BQU8sQ0FBQ0csVUFBUixDQUFtQnpDLElBQW5CLENBQXdCaEQsT0FBeEIsV0FBbUMsS0FBS2hDLGFBQXhDLGNBQXlELEtBQUtNLGNBQTlELEdBQWdGLEVBQWhGLENBQU47O0FBQ0EsZ0JBQUk0SixHQUFHLENBQUNDLE9BQUosQ0FBWSxHQUFaLE1BQXFCLENBQXpCLEVBQTRCO0FBQzFCRCxpQkFBRyxHQUFHQSxHQUFHLENBQUNFLFNBQUosQ0FBYyxDQUFkLENBQU47QUFDRDs7QUFFRCxrQkFBTUMsSUFBSSxHQUFHSCxHQUFHLENBQUNJLEtBQUosQ0FBVSxHQUFWLENBQWI7O0FBQ0EsZ0JBQUlELElBQUksQ0FBQzlELE1BQUwsS0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsb0JBQU1SLE1BQU0sR0FBRztBQUNiM0IsbUJBQUcsRUFBRWlHLElBQUksQ0FBQyxDQUFELENBREk7QUFFYkUscUJBQUssRUFBRWpELE9BQU8sQ0FBQ0csVUFBUixDQUFtQjhDLEtBQW5CLEdBQTJCM0wsTUFBTSxDQUFDdUssS0FBUCxDQUFhN0IsT0FBTyxDQUFDRyxVQUFSLENBQW1COEMsS0FBaEMsQ0FBM0IsR0FBb0UsRUFGOUQ7QUFHYmpCLG9CQUFJLEVBQUVlLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FITztBQUliRSx1QkFBTyxFQUFFSCxJQUFJLENBQUMsQ0FBRDtBQUpBLGVBQWY7QUFPQSxvQkFBTTNFLElBQUksR0FBRztBQUFDN0csdUJBQU8sRUFBRXlJLE9BQVY7QUFBbUJsQix3QkFBUSxFQUFFbUIsUUFBN0I7QUFBdUN4QjtBQUF2QyxlQUFiOztBQUNBLGtCQUFJLEtBQUtoRixnQkFBTCxJQUF5QnJDLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS2xCLGdCQUF4QixDQUF6QixJQUFzRSxLQUFLQSxnQkFBTCxDQUFzQjJFLElBQXRCLE1BQWdDLElBQTFHLEVBQWdIO0FBQzlHO0FBQ0Q7O0FBRUQsa0JBQUksS0FBS0QsWUFBTCxDQUFrQkMsSUFBbEIsQ0FBSixFQUE2QjtBQUMzQixxQkFBSytFLFFBQUwsQ0FBYy9FLElBQWQsRUFBb0IyRSxJQUFJLENBQUMsQ0FBRCxDQUF4QixFQUE2QixLQUFLeEssVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCNkUsSUFBSSxDQUFDLENBQUQsQ0FBNUIsQ0FBN0I7QUFDRDtBQUNGLGFBaEJELE1BZ0JPO0FBQ0w3QyxrQkFBSTtBQUNMO0FBQ0YsV0ExQkQsTUEwQk87QUFDTEEsZ0JBQUk7QUFDTDtBQUNGLFNBOUJELE1BOEJPO0FBQ0wsY0FBSUYsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0IwQyxRQUF4QixXQUFvQyxLQUFLMUgsYUFBekMsRUFBSixFQUErRDtBQUM3RGtLLGVBQUcsR0FBRzVDLE9BQU8sQ0FBQ0csVUFBUixDQUFtQnpDLElBQW5CLENBQXdCaEQsT0FBeEIsV0FBbUMsS0FBS2hDLGFBQXhDLEdBQXlELEVBQXpELENBQU47O0FBQ0EsZ0JBQUlrSyxHQUFHLENBQUNDLE9BQUosQ0FBWSxHQUFaLE1BQXFCLENBQXpCLEVBQTRCO0FBQzFCRCxpQkFBRyxHQUFHQSxHQUFHLENBQUNFLFNBQUosQ0FBYyxDQUFkLENBQU47QUFDRDs7QUFFRCxrQkFBTUMsSUFBSSxHQUFHSCxHQUFHLENBQUNJLEtBQUosQ0FBVSxHQUFWLENBQWI7QUFDQSxnQkFBSUksS0FBSyxHQUFHTCxJQUFJLENBQUNBLElBQUksQ0FBQzlELE1BQUwsR0FBYyxDQUFmLENBQWhCOztBQUNBLGdCQUFJbUUsS0FBSixFQUFXO0FBQ1Qsa0JBQUlGLE9BQUo7O0FBQ0Esa0JBQUlFLEtBQUssQ0FBQ2hELFFBQU4sQ0FBZSxHQUFmLENBQUosRUFBeUI7QUFDdkI4Qyx1QkFBTyxHQUFHRSxLQUFLLENBQUNKLEtBQU4sQ0FBWSxHQUFaLEVBQWlCLENBQWpCLENBQVY7QUFDQUkscUJBQUssR0FBS0EsS0FBSyxDQUFDSixLQUFOLENBQVksR0FBWixFQUFpQixDQUFqQixFQUFvQkEsS0FBcEIsQ0FBMEIsR0FBMUIsRUFBK0IsQ0FBL0IsQ0FBVjtBQUNELGVBSEQsTUFHTztBQUNMRSx1QkFBTyxHQUFHLFVBQVY7QUFDQUUscUJBQUssR0FBS0EsS0FBSyxDQUFDSixLQUFOLENBQVksR0FBWixFQUFpQixDQUFqQixDQUFWO0FBQ0Q7O0FBRUQsb0JBQU12RSxNQUFNLEdBQUc7QUFDYndFLHFCQUFLLEVBQUVqRCxPQUFPLENBQUNHLFVBQVIsQ0FBbUI4QyxLQUFuQixHQUEyQjNMLE1BQU0sQ0FBQ3VLLEtBQVAsQ0FBYTdCLE9BQU8sQ0FBQ0csVUFBUixDQUFtQjhDLEtBQWhDLENBQTNCLEdBQW9FLEVBRDlEO0FBRWJuRixvQkFBSSxFQUFFc0YsS0FGTztBQUdidEcsbUJBQUcsRUFBRXNHLEtBQUssQ0FBQ0osS0FBTixDQUFZLEdBQVosRUFBaUIsQ0FBakIsQ0FIUTtBQUliRSx1QkFKYTtBQUtibEIsb0JBQUksRUFBRW9CO0FBTE8sZUFBZjtBQU9BLG9CQUFNaEYsSUFBSSxHQUFHO0FBQUM3Ryx1QkFBTyxFQUFFeUksT0FBVjtBQUFtQmxCLHdCQUFRLEVBQUVtQixRQUE3QjtBQUF1Q3hCO0FBQXZDLGVBQWI7O0FBQ0Esa0JBQUksS0FBS2hGLGdCQUFMLElBQXlCckMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLbEIsZ0JBQXhCLENBQXpCLElBQXNFLEtBQUtBLGdCQUFMLENBQXNCMkUsSUFBdEIsTUFBZ0MsSUFBMUcsRUFBZ0g7QUFDOUc7QUFDRDs7QUFDRCxtQkFBSytFLFFBQUwsQ0FBYy9FLElBQWQsRUFBb0I4RSxPQUFwQixFQUE2QixLQUFLM0ssVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCTyxNQUFNLENBQUMzQixHQUEvQixDQUE3QjtBQUNELGFBdEJELE1Bc0JPO0FBQ0xvRCxrQkFBSTtBQUNMO0FBQ0YsV0FqQ0QsTUFpQ087QUFDTEEsZ0JBQUk7QUFDTDtBQUNGOztBQUNEO0FBQ0Q7O0FBQ0RBLFVBQUk7QUFDTCxLQTlRRDs7QUFnUkEsUUFBSSxDQUFDLEtBQUtySCxhQUFWLEVBQXlCO0FBQ3ZCLFlBQU13SyxRQUFRLEdBQUcsRUFBakIsQ0FEdUIsQ0FHdkI7QUFDQTs7QUFDQUEsY0FBUSxDQUFDLEtBQUtsRSxZQUFMLENBQWtCSSxPQUFuQixDQUFSLEdBQXNDLFVBQVUrRCxRQUFWLEVBQW9CO0FBQ3hEdk0sYUFBSyxDQUFDdU0sUUFBRCxFQUFXdE0sS0FBSyxDQUFDb0YsS0FBTixDQUFZNUIsTUFBWixFQUFvQjZCLE1BQXBCLENBQVgsQ0FBTDs7QUFDQXJDLFlBQUksQ0FBQzZCLE1BQUwsc0RBQTBEeUgsUUFBMUQ7O0FBRUEsWUFBSXRKLElBQUksQ0FBQ1YsZUFBVCxFQUEwQjtBQUN4QixjQUFJVSxJQUFJLENBQUNsQixjQUFMLElBQXVCMUIsT0FBTyxDQUFDdUQsVUFBUixDQUFtQlgsSUFBSSxDQUFDbEIsY0FBeEIsQ0FBM0IsRUFBb0U7QUFDbEUsa0JBQU15RixNQUFNLEdBQUcsS0FBS0EsTUFBcEI7QUFDQSxrQkFBTWdGLFNBQVMsR0FBRztBQUNoQmhGLG9CQUFNLEVBQUUsS0FBS0EsTUFERzs7QUFFaEJELGtCQUFJLEdBQUc7QUFDTCxvQkFBSTVILE1BQU0sQ0FBQzhNLEtBQVgsRUFBa0I7QUFDaEIseUJBQU85TSxNQUFNLENBQUM4TSxLQUFQLENBQWF0RixPQUFiLENBQXFCSyxNQUFyQixDQUFQO0FBQ0Q7O0FBQ0QsdUJBQU8sSUFBUDtBQUNEOztBQVBlLGFBQWxCOztBQVVBLGdCQUFJLENBQUN2RSxJQUFJLENBQUNsQixjQUFMLENBQW9CNEYsSUFBcEIsQ0FBeUI2RSxTQUF6QixFQUFxQ3ZKLElBQUksQ0FBQzRDLElBQUwsQ0FBVTBHLFFBQVYsS0FBdUIsSUFBNUQsQ0FBTCxFQUF5RTtBQUN2RSxvQkFBTSxJQUFJNU0sTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQiwyQ0FBdEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBRUQsZ0JBQU1nSixNQUFNLEdBQUd6SixJQUFJLENBQUM0QyxJQUFMLENBQVUwRyxRQUFWLENBQWY7O0FBQ0EsY0FBSUcsTUFBTSxDQUFDbEcsS0FBUCxLQUFpQixDQUFyQixFQUF3QjtBQUN0QnZELGdCQUFJLENBQUNtRCxNQUFMLENBQVltRyxRQUFaO0FBQ0EsbUJBQU8sSUFBUDtBQUNEOztBQUNELGdCQUFNLElBQUk1TSxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHNDQUF0QixDQUFOO0FBQ0QsU0F4QkQsTUF3Qk87QUFDTCxnQkFBTSxJQUFJL0QsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpRUFBdEIsQ0FBTjtBQUNEO0FBQ0YsT0EvQkQsQ0FMdUIsQ0F1Q3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E0SSxjQUFRLENBQUMsS0FBS2xFLFlBQUwsQ0FBa0JHLE1BQW5CLENBQVIsR0FBcUMsVUFBVTNCLElBQVYsRUFBZ0IyRSxVQUFoQixFQUE0QjtBQUMvRHZMLGFBQUssQ0FBQzRHLElBQUQsRUFBTztBQUNWRyxjQUFJLEVBQUV6QixNQURJO0FBRVYrRSxnQkFBTSxFQUFFNUcsTUFGRTtBQUdWa0osZ0JBQU0sRUFBRTFNLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZW5KLE1BQWYsQ0FIRTtBQUlWbkMsbUJBQVMsRUFBRTZELE1BSkQ7QUFLVjBCLG9CQUFVLEVBQUUxQjtBQUxGLFNBQVAsQ0FBTDtBQVFBbkYsYUFBSyxDQUFDdUwsVUFBRCxFQUFhdEwsS0FBSyxDQUFDMk0sUUFBTixDQUFlMUgsT0FBZixDQUFiLENBQUw7O0FBRUFqQyxZQUFJLENBQUM2QixNQUFMLGlEQUFxRDhCLElBQUksQ0FBQ0csSUFBTCxDQUFVa0UsSUFBL0QsZ0JBQXlFckUsSUFBSSxDQUFDeUQsTUFBOUU7O0FBQ0F6RCxZQUFJLENBQUNvRSxJQUFMLEdBQVksSUFBWjs7QUFDQSxjQUFNO0FBQUUxRDtBQUFGLFlBQWFyRSxJQUFJLENBQUMwSCxjQUFMLENBQW9CdEssT0FBTyxDQUFDNkssS0FBUixDQUFjdEUsSUFBZCxDQUFwQixFQUF5QyxLQUFLWSxNQUE5QyxFQUFzRCxrQkFBdEQsQ0FBbkI7O0FBRUEsWUFBSXZFLElBQUksQ0FBQ3pCLFVBQUwsQ0FBZ0IyRixPQUFoQixDQUF3QkcsTUFBTSxDQUFDdkIsR0FBL0IsQ0FBSixFQUF5QztBQUN2QyxnQkFBTSxJQUFJcEcsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrREFBdEIsQ0FBTjtBQUNEOztBQUVEa0QsWUFBSSxDQUFDYixHQUFMLEdBQWlCYSxJQUFJLENBQUN5RCxNQUF0QjtBQUNBekQsWUFBSSxDQUFDbkIsU0FBTCxHQUFpQixJQUFJMEYsSUFBSixFQUFqQjtBQUNBdkUsWUFBSSxDQUFDd0UsU0FBTCxHQUFpQnhFLElBQUksQ0FBQ0MsVUFBdEI7O0FBQ0EsWUFBSTtBQUNGNUQsY0FBSSxDQUFDRixjQUFMLENBQW9Cc0ksTUFBcEIsQ0FBMkJoTCxPQUFPLENBQUNpTCxJQUFSLENBQWExRSxJQUFiLEVBQW1CLE1BQW5CLENBQTNCOztBQUNBM0QsY0FBSSxDQUFDeUQsYUFBTCxDQUFtQlksTUFBTSxDQUFDdkIsR0FBMUIsRUFBK0J1QixNQUFNLENBQUNYLElBQXRDLEVBQTRDdEcsT0FBTyxDQUFDaUwsSUFBUixDQUFhMUUsSUFBYixFQUFtQixNQUFuQixDQUE1QztBQUNELFNBSEQsQ0FHRSxPQUFPaUcsQ0FBUCxFQUFVO0FBQ1Y1SixjQUFJLENBQUM2QixNQUFMLDhEQUFrRThCLElBQUksQ0FBQ0csSUFBTCxDQUFVa0UsSUFBNUUsZ0JBQXNGckUsSUFBSSxDQUFDeUQsTUFBM0YsR0FBcUd3QyxDQUFyRzs7QUFDQSxnQkFBTSxJQUFJbE4sTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7O0FBRUQsWUFBSTZILFVBQUosRUFBZ0I7QUFDZCxpQkFBTztBQUNMQyx1QkFBVyxZQUFLdkksSUFBSSxDQUFDdEIsYUFBVixjQUEyQnNCLElBQUksQ0FBQ2hCLGNBQWhDLGNBRE47QUFFTDhFLGdCQUFJLEVBQUVPO0FBRkQsV0FBUDtBQUlEOztBQUNELGVBQU8sSUFBUDtBQUNELE9BckNELENBN0N1QixDQXFGdkI7QUFDQTtBQUNBOzs7QUFDQWdGLGNBQVEsQ0FBQyxLQUFLbEUsWUFBTCxDQUFrQkUsTUFBbkIsQ0FBUixHQUFxQyxVQUFVd0UsS0FBVixFQUFpQjtBQUNwRCxZQUFJbEcsSUFBSSxHQUFHa0csS0FBWDtBQUNBLFlBQUl4RixNQUFKO0FBQ0F0SCxhQUFLLENBQUM0RyxJQUFELEVBQU87QUFDVjBELGFBQUcsRUFBRXJLLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZTFILE9BQWYsQ0FESztBQUVWbUYsZ0JBQU0sRUFBRTVHLE1BRkU7QUFHVjhHLGlCQUFPLEVBQUV0SyxLQUFLLENBQUMyTSxRQUFOLENBQWVuSixNQUFmLENBSEM7QUFJVmlILGlCQUFPLEVBQUV6SyxLQUFLLENBQUMyTSxRQUFOLENBQWV6SCxNQUFmO0FBSkMsU0FBUCxDQUFMOztBQU9BLFlBQUl5QixJQUFJLENBQUMyRCxPQUFULEVBQWtCO0FBQ2hCM0QsY0FBSSxDQUFDMkQsT0FBTCxHQUFlQyxNQUFNLENBQUNDLElBQVAsQ0FBWTdELElBQUksQ0FBQzJELE9BQWpCLEVBQTBCLFFBQTFCLENBQWY7QUFDRDs7QUFFRCxjQUFNekQsZUFBZSxHQUFHN0QsSUFBSSxDQUFDNkQsZUFBTCxDQUFxQkYsSUFBSSxDQUFDeUQsTUFBMUIsQ0FBeEI7O0FBQ0EsWUFBSSxDQUFDdkQsZUFBTCxFQUFzQjtBQUNwQixnQkFBTSxJQUFJbkgsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQiw4REFBdEIsQ0FBTjtBQUNEOztBQUVELGFBQUtxSixPQUFMO0FBQ0EsU0FBQztBQUFDekYsZ0JBQUQ7QUFBU1Y7QUFBVCxZQUFpQjNELElBQUksQ0FBQzBILGNBQUwsQ0FBb0JyRixNQUFNLENBQUNzQyxNQUFQLENBQWNoQixJQUFkLEVBQW9CRSxlQUFwQixDQUFwQixFQUEwRCxLQUFLVSxNQUEvRCxFQUF1RSxLQUF2RSxDQUFsQjs7QUFFQSxZQUFJWixJQUFJLENBQUMwRCxHQUFULEVBQWM7QUFDWixjQUFJO0FBQ0YsbUJBQU9ySCxJQUFJLENBQUMyRixpQkFBTCxDQUF1QnRCLE1BQXZCLEVBQStCVixJQUEvQixDQUFQO0FBQ0QsV0FGRCxDQUVFLE9BQU9vRyxlQUFQLEVBQXdCO0FBQ3hCL0osZ0JBQUksQ0FBQzZCLE1BQUwsQ0FBWSxtREFBWixFQUFpRWtJLGVBQWpFOztBQUNBLGtCQUFNQSxlQUFOO0FBQ0Q7QUFDRixTQVBELE1BT087QUFDTC9KLGNBQUksQ0FBQzRILElBQUwsQ0FBVSxlQUFWLEVBQTJCdkQsTUFBM0IsRUFBbUNWLElBQW5DLEVBQXlDOUYsSUFBekM7QUFDRDs7QUFDRCxlQUFPLElBQVA7QUFDRCxPQWpDRCxDQXhGdUIsQ0EySHZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBd0wsY0FBUSxDQUFDLEtBQUtsRSxZQUFMLENBQWtCQyxNQUFuQixDQUFSLEdBQXFDLFVBQVV0QyxHQUFWLEVBQWU7QUFDbEQvRixhQUFLLENBQUMrRixHQUFELEVBQU10QyxNQUFOLENBQUw7O0FBRUEsY0FBTXFELGVBQWUsR0FBRzdELElBQUksQ0FBQzZELGVBQUwsQ0FBcUJmLEdBQXJCLENBQXhCOztBQUNBOUMsWUFBSSxDQUFDNkIsTUFBTCw2Q0FBaURpQixHQUFqRCxnQkFBMkQxRixPQUFPLENBQUMwRCxRQUFSLENBQWlCK0MsZUFBZSxDQUFDQyxJQUFqQyxJQUF5Q0QsZUFBZSxDQUFDQyxJQUFoQixDQUFxQkosSUFBOUQsR0FBcUUsRUFBaEk7O0FBRUEsWUFBSTFELElBQUksQ0FBQ2UsZUFBTCxJQUF3QmYsSUFBSSxDQUFDZSxlQUFMLENBQXFCK0IsR0FBckIsQ0FBNUIsRUFBdUQ7QUFDckQ5QyxjQUFJLENBQUNlLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQk8sSUFBMUI7O0FBQ0FyRCxjQUFJLENBQUNlLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQlUsS0FBMUI7QUFDRDs7QUFFRCxZQUFJSyxlQUFKLEVBQXFCO0FBQ25CN0QsY0FBSSxDQUFDRixjQUFMLENBQW9CcUQsTUFBcEIsQ0FBMkI7QUFBQ0w7QUFBRCxXQUEzQjs7QUFDQTlDLGNBQUksQ0FBQ21ELE1BQUwsQ0FBWTtBQUFDTDtBQUFELFdBQVo7O0FBQ0EsY0FBSTFGLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUIrQyxlQUFlLENBQUNDLElBQWpDLEtBQTBDRCxlQUFlLENBQUNDLElBQWhCLENBQXFCSixJQUFuRSxFQUF5RTtBQUN2RTFELGdCQUFJLENBQUNnSyxNQUFMLENBQVk7QUFBQ2xILGlCQUFEO0FBQU1ZLGtCQUFJLEVBQUVHLGVBQWUsQ0FBQ0MsSUFBaEIsQ0FBcUJKO0FBQWpDLGFBQVo7QUFDRDtBQUNGOztBQUNELGVBQU8sSUFBUDtBQUNELE9BbkJEOztBQXFCQWhILFlBQU0sQ0FBQ3VOLE9BQVAsQ0FBZVosUUFBZjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UzQixnQkFBYyxHQUErQjtBQUFBLFFBQTlCL0QsSUFBOEIsdUVBQXZCLEVBQXVCO0FBQUEsUUFBbkJZLE1BQW1CO0FBQUEsUUFBWDJGLFNBQVc7QUFDM0MsUUFBSUMsR0FBSjs7QUFDQSxRQUFJLENBQUMvTSxPQUFPLENBQUM2QyxTQUFSLENBQWtCMEQsSUFBSSxDQUFDMEQsR0FBdkIsQ0FBTCxFQUFrQztBQUNoQzFELFVBQUksQ0FBQzBELEdBQUwsR0FBVyxLQUFYO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDMUQsSUFBSSxDQUFDMkQsT0FBVixFQUFtQjtBQUNqQjNELFVBQUksQ0FBQzJELE9BQUwsR0FBZSxLQUFmO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDbEssT0FBTyxDQUFDd0QsUUFBUixDQUFpQitDLElBQUksQ0FBQzhELE9BQXRCLENBQUwsRUFBcUM7QUFDbkM5RCxVQUFJLENBQUM4RCxPQUFMLEdBQWUsQ0FBQyxDQUFoQjtBQUNEOztBQUVELFFBQUksQ0FBQ3JLLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUJ1RCxJQUFJLENBQUMrRixNQUF0QixDQUFMLEVBQW9DO0FBQ2xDL0YsVUFBSSxDQUFDK0YsTUFBTCxHQUFjL0YsSUFBSSxDQUFDeUQsTUFBbkI7QUFDRDs7QUFFRCxTQUFLdkYsTUFBTCx1Q0FBMkNxSSxTQUEzQyxvQkFBOER2RyxJQUFJLENBQUM4RCxPQUFuRSxjQUE4RTlELElBQUksQ0FBQ0MsVUFBbkYsMkJBQThHRCxJQUFJLENBQUNHLElBQUwsQ0FBVWtFLElBQVYsSUFBa0JyRSxJQUFJLENBQUNHLElBQUwsQ0FBVXNHLFFBQTFJOztBQUVBLFVBQU1BLFFBQVEsR0FBRyxLQUFLQyxZQUFMLENBQWtCMUcsSUFBSSxDQUFDRyxJQUF2QixDQUFqQjs7QUFDQSxVQUFNO0FBQUN3RyxlQUFEO0FBQVlDO0FBQVosUUFBZ0MsS0FBS0MsT0FBTCxDQUFhSixRQUFiLENBQXRDOztBQUVBLFFBQUksQ0FBQ2hOLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQTNCLENBQUwsRUFBdUM7QUFDckNoRSxVQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQVYsR0FBaUIsRUFBakI7QUFDRDs7QUFFRCxRQUFJdEQsTUFBTSxHQUFTVixJQUFJLENBQUNHLElBQXhCO0FBQ0FPLFVBQU0sQ0FBQzJELElBQVAsR0FBbUJvQyxRQUFuQjtBQUNBL0YsVUFBTSxDQUFDc0QsSUFBUCxHQUFtQmhFLElBQUksQ0FBQ0csSUFBTCxDQUFVNkQsSUFBN0I7QUFDQXRELFVBQU0sQ0FBQ2lHLFNBQVAsR0FBbUJBLFNBQW5CO0FBQ0FqRyxVQUFNLENBQUNvRyxHQUFQLEdBQW1CSCxTQUFuQjtBQUNBakcsVUFBTSxDQUFDdkIsR0FBUCxHQUFtQmEsSUFBSSxDQUFDeUQsTUFBeEI7QUFDQS9DLFVBQU0sQ0FBQ0UsTUFBUCxHQUFtQkEsTUFBTSxJQUFJLElBQTdCO0FBQ0FaLFFBQUksQ0FBQytGLE1BQUwsR0FBbUIvRixJQUFJLENBQUMrRixNQUFMLENBQVloSixPQUFaLENBQW9CLG9CQUFwQixFQUEwQyxHQUExQyxDQUFuQjtBQUNBMkQsVUFBTSxDQUFDWCxJQUFQLGFBQXNCLEtBQUsxRixXQUFMLENBQWlCcUcsTUFBakIsQ0FBdEIsU0FBaUQ1RyxRQUFRLENBQUMrRCxHQUExRCxTQUFnRW1DLElBQUksQ0FBQytGLE1BQXJFLFNBQThFYSxnQkFBOUU7QUFDQWxHLFVBQU0sR0FBYWhDLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBY04sTUFBZCxFQUFzQixLQUFLcUcsYUFBTCxDQUFtQnJHLE1BQW5CLENBQXRCLENBQW5COztBQUVBLFFBQUksS0FBS3BGLGNBQUwsSUFBdUI3QixPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUsxQixjQUF4QixDQUEzQixFQUFvRTtBQUNsRWtMLFNBQUcsR0FBRzlILE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYztBQUNsQmIsWUFBSSxFQUFFSCxJQUFJLENBQUNHO0FBRE8sT0FBZCxFQUVIO0FBQ0QyRCxlQUFPLEVBQUU5RCxJQUFJLENBQUM4RCxPQURiO0FBRURsRCxjQUFNLEVBQUVGLE1BQU0sQ0FBQ0UsTUFGZDs7QUFHREQsWUFBSSxHQUFHO0FBQ0wsY0FBSTVILE1BQU0sQ0FBQzhNLEtBQVAsSUFBZ0JuRixNQUFNLENBQUNFLE1BQTNCLEVBQW1DO0FBQ2pDLG1CQUFPN0gsTUFBTSxDQUFDOE0sS0FBUCxDQUFhdEYsT0FBYixDQUFxQkcsTUFBTSxDQUFDRSxNQUE1QixDQUFQO0FBQ0Q7O0FBQ0QsaUJBQU8sSUFBUDtBQUNELFNBUkE7O0FBU0Q4QyxXQUFHLEVBQUUxRCxJQUFJLENBQUMwRDtBQVRULE9BRkcsQ0FBTjtBQWFBLFlBQU1zRCxlQUFlLEdBQUcsS0FBSzFMLGNBQUwsQ0FBb0J5RixJQUFwQixDQUF5QnlGLEdBQXpCLEVBQThCOUYsTUFBOUIsQ0FBeEI7O0FBRUEsVUFBSXNHLGVBQWUsS0FBSyxJQUF4QixFQUE4QjtBQUM1QixjQUFNLElBQUlqTyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCckQsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQnVLLGVBQWpCLElBQW9DQSxlQUFwQyxHQUFzRCxrQ0FBNUUsQ0FBTjtBQUNELE9BRkQsTUFFTztBQUNMLFlBQUtoSCxJQUFJLENBQUNvRSxJQUFMLEtBQWMsSUFBZixJQUF3QixLQUFLdkksZ0JBQTdCLElBQWlEcEMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLbkIsZ0JBQXhCLENBQXJELEVBQWdHO0FBQzlGLGVBQUtBLGdCQUFMLENBQXNCa0YsSUFBdEIsQ0FBMkJ5RixHQUEzQixFQUFnQzlGLE1BQWhDO0FBQ0Q7QUFDRjtBQUNGLEtBdkJELE1BdUJPLElBQUtWLElBQUksQ0FBQ29FLElBQUwsS0FBYyxJQUFmLElBQXdCLEtBQUt2SSxnQkFBN0IsSUFBaURwQyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtuQixnQkFBeEIsQ0FBckQsRUFBZ0c7QUFDckcySyxTQUFHLEdBQUc5SCxNQUFNLENBQUNzQyxNQUFQLENBQWM7QUFDbEJiLFlBQUksRUFBRUgsSUFBSSxDQUFDRztBQURPLE9BQWQsRUFFSDtBQUNEMkQsZUFBTyxFQUFFOUQsSUFBSSxDQUFDOEQsT0FEYjtBQUVEbEQsY0FBTSxFQUFFRixNQUFNLENBQUNFLE1BRmQ7O0FBR0RELFlBQUksR0FBRztBQUNMLGNBQUk1SCxNQUFNLENBQUM4TSxLQUFQLElBQWdCbkYsTUFBTSxDQUFDRSxNQUEzQixFQUFtQztBQUNqQyxtQkFBTzdILE1BQU0sQ0FBQzhNLEtBQVAsQ0FBYXRGLE9BQWIsQ0FBcUJHLE1BQU0sQ0FBQ0UsTUFBNUIsQ0FBUDtBQUNEOztBQUNELGlCQUFPLElBQVA7QUFDRCxTQVJBOztBQVNEOEMsV0FBRyxFQUFFMUQsSUFBSSxDQUFDMEQ7QUFUVCxPQUZHLENBQU47QUFhQSxXQUFLN0gsZ0JBQUwsQ0FBc0JrRixJQUF0QixDQUEyQnlGLEdBQTNCLEVBQWdDOUYsTUFBaEM7QUFDRDs7QUFFRCxXQUFPO0FBQUNBLFlBQUQ7QUFBU1Y7QUFBVCxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UrQixlQUFhLENBQUNyQixNQUFELEVBQVNWLElBQVQsRUFBZWlILEVBQWYsRUFBbUI7QUFDOUIsU0FBSy9JLE1BQUwsNkRBQWlFd0MsTUFBTSxDQUFDWCxJQUF4RTs7QUFDQXJHLE1BQUUsQ0FBQ3dOLEtBQUgsQ0FBU3hHLE1BQU0sQ0FBQ1gsSUFBaEIsRUFBc0IsS0FBS2xGLFdBQTNCLEVBQXdDWCxJQUF4QztBQUNBd0csVUFBTSxDQUFDOUMsSUFBUCxHQUFnQixLQUFLdUosWUFBTCxDQUFrQm5ILElBQUksQ0FBQ0csSUFBdkIsQ0FBaEI7QUFDQU8sVUFBTSxDQUFDbEcsTUFBUCxHQUFnQixLQUFLQSxNQUFyQjs7QUFDQSxTQUFLNE0sZ0JBQUwsQ0FBc0IxRyxNQUF0Qjs7QUFFQSxTQUFLOUYsVUFBTCxDQUFnQjZKLE1BQWhCLENBQXVCaEwsT0FBTyxDQUFDNkssS0FBUixDQUFjNUQsTUFBZCxDQUF2QixFQUE4QyxDQUFDMkcsU0FBRCxFQUFZbEksR0FBWixLQUFvQjtBQUNoRSxVQUFJa0ksU0FBSixFQUFlO0FBQ2JKLFVBQUUsSUFBSUEsRUFBRSxDQUFDSSxTQUFELENBQVI7O0FBQ0EsYUFBS25KLE1BQUwsQ0FBWSw0REFBWixFQUEwRW1KLFNBQTFFO0FBQ0QsT0FIRCxNQUdPO0FBQ0wsYUFBS2xMLGNBQUwsQ0FBb0JtTCxNQUFwQixDQUEyQjtBQUFDbkksYUFBRyxFQUFFYSxJQUFJLENBQUN5RDtBQUFYLFNBQTNCLEVBQStDO0FBQUM4RCxjQUFJLEVBQUU7QUFBQ25JLHNCQUFVLEVBQUU7QUFBYjtBQUFQLFNBQS9DLEVBQTRFb0ksY0FBRCxJQUFvQjtBQUM3RixjQUFJQSxjQUFKLEVBQW9CO0FBQ2xCUCxjQUFFLElBQUlBLEVBQUUsQ0FBQ08sY0FBRCxDQUFSOztBQUNBLGlCQUFLdEosTUFBTCxDQUFZLDREQUFaLEVBQTBFc0osY0FBMUU7QUFDRCxXQUhELE1BR087QUFDTDlHLGtCQUFNLENBQUN2QixHQUFQLEdBQWFBLEdBQWI7O0FBQ0EsaUJBQUtqQixNQUFMLDREQUFnRXdDLE1BQU0sQ0FBQ1gsSUFBdkU7O0FBQ0EsaUJBQUsvRSxhQUFMLElBQXNCLEtBQUtBLGFBQUwsQ0FBbUIrRixJQUFuQixDQUF3QixJQUF4QixFQUE4QkwsTUFBOUIsQ0FBdEI7QUFDQSxpQkFBS3VELElBQUwsQ0FBVSxhQUFWLEVBQXlCdkQsTUFBekI7QUFDQXVHLGNBQUUsSUFBSUEsRUFBRSxDQUFDLElBQUQsRUFBT3ZHLE1BQVAsQ0FBUjtBQUNEO0FBQ0YsU0FYRDtBQVlEO0FBQ0YsS0FsQkQ7QUFtQkQ7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VvQixlQUFhLENBQUNwQixNQUFELEVBQVNWLElBQVQsRUFBZWlILEVBQWYsRUFBbUI7QUFDOUIsUUFBSTtBQUNGLFVBQUlqSCxJQUFJLENBQUMwRCxHQUFULEVBQWM7QUFDWixhQUFLdEcsZUFBTCxDQUFxQnNELE1BQU0sQ0FBQ3ZCLEdBQTVCLEVBQWlDUSxHQUFqQyxDQUFxQyxNQUFNO0FBQ3pDLGVBQUtzRSxJQUFMLENBQVUsZUFBVixFQUEyQnZELE1BQTNCLEVBQW1DVixJQUFuQyxFQUF5Q2lILEVBQXpDO0FBQ0QsU0FGRDtBQUdELE9BSkQsTUFJTztBQUNMLGFBQUs3SixlQUFMLENBQXFCc0QsTUFBTSxDQUFDdkIsR0FBNUIsRUFBaUNzSSxLQUFqQyxDQUF1Q3pILElBQUksQ0FBQzhELE9BQTVDLEVBQXFEOUQsSUFBSSxDQUFDMkQsT0FBMUQsRUFBbUVzRCxFQUFuRTtBQUNEO0FBQ0YsS0FSRCxDQVFFLE9BQU9oQixDQUFQLEVBQVU7QUFDVixXQUFLL0gsTUFBTCxDQUFZLDhCQUFaLEVBQTRDK0gsQ0FBNUM7O0FBQ0FnQixRQUFFLElBQUlBLEVBQUUsQ0FBQ2hCLENBQUQsQ0FBUjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWtCLGNBQVksQ0FBQ08sUUFBRCxFQUFXO0FBQ3JCLFFBQUlDLElBQUo7QUFDQXZPLFNBQUssQ0FBQ3NPLFFBQUQsRUFBV2hKLE1BQVgsQ0FBTDs7QUFDQSxRQUFJakYsT0FBTyxDQUFDMEQsUUFBUixDQUFpQnVLLFFBQWpCLEtBQThCQSxRQUFRLENBQUM5SixJQUEzQyxFQUFpRDtBQUMvQytKLFVBQUksR0FBR0QsUUFBUSxDQUFDOUosSUFBaEI7QUFDRDs7QUFFRCxRQUFJOEosUUFBUSxDQUFDM0gsSUFBVCxLQUFrQixDQUFDNEgsSUFBRCxJQUFTLENBQUNsTyxPQUFPLENBQUNnRCxRQUFSLENBQWlCa0wsSUFBakIsQ0FBNUIsQ0FBSixFQUF5RDtBQUN2RCxVQUFJO0FBQ0YsWUFBSUMsR0FBRyxHQUFJaEUsTUFBTSxDQUFDaUUsS0FBUCxDQUFhLEdBQWIsQ0FBWDtBQUNBLGNBQU1DLEVBQUUsR0FBR3BPLEVBQUUsQ0FBQ3FPLFFBQUgsQ0FBWUwsUUFBUSxDQUFDM0gsSUFBckIsRUFBMkIsR0FBM0IsQ0FBWDtBQUNBLGNBQU1pSSxFQUFFLEdBQUd0TyxFQUFFLENBQUN1TyxRQUFILENBQVlILEVBQVosRUFBZ0JGLEdBQWhCLEVBQXFCLENBQXJCLEVBQXdCLEdBQXhCLEVBQTZCLENBQTdCLENBQVg7QUFDQWxPLFVBQUUsQ0FBQ3dPLEtBQUgsQ0FBU0osRUFBVCxFQUFhNU4sSUFBYjs7QUFDQSxZQUFJOE4sRUFBRSxHQUFHLEdBQVQsRUFBYztBQUNaSixhQUFHLEdBQUdBLEdBQUcsQ0FBQ08sS0FBSixDQUFVLENBQVYsRUFBYUgsRUFBYixDQUFOO0FBQ0Q7O0FBQ0QsU0FBQztBQUFDTDtBQUFELFlBQVM5TixRQUFRLENBQUMrTixHQUFELENBQWxCO0FBQ0QsT0FURCxDQVNFLE9BQU8zQixDQUFQLEVBQVUsQ0FDVjtBQUNEO0FBQ0Y7O0FBRUQsUUFBSSxDQUFDMEIsSUFBRCxJQUFTLENBQUNsTyxPQUFPLENBQUNnRCxRQUFSLENBQWlCa0wsSUFBakIsQ0FBZCxFQUFzQztBQUNwQ0EsVUFBSSxHQUFHLDBCQUFQO0FBQ0Q7O0FBQ0QsV0FBT0EsSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbkUsWUFBVSxDQUFDNEUsS0FBRCxFQUFRO0FBQ2hCLFFBQUksQ0FBQ0EsS0FBTCxFQUFZLE9BQU8sSUFBUCxDQURJLENBR2hCOztBQUNBLFFBQUksQ0FBQ3JQLE1BQU0sQ0FBQ3NQLE1BQVAsQ0FBY0MsUUFBZixZQUFtQ0MsR0FBbkMsSUFBMEMsQ0FBQzlPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUNzUCxNQUFQLENBQWNDLFFBQS9CLENBQS9DLEVBQXlGO0FBQ3ZGLFlBQU0sSUFBSXhMLEtBQUosQ0FBVSxzREFBVixDQUFOO0FBQ0Q7O0FBRUQsUUFBSS9ELE1BQU0sQ0FBQ3NQLE1BQVAsQ0FBY0MsUUFBZCxZQUFrQ0MsR0FBbEMsSUFBeUN4UCxNQUFNLENBQUNzUCxNQUFQLENBQWNDLFFBQWQsQ0FBdUJFLEdBQXZCLENBQTJCSixLQUEzQixDQUF6QyxJQUE4RTNPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUNzUCxNQUFQLENBQWNDLFFBQWQsQ0FBdUJHLEdBQXZCLENBQTJCTCxLQUEzQixDQUFqQixDQUFsRixFQUF1STtBQUNySTtBQUNBLGFBQU9yUCxNQUFNLENBQUNzUCxNQUFQLENBQWNDLFFBQWQsQ0FBdUJHLEdBQXZCLENBQTJCTCxLQUEzQixFQUFrQ3hILE1BQXpDO0FBQ0QsS0FIRCxNQUdPLElBQUluSCxPQUFPLENBQUMwRCxRQUFSLENBQWlCcEUsTUFBTSxDQUFDc1AsTUFBUCxDQUFjQyxRQUEvQixLQUE0Q0YsS0FBSyxJQUFJclAsTUFBTSxDQUFDc1AsTUFBUCxDQUFjQyxRQUFuRSxJQUErRTdPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUNzUCxNQUFQLENBQWNDLFFBQWQsQ0FBdUJGLEtBQXZCLENBQWpCLENBQW5GLEVBQW9JO0FBQ3pJO0FBQ0EsYUFBT3JQLE1BQU0sQ0FBQ3NQLE1BQVAsQ0FBY0MsUUFBZCxDQUF1QkYsS0FBdkIsRUFBOEJ4SCxNQUFyQztBQUNEOztBQUVELFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxVQUFRLENBQUNKLElBQUQsRUFBTztBQUNiLFVBQU1DLE1BQU0sR0FBRztBQUNiQyxVQUFJLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQURWOztBQUViQyxZQUFNLEVBQUU7QUFGSyxLQUFmOztBQUtBLFFBQUlILElBQUosRUFBVTtBQUNSLFVBQUlpSSxJQUFJLEdBQUcsSUFBWDs7QUFDQSxVQUFJakksSUFBSSxDQUFDN0csT0FBTCxDQUFhNEQsT0FBYixDQUFxQixRQUFyQixDQUFKLEVBQW9DO0FBQ2xDa0wsWUFBSSxHQUFHakksSUFBSSxDQUFDN0csT0FBTCxDQUFhNEQsT0FBYixDQUFxQixRQUFyQixDQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTW1MLE1BQU0sR0FBR2xJLElBQUksQ0FBQzdHLE9BQUwsQ0FBYVgsT0FBNUI7O0FBQ0EsWUFBSTBQLE1BQU0sQ0FBQ0gsR0FBUCxDQUFXLFFBQVgsQ0FBSixFQUEwQjtBQUN4QkUsY0FBSSxHQUFHQyxNQUFNLENBQUNGLEdBQVAsQ0FBVyxRQUFYLENBQVA7QUFDRDtBQUNGOztBQUVELFVBQUlDLElBQUosRUFBVTtBQUNSLGNBQU05SCxNQUFNLEdBQUcsS0FBSzRDLFVBQUwsQ0FBZ0JrRixJQUFoQixDQUFmOztBQUVBLFlBQUk5SCxNQUFKLEVBQVk7QUFDVkYsZ0JBQU0sQ0FBQ0MsSUFBUCxHQUFnQixNQUFNNUgsTUFBTSxDQUFDOE0sS0FBUCxDQUFhdEYsT0FBYixDQUFxQkssTUFBckIsQ0FBdEI7O0FBQ0FGLGdCQUFNLENBQUNFLE1BQVAsR0FBZ0JBLE1BQWhCO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFdBQU9GLE1BQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRStHLE9BQUssQ0FBQ21CLE1BQUQsRUFBcUQ7QUFBQSxRQUE1QzFDLEtBQTRDLHVFQUFwQyxFQUFvQzs7QUFBQSxRQUFoQzJDLFNBQWdDOztBQUFBLFFBQXJCQyxtQkFBcUI7O0FBQ3hELFNBQUs1SyxNQUFMLENBQVksNkJBQVo7O0FBQ0EsUUFBSThCLElBQUksR0FBR2tHLEtBQVg7QUFDQSxRQUFJak0sUUFBUSxHQUFHNE8sU0FBZjtBQUNBLFFBQUlFLGtCQUFrQixHQUFHRCxtQkFBekI7O0FBRUEsUUFBSXJQLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJnRCxJQUFuQixDQUFKLEVBQThCO0FBQzVCK0ksd0JBQWtCLEdBQUc5TyxRQUFyQjtBQUNBQSxjQUFRLEdBQUcrRixJQUFYO0FBQ0FBLFVBQUksR0FBTyxFQUFYO0FBQ0QsS0FKRCxNQUlPLElBQUl2RyxPQUFPLENBQUM2QyxTQUFSLENBQWtCckMsUUFBbEIsQ0FBSixFQUFpQztBQUN0QzhPLHdCQUFrQixHQUFHOU8sUUFBckI7QUFDRCxLQUZNLE1BRUEsSUFBSVIsT0FBTyxDQUFDNkMsU0FBUixDQUFrQjBELElBQWxCLENBQUosRUFBNkI7QUFDbEMrSSx3QkFBa0IsR0FBRy9JLElBQXJCO0FBQ0Q7O0FBRUQ1RyxTQUFLLENBQUM0RyxJQUFELEVBQU8zRyxLQUFLLENBQUMyTSxRQUFOLENBQWV0SCxNQUFmLENBQVAsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDYSxRQUFELEVBQVdaLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZXhILFFBQWYsQ0FBWCxDQUFMO0FBQ0FwRixTQUFLLENBQUMyUCxrQkFBRCxFQUFxQjFQLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZTFILE9BQWYsQ0FBckIsQ0FBTDtBQUVBLFVBQU1tRixNQUFNLEdBQUt6RCxJQUFJLENBQUN5RCxNQUFMLElBQWV6SyxNQUFNLENBQUNnUSxFQUFQLEVBQWhDO0FBQ0EsVUFBTWpELE1BQU0sR0FBSyxLQUFLeEssY0FBTCxHQUFzQixLQUFLQSxjQUFMLENBQW9CeUUsSUFBcEIsQ0FBdEIsR0FBa0R5RCxNQUFuRTtBQUNBLFVBQU1nRCxRQUFRLEdBQUl6RyxJQUFJLENBQUNxRSxJQUFMLElBQWFyRSxJQUFJLENBQUN5RyxRQUFuQixHQUFnQ3pHLElBQUksQ0FBQ3FFLElBQUwsSUFBYXJFLElBQUksQ0FBQ3lHLFFBQWxELEdBQThEVixNQUEvRTs7QUFFQSxVQUFNO0FBQUNZLGVBQUQ7QUFBWUM7QUFBWixRQUFnQyxLQUFLQyxPQUFMLENBQWFKLFFBQWIsQ0FBdEM7O0FBRUF6RyxRQUFJLENBQUNELElBQUwsYUFBZSxLQUFLMUYsV0FBTCxDQUFpQjJGLElBQWpCLENBQWYsU0FBd0NsRyxRQUFRLENBQUMrRCxHQUFqRCxTQUF1RGtJLE1BQXZELFNBQWdFYSxnQkFBaEU7QUFDQTVHLFFBQUksQ0FBQ3BDLElBQUwsR0FBWSxLQUFLdUosWUFBTCxDQUFrQm5ILElBQWxCLENBQVo7O0FBQ0EsUUFBSSxDQUFDdkcsT0FBTyxDQUFDMEQsUUFBUixDQUFpQjZDLElBQUksQ0FBQ2dFLElBQXRCLENBQUwsRUFBa0M7QUFDaENoRSxVQUFJLENBQUNnRSxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVELFFBQUksQ0FBQ3ZLLE9BQU8sQ0FBQ3dELFFBQVIsQ0FBaUIrQyxJQUFJLENBQUN0QyxJQUF0QixDQUFMLEVBQWtDO0FBQ2hDc0MsVUFBSSxDQUFDdEMsSUFBTCxHQUFZa0wsTUFBTSxDQUFDdEgsTUFBbkI7QUFDRDs7QUFFRCxVQUFNWixNQUFNLEdBQUcsS0FBS3FHLGFBQUwsQ0FBbUI7QUFDaEMxQyxVQUFJLEVBQUVvQyxRQUQwQjtBQUVoQzFHLFVBQUksRUFBRUMsSUFBSSxDQUFDRCxJQUZxQjtBQUdoQ2lFLFVBQUksRUFBRWhFLElBQUksQ0FBQ2dFLElBSHFCO0FBSWhDcEcsVUFBSSxFQUFFb0MsSUFBSSxDQUFDcEMsSUFKcUI7QUFLaENGLFVBQUksRUFBRXNDLElBQUksQ0FBQ3RDLElBTHFCO0FBTWhDa0QsWUFBTSxFQUFFWixJQUFJLENBQUNZLE1BTm1CO0FBT2hDK0Y7QUFQZ0MsS0FBbkIsQ0FBZjs7QUFVQWpHLFVBQU0sQ0FBQ3ZCLEdBQVAsR0FBYXNFLE1BQWI7QUFFQS9KLE1BQUUsQ0FBQ3VQLFVBQUgsQ0FBY2pKLElBQUksQ0FBQ0QsSUFBbkIsRUFBMEJtSixPQUFELElBQWE7QUFDcENuUCxXQUFLLENBQUMsTUFBTTtBQUNWLFlBQUltUCxPQUFKLEVBQWE7QUFDWGpQLGtCQUFRLElBQUlBLFFBQVEsQ0FBQ2lQLE9BQUQsQ0FBcEI7O0FBQ0EsZUFBS2hMLE1BQUwsMkRBQStEdUksUUFBL0QsaUJBQThFekcsSUFBSSxDQUFDRCxJQUFuRixHQUEyRm1KLE9BQTNGO0FBQ0QsU0FIRCxNQUdPO0FBQ0wsZ0JBQU1DLE1BQU0sR0FBR3pQLEVBQUUsQ0FBQzBQLGlCQUFILENBQXFCcEosSUFBSSxDQUFDRCxJQUExQixFQUFnQztBQUFDc0osaUJBQUssRUFBRSxHQUFSO0FBQWFqTCxnQkFBSSxFQUFFLEtBQUt2RDtBQUF4QixXQUFoQyxDQUFmO0FBQ0FzTyxnQkFBTSxDQUFDeEosR0FBUCxDQUFXaUosTUFBWCxFQUFvQlUsU0FBRCxJQUFlO0FBQ2hDdlAsaUJBQUssQ0FBQyxNQUFNO0FBQ1Ysa0JBQUl1UCxTQUFKLEVBQWU7QUFDYnJQLHdCQUFRLElBQUlBLFFBQVEsQ0FBQ3FQLFNBQUQsQ0FBcEI7QUFDRCxlQUZELE1BRU87QUFDTCxxQkFBSzFPLFVBQUwsQ0FBZ0I2SixNQUFoQixDQUF1Qi9ELE1BQXZCLEVBQStCLENBQUM2SSxTQUFELEVBQVlwSyxHQUFaLEtBQW9CO0FBQ2pELHNCQUFJb0ssU0FBSixFQUFlO0FBQ2J0UCw0QkFBUSxJQUFJQSxRQUFRLENBQUNzUCxTQUFELENBQXBCOztBQUNBLHlCQUFLckwsTUFBTCxxREFBeUR1SSxRQUF6RCxpQkFBd0UsS0FBS3BMLGNBQTdFLEdBQStGa08sU0FBL0Y7QUFDRCxtQkFIRCxNQUdPO0FBQ0wsMEJBQU1qTSxPQUFPLEdBQUcsS0FBSzFDLFVBQUwsQ0FBZ0IyRixPQUFoQixDQUF3QnBCLEdBQXhCLENBQWhCO0FBQ0FsRiw0QkFBUSxJQUFJQSxRQUFRLENBQUMsSUFBRCxFQUFPcUQsT0FBUCxDQUFwQjs7QUFDQSx3QkFBSXlMLGtCQUFrQixLQUFLLElBQTNCLEVBQWlDO0FBQy9CLDJCQUFLL04sYUFBTCxJQUFzQixLQUFLQSxhQUFMLENBQW1CK0YsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEJ6RCxPQUE5QixDQUF0QjtBQUNBLDJCQUFLMkcsSUFBTCxDQUFVLGFBQVYsRUFBeUIzRyxPQUF6QjtBQUNEOztBQUNELHlCQUFLWSxNQUFMLHNDQUEwQ3VJLFFBQTFDLGlCQUF5RCxLQUFLcEwsY0FBOUQ7QUFDRDtBQUNGLGlCQWJEO0FBY0Q7QUFDRixhQW5CSSxDQUFMO0FBb0JELFdBckJEO0FBc0JEO0FBQ0YsT0E3QkksQ0FBTDtBQThCRCxLQS9CRDtBQWdDQSxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbU8sTUFBSSxDQUFDQyxHQUFELEVBQWtEO0FBQUEsUUFBNUN2RCxLQUE0Qyx1RUFBcEMsRUFBb0M7O0FBQUEsUUFBaEMyQyxTQUFnQzs7QUFBQSxRQUFyQkMsbUJBQXFCOztBQUNwRCxTQUFLNUssTUFBTCxtQ0FBdUN1TCxHQUF2QyxlQUErQ3JHLElBQUksQ0FBQ0MsU0FBTCxDQUFlNkMsS0FBZixDQUEvQzs7QUFDQSxRQUFJbEcsSUFBSSxHQUFHa0csS0FBWDtBQUNBLFFBQUlqTSxRQUFRLEdBQUc0TyxTQUFmO0FBQ0EsUUFBSUUsa0JBQWtCLEdBQUdELG1CQUF6Qjs7QUFFQSxRQUFJclAsT0FBTyxDQUFDdUQsVUFBUixDQUFtQmdELElBQW5CLENBQUosRUFBOEI7QUFDNUIrSSx3QkFBa0IsR0FBRzlPLFFBQXJCO0FBQ0FBLGNBQVEsR0FBRytGLElBQVg7QUFDQUEsVUFBSSxHQUFPLEVBQVg7QUFDRCxLQUpELE1BSU8sSUFBSXZHLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0JyQyxRQUFsQixDQUFKLEVBQWlDO0FBQ3RDOE8sd0JBQWtCLEdBQUc5TyxRQUFyQjtBQUNELEtBRk0sTUFFQSxJQUFJUixPQUFPLENBQUM2QyxTQUFSLENBQWtCMEQsSUFBbEIsQ0FBSixFQUE2QjtBQUNsQytJLHdCQUFrQixHQUFHL0ksSUFBckI7QUFDRDs7QUFFRDVHLFNBQUssQ0FBQ3FRLEdBQUQsRUFBTTVNLE1BQU4sQ0FBTDtBQUNBekQsU0FBSyxDQUFDNEcsSUFBRCxFQUFPM0csS0FBSyxDQUFDMk0sUUFBTixDQUFldEgsTUFBZixDQUFQLENBQUw7QUFDQXRGLFNBQUssQ0FBQ2EsUUFBRCxFQUFXWixLQUFLLENBQUMyTSxRQUFOLENBQWV4SCxRQUFmLENBQVgsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDMlAsa0JBQUQsRUFBcUIxUCxLQUFLLENBQUMyTSxRQUFOLENBQWUxSCxPQUFmLENBQXJCLENBQUw7O0FBRUEsUUFBSSxDQUFDN0UsT0FBTyxDQUFDMEQsUUFBUixDQUFpQjZDLElBQWpCLENBQUwsRUFBNkI7QUFDM0JBLFVBQUksR0FBRyxFQUFQO0FBQ0Q7O0FBRUQsVUFBTXlELE1BQU0sR0FBTXpELElBQUksQ0FBQ3lELE1BQUwsSUFBZXpLLE1BQU0sQ0FBQ2dRLEVBQVAsRUFBakM7QUFDQSxVQUFNakQsTUFBTSxHQUFNLEtBQUt4SyxjQUFMLEdBQXNCLEtBQUtBLGNBQUwsQ0FBb0J5RSxJQUFwQixDQUF0QixHQUFrRHlELE1BQXBFO0FBQ0EsVUFBTWlHLFNBQVMsR0FBR0QsR0FBRyxDQUFDcEUsS0FBSixDQUFVLEdBQVYsQ0FBbEI7QUFDQSxVQUFNb0IsUUFBUSxHQUFLekcsSUFBSSxDQUFDcUUsSUFBTCxJQUFhckUsSUFBSSxDQUFDeUcsUUFBbkIsR0FBZ0N6RyxJQUFJLENBQUNxRSxJQUFMLElBQWFyRSxJQUFJLENBQUN5RyxRQUFsRCxHQUE4RGlELFNBQVMsQ0FBQ0EsU0FBUyxDQUFDcEksTUFBVixHQUFtQixDQUFwQixDQUFULElBQW1DeUUsTUFBbkg7O0FBRUEsVUFBTTtBQUFDWSxlQUFEO0FBQVlDO0FBQVosUUFBZ0MsS0FBS0MsT0FBTCxDQUFhSixRQUFiLENBQXRDOztBQUNBekcsUUFBSSxDQUFDRCxJQUFMLGFBQWdCLEtBQUsxRixXQUFMLENBQWlCMkYsSUFBakIsQ0FBaEIsU0FBeUNsRyxRQUFRLENBQUMrRCxHQUFsRCxTQUF3RGtJLE1BQXhELFNBQWlFYSxnQkFBakU7O0FBRUEsVUFBTStDLFdBQVcsR0FBRyxDQUFDakosTUFBRCxFQUFTdUcsRUFBVCxLQUFnQjtBQUNsQ3ZHLFlBQU0sQ0FBQ3ZCLEdBQVAsR0FBYXNFLE1BQWI7QUFFQSxXQUFLN0ksVUFBTCxDQUFnQjZKLE1BQWhCLENBQXVCL0QsTUFBdkIsRUFBK0IsQ0FBQ3JDLEtBQUQsRUFBUWMsR0FBUixLQUFnQjtBQUM3QyxZQUFJZCxLQUFKLEVBQVc7QUFDVDRJLFlBQUUsSUFBSUEsRUFBRSxDQUFDNUksS0FBRCxDQUFSOztBQUNBLGVBQUtILE1BQUwsb0RBQXdEdUksUUFBeEQsaUJBQXVFLEtBQUtwTCxjQUE1RSxHQUE4RmdELEtBQTlGO0FBQ0QsU0FIRCxNQUdPO0FBQ0wsZ0JBQU1mLE9BQU8sR0FBRyxLQUFLMUMsVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCcEIsR0FBeEIsQ0FBaEI7QUFDQThILFlBQUUsSUFBSUEsRUFBRSxDQUFDLElBQUQsRUFBTzNKLE9BQVAsQ0FBUjs7QUFDQSxjQUFJeUwsa0JBQWtCLEtBQUssSUFBM0IsRUFBaUM7QUFDL0IsaUJBQUsvTixhQUFMLElBQXNCLEtBQUtBLGFBQUwsQ0FBbUIrRixJQUFuQixDQUF3QixJQUF4QixFQUE4QnpELE9BQTlCLENBQXRCO0FBQ0EsaUJBQUsyRyxJQUFMLENBQVUsYUFBVixFQUF5QjNHLE9BQXpCO0FBQ0Q7O0FBQ0QsZUFBS1ksTUFBTCw2Q0FBaUR1SSxRQUFqRCxpQkFBZ0UsS0FBS3BMLGNBQXJFO0FBQ0Q7QUFDRixPQWJEO0FBY0QsS0FqQkQ7O0FBbUJBM0IsTUFBRSxDQUFDdVAsVUFBSCxDQUFjakosSUFBSSxDQUFDRCxJQUFuQixFQUEwQm1KLE9BQUQsSUFBYTtBQUNwQ25QLFdBQUssQ0FBQyxNQUFNO0FBQ1YsWUFBSW1QLE9BQUosRUFBYTtBQUNYalAsa0JBQVEsSUFBSUEsUUFBUSxDQUFDaVAsT0FBRCxDQUFwQjs7QUFDQSxlQUFLaEwsTUFBTCwwREFBOER1SSxRQUE5RCxpQkFBNkV6RyxJQUFJLENBQUNELElBQWxGLEdBQTBGbUosT0FBMUY7QUFDRCxTQUhELE1BR087QUFDTHRQLGlCQUFPLENBQUM7QUFDTjZQLGVBRE07QUFFTmpNLG1CQUFPLEVBQUV3QyxJQUFJLENBQUN4QyxPQUFMLElBQWdCLEVBRm5CO0FBR05vTSxnQkFBSSxFQUFFO0FBSEEsV0FBRCxFQUlKLENBQUNDLFFBQUQsRUFBVzFJLFFBQVgsS0FBd0JwSCxLQUFLLENBQUMsTUFBTTtBQUNyQyxnQkFBSThQLFFBQUosRUFBYztBQUNaNVAsc0JBQVEsSUFBSUEsUUFBUSxDQUFDNFAsUUFBRCxDQUFwQjs7QUFDQSxtQkFBSzNMLE1BQUwsaURBQXFEdUwsR0FBckQsZ0JBQXFFSSxRQUFyRTtBQUNELGFBSEQsTUFHTztBQUNMLG1CQUFLM0wsTUFBTCw4Q0FBa0R1TCxHQUFsRDs7QUFDQSxvQkFBTS9JLE1BQU0sR0FBRyxLQUFLcUcsYUFBTCxDQUFtQjtBQUNoQzFDLG9CQUFJLEVBQUVvQyxRQUQwQjtBQUVoQzFHLG9CQUFJLEVBQUVDLElBQUksQ0FBQ0QsSUFGcUI7QUFHaENpRSxvQkFBSSxFQUFFaEUsSUFBSSxDQUFDZ0UsSUFIcUI7QUFJaENwRyxvQkFBSSxFQUFFb0MsSUFBSSxDQUFDcEMsSUFBTCxJQUFhdUQsUUFBUSxDQUFDM0QsT0FBVCxDQUFpQixjQUFqQixDQUFiLElBQWlELEtBQUsySixZQUFMLENBQWtCO0FBQUNwSCxzQkFBSSxFQUFFQyxJQUFJLENBQUNEO0FBQVosaUJBQWxCLENBSnZCO0FBS2hDckMsb0JBQUksRUFBRXNDLElBQUksQ0FBQ3RDLElBQUwsSUFBYVIsUUFBUSxDQUFDaUUsUUFBUSxDQUFDM0QsT0FBVCxDQUFpQixnQkFBakIsS0FBc0MsQ0FBdkMsQ0FMSztBQU1oQ29ELHNCQUFNLEVBQUVaLElBQUksQ0FBQ1ksTUFObUI7QUFPaEMrRjtBQVBnQyxlQUFuQixDQUFmOztBQVVBLGtCQUFJLENBQUNqRyxNQUFNLENBQUNoRCxJQUFaLEVBQWtCO0FBQ2hCaEUsa0JBQUUsQ0FBQ29RLElBQUgsQ0FBUTlKLElBQUksQ0FBQ0QsSUFBYixFQUFtQixDQUFDMUIsS0FBRCxFQUFRMEwsS0FBUixLQUFrQmhRLEtBQUssQ0FBQyxNQUFNO0FBQy9DLHNCQUFJc0UsS0FBSixFQUFXO0FBQ1RwRSw0QkFBUSxJQUFJQSxRQUFRLENBQUNvRSxLQUFELENBQXBCO0FBQ0QsbUJBRkQsTUFFTztBQUNMcUMsMEJBQU0sQ0FBQ3NKLFFBQVAsQ0FBZ0JDLFFBQWhCLENBQXlCdk0sSUFBekIsR0FBaUNnRCxNQUFNLENBQUNoRCxJQUFQLEdBQWNxTSxLQUFLLENBQUNyTSxJQUFyRDtBQUNBaU0sK0JBQVcsQ0FBQ2pKLE1BQUQsRUFBU3pHLFFBQVQsQ0FBWDtBQUNEO0FBQ0YsaUJBUHlDLENBQTFDO0FBUUQsZUFURCxNQVNPO0FBQ0wwUCwyQkFBVyxDQUFDakosTUFBRCxFQUFTekcsUUFBVCxDQUFYO0FBQ0Q7QUFDRjtBQUNGLFdBN0IrQixDQUp6QixDQUFQLENBaUNJaVEsSUFqQ0osQ0FpQ1N4USxFQUFFLENBQUMwUCxpQkFBSCxDQUFxQnBKLElBQUksQ0FBQ0QsSUFBMUIsRUFBZ0M7QUFBQ3NKLGlCQUFLLEVBQUUsR0FBUjtBQUFhakwsZ0JBQUksRUFBRSxLQUFLdkQ7QUFBeEIsV0FBaEMsQ0FqQ1QsRUFpQ2dGc1AsSUFqQ2hGO0FBa0NEO0FBQ0YsT0F4Q0ksQ0FBTDtBQXlDRCxLQTFDRDtBQTZDQSxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUMsU0FBTyxDQUFDckssSUFBRCxFQUFtRDtBQUFBLFFBQTVDbUcsS0FBNEMsdUVBQXBDLEVBQW9DOztBQUFBLFFBQWhDMkMsU0FBZ0M7O0FBQUEsUUFBckJDLG1CQUFxQjs7QUFDeEQsU0FBSzVLLE1BQUwsc0NBQTBDNkIsSUFBMUM7O0FBQ0EsUUFBSUMsSUFBSSxHQUFHa0csS0FBWDtBQUNBLFFBQUlqTSxRQUFRLEdBQUc0TyxTQUFmO0FBQ0EsUUFBSUUsa0JBQWtCLEdBQUdELG1CQUF6Qjs7QUFFQSxRQUFJclAsT0FBTyxDQUFDdUQsVUFBUixDQUFtQmdELElBQW5CLENBQUosRUFBOEI7QUFDNUIrSSx3QkFBa0IsR0FBRzlPLFFBQXJCO0FBQ0FBLGNBQVEsR0FBRytGLElBQVg7QUFDQUEsVUFBSSxHQUFPLEVBQVg7QUFDRCxLQUpELE1BSU8sSUFBSXZHLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0JyQyxRQUFsQixDQUFKLEVBQWlDO0FBQ3RDOE8sd0JBQWtCLEdBQUc5TyxRQUFyQjtBQUNELEtBRk0sTUFFQSxJQUFJUixPQUFPLENBQUM2QyxTQUFSLENBQWtCMEQsSUFBbEIsQ0FBSixFQUE2QjtBQUNsQytJLHdCQUFrQixHQUFHL0ksSUFBckI7QUFDRDs7QUFFRCxRQUFJLEtBQUt4RixNQUFULEVBQWlCO0FBQ2YsWUFBTSxJQUFJekIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrSEFBdEIsQ0FBTjtBQUNEOztBQUVEMUQsU0FBSyxDQUFDMkcsSUFBRCxFQUFPbEQsTUFBUCxDQUFMO0FBQ0F6RCxTQUFLLENBQUM0RyxJQUFELEVBQU8zRyxLQUFLLENBQUMyTSxRQUFOLENBQWV0SCxNQUFmLENBQVAsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDYSxRQUFELEVBQVdaLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZXhILFFBQWYsQ0FBWCxDQUFMO0FBQ0FwRixTQUFLLENBQUMyUCxrQkFBRCxFQUFxQjFQLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZTFILE9BQWYsQ0FBckIsQ0FBTDtBQUVBNUUsTUFBRSxDQUFDb1EsSUFBSCxDQUFRL0osSUFBUixFQUFjLENBQUNzSyxPQUFELEVBQVVOLEtBQVYsS0FBb0JoUSxLQUFLLENBQUMsTUFBTTtBQUM1QyxVQUFJc1EsT0FBSixFQUFhO0FBQ1hwUSxnQkFBUSxJQUFJQSxRQUFRLENBQUNvUSxPQUFELENBQXBCO0FBQ0QsT0FGRCxNQUVPLElBQUlOLEtBQUssQ0FBQ08sTUFBTixFQUFKLEVBQW9CO0FBQ3pCLFlBQUksQ0FBQzdRLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFqQixDQUFMLEVBQTZCO0FBQzNCQSxjQUFJLEdBQUcsRUFBUDtBQUNEOztBQUNEQSxZQUFJLENBQUNELElBQUwsR0FBYUEsSUFBYjs7QUFFQSxZQUFJLENBQUNDLElBQUksQ0FBQ3lHLFFBQVYsRUFBb0I7QUFDbEIsZ0JBQU1pRCxTQUFTLEdBQUczSixJQUFJLENBQUNzRixLQUFMLENBQVd2TCxRQUFRLENBQUMrRCxHQUFwQixDQUFsQjtBQUNBbUMsY0FBSSxDQUFDeUcsUUFBTCxHQUFrQjFHLElBQUksQ0FBQ3NGLEtBQUwsQ0FBV3ZMLFFBQVEsQ0FBQytELEdBQXBCLEVBQXlCNkwsU0FBUyxDQUFDcEksTUFBVixHQUFtQixDQUE1QyxDQUFsQjtBQUNEOztBQUVELGNBQU07QUFBQ3FGO0FBQUQsWUFBYyxLQUFLRSxPQUFMLENBQWE3RyxJQUFJLENBQUN5RyxRQUFsQixDQUFwQjs7QUFFQSxZQUFJLENBQUNoTixPQUFPLENBQUNnRCxRQUFSLENBQWlCdUQsSUFBSSxDQUFDcEMsSUFBdEIsQ0FBTCxFQUFrQztBQUNoQ29DLGNBQUksQ0FBQ3BDLElBQUwsR0FBWSxLQUFLdUosWUFBTCxDQUFrQm5ILElBQWxCLENBQVo7QUFDRDs7QUFFRCxZQUFJLENBQUN2RyxPQUFPLENBQUMwRCxRQUFSLENBQWlCNkMsSUFBSSxDQUFDZ0UsSUFBdEIsQ0FBTCxFQUFrQztBQUNoQ2hFLGNBQUksQ0FBQ2dFLElBQUwsR0FBWSxFQUFaO0FBQ0Q7O0FBRUQsWUFBSSxDQUFDdkssT0FBTyxDQUFDd0QsUUFBUixDQUFpQitDLElBQUksQ0FBQ3RDLElBQXRCLENBQUwsRUFBa0M7QUFDaENzQyxjQUFJLENBQUN0QyxJQUFMLEdBQVlxTSxLQUFLLENBQUNyTSxJQUFsQjtBQUNEOztBQUVELGNBQU1nRCxNQUFNLEdBQUcsS0FBS3FHLGFBQUwsQ0FBbUI7QUFDaEMxQyxjQUFJLEVBQUVyRSxJQUFJLENBQUN5RyxRQURxQjtBQUVoQzFHLGNBRmdDO0FBR2hDaUUsY0FBSSxFQUFFaEUsSUFBSSxDQUFDZ0UsSUFIcUI7QUFJaENwRyxjQUFJLEVBQUVvQyxJQUFJLENBQUNwQyxJQUpxQjtBQUtoQ0YsY0FBSSxFQUFFc0MsSUFBSSxDQUFDdEMsSUFMcUI7QUFNaENrRCxnQkFBTSxFQUFFWixJQUFJLENBQUNZLE1BTm1CO0FBT2hDK0YsbUJBUGdDO0FBUWhDNEQsc0JBQVksRUFBRXhLLElBQUksQ0FBQ2hELE9BQUwsV0FBZ0JqRCxRQUFRLENBQUMrRCxHQUF6QixTQUErQm1DLElBQUksQ0FBQ3lHLFFBQXBDLEdBQWdELEVBQWhELENBUmtCO0FBU2hDaEQsZ0JBQU0sRUFBRXpELElBQUksQ0FBQ3lELE1BQUwsSUFBZTtBQVRTLFNBQW5CLENBQWY7O0FBYUEsYUFBSzdJLFVBQUwsQ0FBZ0I2SixNQUFoQixDQUF1Qi9ELE1BQXZCLEVBQStCLENBQUM2SSxTQUFELEVBQVlwSyxHQUFaLEtBQW9CO0FBQ2pELGNBQUlvSyxTQUFKLEVBQWU7QUFDYnRQLG9CQUFRLElBQUlBLFFBQVEsQ0FBQ3NQLFNBQUQsQ0FBcEI7O0FBQ0EsaUJBQUtyTCxNQUFMLHVEQUEyRHdDLE1BQU0sQ0FBQzJELElBQWxFLGlCQUE2RSxLQUFLaEosY0FBbEYsR0FBb0drTyxTQUFwRztBQUNELFdBSEQsTUFHTztBQUNMLGtCQUFNak0sT0FBTyxHQUFHLEtBQUsxQyxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JwQixHQUF4QixDQUFoQjtBQUNBbEYsb0JBQVEsSUFBSUEsUUFBUSxDQUFDLElBQUQsRUFBT3FELE9BQVAsQ0FBcEI7O0FBQ0EsZ0JBQUl5TCxrQkFBa0IsS0FBSyxJQUEzQixFQUFpQztBQUMvQixtQkFBSy9OLGFBQUwsSUFBc0IsS0FBS0EsYUFBTCxDQUFtQitGLElBQW5CLENBQXdCLElBQXhCLEVBQThCekQsT0FBOUIsQ0FBdEI7QUFDQSxtQkFBSzJHLElBQUwsQ0FBVSxhQUFWLEVBQXlCM0csT0FBekI7QUFDRDs7QUFDRCxpQkFBS1ksTUFBTCx3Q0FBNEN3QyxNQUFNLENBQUMyRCxJQUFuRCxpQkFBOEQsS0FBS2hKLGNBQW5FO0FBQ0Q7QUFDRixTQWJEO0FBY0QsT0FwRE0sTUFvREE7QUFDTHBCLGdCQUFRLElBQUlBLFFBQVEsQ0FBQyxJQUFJbEIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQix1Q0FBb0RpRCxJQUFwRCw2QkFBRCxDQUFwQjtBQUNEO0FBQ0YsS0ExRHNDLENBQXZDO0FBMkRBLFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVAsUUFBTSxDQUFDbUcsUUFBRCxFQUFXMUwsUUFBWCxFQUFxQjtBQUN6QixTQUFLaUUsTUFBTCxxQ0FBeUNrRixJQUFJLENBQUNDLFNBQUwsQ0FBZXNDLFFBQWYsQ0FBekM7O0FBQ0EsUUFBSUEsUUFBUSxLQUFLLEtBQUssQ0FBdEIsRUFBeUI7QUFDdkIsYUFBTyxDQUFQO0FBQ0Q7O0FBQ0R2TSxTQUFLLENBQUNhLFFBQUQsRUFBV1osS0FBSyxDQUFDMk0sUUFBTixDQUFleEgsUUFBZixDQUFYLENBQUw7QUFFQSxVQUFNZ00sS0FBSyxHQUFHLEtBQUs1UCxVQUFMLENBQWdCcUUsSUFBaEIsQ0FBcUIwRyxRQUFyQixDQUFkOztBQUNBLFFBQUk2RSxLQUFLLENBQUM1SyxLQUFOLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCNEssV0FBSyxDQUFDQyxPQUFOLENBQWV0SyxJQUFELElBQVU7QUFDdEIsYUFBS2tHLE1BQUwsQ0FBWWxHLElBQVo7QUFDRCxPQUZEO0FBR0QsS0FKRCxNQUlPO0FBQ0xsRyxjQUFRLElBQUlBLFFBQVEsQ0FBQyxJQUFJbEIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixzQ0FBdEIsQ0FBRCxDQUFwQjtBQUNBLGFBQU8sSUFBUDtBQUNEOztBQUVELFFBQUksS0FBSzdCLGFBQVQsRUFBd0I7QUFDdEIsWUFBTXlQLElBQUksR0FBR0YsS0FBSyxDQUFDRyxLQUFOLEVBQWI7QUFDQSxZQUFNdE8sSUFBSSxHQUFHLElBQWI7QUFDQSxXQUFLekIsVUFBTCxDQUFnQjRFLE1BQWhCLENBQXVCbUcsUUFBdkIsRUFBaUMsWUFBWTtBQUMzQzFMLGdCQUFRLElBQUlBLFFBQVEsQ0FBQzhELEtBQVQsQ0FBZSxJQUFmLEVBQXFCQyxTQUFyQixDQUFaO0FBQ0EzQixZQUFJLENBQUNwQixhQUFMLENBQW1CeVAsSUFBbkI7QUFDRCxPQUhEO0FBSUQsS0FQRCxNQU9PO0FBQ0wsV0FBSzlQLFVBQUwsQ0FBZ0I0RSxNQUFoQixDQUF1Qm1HLFFBQXZCLEVBQWtDMUwsUUFBUSxJQUFJQyxJQUE5QztBQUNEOztBQUNELFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTBRLE1BQUksQ0FBQ0MsS0FBRCxFQUFRO0FBQ1YsU0FBS2pRLFVBQUwsQ0FBZ0JnUSxJQUFoQixDQUFxQkMsS0FBckI7QUFDQSxXQUFPLEtBQUtqUSxVQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFa1EsT0FBSyxDQUFDRCxLQUFELEVBQVE7QUFDWCxTQUFLalEsVUFBTCxDQUFnQmtRLEtBQWhCLENBQXNCRCxLQUF0QjtBQUNBLFdBQU8sS0FBS2pRLFVBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbVEsWUFBVSxHQUFHO0FBQ1gsU0FBS25RLFVBQUwsQ0FBZ0JnUSxJQUFoQixDQUFxQjtBQUNuQm5HLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjLE9BRE47O0FBRW5CNkMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FGTjs7QUFHbkI5SCxZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYzs7QUFITixLQUFyQjtBQUtBLFdBQU8sS0FBSzVFLFVBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFb1EsYUFBVyxHQUFHO0FBQ1osU0FBS3BRLFVBQUwsQ0FBZ0JrUSxLQUFoQixDQUFzQjtBQUNwQnJHLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjLE9BREw7O0FBRXBCNkMsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FGTDs7QUFHcEI5SCxZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYzs7QUFITCxLQUF0QjtBQUtBLFdBQU8sS0FBSzVFLFVBQVo7QUFDRDtBQUdEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXlMLFFBQU0sQ0FBQy9JLE9BQUQsRUFBVWlJLE9BQVYsRUFBbUJ0TCxRQUFuQixFQUE2QjtBQUNqQyxTQUFLaUUsTUFBTCxxQ0FBeUNaLE9BQU8sQ0FBQzZCLEdBQWpELGVBQXlEb0csT0FBekQ7O0FBQ0EsUUFBSUEsT0FBSixFQUFhO0FBQ1gsVUFBSTlMLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJHLE9BQU8sQ0FBQzBNLFFBQXpCLEtBQXNDdlEsT0FBTyxDQUFDMEQsUUFBUixDQUFpQkcsT0FBTyxDQUFDME0sUUFBUixDQUFpQnpFLE9BQWpCLENBQWpCLENBQXRDLElBQXFGakksT0FBTyxDQUFDME0sUUFBUixDQUFpQnpFLE9BQWpCLEVBQTBCeEYsSUFBbkgsRUFBeUg7QUFDdkhyRyxVQUFFLENBQUMyTSxNQUFILENBQVUvSSxPQUFPLENBQUMwTSxRQUFSLENBQWlCekUsT0FBakIsRUFBMEJ4RixJQUFwQyxFQUEyQzlGLFFBQVEsSUFBSUMsSUFBdkQ7QUFDRDtBQUNGLEtBSkQsTUFJTztBQUNMLFVBQUlULE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJHLE9BQU8sQ0FBQzBNLFFBQXpCLENBQUosRUFBd0M7QUFDdEMsYUFBSSxJQUFJaUIsSUFBUixJQUFnQjNOLE9BQU8sQ0FBQzBNLFFBQXhCLEVBQWtDO0FBQ2hDLGNBQUkxTSxPQUFPLENBQUMwTSxRQUFSLENBQWlCaUIsSUFBakIsS0FBMEIzTixPQUFPLENBQUMwTSxRQUFSLENBQWlCaUIsSUFBakIsRUFBdUJsTCxJQUFyRCxFQUEyRDtBQUN6RHJHLGNBQUUsQ0FBQzJNLE1BQUgsQ0FBVS9JLE9BQU8sQ0FBQzBNLFFBQVIsQ0FBaUJpQixJQUFqQixFQUF1QmxMLElBQWpDLEVBQXdDOUYsUUFBUSxJQUFJQyxJQUFwRDtBQUNEO0FBQ0Y7QUFDRixPQU5ELE1BTU87QUFDTFIsVUFBRSxDQUFDMk0sTUFBSCxDQUFVL0ksT0FBTyxDQUFDeUMsSUFBbEIsRUFBeUI5RixRQUFRLElBQUlDLElBQXJDO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWdSLE1BQUksQ0FBQ3pLLElBQUQsRUFBTztBQUNULFNBQUt2QyxNQUFMLHVDQUEyQ3VDLElBQUksQ0FBQzdHLE9BQUwsQ0FBYXVSLFdBQXhEOztBQUNBLFVBQU1qSyxJQUFJLEdBQUcsbUJBQWI7O0FBRUEsUUFBSSxDQUFDVCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLFVBQUksQ0FBQ1UsUUFBTCxDQUFjRSxTQUFkLENBQXdCLEdBQXhCLEVBQTZCO0FBQzNCLHdCQUFnQixZQURXO0FBRTNCLDBCQUFrQkgsSUFBSSxDQUFDSTtBQUZJLE9BQTdCO0FBS0Q7O0FBQ0QsUUFBSSxDQUFDYixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLFVBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZCxDQUFrQnVCLElBQWxCO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXNFLFVBQVEsQ0FBQy9FLElBQUQsRUFBc0M7QUFBQSxRQUEvQjhFLE9BQStCLHVFQUFyQixVQUFxQjtBQUFBLFFBQVRqSSxPQUFTO0FBQzVDLFFBQUk4TixJQUFKOztBQUNBLFNBQUtsTixNQUFMLHVDQUEyQ3VDLElBQUksQ0FBQzdHLE9BQUwsQ0FBYXVSLFdBQXhELGVBQXdFNUYsT0FBeEU7O0FBRUEsUUFBSWpJLE9BQUosRUFBYTtBQUNYLFVBQUk3RCxPQUFPLENBQUMrTyxHQUFSLENBQVlsTCxPQUFaLEVBQXFCLFVBQXJCLEtBQW9DN0QsT0FBTyxDQUFDK08sR0FBUixDQUFZbEwsT0FBTyxDQUFDME0sUUFBcEIsRUFBOEJ6RSxPQUE5QixDQUF4QyxFQUFnRjtBQUM5RTZGLFlBQUksR0FBRzlOLE9BQU8sQ0FBQzBNLFFBQVIsQ0FBaUJ6RSxPQUFqQixDQUFQO0FBQ0E2RixZQUFJLENBQUNqTSxHQUFMLEdBQVc3QixPQUFPLENBQUM2QixHQUFuQjtBQUNELE9BSEQsTUFHTztBQUNMaU0sWUFBSSxHQUFHOU4sT0FBUDtBQUNEO0FBQ0YsS0FQRCxNQU9PO0FBQ0w4TixVQUFJLEdBQUcsS0FBUDtBQUNEOztBQUVELFFBQUksQ0FBQ0EsSUFBRCxJQUFTLENBQUMzUixPQUFPLENBQUMwRCxRQUFSLENBQWlCaU8sSUFBakIsQ0FBZCxFQUFzQztBQUNwQyxhQUFPLEtBQUtGLElBQUwsQ0FBVXpLLElBQVYsQ0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJbkQsT0FBSixFQUFhO0FBQ2xCLFVBQUksS0FBSzFCLGdCQUFULEVBQTJCO0FBQ3pCLFlBQUksQ0FBQyxLQUFLQSxnQkFBTCxDQUFzQm1GLElBQXRCLENBQTJCckMsTUFBTSxDQUFDc0MsTUFBUCxDQUFjUCxJQUFkLEVBQW9CLEtBQUtJLFFBQUwsQ0FBY0osSUFBZCxDQUFwQixDQUEzQixFQUFxRW5ELE9BQXJFLENBQUwsRUFBb0Y7QUFDbEYsaUJBQU8sS0FBSzROLElBQUwsQ0FBVXpLLElBQVYsQ0FBUDtBQUNEO0FBQ0Y7O0FBRUQsVUFBSSxLQUFLMUUsaUJBQUwsSUFBMEJ0QyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtqQixpQkFBeEIsQ0FBMUIsSUFBd0UsS0FBS0EsaUJBQUwsQ0FBdUIwRSxJQUF2QixFQUE2Qm5ELE9BQTdCLEVBQXNDaUksT0FBdEMsTUFBbUQsSUFBL0gsRUFBcUk7QUFDbkksZUFBTyxLQUFLLENBQVo7QUFDRDs7QUFFRDdMLFFBQUUsQ0FBQ29RLElBQUgsQ0FBUXNCLElBQUksQ0FBQ3JMLElBQWIsRUFBbUIsQ0FBQ3NLLE9BQUQsRUFBVU4sS0FBVixLQUFvQmhRLEtBQUssQ0FBQyxNQUFNO0FBQ2pELFlBQUlzUixZQUFKOztBQUNBLFlBQUloQixPQUFPLElBQUksQ0FBQ04sS0FBSyxDQUFDTyxNQUFOLEVBQWhCLEVBQWdDO0FBQzlCLGlCQUFPLEtBQUtZLElBQUwsQ0FBVXpLLElBQVYsQ0FBUDtBQUNEOztBQUVELFlBQUtzSixLQUFLLENBQUNyTSxJQUFOLEtBQWUwTixJQUFJLENBQUMxTixJQUFyQixJQUE4QixDQUFDLEtBQUt0QyxjQUF4QyxFQUF3RDtBQUN0RGdRLGNBQUksQ0FBQzFOLElBQUwsR0FBWXFNLEtBQUssQ0FBQ3JNLElBQWxCO0FBQ0Q7O0FBRUQsWUFBS3FNLEtBQUssQ0FBQ3JNLElBQU4sS0FBZTBOLElBQUksQ0FBQzFOLElBQXJCLElBQThCLEtBQUt0QyxjQUF2QyxFQUF1RDtBQUNyRGlRLHNCQUFZLEdBQUcsS0FBZjtBQUNEOztBQUVELGVBQU8sS0FBS0MsS0FBTCxDQUFXN0ssSUFBWCxFQUFpQm5ELE9BQWpCLEVBQTBCOE4sSUFBMUIsRUFBZ0M3RixPQUFoQyxFQUF5QyxJQUF6QyxFQUFnRDhGLFlBQVksSUFBSSxLQUFoRSxDQUFQO0FBQ0QsT0FmMkMsQ0FBNUM7QUFnQkEsYUFBTyxLQUFLLENBQVo7QUFDRDs7QUFDRCxXQUFPLEtBQUtILElBQUwsQ0FBVXpLLElBQVYsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U2SyxPQUFLLENBQUM3SyxJQUFELEVBQU9uRCxPQUFQLEVBQWdCOE4sSUFBaEIsRUFBNEc7QUFBQSxRQUF0RjdGLE9BQXNGLHVFQUE1RSxVQUE0RTtBQUFBLFFBQWhFZ0csY0FBZ0UsdUVBQS9DLElBQStDOztBQUFBLFFBQXpDQyxhQUF5Qyx1RUFBekIsS0FBeUI7O0FBQUEsUUFBbEJDLFFBQWtCLHVFQUFQLEtBQU87QUFDL0csUUFBSUMsUUFBUSxHQUFHLEtBQWY7QUFDQSxRQUFJQyxRQUFRLEdBQUcsS0FBZjtBQUNBLFFBQUlDLGVBQWUsR0FBRyxFQUF0QjtBQUNBLFFBQUlDLEtBQUo7QUFDQSxRQUFJbE0sR0FBSjtBQUNBLFFBQUltTSxJQUFKO0FBQ0EsUUFBSVQsWUFBWSxHQUFHRyxhQUFuQjs7QUFFQSxRQUFJL0ssSUFBSSxDQUFDSyxNQUFMLENBQVl3RSxLQUFaLENBQWtCRSxRQUFsQixJQUErQi9FLElBQUksQ0FBQ0ssTUFBTCxDQUFZd0UsS0FBWixDQUFrQkUsUUFBbEIsS0FBK0IsTUFBbEUsRUFBMkU7QUFDekVvRyxxQkFBZSxHQUFHLGNBQWxCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLHFCQUFlLEdBQUcsVUFBbEI7QUFDRDs7QUFFRCxVQUFNRyxlQUFlLHdCQUFpQkMsU0FBUyxDQUFDWixJQUFJLENBQUMvRyxJQUFMLElBQWEvRyxPQUFPLENBQUMrRyxJQUF0QixDQUFULENBQXFDdEgsT0FBckMsQ0FBNkMsS0FBN0MsRUFBb0QsS0FBcEQsQ0FBakIsa0NBQW1Ha1Asa0JBQWtCLENBQUNiLElBQUksQ0FBQy9HLElBQUwsSUFBYS9HLE9BQU8sQ0FBQytHLElBQXRCLENBQXJILE9BQXJCO0FBQ0EsVUFBTTZILG1CQUFtQixHQUFHLGVBQTVCOztBQUVBLFFBQUksQ0FBQ3pMLElBQUksQ0FBQ1UsUUFBTCxDQUFjQyxXQUFuQixFQUFnQztBQUM5QlgsVUFBSSxDQUFDVSxRQUFMLENBQWN5QixTQUFkLENBQXdCLHFCQUF4QixFQUErQ2dKLGVBQWUsR0FBR0csZUFBbEIsR0FBb0NHLG1CQUFuRjtBQUNEOztBQUVELFFBQUl6TCxJQUFJLENBQUM3RyxPQUFMLENBQWE0RCxPQUFiLENBQXFCMk8sS0FBckIsSUFBOEIsQ0FBQ1YsUUFBbkMsRUFBNkM7QUFDM0NDLGNBQVEsR0FBRyxJQUFYO0FBQ0EsWUFBTVUsS0FBSyxHQUFHM0wsSUFBSSxDQUFDN0csT0FBTCxDQUFhNEQsT0FBYixDQUFxQjJPLEtBQXJCLENBQTJCOUcsS0FBM0IsQ0FBaUMseUJBQWpDLENBQWQ7QUFDQXdHLFdBQUssR0FBRzNPLFFBQVEsQ0FBQ2tQLEtBQUssQ0FBQyxDQUFELENBQU4sQ0FBaEI7QUFDQXpNLFNBQUcsR0FBR3pDLFFBQVEsQ0FBQ2tQLEtBQUssQ0FBQyxDQUFELENBQU4sQ0FBZDs7QUFDQSxVQUFJQyxLQUFLLENBQUMxTSxHQUFELENBQVQsRUFBZ0I7QUFDZEEsV0FBRyxHQUFHeUwsSUFBSSxDQUFDMU4sSUFBTCxHQUFZLENBQWxCO0FBQ0Q7O0FBQ0RvTyxVQUFJLEdBQUduTSxHQUFHLEdBQUdrTSxLQUFiO0FBQ0QsS0FURCxNQVNPO0FBQ0xBLFdBQUssR0FBRyxDQUFSO0FBQ0FsTSxTQUFHLEdBQUd5TCxJQUFJLENBQUMxTixJQUFMLEdBQVksQ0FBbEI7QUFDQW9PLFVBQUksR0FBR1YsSUFBSSxDQUFDMU4sSUFBWjtBQUNEOztBQUVELFFBQUlnTyxRQUFRLElBQUtqTCxJQUFJLENBQUNLLE1BQUwsQ0FBWXdFLEtBQVosQ0FBa0JnSCxJQUFsQixJQUEyQjdMLElBQUksQ0FBQ0ssTUFBTCxDQUFZd0UsS0FBWixDQUFrQmdILElBQWxCLEtBQTJCLE1BQXZFLEVBQWlGO0FBQy9FWCxjQUFRLEdBQUc7QUFBQ0UsYUFBRDtBQUFRbE07QUFBUixPQUFYOztBQUNBLFVBQUkwTSxLQUFLLENBQUNSLEtBQUQsQ0FBTCxJQUFnQixDQUFDUSxLQUFLLENBQUMxTSxHQUFELENBQTFCLEVBQWlDO0FBQy9CZ00sZ0JBQVEsQ0FBQ0UsS0FBVCxHQUFpQmxNLEdBQUcsR0FBR21NLElBQXZCO0FBQ0FILGdCQUFRLENBQUNoTSxHQUFULEdBQWlCQSxHQUFqQjtBQUNEOztBQUNELFVBQUksQ0FBQzBNLEtBQUssQ0FBQ1IsS0FBRCxDQUFOLElBQWlCUSxLQUFLLENBQUMxTSxHQUFELENBQTFCLEVBQWlDO0FBQy9CZ00sZ0JBQVEsQ0FBQ0UsS0FBVCxHQUFpQkEsS0FBakI7QUFDQUYsZ0JBQVEsQ0FBQ2hNLEdBQVQsR0FBaUJrTSxLQUFLLEdBQUdDLElBQXpCO0FBQ0Q7O0FBRUQsVUFBS0QsS0FBSyxHQUFHQyxJQUFULElBQWtCVixJQUFJLENBQUMxTixJQUEzQixFQUFpQztBQUMvQmlPLGdCQUFRLENBQUNoTSxHQUFULEdBQWV5TCxJQUFJLENBQUMxTixJQUFMLEdBQVksQ0FBM0I7QUFDRDs7QUFFRCxVQUFJLEtBQUtqRCxNQUFMLEtBQWlCa1IsUUFBUSxDQUFDRSxLQUFULElBQW1CVCxJQUFJLENBQUMxTixJQUFMLEdBQVksQ0FBaEMsSUFBd0NpTyxRQUFRLENBQUNoTSxHQUFULEdBQWdCeUwsSUFBSSxDQUFDMU4sSUFBTCxHQUFZLENBQXBGLENBQUosRUFBOEY7QUFDNUYyTixvQkFBWSxHQUFHLEtBQWY7QUFDRCxPQUZELE1BRU87QUFDTEEsb0JBQVksR0FBRyxLQUFmO0FBQ0Q7QUFDRixLQXBCRCxNQW9CTztBQUNMQSxrQkFBWSxHQUFHLEtBQWY7QUFDRDs7QUFFRCxVQUFNa0Isa0JBQWtCLEdBQUlsTyxLQUFELElBQVc7QUFDcEMsV0FBS0gsTUFBTCxvQ0FBd0NrTixJQUFJLENBQUNyTCxJQUE3QyxlQUFzRHdGLE9BQXRELGVBQXlFbEgsS0FBekU7O0FBQ0EsVUFBSSxDQUFDb0MsSUFBSSxDQUFDVSxRQUFMLENBQWNJLFFBQW5CLEVBQTZCO0FBQzNCZCxZQUFJLENBQUNVLFFBQUwsQ0FBY3hCLEdBQWQsQ0FBa0J0QixLQUFLLENBQUM4RSxRQUFOLEVBQWxCO0FBQ0Q7QUFDRixLQUxEOztBQU9BLFVBQU0zRixPQUFPLEdBQUcvRCxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUt4QixlQUF4QixJQUEyQyxLQUFLQSxlQUFMLENBQXFCNlAsWUFBckIsRUFBbUMvTixPQUFuQyxFQUE0QzhOLElBQTVDLEVBQWtEN0YsT0FBbEQsRUFBMkQ5RSxJQUEzRCxDQUEzQyxHQUE4RyxLQUFLakYsZUFBbkk7O0FBRUEsUUFBSSxDQUFDZ0MsT0FBTyxDQUFDLGVBQUQsQ0FBWixFQUErQjtBQUM3QixVQUFJLENBQUNpRCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLFlBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QixlQUF4QixFQUF5QyxLQUFLOUgsWUFBOUM7QUFDRDtBQUNGOztBQUVELFNBQUssSUFBSTBSLEdBQVQsSUFBZ0JoUCxPQUFoQixFQUF5QjtBQUN2QixVQUFJLENBQUNpRCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLFlBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QjRKLEdBQXhCLEVBQTZCaFAsT0FBTyxDQUFDZ1AsR0FBRCxDQUFwQztBQUNEO0FBQ0Y7O0FBRUQsVUFBTUMsT0FBTyxHQUFHLENBQUN0RCxNQUFELEVBQVN1RCxJQUFULEtBQWtCO0FBQ2hDdkQsWUFBTSxDQUFDd0QsUUFBUCxHQUFrQixLQUFsQjs7QUFDQSxZQUFNQyxhQUFhLEdBQUlDLFVBQUQsSUFBZ0I7QUFDcEMsWUFBSSxDQUFDQSxVQUFMLEVBQWlCO0FBQ2YxRCxnQkFBTSxDQUFDd0QsUUFBUCxHQUFrQixJQUFsQjtBQUNELFNBRkQsTUFFTztBQUNMLGVBQUt6TyxNQUFMLG9DQUF3Q2tOLElBQUksQ0FBQ3JMLElBQTdDLGVBQXNEd0YsT0FBdEQsMENBQW9Hc0gsVUFBcEc7QUFDRDtBQUNGLE9BTkQ7O0FBUUEsWUFBTUMsV0FBVyxHQUFHLE1BQU07QUFDeEIsWUFBSSxDQUFDM0QsTUFBTSxDQUFDd0QsUUFBWixFQUFzQjtBQUNwQixjQUFJLE9BQU94RCxNQUFNLENBQUNqQixLQUFkLEtBQXdCLFVBQTVCLEVBQXdDO0FBQ3RDaUIsa0JBQU0sQ0FBQ2pCLEtBQVAsQ0FBYTBFLGFBQWI7QUFDRCxXQUZELE1BRU8sSUFBSSxPQUFPekQsTUFBTSxDQUFDeEosR0FBZCxLQUFzQixVQUExQixFQUFzQztBQUMzQ3dKLGtCQUFNLENBQUN4SixHQUFQLENBQVdpTixhQUFYO0FBQ0QsV0FGTSxNQUVBLElBQUksT0FBT3pELE1BQU0sQ0FBQzRELE9BQWQsS0FBMEIsVUFBOUIsRUFBMEM7QUFDL0M1RCxrQkFBTSxDQUFDNEQsT0FBUCxDQUFlLDBCQUFmLEVBQTJDSCxhQUEzQztBQUNEO0FBQ0Y7QUFDRixPQVZEOztBQVlBLFVBQUksQ0FBQ25NLElBQUksQ0FBQ1UsUUFBTCxDQUFjQyxXQUFmLElBQThCbUssY0FBbEMsRUFBa0Q7QUFDaEQ5SyxZQUFJLENBQUNVLFFBQUwsQ0FBY0UsU0FBZCxDQUF3QnFMLElBQXhCO0FBQ0Q7O0FBRURqTSxVQUFJLENBQUNVLFFBQUwsQ0FBY1UsRUFBZCxDQUFpQixPQUFqQixFQUEwQmlMLFdBQTFCO0FBQ0FyTSxVQUFJLENBQUM3RyxPQUFMLENBQWFpSSxFQUFiLENBQWdCLFNBQWhCLEVBQTJCLE1BQU07QUFDL0JwQixZQUFJLENBQUM3RyxPQUFMLENBQWF3RyxPQUFiLEdBQXVCLElBQXZCO0FBQ0EwTSxtQkFBVztBQUNaLE9BSEQ7QUFLQTNELFlBQU0sQ0FBQ3RILEVBQVAsQ0FBVSxNQUFWLEVBQWtCLE1BQU07QUFDdEIsWUFBSSxDQUFDcEIsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxjQUFJLENBQUNVLFFBQUwsQ0FBY0UsU0FBZCxDQUF3QnFMLElBQXhCO0FBQ0Q7QUFDRixPQUpELEVBSUc3SyxFQUpILENBSU0sT0FKTixFQUllLE1BQU07QUFDbkJpTCxtQkFBVzs7QUFDWCxZQUFJLENBQUNyTSxJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZDtBQUNEOztBQUNELFlBQUksQ0FBQ2MsSUFBSSxDQUFDN0csT0FBTCxDQUFhd0csT0FBbEIsRUFBMkI7QUFDekJLLGNBQUksQ0FBQzdHLE9BQUwsQ0FBYW1ULE9BQWI7QUFDRDtBQUNGLE9BWkQsRUFZR2xMLEVBWkgsQ0FZTSxPQVpOLEVBWWdCbUwsR0FBRCxJQUFTO0FBQ3RCRixtQkFBVztBQUNYUCwwQkFBa0IsQ0FBQ1MsR0FBRCxDQUFsQjtBQUNELE9BZkQsRUFlR25MLEVBZkgsQ0FlTSxLQWZOLEVBZWEsTUFBTTtBQUNqQmlMLG1CQUFXOztBQUNYLFlBQUksQ0FBQ3JNLElBQUksQ0FBQ1UsUUFBTCxDQUFjSSxRQUFuQixFQUE2QjtBQUMzQmQsY0FBSSxDQUFDVSxRQUFMLENBQWN4QixHQUFkO0FBQ0Q7QUFDRixPQXBCRCxFQW9CR3VLLElBcEJILENBb0JRekosSUFBSSxDQUFDVSxRQXBCYjtBQXFCRCxLQXJERDs7QUF1REEsWUFBUWtLLFlBQVI7QUFDQSxXQUFLLEtBQUw7QUFDRSxhQUFLbk4sTUFBTCxvQ0FBd0NrTixJQUFJLENBQUNyTCxJQUE3QyxlQUFzRHdGLE9BQXREOztBQUNBLFlBQUlyRSxJQUFJLEdBQUcsMEJBQVg7O0FBRUEsWUFBSSxDQUFDVCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjRSxTQUFkLENBQXdCLEdBQXhCLEVBQTZCO0FBQzNCLDRCQUFnQixZQURXO0FBRTNCLDhCQUFrQkgsSUFBSSxDQUFDSTtBQUZJLFdBQTdCO0FBSUQ7O0FBRUQsWUFBSSxDQUFDYixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZCxDQUFrQnVCLElBQWxCO0FBQ0Q7O0FBQ0Q7O0FBQ0YsV0FBSyxLQUFMO0FBQ0UsYUFBS2dLLElBQUwsQ0FBVXpLLElBQVY7O0FBQ0E7O0FBQ0YsV0FBSyxLQUFMO0FBQ0UsYUFBS3ZDLE1BQUwsb0NBQXdDa04sSUFBSSxDQUFDckwsSUFBN0MsZUFBc0R3RixPQUF0RDs7QUFDQSxZQUFJLENBQUM5RSxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjRSxTQUFkLENBQXdCLEdBQXhCO0FBQ0Q7O0FBQ0QsWUFBSSxDQUFDWixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZDtBQUNEOztBQUNEOztBQUNGLFdBQUssS0FBTDtBQUNFLGFBQUt6QixNQUFMLG9DQUF3Q2tOLElBQUksQ0FBQ3JMLElBQTdDLGVBQXNEd0YsT0FBdEQ7O0FBQ0EsWUFBSSxDQUFDOUUsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxjQUFJLENBQUNVLFFBQUwsQ0FBY3lCLFNBQWQsQ0FBd0IsZUFBeEIsa0JBQWtEK0ksUUFBUSxDQUFDRSxLQUEzRCxjQUFvRUYsUUFBUSxDQUFDaE0sR0FBN0UsY0FBb0Z5TCxJQUFJLENBQUMxTixJQUF6RjtBQUNEOztBQUNEK08sZUFBTyxDQUFDbEIsY0FBYyxJQUFJN1IsRUFBRSxDQUFDdVQsZ0JBQUgsQ0FBb0I3QixJQUFJLENBQUNyTCxJQUF6QixFQUErQjtBQUFDOEwsZUFBSyxFQUFFRixRQUFRLENBQUNFLEtBQWpCO0FBQXdCbE0sYUFBRyxFQUFFZ00sUUFBUSxDQUFDaE07QUFBdEMsU0FBL0IsQ0FBbkIsRUFBK0YsR0FBL0YsQ0FBUDtBQUNBOztBQUNGO0FBQ0UsWUFBSSxDQUFDYyxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QixnQkFBeEIsWUFBNkN3SSxJQUFJLENBQUMxTixJQUFsRDtBQUNEOztBQUNELGFBQUtRLE1BQUwsb0NBQXdDa04sSUFBSSxDQUFDckwsSUFBN0MsZUFBc0R3RixPQUF0RDs7QUFDQWtILGVBQU8sQ0FBQ2xCLGNBQWMsSUFBSTdSLEVBQUUsQ0FBQ3VULGdCQUFILENBQW9CN0IsSUFBSSxDQUFDckwsSUFBekIsQ0FBbkIsRUFBbUQsR0FBbkQsQ0FBUDtBQUNBO0FBekNGO0FBMkNEOztBQTF2RHNELEM7Ozs7Ozs7Ozs7O0FDcEV6RHZILE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNVLFNBQU8sRUFBQyxNQUFJRztBQUFiLENBQWQ7QUFBaUQsSUFBSTRULFlBQUo7QUFBaUIxVSxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzVSxjQUFZLENBQUNyVSxDQUFELEVBQUc7QUFBQ3FVLGdCQUFZLEdBQUNyVSxDQUFiO0FBQWU7O0FBQWhDLENBQTVCLEVBQThELENBQTlEO0FBQWlFLElBQUlPLEtBQUosRUFBVUMsS0FBVjtBQUFnQmIsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUSxHQUFsQjs7QUFBbUJRLE9BQUssQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLFNBQUssR0FBQ1IsQ0FBTjtBQUFROztBQUFwQyxDQUEzQixFQUFpRSxDQUFqRTtBQUFvRSxJQUFJc1UsWUFBSixFQUFpQjFULE9BQWpCO0FBQXlCakIsTUFBTSxDQUFDSSxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDdVUsY0FBWSxDQUFDdFUsQ0FBRCxFQUFHO0FBQUNzVSxnQkFBWSxHQUFDdFUsQ0FBYjtBQUFlLEdBQWhDOztBQUFpQ1ksU0FBTyxDQUFDWixDQUFELEVBQUc7QUFBQ1ksV0FBTyxHQUFDWixDQUFSO0FBQVU7O0FBQXRELENBQXZCLEVBQStFLENBQS9FO0FBQWtGLElBQUl1VSxXQUFKLEVBQWdCQyxVQUFoQjtBQUEyQjdVLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ3dVLGFBQVcsQ0FBQ3ZVLENBQUQsRUFBRztBQUFDdVUsZUFBVyxHQUFDdlUsQ0FBWjtBQUFjLEdBQTlCOztBQUErQndVLFlBQVUsQ0FBQ3hVLENBQUQsRUFBRztBQUFDd1UsY0FBVSxHQUFDeFUsQ0FBWDtBQUFhOztBQUExRCxDQUExQixFQUFzRixDQUF0Rjs7QUFLOVUsTUFBTVMsbUJBQU4sU0FBa0M0VCxZQUFsQyxDQUErQztBQUM1RC9TLGFBQVcsR0FBRztBQUNaO0FBQ0Q7O0FBMEZEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0UrRCxRQUFNLEdBQUc7QUFDUCxRQUFJLEtBQUs1RCxLQUFULEVBQWdCO0FBQ2QsT0FBQzBJLE9BQU8sQ0FBQ3NLLElBQVIsSUFBZ0J0SyxPQUFPLENBQUN1SyxHQUF4QixJQUErQixZQUFZLENBQUcsQ0FBL0MsRUFBaUR4UCxLQUFqRCxDQUF1RCxLQUFLLENBQTVELEVBQStEQyxTQUEvRDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTBJLGNBQVksQ0FBQ2dCLFFBQUQsRUFBVztBQUNyQixVQUFNakIsUUFBUSxHQUFHaUIsUUFBUSxDQUFDckQsSUFBVCxJQUFpQnFELFFBQVEsQ0FBQ2pCLFFBQTNDOztBQUNBLFFBQUloTixPQUFPLENBQUNnRCxRQUFSLENBQWlCZ0ssUUFBakIsS0FBK0JBLFFBQVEsQ0FBQ25GLE1BQVQsR0FBa0IsQ0FBckQsRUFBeUQ7QUFDdkQsYUFBTyxDQUFDb0csUUFBUSxDQUFDckQsSUFBVCxJQUFpQnFELFFBQVEsQ0FBQ2pCLFFBQTNCLEVBQXFDMUosT0FBckMsQ0FBNkMsUUFBN0MsRUFBdUQsRUFBdkQsRUFBMkRBLE9BQTNELENBQW1FLFNBQW5FLEVBQThFLEdBQTlFLEVBQW1GQSxPQUFuRixDQUEyRixLQUEzRixFQUFrRyxFQUFsRyxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRThKLFNBQU8sQ0FBQ0osUUFBRCxFQUFXO0FBQ2hCLFFBQUlBLFFBQVEsQ0FBQ2hFLFFBQVQsQ0FBa0IsR0FBbEIsQ0FBSixFQUE0QjtBQUMxQixZQUFNa0UsU0FBUyxHQUFHLENBQUNGLFFBQVEsQ0FBQ3BCLEtBQVQsQ0FBZSxHQUFmLEVBQW9CbUksR0FBcEIsR0FBMEJuSSxLQUExQixDQUFnQyxHQUFoQyxFQUFxQyxDQUFyQyxLQUEyQyxFQUE1QyxFQUFnRG9JLFdBQWhELEVBQWxCO0FBQ0EsYUFBTztBQUFFM0csV0FBRyxFQUFFSCxTQUFQO0FBQWtCQSxpQkFBbEI7QUFBNkJDLHdCQUFnQixhQUFNRCxTQUFOO0FBQTdDLE9BQVA7QUFDRDs7QUFDRCxXQUFPO0FBQUVHLFNBQUcsRUFBRSxFQUFQO0FBQVdILGVBQVMsRUFBRSxFQUF0QjtBQUEwQkMsc0JBQWdCLEVBQUU7QUFBNUMsS0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFUSxrQkFBZ0IsQ0FBQ3BDLElBQUQsRUFBTztBQUNyQkEsUUFBSSxDQUFDMEksT0FBTCxHQUFnQixZQUFZaEwsSUFBWixDQUFpQnNDLElBQUksQ0FBQ3BILElBQXRCLENBQWhCO0FBQ0FvSCxRQUFJLENBQUMySSxPQUFMLEdBQWdCLFlBQVlqTCxJQUFaLENBQWlCc0MsSUFBSSxDQUFDcEgsSUFBdEIsQ0FBaEI7QUFDQW9ILFFBQUksQ0FBQzRJLE9BQUwsR0FBZ0IsWUFBWWxMLElBQVosQ0FBaUJzQyxJQUFJLENBQUNwSCxJQUF0QixDQUFoQjtBQUNBb0gsUUFBSSxDQUFDNkksTUFBTCxHQUFnQixXQUFXbkwsSUFBWCxDQUFnQnNDLElBQUksQ0FBQ3BILElBQXJCLENBQWhCO0FBQ0FvSCxRQUFJLENBQUM4SSxNQUFMLEdBQWdCLHVCQUF1QnBMLElBQXZCLENBQTRCc0MsSUFBSSxDQUFDcEgsSUFBakMsQ0FBaEI7QUFDQW9ILFFBQUksQ0FBQytJLEtBQUwsR0FBZ0IsMkJBQTJCckwsSUFBM0IsQ0FBZ0NzQyxJQUFJLENBQUNwSCxJQUFyQyxDQUFoQjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VtSixlQUFhLENBQUMvQixJQUFELEVBQU87QUFDbEIsVUFBTWdKLEVBQUUsR0FBRztBQUNUM0osVUFBSSxFQUFFVyxJQUFJLENBQUNYLElBREY7QUFFVHNDLGVBQVMsRUFBRTNCLElBQUksQ0FBQzJCLFNBRlA7QUFHVEcsU0FBRyxFQUFFOUIsSUFBSSxDQUFDMkIsU0FIRDtBQUlUQyxzQkFBZ0IsRUFBRSxNQUFNNUIsSUFBSSxDQUFDMkIsU0FKcEI7QUFLVDVHLFVBQUksRUFBRWlGLElBQUksQ0FBQ2pGLElBTEY7QUFNVGlFLFVBQUksRUFBRWdCLElBQUksQ0FBQ2hCLElBTkY7QUFPVHBHLFVBQUksRUFBRW9ILElBQUksQ0FBQ3BILElBUEY7QUFRVCtKLFVBQUksRUFBRTNDLElBQUksQ0FBQ3BILElBUkY7QUFTVCxtQkFBYW9ILElBQUksQ0FBQ3BILElBVFQ7QUFVVEYsVUFBSSxFQUFFc0gsSUFBSSxDQUFDdEgsSUFWRjtBQVdUa0QsWUFBTSxFQUFFb0UsSUFBSSxDQUFDcEUsTUFBTCxJQUFlLElBWGQ7QUFZVG9KLGNBQVEsRUFBRTtBQUNSQyxnQkFBUSxFQUFFO0FBQ1JsSyxjQUFJLEVBQUVpRixJQUFJLENBQUNqRixJQURIO0FBRVJyQyxjQUFJLEVBQUVzSCxJQUFJLENBQUN0SCxJQUZIO0FBR1JFLGNBQUksRUFBRW9ILElBQUksQ0FBQ3BILElBSEg7QUFJUitJLG1CQUFTLEVBQUUzQixJQUFJLENBQUMyQjtBQUpSO0FBREYsT0FaRDtBQW9CVHNILG9CQUFjLEVBQUVqSixJQUFJLENBQUNpSixjQUFMLElBQXVCLEtBQUtsVCxhQXBCbkM7QUFxQlRtVCxxQkFBZSxFQUFFbEosSUFBSSxDQUFDa0osZUFBTCxJQUF3QixLQUFLN1M7QUFyQnJDLEtBQVgsQ0FEa0IsQ0F5QmxCOztBQUNBLFFBQUkySixJQUFJLENBQUN2QixNQUFULEVBQWlCO0FBQ2Z1SyxRQUFFLENBQUM3TyxHQUFILEdBQVM2RixJQUFJLENBQUN2QixNQUFkO0FBQ0Q7O0FBRUQsU0FBSzJELGdCQUFMLENBQXNCNEcsRUFBdEI7O0FBQ0FBLE1BQUUsQ0FBQ3pELFlBQUgsR0FBa0J2RixJQUFJLENBQUN1RixZQUFMLElBQXFCLEtBQUtsUSxXQUFMLENBQWlCcUUsTUFBTSxDQUFDc0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JnRSxJQUFsQixFQUF3QmdKLEVBQXhCLENBQWpCLENBQXZDO0FBQ0EsV0FBT0EsRUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXpOLFNBQU8sR0FBeUI7QUFBQSxRQUF4Qm9GLFFBQXdCLHVFQUFiLEVBQWE7QUFBQSxRQUFUd0ksT0FBUzs7QUFDOUIsU0FBS2pRLE1BQUwsc0NBQTBDa0YsSUFBSSxDQUFDQyxTQUFMLENBQWVzQyxRQUFmLENBQTFDLGVBQXVFdkMsSUFBSSxDQUFDQyxTQUFMLENBQWU4SyxPQUFmLENBQXZFOztBQUNBL1UsU0FBSyxDQUFDdU0sUUFBRCxFQUFXdE0sS0FBSyxDQUFDMk0sUUFBTixDQUFlM00sS0FBSyxDQUFDb0YsS0FBTixDQUFZQyxNQUFaLEVBQW9CN0IsTUFBcEIsRUFBNEJ5QixPQUE1QixFQUFxQ0MsTUFBckMsRUFBNkMsSUFBN0MsQ0FBZixDQUFYLENBQUw7QUFDQW5GLFNBQUssQ0FBQytVLE9BQUQsRUFBVTlVLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZXRILE1BQWYsQ0FBVixDQUFMO0FBRUEsVUFBTWEsR0FBRyxHQUFHLEtBQUszRSxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JvRixRQUF4QixFQUFrQ3dJLE9BQWxDLENBQVo7O0FBQ0EsUUFBSTVPLEdBQUosRUFBUztBQUNQLGFBQU8sSUFBSThOLFVBQUosQ0FBZTlOLEdBQWYsRUFBb0IsSUFBcEIsQ0FBUDtBQUNEOztBQUNELFdBQU9BLEdBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VOLE1BQUksR0FBeUI7QUFBQSxRQUF4QjBHLFFBQXdCLHVFQUFiLEVBQWE7QUFBQSxRQUFUd0ksT0FBUzs7QUFDM0IsU0FBS2pRLE1BQUwsbUNBQXVDa0YsSUFBSSxDQUFDQyxTQUFMLENBQWVzQyxRQUFmLENBQXZDLGVBQW9FdkMsSUFBSSxDQUFDQyxTQUFMLENBQWU4SyxPQUFmLENBQXBFOztBQUNBL1UsU0FBSyxDQUFDdU0sUUFBRCxFQUFXdE0sS0FBSyxDQUFDMk0sUUFBTixDQUFlM00sS0FBSyxDQUFDb0YsS0FBTixDQUFZQyxNQUFaLEVBQW9CN0IsTUFBcEIsRUFBNEJ5QixPQUE1QixFQUFxQ0MsTUFBckMsRUFBNkMsSUFBN0MsQ0FBZixDQUFYLENBQUw7QUFDQW5GLFNBQUssQ0FBQytVLE9BQUQsRUFBVTlVLEtBQUssQ0FBQzJNLFFBQU4sQ0FBZXRILE1BQWYsQ0FBVixDQUFMO0FBRUEsV0FBTyxJQUFJME8sV0FBSixDQUFnQnpILFFBQWhCLEVBQTBCd0ksT0FBMUIsRUFBbUMsSUFBbkMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U3RyxRQUFNLEdBQUc7QUFDUCxTQUFLMU0sVUFBTCxDQUFnQjBNLE1BQWhCLENBQXVCdkosS0FBdkIsQ0FBNkIsS0FBS25ELFVBQWxDLEVBQThDb0QsU0FBOUM7QUFDQSxXQUFPLEtBQUtwRCxVQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VoQyxNQUFJLENBQUMwRSxPQUFELEVBQXlDO0FBQUEsUUFBL0JpSSxPQUErQix1RUFBckIsVUFBcUI7QUFBQSxRQUFUNkksT0FBUzs7QUFDM0MsU0FBS2xRLE1BQUwsbUNBQXdDekUsT0FBTyxDQUFDMEQsUUFBUixDQUFpQkcsT0FBakIsSUFBNEJBLE9BQU8sQ0FBQzZCLEdBQXBDLEdBQTBDLEtBQUssQ0FBdkYsZUFBOEZvRyxPQUE5Rjs7QUFDQW5NLFNBQUssQ0FBQ2tFLE9BQUQsRUFBVW9CLE1BQVYsQ0FBTDs7QUFFQSxRQUFJLENBQUNwQixPQUFMLEVBQWM7QUFDWixhQUFPLEVBQVA7QUFDRDs7QUFDRCxXQUFPNlAsWUFBWSxDQUFDN1AsT0FBRCxFQUFVaUksT0FBVixFQUFtQjZJLE9BQW5CLENBQW5CO0FBQ0Q7O0FBMVEyRDs7QUFBekM5VSxtQixDQUtaK1UsUyxHQUFZNVUsTztBQUxBSCxtQixDQU9aaUIsTSxHQUFTO0FBQ2Q0RSxLQUFHLEVBQUU7QUFDSHZCLFFBQUksRUFBRWY7QUFESCxHQURTO0FBSWRhLE1BQUksRUFBRTtBQUNKRSxRQUFJLEVBQUVXO0FBREYsR0FKUTtBQU9kOEYsTUFBSSxFQUFFO0FBQ0p6RyxRQUFJLEVBQUVmO0FBREYsR0FQUTtBQVVkZSxNQUFJLEVBQUU7QUFDSkEsUUFBSSxFQUFFZjtBQURGLEdBVlE7QUFhZGtELE1BQUksRUFBRTtBQUNKbkMsUUFBSSxFQUFFZjtBQURGLEdBYlE7QUFnQmQ2USxTQUFPLEVBQUU7QUFDUDlQLFFBQUksRUFBRVU7QUFEQyxHQWhCSztBQW1CZHFQLFNBQU8sRUFBRTtBQUNQL1AsUUFBSSxFQUFFVTtBQURDLEdBbkJLO0FBc0Jkc1AsU0FBTyxFQUFFO0FBQ1BoUSxRQUFJLEVBQUVVO0FBREMsR0F0Qks7QUF5QmR1UCxRQUFNLEVBQUU7QUFDTmpRLFFBQUksRUFBRVU7QUFEQSxHQXpCTTtBQTRCZHdQLFFBQU0sRUFBRTtBQUNObFEsUUFBSSxFQUFFVTtBQURBLEdBNUJNO0FBK0JkeVAsT0FBSyxFQUFFO0FBQ0xuUSxRQUFJLEVBQUVVO0FBREQsR0EvQk87QUFrQ2RxSSxXQUFTLEVBQUU7QUFDVC9JLFFBQUksRUFBRWYsTUFERztBQUVUeVIsWUFBUSxFQUFFO0FBRkQsR0FsQ0c7QUFzQ2R4SCxLQUFHLEVBQUU7QUFDSGxKLFFBQUksRUFBRWYsTUFESDtBQUVIeVIsWUFBUSxFQUFFO0FBRlAsR0F0Q1M7QUEwQ2QxSCxrQkFBZ0IsRUFBRTtBQUNoQmhKLFFBQUksRUFBRWYsTUFEVTtBQUVoQnlSLFlBQVEsRUFBRTtBQUZNLEdBMUNKO0FBOENkM0csTUFBSSxFQUFFO0FBQ0ovSixRQUFJLEVBQUVmLE1BREY7QUFFSnlSLFlBQVEsRUFBRTtBQUZOLEdBOUNRO0FBa0RkLGVBQWE7QUFDWDFRLFFBQUksRUFBRWYsTUFESztBQUVYeVIsWUFBUSxFQUFFO0FBRkMsR0FsREM7QUFzRGQvRCxjQUFZLEVBQUU7QUFDWjNNLFFBQUksRUFBRWY7QUFETSxHQXREQTtBQXlEZG9SLGdCQUFjLEVBQUU7QUFDZHJRLFFBQUksRUFBRWY7QUFEUSxHQXpERjtBQTREZHFSLGlCQUFlLEVBQUU7QUFDZnRRLFFBQUksRUFBRWY7QUFEUyxHQTVESDtBQStEZHJDLFFBQU0sRUFBRTtBQUNOb0QsUUFBSSxFQUFFVSxPQURBO0FBRU5nUSxZQUFRLEVBQUU7QUFGSixHQS9ETTtBQW1FZHRLLE1BQUksRUFBRTtBQUNKcEcsUUFBSSxFQUFFYyxNQURGO0FBRUo2UCxZQUFRLEVBQUUsSUFGTjtBQUdKRCxZQUFRLEVBQUU7QUFITixHQW5FUTtBQXdFZDFOLFFBQU0sRUFBRTtBQUNOaEQsUUFBSSxFQUFFZixNQURBO0FBRU55UixZQUFRLEVBQUU7QUFGSixHQXhFTTtBQTRFZEUsV0FBUyxFQUFFO0FBQ1Q1USxRQUFJLEVBQUUyRyxJQURHO0FBRVQrSixZQUFRLEVBQUU7QUFGRCxHQTVFRztBQWdGZHRFLFVBQVEsRUFBRTtBQUNScE0sUUFBSSxFQUFFYyxNQURFO0FBRVI2UCxZQUFRLEVBQUU7QUFGRjtBQWhGSSxDOzs7Ozs7Ozs7OztBQ1psQi9WLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUM0VSxZQUFVLEVBQUMsTUFBSUEsVUFBaEI7QUFBMkJELGFBQVcsRUFBQyxNQUFJQTtBQUEzQyxDQUFkO0FBQXVFLElBQUlyVSxNQUFKO0FBQVdQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0csUUFBTSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsVUFBTSxHQUFDRixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQVUzRSxNQUFNd1UsVUFBTixDQUFpQjtBQUN0QmxULGFBQVcsQ0FBQ3NVLFFBQUQsRUFBV0MsV0FBWCxFQUF3QjtBQUNqQyxTQUFLRCxRQUFMLEdBQW1CQSxRQUFuQjtBQUNBLFNBQUtDLFdBQUwsR0FBbUJBLFdBQW5CO0FBQ0FoUSxVQUFNLENBQUNzQyxNQUFQLENBQWMsSUFBZCxFQUFvQnlOLFFBQXBCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWpQLFFBQU0sQ0FBQ3ZGLFFBQUQsRUFBVztBQUNmLFNBQUt5VSxXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsMkNBQXhCOztBQUNBLFFBQUksS0FBS3VRLFFBQVQsRUFBbUI7QUFDakIsV0FBS0MsV0FBTCxDQUFpQmxQLE1BQWpCLENBQXdCLEtBQUtpUCxRQUFMLENBQWN0UCxHQUF0QyxFQUEyQ2xGLFFBQTNDO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLGNBQVEsSUFBSUEsUUFBUSxDQUFDLElBQUlsQixNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQUQsQ0FBcEI7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VsRSxNQUFJLEdBQWdDO0FBQUEsUUFBL0IyTSxPQUErQix1RUFBckIsVUFBcUI7QUFBQSxRQUFUNkksT0FBUzs7QUFDbEMsU0FBS00sV0FBTCxDQUFpQnhRLE1BQWpCLGdEQUFnRXFILE9BQWhFOztBQUNBLFFBQUksS0FBS2tKLFFBQVQsRUFBbUI7QUFDakIsYUFBTyxLQUFLQyxXQUFMLENBQWlCOVYsSUFBakIsQ0FBc0IsS0FBSzZWLFFBQTNCLEVBQXFDbEosT0FBckMsRUFBOEM2SSxPQUE5QyxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTNGLEtBQUcsQ0FBQ2tHLFFBQUQsRUFBVztBQUNaLFNBQUtELFdBQUwsQ0FBaUJ4USxNQUFqQiwrQ0FBK0R5USxRQUEvRDs7QUFDQSxRQUFJQSxRQUFKLEVBQWM7QUFDWixhQUFPLEtBQUtGLFFBQUwsQ0FBY0UsUUFBZCxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLRixRQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U5RCxPQUFLLEdBQUc7QUFDTixTQUFLK0QsV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLDBDQUF4Qjs7QUFDQSxXQUFPLENBQUMsS0FBS3VRLFFBQU4sQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFRyxNQUFJLEdBQUc7QUFDTCxTQUFLRixXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IseUNBQXhCOztBQUNBLFdBQU9RLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYyxJQUFkLEVBQW9CLEtBQUswTixXQUFMLENBQWlCOVQsVUFBakIsQ0FBNEIyRixPQUE1QixDQUFvQyxLQUFLa08sUUFBTCxDQUFjdFAsR0FBbEQsQ0FBcEIsQ0FBUDtBQUNEOztBQWhGcUI7O0FBNEZqQixNQUFNaU8sV0FBTixDQUFrQjtBQUN2QmpULGFBQVcsR0FBdUM7QUFBQSxRQUF0QzBVLFNBQXNDLHVFQUExQixFQUEwQjs7QUFBQSxRQUF0QlYsT0FBc0I7O0FBQUEsUUFBYk8sV0FBYTs7QUFDaEQsU0FBS0EsV0FBTCxHQUFtQkEsV0FBbkI7QUFDQSxTQUFLRyxTQUFMLEdBQW1CQSxTQUFuQjtBQUNBLFNBQUtDLFFBQUwsR0FBbUIsQ0FBQyxDQUFwQjtBQUNBLFNBQUtoSixNQUFMLEdBQW1CLEtBQUs0SSxXQUFMLENBQWlCOVQsVUFBakIsQ0FBNEJxRSxJQUE1QixDQUFpQyxLQUFLNFAsU0FBdEMsRUFBaURWLE9BQWpELENBQW5CO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UxRixLQUFHLEdBQUc7QUFDSixTQUFLaUcsV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLHlDQUF4Qjs7QUFDQSxXQUFPLEtBQUs0SCxNQUFMLENBQVk2RSxLQUFaLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRW9FLFNBQU8sR0FBRztBQUNSLFNBQUtMLFdBQUwsQ0FBaUJ4USxNQUFqQixDQUF3Qiw2Q0FBeEI7O0FBQ0EsV0FBTyxLQUFLNFEsUUFBTCxHQUFpQixLQUFLaEosTUFBTCxDQUFZbEcsS0FBWixLQUFzQixDQUE5QztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMkMsTUFBSSxHQUFHO0FBQ0wsU0FBS21NLFdBQUwsQ0FBaUJ4USxNQUFqQixDQUF3QiwwQ0FBeEI7O0FBQ0EsU0FBSzRILE1BQUwsQ0FBWTZFLEtBQVosR0FBb0IsRUFBRSxLQUFLbUUsUUFBM0I7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUUsYUFBVyxHQUFHO0FBQ1osU0FBS04sV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLGlEQUF4Qjs7QUFDQSxXQUFPLEtBQUs0USxRQUFMLEtBQWtCLENBQUMsQ0FBMUI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUcsVUFBUSxHQUFHO0FBQ1QsU0FBS1AsV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLDhDQUF4Qjs7QUFDQSxTQUFLNEgsTUFBTCxDQUFZNkUsS0FBWixHQUFvQixFQUFFLEtBQUttRSxRQUEzQjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbkUsT0FBSyxHQUFHO0FBQ04sU0FBSytELFdBQUwsQ0FBaUJ4USxNQUFqQixDQUF3QiwyQ0FBeEI7O0FBQ0EsV0FBTyxLQUFLNEgsTUFBTCxDQUFZNkUsS0FBWixNQUF1QixFQUE5QjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFdUUsT0FBSyxHQUFHO0FBQ04sU0FBS1IsV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLDJDQUF4Qjs7QUFDQSxTQUFLNFEsUUFBTCxHQUFnQixDQUFoQjtBQUNBLFdBQU8sS0FBS25FLEtBQUwsR0FBYSxLQUFLbUUsUUFBbEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFSyxNQUFJLEdBQUc7QUFDTCxTQUFLVCxXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsMENBQXhCOztBQUNBLFNBQUs0USxRQUFMLEdBQWdCLEtBQUtsUCxLQUFMLEtBQWUsQ0FBL0I7QUFDQSxXQUFPLEtBQUsrSyxLQUFMLEdBQWEsS0FBS21FLFFBQWxCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWxQLE9BQUssR0FBRztBQUNOLFNBQUs4TyxXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsMkNBQXhCOztBQUNBLFdBQU8sS0FBSzRILE1BQUwsQ0FBWWxHLEtBQVosRUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VKLFFBQU0sQ0FBQ3ZGLFFBQUQsRUFBVztBQUNmLFNBQUt5VSxXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsNENBQXhCOztBQUNBLFNBQUt3USxXQUFMLENBQWlCbFAsTUFBakIsQ0FBd0IsS0FBS3FQLFNBQTdCLEVBQXdDNVUsUUFBeEM7O0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFd1EsU0FBTyxDQUFDeFEsUUFBRCxFQUF5QjtBQUFBLFFBQWRtVixPQUFjLHVFQUFKLEVBQUk7O0FBQzlCLFNBQUtWLFdBQUwsQ0FBaUJ4USxNQUFqQixDQUF3Qiw2Q0FBeEI7O0FBQ0EsU0FBSzRILE1BQUwsQ0FBWTJFLE9BQVosQ0FBb0J4USxRQUFwQixFQUE4Qm1WLE9BQTlCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUMsTUFBSSxHQUFHO0FBQ0wsV0FBTyxLQUFLQyxHQUFMLENBQVVuUCxJQUFELElBQVU7QUFDeEIsYUFBTyxJQUFJa04sVUFBSixDQUFlbE4sSUFBZixFQUFxQixLQUFLdU8sV0FBMUIsQ0FBUDtBQUNELEtBRk0sQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVksS0FBRyxDQUFDclYsUUFBRCxFQUF5QjtBQUFBLFFBQWRtVixPQUFjLHVFQUFKLEVBQUk7O0FBQzFCLFNBQUtWLFdBQUwsQ0FBaUJ4USxNQUFqQixDQUF3Qix5Q0FBeEI7O0FBQ0EsV0FBTyxLQUFLNEgsTUFBTCxDQUFZd0osR0FBWixDQUFnQnJWLFFBQWhCLEVBQTBCbVYsT0FBMUIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFRyxTQUFPLEdBQUc7QUFDUixTQUFLYixXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsNkNBQXhCOztBQUNBLFFBQUksS0FBSzRRLFFBQUwsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsV0FBS0EsUUFBTCxHQUFnQixDQUFoQjtBQUNEOztBQUNELFdBQU8sS0FBS25FLEtBQUwsR0FBYSxLQUFLbUUsUUFBbEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXpQLFNBQU8sQ0FBQ21RLFNBQUQsRUFBWTtBQUNqQixTQUFLZCxXQUFMLENBQWlCeFEsTUFBakIsQ0FBd0IsNkNBQXhCOztBQUNBLFdBQU8sS0FBSzRILE1BQUwsQ0FBWXpHLE9BQVosQ0FBb0JtUSxTQUFwQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxnQkFBYyxDQUFDRCxTQUFELEVBQVk7QUFDeEIsU0FBS2QsV0FBTCxDQUFpQnhRLE1BQWpCLENBQXdCLG9EQUF4Qjs7QUFDQSxXQUFPLEtBQUs0SCxNQUFMLENBQVkySixjQUFaLENBQTJCRCxTQUEzQixDQUFQO0FBQ0Q7O0FBdk5zQixDOzs7Ozs7Ozs7OztBQ3RHekJoWCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDYyxjQUFZLEVBQUMsTUFBSUEsWUFBbEI7QUFBK0JDLGtCQUFnQixFQUFDLE1BQUlBLGdCQUFwRDtBQUFxRTJULGNBQVksRUFBQyxNQUFJQSxZQUF0RjtBQUFtRzFULFNBQU8sRUFBQyxNQUFJQTtBQUEvRyxDQUFkO0FBQXVJLElBQUlMLEtBQUo7QUFBVVosTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFakosTUFBTVksT0FBTyxHQUFHO0FBQ2RpVyxhQUFXLENBQUNDLEdBQUQsRUFBTTtBQUNmLFdBQU9BLEdBQUcsS0FBSyxLQUFLLENBQXBCO0FBQ0QsR0FIYTs7QUFJZHhTLFVBQVEsQ0FBQ3dTLEdBQUQsRUFBTTtBQUNaLFFBQUksS0FBS0MsT0FBTCxDQUFhRCxHQUFiLEtBQXFCLEtBQUszUyxVQUFMLENBQWdCMlMsR0FBaEIsQ0FBekIsRUFBK0M7QUFDN0MsYUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsV0FBT0EsR0FBRyxLQUFLalIsTUFBTSxDQUFDaVIsR0FBRCxDQUFyQjtBQUNELEdBVGE7O0FBVWRDLFNBQU8sQ0FBQ0QsR0FBRCxFQUFNO0FBQ1gsV0FBT0UsS0FBSyxDQUFDRCxPQUFOLENBQWNELEdBQWQsQ0FBUDtBQUNELEdBWmE7O0FBYWRyVCxXQUFTLENBQUNxVCxHQUFELEVBQU07QUFDYixXQUFPQSxHQUFHLEtBQUssSUFBUixJQUFnQkEsR0FBRyxLQUFLLEtBQXhCLElBQWlDalIsTUFBTSxDQUFDb1IsU0FBUCxDQUFpQjNNLFFBQWpCLENBQTBCcEMsSUFBMUIsQ0FBK0I0TyxHQUEvQixNQUF3QyxrQkFBaEY7QUFDRCxHQWZhOztBQWdCZDNTLFlBQVUsQ0FBQzJTLEdBQUQsRUFBTTtBQUNkLFdBQU8sT0FBT0EsR0FBUCxLQUFlLFVBQWYsSUFBNkIsS0FBcEM7QUFDRCxHQWxCYTs7QUFtQmRJLFNBQU8sQ0FBQ0osR0FBRCxFQUFNO0FBQ1gsUUFBSSxLQUFLSyxNQUFMLENBQVlMLEdBQVosQ0FBSixFQUFzQjtBQUNwQixhQUFPLEtBQVA7QUFDRDs7QUFDRCxRQUFJLEtBQUt4UyxRQUFMLENBQWN3UyxHQUFkLENBQUosRUFBd0I7QUFDdEIsYUFBTyxDQUFDalIsTUFBTSxDQUFDcUcsSUFBUCxDQUFZNEssR0FBWixFQUFpQnJPLE1BQXpCO0FBQ0Q7O0FBQ0QsUUFBSSxLQUFLc08sT0FBTCxDQUFhRCxHQUFiLEtBQXFCLEtBQUtsVCxRQUFMLENBQWNrVCxHQUFkLENBQXpCLEVBQTZDO0FBQzNDLGFBQU8sQ0FBQ0EsR0FBRyxDQUFDck8sTUFBWjtBQUNEOztBQUNELFdBQU8sS0FBUDtBQUNELEdBOUJhOztBQStCZGdELE9BQUssQ0FBQ3FMLEdBQUQsRUFBTTtBQUNULFFBQUksQ0FBQyxLQUFLeFMsUUFBTCxDQUFjd1MsR0FBZCxDQUFMLEVBQXlCLE9BQU9BLEdBQVA7QUFDekIsV0FBTyxLQUFLQyxPQUFMLENBQWFELEdBQWIsSUFBb0JBLEdBQUcsQ0FBQ3hILEtBQUosRUFBcEIsR0FBa0N6SixNQUFNLENBQUNzQyxNQUFQLENBQWMsRUFBZCxFQUFrQjJPLEdBQWxCLENBQXpDO0FBQ0QsR0FsQ2E7O0FBbUNkbkgsS0FBRyxDQUFDeUgsSUFBRCxFQUFPbFEsSUFBUCxFQUFhO0FBQ2QsUUFBSTRQLEdBQUcsR0FBR00sSUFBVjs7QUFDQSxRQUFJLENBQUMsS0FBSzlTLFFBQUwsQ0FBY3dTLEdBQWQsQ0FBTCxFQUF5QjtBQUN2QixhQUFPLEtBQVA7QUFDRDs7QUFDRCxRQUFJLENBQUMsS0FBS0MsT0FBTCxDQUFhN1AsSUFBYixDQUFMLEVBQXlCO0FBQ3ZCLGFBQU8sS0FBSzVDLFFBQUwsQ0FBY3dTLEdBQWQsS0FBc0JqUixNQUFNLENBQUNvUixTQUFQLENBQWlCSSxjQUFqQixDQUFnQ25QLElBQWhDLENBQXFDNE8sR0FBckMsRUFBMEM1UCxJQUExQyxDQUE3QjtBQUNEOztBQUVELFVBQU11QixNQUFNLEdBQUd2QixJQUFJLENBQUN1QixNQUFwQjs7QUFDQSxTQUFLLElBQUk2TyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHN08sTUFBcEIsRUFBNEI2TyxDQUFDLEVBQTdCLEVBQWlDO0FBQy9CLFVBQUksQ0FBQ3pSLE1BQU0sQ0FBQ29SLFNBQVAsQ0FBaUJJLGNBQWpCLENBQWdDblAsSUFBaEMsQ0FBcUM0TyxHQUFyQyxFQUEwQzVQLElBQUksQ0FBQ29RLENBQUQsQ0FBOUMsQ0FBTCxFQUF5RDtBQUN2RCxlQUFPLEtBQVA7QUFDRDs7QUFDRFIsU0FBRyxHQUFHQSxHQUFHLENBQUM1UCxJQUFJLENBQUNvUSxDQUFELENBQUwsQ0FBVDtBQUNEOztBQUNELFdBQU8sQ0FBQyxDQUFDN08sTUFBVDtBQUNELEdBcERhOztBQXFEZG9ELE1BQUksQ0FBQ2lMLEdBQUQsRUFBZTtBQUNqQixVQUFNUyxLQUFLLEdBQUcxUixNQUFNLENBQUNzQyxNQUFQLENBQWMsRUFBZCxFQUFrQjJPLEdBQWxCLENBQWQ7O0FBRGlCLHNDQUFONUssSUFBTTtBQUFOQSxVQUFNO0FBQUE7O0FBRWpCLFNBQUssSUFBSW9MLENBQUMsR0FBR3BMLElBQUksQ0FBQ3pELE1BQUwsR0FBYyxDQUEzQixFQUE4QjZPLENBQUMsSUFBSSxDQUFuQyxFQUFzQ0EsQ0FBQyxFQUF2QyxFQUEyQztBQUN6QyxhQUFPQyxLQUFLLENBQUNyTCxJQUFJLENBQUNvTCxDQUFELENBQUwsQ0FBWjtBQUNEOztBQUVELFdBQU9DLEtBQVA7QUFDRCxHQTVEYTs7QUE2RGRDLEtBQUcsRUFBRTlMLElBQUksQ0FBQzhMLEdBN0RJOztBQThEZEMsVUFBUSxDQUFDQyxJQUFELEVBQU8zRyxJQUFQLEVBQTJCO0FBQUEsUUFBZHVFLE9BQWMsdUVBQUosRUFBSTtBQUNqQyxRQUFJYyxRQUFRLEdBQUcsQ0FBZjtBQUNBLFFBQUl1QixPQUFPLEdBQUcsSUFBZDtBQUNBLFFBQUk5UCxNQUFKO0FBQ0EsVUFBTStQLElBQUksR0FBRyxJQUFiO0FBQ0EsUUFBSXBVLElBQUo7QUFDQSxRQUFJcVUsSUFBSjs7QUFFQSxVQUFNQyxLQUFLLEdBQUcsTUFBTTtBQUNsQjFCLGNBQVEsR0FBR2QsT0FBTyxDQUFDeUMsT0FBUixLQUFvQixLQUFwQixHQUE0QixDQUE1QixHQUFnQ0gsSUFBSSxDQUFDSixHQUFMLEVBQTNDO0FBQ0FHLGFBQU8sR0FBRyxJQUFWO0FBQ0E5UCxZQUFNLEdBQUc2UCxJQUFJLENBQUN4UyxLQUFMLENBQVcxQixJQUFYLEVBQWlCcVUsSUFBakIsQ0FBVDs7QUFDQSxVQUFJLENBQUNGLE9BQUwsRUFBYztBQUNablUsWUFBSSxHQUFHcVUsSUFBSSxHQUFHLElBQWQ7QUFDRDtBQUNGLEtBUEQ7O0FBU0EsVUFBTUcsU0FBUyxHQUFHLFlBQVk7QUFDNUIsWUFBTVIsR0FBRyxHQUFHSSxJQUFJLENBQUNKLEdBQUwsRUFBWjtBQUNBLFVBQUksQ0FBQ3BCLFFBQUQsSUFBYWQsT0FBTyxDQUFDeUMsT0FBUixLQUFvQixLQUFyQyxFQUE0QzNCLFFBQVEsR0FBR29CLEdBQVg7QUFDNUMsWUFBTVMsU0FBUyxHQUFHbEgsSUFBSSxJQUFJeUcsR0FBRyxHQUFHcEIsUUFBVixDQUF0QjtBQUNBNVMsVUFBSSxHQUFHLElBQVA7QUFDQXFVLFVBQUksR0FBRzFTLFNBQVA7O0FBQ0EsVUFBSThTLFNBQVMsSUFBSSxDQUFiLElBQWtCQSxTQUFTLEdBQUdsSCxJQUFsQyxFQUF3QztBQUN0QyxZQUFJNEcsT0FBSixFQUFhO0FBQ1hPLHNCQUFZLENBQUNQLE9BQUQsQ0FBWjtBQUNBQSxpQkFBTyxHQUFHLElBQVY7QUFDRDs7QUFDRHZCLGdCQUFRLEdBQUdvQixHQUFYO0FBQ0EzUCxjQUFNLEdBQUc2UCxJQUFJLENBQUN4UyxLQUFMLENBQVcxQixJQUFYLEVBQWlCcVUsSUFBakIsQ0FBVDs7QUFDQSxZQUFJLENBQUNGLE9BQUwsRUFBYztBQUNablUsY0FBSSxHQUFHcVUsSUFBSSxHQUFHLElBQWQ7QUFDRDtBQUNGLE9BVkQsTUFVTyxJQUFJLENBQUNGLE9BQUQsSUFBWXJDLE9BQU8sQ0FBQzZDLFFBQVIsS0FBcUIsS0FBckMsRUFBNEM7QUFDakRSLGVBQU8sR0FBRzFMLFVBQVUsQ0FBQzZMLEtBQUQsRUFBUUcsU0FBUixDQUFwQjtBQUNEOztBQUNELGFBQU9wUSxNQUFQO0FBQ0QsS0FwQkQ7O0FBc0JBbVEsYUFBUyxDQUFDSSxNQUFWLEdBQW1CLE1BQU07QUFDdkJGLGtCQUFZLENBQUNQLE9BQUQsQ0FBWjtBQUNBdkIsY0FBUSxHQUFHLENBQVg7QUFDQXVCLGFBQU8sR0FBR25VLElBQUksR0FBR3FVLElBQUksR0FBRyxJQUF4QjtBQUNELEtBSkQ7O0FBTUEsV0FBT0csU0FBUDtBQUNEOztBQTVHYSxDQUFoQjtBQStHQSxNQUFNSyxRQUFRLEdBQUcsQ0FBQyxRQUFELEVBQVcsUUFBWCxFQUFxQixNQUFyQixDQUFqQjs7QUFDQSxLQUFLLElBQUlmLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdlLFFBQVEsQ0FBQzVQLE1BQTdCLEVBQXFDNk8sQ0FBQyxFQUF0QyxFQUEwQztBQUN4QzFXLFNBQU8sQ0FBQyxPQUFPeVgsUUFBUSxDQUFDZixDQUFELENBQWhCLENBQVAsR0FBOEIsVUFBVVIsR0FBVixFQUFlO0FBQzNDLFdBQU9qUixNQUFNLENBQUNvUixTQUFQLENBQWlCM00sUUFBakIsQ0FBMEJwQyxJQUExQixDQUErQjRPLEdBQS9CLE1BQXdDLGFBQWF1QixRQUFRLENBQUNmLENBQUQsQ0FBckIsR0FBMkIsR0FBMUU7QUFDRCxHQUZEO0FBR0Q7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLE1BQU01VyxZQUFZLEdBQUcsVUFBU29XLEdBQVQsRUFBYztBQUNqQyxPQUFLLElBQUluRCxHQUFULElBQWdCbUQsR0FBaEIsRUFBcUI7QUFDbkIsUUFBSWxXLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUJrVCxHQUFHLENBQUNuRCxHQUFELENBQXBCLEtBQThCbUQsR0FBRyxDQUFDbkQsR0FBRCxDQUFILENBQVMvSixRQUFULENBQWtCLGlCQUFsQixDQUFsQyxFQUF3RTtBQUN0RWtOLFNBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxHQUFXbUQsR0FBRyxDQUFDbkQsR0FBRCxDQUFILENBQVN6UCxPQUFULENBQWlCLGlCQUFqQixFQUFvQyxFQUFwQyxDQUFYO0FBQ0E0UyxTQUFHLENBQUNuRCxHQUFELENBQUgsR0FBVyxJQUFJakksSUFBSixDQUFTckgsUUFBUSxDQUFDeVMsR0FBRyxDQUFDbkQsR0FBRCxDQUFKLENBQWpCLENBQVg7QUFDRCxLQUhELE1BR08sSUFBSS9TLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJ3UyxHQUFHLENBQUNuRCxHQUFELENBQXBCLENBQUosRUFBZ0M7QUFDckNtRCxTQUFHLENBQUNuRCxHQUFELENBQUgsR0FBV2pULFlBQVksQ0FBQ29XLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSixDQUF2QjtBQUNELEtBRk0sTUFFQSxJQUFJL1MsT0FBTyxDQUFDbVcsT0FBUixDQUFnQkQsR0FBRyxDQUFDbkQsR0FBRCxDQUFuQixDQUFKLEVBQStCO0FBQ3BDLFVBQUkzVCxDQUFKOztBQUNBLFdBQUssSUFBSXNYLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdSLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTbEwsTUFBN0IsRUFBcUM2TyxDQUFDLEVBQXRDLEVBQTBDO0FBQ3hDdFgsU0FBQyxHQUFHOFcsR0FBRyxDQUFDbkQsR0FBRCxDQUFILENBQVMyRCxDQUFULENBQUo7O0FBQ0EsWUFBSTFXLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJ0RSxDQUFqQixDQUFKLEVBQXlCO0FBQ3ZCOFcsYUFBRyxDQUFDbkQsR0FBRCxDQUFILENBQVMyRCxDQUFULElBQWM1VyxZQUFZLENBQUNWLENBQUQsQ0FBMUI7QUFDRCxTQUZELE1BRU8sSUFBSVksT0FBTyxDQUFDZ0QsUUFBUixDQUFpQjVELENBQWpCLEtBQXVCQSxDQUFDLENBQUM0SixRQUFGLENBQVcsaUJBQVgsQ0FBM0IsRUFBMEQ7QUFDL0Q1SixXQUFDLEdBQUdBLENBQUMsQ0FBQ2tFLE9BQUYsQ0FBVSxpQkFBVixFQUE2QixFQUE3QixDQUFKO0FBQ0E0UyxhQUFHLENBQUNuRCxHQUFELENBQUgsQ0FBUzJELENBQVQsSUFBYyxJQUFJNUwsSUFBSixDQUFTckgsUUFBUSxDQUFDckUsQ0FBRCxDQUFqQixDQUFkO0FBQ0Q7QUFDRjtBQUNGO0FBQ0Y7O0FBQ0QsU0FBTzhXLEdBQVA7QUFDRCxDQXJCRDtBQXVCQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU1uVyxnQkFBZ0IsR0FBRyxVQUFTbVcsR0FBVCxFQUFjO0FBQ3JDLE9BQUssSUFBSW5ELEdBQVQsSUFBZ0JtRCxHQUFoQixFQUFxQjtBQUNuQixRQUFJbFcsT0FBTyxDQUFDdVcsTUFBUixDQUFlTCxHQUFHLENBQUNuRCxHQUFELENBQWxCLENBQUosRUFBOEI7QUFDNUJtRCxTQUFHLENBQUNuRCxHQUFELENBQUgsNEJBQTZCLENBQUNtRCxHQUFHLENBQUNuRCxHQUFELENBQWpDO0FBQ0QsS0FGRCxNQUVPLElBQUkvUyxPQUFPLENBQUMwRCxRQUFSLENBQWlCd1MsR0FBRyxDQUFDbkQsR0FBRCxDQUFwQixDQUFKLEVBQWdDO0FBQ3JDbUQsU0FBRyxDQUFDbkQsR0FBRCxDQUFILEdBQVdoVCxnQkFBZ0IsQ0FBQ21XLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSixDQUEzQjtBQUNELEtBRk0sTUFFQSxJQUFJL1MsT0FBTyxDQUFDbVcsT0FBUixDQUFnQkQsR0FBRyxDQUFDbkQsR0FBRCxDQUFuQixDQUFKLEVBQStCO0FBQ3BDLFVBQUkzVCxDQUFKOztBQUNBLFdBQUssSUFBSXNYLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdSLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTbEwsTUFBN0IsRUFBcUM2TyxDQUFDLEVBQXRDLEVBQTBDO0FBQ3hDdFgsU0FBQyxHQUFHOFcsR0FBRyxDQUFDbkQsR0FBRCxDQUFILENBQVMyRCxDQUFULENBQUo7O0FBQ0EsWUFBSTFXLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJ0RSxDQUFqQixDQUFKLEVBQXlCO0FBQ3ZCOFcsYUFBRyxDQUFDbkQsR0FBRCxDQUFILENBQVMyRCxDQUFULElBQWMzVyxnQkFBZ0IsQ0FBQ1gsQ0FBRCxDQUE5QjtBQUNELFNBRkQsTUFFTyxJQUFJWSxPQUFPLENBQUN1VyxNQUFSLENBQWVuWCxDQUFmLENBQUosRUFBdUI7QUFDNUI4VyxhQUFHLENBQUNuRCxHQUFELENBQUgsQ0FBUzJELENBQVQsNkJBQWdDLENBQUN0WCxDQUFqQztBQUNEO0FBQ0Y7QUFDRjtBQUNGOztBQUNELFNBQU84VyxHQUFQO0FBQ0QsQ0FuQkQ7QUFxQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU14QyxZQUFZLEdBQUcsVUFBQzdQLE9BQUQsRUFBMEY7QUFBQSxNQUFoRmlJLE9BQWdGLHVFQUF0RSxVQUFzRTs7QUFBQSxNQUExRDRMLFFBQTBELHVFQUEvQyxDQUFDQyx5QkFBeUIsSUFBSSxFQUE5QixFQUFrQ0MsUUFBYTs7QUFDN0dqWSxPQUFLLENBQUNrRSxPQUFELEVBQVVvQixNQUFWLENBQUw7QUFDQXRGLE9BQUssQ0FBQ21NLE9BQUQsRUFBVTFJLE1BQVYsQ0FBTDtBQUNBLE1BQUl1UixPQUFPLEdBQUcrQyxRQUFkOztBQUVBLE1BQUksQ0FBQzFYLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIyUixPQUFqQixDQUFMLEVBQWdDO0FBQzlCQSxXQUFPLEdBQUcsQ0FBQ2dELHlCQUF5QixJQUFJLEVBQTlCLEVBQWtDQyxRQUFsQyxJQUE4QyxHQUF4RDtBQUNEOztBQUVELFFBQU1DLEtBQUssR0FBR2xELE9BQU8sQ0FBQ3JSLE9BQVIsQ0FBZ0IsTUFBaEIsRUFBd0IsRUFBeEIsQ0FBZDs7QUFDQSxRQUFNcU8sSUFBSSxHQUFJOU4sT0FBTyxDQUFDME0sUUFBUixJQUFvQjFNLE9BQU8sQ0FBQzBNLFFBQVIsQ0FBaUJ6RSxPQUFqQixDQUFyQixJQUFtRGpJLE9BQW5ELElBQThELEVBQTNFO0FBRUEsTUFBSXdKLEdBQUo7O0FBQ0EsTUFBSXJOLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIyTyxJQUFJLENBQUN6RSxTQUF0QixDQUFKLEVBQXNDO0FBQ3BDRyxPQUFHLGNBQU9zRSxJQUFJLENBQUN6RSxTQUFMLENBQWU1SixPQUFmLENBQXVCLEtBQXZCLEVBQThCLEVBQTlCLENBQVAsQ0FBSDtBQUNELEdBRkQsTUFFTztBQUNMK0osT0FBRyxHQUFHLEVBQU47QUFDRDs7QUFFRCxNQUFJeEosT0FBTyxDQUFDOUMsTUFBUixLQUFtQixJQUF2QixFQUE2QjtBQUMzQixXQUFPOFcsS0FBSyxJQUFJL0wsT0FBTyxLQUFLLFVBQVosYUFBNEJqSSxPQUFPLENBQUMyUSxjQUFwQyxjQUFzRDNRLE9BQU8sQ0FBQzZCLEdBQTlELFNBQW9FMkgsR0FBcEUsY0FBK0V4SixPQUFPLENBQUMyUSxjQUF2RixjQUF5RzFJLE9BQXpHLGNBQW9IakksT0FBTyxDQUFDNkIsR0FBNUgsU0FBa0kySCxHQUFsSSxDQUFKLENBQVo7QUFDRDs7QUFDRCxTQUFPd0ssS0FBSyxhQUFNaFUsT0FBTyxDQUFDMlEsY0FBZCxjQUFnQzNRLE9BQU8sQ0FBQzRRLGVBQXhDLGNBQTJENVEsT0FBTyxDQUFDNkIsR0FBbkUsY0FBMEVvRyxPQUExRSxjQUFxRmpJLE9BQU8sQ0FBQzZCLEdBQTdGLFNBQW1HMkgsR0FBbkcsQ0FBWjtBQUNELENBdkJELEM7Ozs7Ozs7Ozs7O0FDcExBdE8sTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ1UsU0FBTyxFQUFDLE1BQUlEO0FBQWIsQ0FBZDtBQUF5QyxJQUFJUSxFQUFKO0FBQU9sQixNQUFNLENBQUNJLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNPLFNBQU8sQ0FBQ04sQ0FBRCxFQUFHO0FBQUNhLE1BQUUsR0FBQ2IsQ0FBSDtBQUFLOztBQUFqQixDQUF2QixFQUEwQyxDQUExQztBQUE2QyxJQUFJRSxNQUFKO0FBQVdQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0csUUFBTSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsVUFBTSxHQUFDRixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlZLE9BQUo7QUFBWWpCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ2EsU0FBTyxDQUFDWixDQUFELEVBQUc7QUFBQ1ksV0FBTyxHQUFDWixDQUFSO0FBQVU7O0FBQXRCLENBQXZCLEVBQStDLENBQS9DOztBQUd6SyxNQUFNcUIsSUFBSSxHQUFHLE1BQU0sQ0FBRSxDQUFyQjtBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNSCxLQUFLLEdBQUtoQixNQUFNLENBQUNpQixlQUFQLENBQXVCQyxRQUFRLElBQUlBLFFBQVEsRUFBM0MsQ0FBaEI7QUFDQSxNQUFNc1gsT0FBTyxHQUFHLEVBQWhCO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ2UsTUFBTXJZLFdBQU4sQ0FBa0I7QUFDL0JpQixhQUFXLENBQUM0RixJQUFELEVBQU95RSxTQUFQLEVBQWtCckUsSUFBbEIsRUFBd0J0RixXQUF4QixFQUFxQztBQUM5QyxTQUFLa0YsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS3lFLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EsU0FBS3JFLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUt0RixXQUFMLEdBQW1CQSxXQUFuQjs7QUFDQSxRQUFJLENBQUMsS0FBS2tGLElBQU4sSUFBYyxDQUFDdEcsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLc0QsSUFBdEIsQ0FBbkIsRUFBZ0Q7QUFDOUM7QUFDRDs7QUFFRCxTQUFLK0gsRUFBTCxHQUFxQixJQUFyQjtBQUNBLFNBQUswSixhQUFMLEdBQXFCLENBQXJCO0FBQ0EsU0FBS25SLEtBQUwsR0FBcUIsS0FBckI7QUFDQSxTQUFLRCxPQUFMLEdBQXFCLEtBQXJCOztBQUVBLFFBQUltUixPQUFPLENBQUMsS0FBS3hSLElBQU4sQ0FBUCxJQUFzQixDQUFDd1IsT0FBTyxDQUFDLEtBQUt4UixJQUFOLENBQVAsQ0FBbUJNLEtBQTFDLElBQW1ELENBQUNrUixPQUFPLENBQUMsS0FBS3hSLElBQU4sQ0FBUCxDQUFtQkssT0FBM0UsRUFBb0Y7QUFDbEYsV0FBSzBILEVBQUwsR0FBVXlKLE9BQU8sQ0FBQyxLQUFLeFIsSUFBTixDQUFQLENBQW1CK0gsRUFBN0I7QUFDQSxXQUFLMEosYUFBTCxHQUFxQkQsT0FBTyxDQUFDLEtBQUt4UixJQUFOLENBQVAsQ0FBbUJ5UixhQUF4QztBQUNELEtBSEQsTUFHTztBQUNMOVgsUUFBRSxDQUFDdVAsVUFBSCxDQUFjLEtBQUtsSixJQUFuQixFQUEwQm1KLE9BQUQsSUFBYTtBQUNwQ25QLGFBQUssQ0FBQyxNQUFNO0FBQ1YsY0FBSW1QLE9BQUosRUFBYTtBQUNYLGlCQUFLckosS0FBTDtBQUNBLGtCQUFNLElBQUk5RyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDJEQUEyRG9NLE9BQWpGLENBQU47QUFDRCxXQUhELE1BR087QUFDTHhQLGNBQUUsQ0FBQytYLElBQUgsQ0FBUSxLQUFLMVIsSUFBYixFQUFtQixJQUFuQixFQUF5QixLQUFLbEYsV0FBOUIsRUFBMkMsQ0FBQzZXLE1BQUQsRUFBUzVKLEVBQVQsS0FBZ0I7QUFDekQvTixtQkFBSyxDQUFDLE1BQU07QUFDVixvQkFBSTJYLE1BQUosRUFBWTtBQUNWLHVCQUFLN1IsS0FBTDtBQUNBLHdCQUFNLElBQUk5RyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGtFQUFrRTRVLE1BQXhGLENBQU47QUFDRCxpQkFIRCxNQUdPO0FBQ0wsdUJBQUs1SixFQUFMLEdBQVVBLEVBQVY7QUFDQXlKLHlCQUFPLENBQUMsS0FBS3hSLElBQU4sQ0FBUCxHQUFxQixJQUFyQjtBQUNEO0FBQ0YsZUFSSSxDQUFMO0FBU0QsYUFWRDtBQVdEO0FBQ0YsU0FqQkksQ0FBTDtBQWtCRCxPQW5CRDtBQW9CRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTBILE9BQUssQ0FBQ2tLLEdBQUQsRUFBTUMsS0FBTixFQUFhM1gsUUFBYixFQUF1QjtBQUMxQixRQUFJLENBQUMsS0FBS21HLE9BQU4sSUFBaUIsQ0FBQyxLQUFLQyxLQUEzQixFQUFrQztBQUNoQyxVQUFJLEtBQUt5SCxFQUFULEVBQWE7QUFDWHBPLFVBQUUsQ0FBQytOLEtBQUgsQ0FBUyxLQUFLSyxFQUFkLEVBQWtCOEosS0FBbEIsRUFBeUIsQ0FBekIsRUFBNEJBLEtBQUssQ0FBQ3RRLE1BQWxDLEVBQTBDLENBQUNxUSxHQUFHLEdBQUcsQ0FBUCxJQUFZLEtBQUt4UixJQUFMLENBQVV6RixTQUFoRSxFQUEyRSxDQUFDMkQsS0FBRCxFQUFRd1QsT0FBUixFQUFpQmpKLE1BQWpCLEtBQTRCO0FBQ3JHN08sZUFBSyxDQUFDLE1BQU07QUFDVkUsb0JBQVEsSUFBSUEsUUFBUSxDQUFDb0UsS0FBRCxFQUFRd1QsT0FBUixFQUFpQmpKLE1BQWpCLENBQXBCOztBQUNBLGdCQUFJdkssS0FBSixFQUFXO0FBQ1QyRSxxQkFBTyxDQUFDQyxJQUFSLENBQWEsa0RBQWIsRUFBaUU1RSxLQUFqRTtBQUNBLG1CQUFLd0IsS0FBTDtBQUNELGFBSEQsTUFHTztBQUNMLGdCQUFFLEtBQUsyUixhQUFQO0FBQ0Q7QUFDRixXQVJJLENBQUw7QUFTRCxTQVZEO0FBV0QsT0FaRCxNQVlPO0FBQ0x6WSxjQUFNLENBQUMrTCxVQUFQLENBQWtCLE1BQU07QUFDdEIsZUFBSzJDLEtBQUwsQ0FBV2tLLEdBQVgsRUFBZ0JDLEtBQWhCLEVBQXVCM1gsUUFBdkI7QUFDRCxTQUZELEVBRUcsRUFGSDtBQUdEO0FBQ0Y7O0FBQ0QsV0FBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UwRixLQUFHLENBQUMxRixRQUFELEVBQVc7QUFDWixRQUFJLENBQUMsS0FBS21HLE9BQU4sSUFBaUIsQ0FBQyxLQUFLQyxLQUEzQixFQUFrQztBQUNoQyxVQUFJLEtBQUttUixhQUFMLEtBQXVCLEtBQUtoTixTQUFoQyxFQUEyQztBQUN6QzlLLFVBQUUsQ0FBQ3dPLEtBQUgsQ0FBUyxLQUFLSixFQUFkLEVBQWtCLE1BQU07QUFDdEIvTixlQUFLLENBQUMsTUFBTTtBQUNWLG1CQUFPd1gsT0FBTyxDQUFDLEtBQUt4UixJQUFOLENBQWQ7QUFDQSxpQkFBS00sS0FBTCxHQUFhLElBQWI7QUFDQXBHLG9CQUFRLElBQUlBLFFBQVEsQ0FBQyxLQUFLLENBQU4sRUFBUyxJQUFULENBQXBCO0FBQ0QsV0FKSSxDQUFMO0FBS0QsU0FORDtBQU9BLGVBQU8sSUFBUDtBQUNEOztBQUVEUCxRQUFFLENBQUNvUSxJQUFILENBQVEsS0FBSy9KLElBQWIsRUFBbUIsQ0FBQzFCLEtBQUQsRUFBUXlMLElBQVIsS0FBaUI7QUFDbEMvUCxhQUFLLENBQUMsTUFBTTtBQUNWLGNBQUksQ0FBQ3NFLEtBQUQsSUFBVXlMLElBQWQsRUFBb0I7QUFDbEIsaUJBQUswSCxhQUFMLEdBQXFCalYsSUFBSSxDQUFDdVYsSUFBTCxDQUFVaEksSUFBSSxDQUFDcE0sSUFBTCxHQUFZLEtBQUt5QyxJQUFMLENBQVV6RixTQUFoQyxDQUFyQjtBQUNEOztBQUVELGlCQUFPM0IsTUFBTSxDQUFDK0wsVUFBUCxDQUFrQixNQUFNO0FBQzdCLGlCQUFLbkYsR0FBTCxDQUFTMUYsUUFBVDtBQUNELFdBRk0sRUFFSixFQUZJLENBQVA7QUFHRCxTQVJJLENBQUw7QUFTRCxPQVZEO0FBV0QsS0F2QkQsTUF1Qk87QUFDTEEsY0FBUSxJQUFJQSxRQUFRLENBQUMsS0FBSyxDQUFOLEVBQVMsS0FBS29HLEtBQWQsQ0FBcEI7QUFDRDs7QUFDRCxXQUFPLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVIsT0FBSyxDQUFDNUYsUUFBRCxFQUFXO0FBQ2QsU0FBS21HLE9BQUwsR0FBZSxJQUFmO0FBQ0EsV0FBT21SLE9BQU8sQ0FBQyxLQUFLeFIsSUFBTixDQUFkO0FBQ0FyRyxNQUFFLENBQUMyTSxNQUFILENBQVUsS0FBS3RHLElBQWYsRUFBc0I5RixRQUFRLElBQUlDLElBQWxDO0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFd0YsTUFBSSxHQUFHO0FBQ0wsU0FBS1UsT0FBTCxHQUFlLElBQWY7QUFDQSxXQUFPbVIsT0FBTyxDQUFDLEtBQUt4UixJQUFOLENBQWQ7QUFDQSxXQUFPLElBQVA7QUFDRDs7QUF2SThCLEMiLCJmaWxlIjoiL3BhY2thZ2VzL29zdHJpb19maWxlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gICAgICAgICAgIGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBXZWJBcHAgfSAgICAgICAgICBmcm9tICdtZXRlb3Ivd2ViYXBwJztcbmltcG9ydCB7IE1ldGVvciB9ICAgICAgICAgIGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUmFuZG9tIH0gICAgICAgICAgZnJvbSAnbWV0ZW9yL3JhbmRvbSc7XG5pbXBvcnQgeyBDb29raWVzIH0gICAgICAgICBmcm9tICdtZXRlb3Ivb3N0cmlvOmNvb2tpZXMnO1xuaW1wb3J0IFdyaXRlU3RyZWFtICAgICAgICAgZnJvbSAnLi93cml0ZS1zdHJlYW0uanMnO1xuaW1wb3J0IHsgY2hlY2ssIE1hdGNoIH0gICAgZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBGaWxlc0NvbGxlY3Rpb25Db3JlIGZyb20gJy4vY29yZS5qcyc7XG5pbXBvcnQgeyBmaXhKU09OUGFyc2UsIGZpeEpTT05TdHJpbmdpZnksIGhlbHBlcnMgfSBmcm9tICcuL2xpYi5qcyc7XG5cbmltcG9ydCBmcyAgICAgICBmcm9tICdmcy1leHRyYSc7XG5pbXBvcnQgbm9kZVFzICAgZnJvbSAncXVlcnlzdHJpbmcnO1xuaW1wb3J0IHJlcXVlc3QgIGZyb20gJ3JlcXVlc3QtbGliY3VybCc7XG5pbXBvcnQgZmlsZVR5cGUgZnJvbSAnZmlsZS10eXBlJztcbmltcG9ydCBub2RlUGF0aCBmcm9tICdwYXRoJztcblxuLypcbiAqIEBjb25zdCB7T2JqZWN0fSBib3VuZCAgLSBNZXRlb3IuYmluZEVudmlyb25tZW50IChGaWJlciB3cmFwcGVyKVxuICogQGNvbnN0IHtGdW5jdGlvbn0gTk9PUCAtIE5vIE9wZXJhdGlvbiBmdW5jdGlvbiwgcGxhY2Vob2xkZXIgZm9yIHJlcXVpcmVkIGNhbGxiYWNrc1xuICovXG5jb25zdCBib3VuZCA9IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoY2FsbGJhY2sgPT4gY2FsbGJhY2soKSk7XG5jb25zdCBOT09QICA9ICgpID0+IHsgIH07XG5cbi8qXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBjbGFzcyBGaWxlc0NvbGxlY3Rpb25cbiAqIEBwYXJhbSBjb25maWcgICAgICAgICAgIHtPYmplY3R9ICAgLSBbQm90aF0gICBDb25maWd1cmF0aW9uIG9iamVjdCB3aXRoIG5leHQgcHJvcGVydGllczpcbiAqIEBwYXJhbSBjb25maWcuZGVidWcgICAgIHtCb29sZWFufSAgLSBbQm90aF0gICBUdXJuIG9uL29mIGRlYnVnZ2luZyBhbmQgZXh0cmEgbG9nZ2luZ1xuICogQHBhcmFtIGNvbmZpZy5zY2hlbWEgICAge09iamVjdH0gICAtIFtCb3RoXSAgIENvbGxlY3Rpb24gU2NoZW1hXG4gKiBAcGFyYW0gY29uZmlnLnB1YmxpYyAgICB7Qm9vbGVhbn0gIC0gW0JvdGhdICAgU3RvcmUgZmlsZXMgaW4gZm9sZGVyIGFjY2Vzc2libGUgZm9yIHByb3h5IHNlcnZlcnMsIGZvciBsaW1pdHMsIGFuZCBtb3JlIC0gcmVhZCBkb2NzXG4gKiBAcGFyYW0gY29uZmlnLnN0cmljdCAgICB7Qm9vbGVhbn0gIC0gW1NlcnZlcl0gU3RyaWN0IG1vZGUgZm9yIHBhcnRpYWwgY29udGVudCwgaWYgaXMgYHRydWVgIHNlcnZlciB3aWxsIHJldHVybiBgNDE2YCByZXNwb25zZSBjb2RlLCB3aGVuIGByYW5nZWAgaXMgbm90IHNwZWNpZmllZCwgb3RoZXJ3aXNlIHNlcnZlciByZXR1cm4gYDIwNmBcbiAqIEBwYXJhbSBjb25maWcucHJvdGVjdGVkIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBJZiBgdHJ1ZWAgLSBmaWxlcyB3aWxsIGJlIHNlcnZlZCBvbmx5IHRvIGF1dGhvcml6ZWQgdXNlcnMsIGlmIGBmdW5jdGlvbigpYCAtIHlvdSdyZSBhYmxlIHRvIGNoZWNrIHZpc2l0b3IncyBwZXJtaXNzaW9ucyBpbiB5b3VyIG93biB3YXkgZnVuY3Rpb24ncyBjb250ZXh0IGhhczpcbiAqICAtIGByZXF1ZXN0YFxuICogIC0gYHJlc3BvbnNlYFxuICogIC0gYHVzZXIoKWBcbiAqICAtIGB1c2VySWRgXG4gKiBAcGFyYW0gY29uZmlnLmNodW5rU2l6ZSAgICAgIHtOdW1iZXJ9ICAtIFtCb3RoXSBVcGxvYWQgY2h1bmsgc2l6ZSwgZGVmYXVsdDogNTI0Mjg4IGJ5dGVzICgwLDUgTWIpXG4gKiBAcGFyYW0gY29uZmlnLnBlcm1pc3Npb25zICAgIHtOdW1iZXJ9ICAtIFtTZXJ2ZXJdIFBlcm1pc3Npb25zIHdoaWNoIHdpbGwgYmUgc2V0IHRvIHVwbG9hZGVkIGZpbGVzIChvY3RhbCksIGxpa2U6IGA1MTFgIG9yIGAwbzc1NWAuIERlZmF1bHQ6IDA2NDRcbiAqIEBwYXJhbSBjb25maWcucGFyZW50RGlyUGVybWlzc2lvbnMge051bWJlcn0gIC0gW1NlcnZlcl0gUGVybWlzc2lvbnMgd2hpY2ggd2lsbCBiZSBzZXQgdG8gcGFyZW50IGRpcmVjdG9yeSBvZiB1cGxvYWRlZCBmaWxlcyAob2N0YWwpLCBsaWtlOiBgNjExYCBvciBgMG83NzdgLiBEZWZhdWx0OiAwNzU1XG4gKiBAcGFyYW0gY29uZmlnLnN0b3JhZ2VQYXRoICAgIHtTdHJpbmd8RnVuY3Rpb259ICAtIFtTZXJ2ZXJdIFN0b3JhZ2UgcGF0aCBvbiBmaWxlIHN5c3RlbVxuICogQHBhcmFtIGNvbmZpZy5jYWNoZUNvbnRyb2wgICB7U3RyaW5nfSAgLSBbU2VydmVyXSBEZWZhdWx0IGBDYWNoZS1Db250cm9sYCBoZWFkZXJcbiAqIEBwYXJhbSBjb25maWcucmVzcG9uc2VIZWFkZXJzIHtPYmplY3R8RnVuY3Rpb259IC0gW1NlcnZlcl0gQ3VzdG9tIHJlc3BvbnNlIGhlYWRlcnMsIGlmIGZ1bmN0aW9uIGlzIHBhc3NlZCwgbXVzdCByZXR1cm4gT2JqZWN0XG4gKiBAcGFyYW0gY29uZmlnLnRocm90dGxlICAgICAgIHtOdW1iZXJ9ICAtIFtTZXJ2ZXJdIERFUFJFQ0FURUQgYnBzIHRocm90dGxlIHRocmVzaG9sZFxuICogQHBhcmFtIGNvbmZpZy5kb3dubG9hZFJvdXRlICB7U3RyaW5nfSAgLSBbQm90aF0gICBTZXJ2ZXIgUm91dGUgdXNlZCB0byByZXRyaWV2ZSBmaWxlc1xuICogQHBhcmFtIGNvbmZpZy5jb2xsZWN0aW9uICAgICB7TW9uZ28uQ29sbGVjdGlvbn0gLSBbQm90aF0gTW9uZ28gQ29sbGVjdGlvbiBJbnN0YW5jZVxuICogQHBhcmFtIGNvbmZpZy5jb2xsZWN0aW9uTmFtZSB7U3RyaW5nfSAgLSBbQm90aF0gICBDb2xsZWN0aW9uIG5hbWVcbiAqIEBwYXJhbSBjb25maWcubmFtaW5nRnVuY3Rpb24ge0Z1bmN0aW9ufS0gW0JvdGhdICAgRnVuY3Rpb24gd2hpY2ggcmV0dXJucyBgU3RyaW5nYFxuICogQHBhcmFtIGNvbmZpZy5pbnRlZ3JpdHlDaGVjayB7Qm9vbGVhbn0gLSBbU2VydmVyXSBDaGVjayBmaWxlJ3MgaW50ZWdyaXR5IGJlZm9yZSBzZXJ2aW5nIHRvIHVzZXJzXG4gKiBAcGFyYW0gY29uZmlnLm9uQWZ0ZXJVcGxvYWQgIHtGdW5jdGlvbn0tIFtTZXJ2ZXJdIENhbGxlZCByaWdodCBhZnRlciBmaWxlIGlzIHJlYWR5IG9uIEZTLiBVc2UgdG8gdHJhbnNmZXIgZmlsZSBzb21ld2hlcmUgZWxzZSwgb3IgZG8gb3RoZXIgdGhpbmcgd2l0aCBmaWxlIGRpcmVjdGx5XG4gKiBAcGFyYW0gY29uZmlnLm9uQWZ0ZXJSZW1vdmUgIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBDYWxsZWQgcmlnaHQgYWZ0ZXIgZmlsZSBpcyByZW1vdmVkLiBSZW1vdmVkIG9iamVjdHMgaXMgcGFzc2VkIHRvIGNhbGxiYWNrXG4gKiBAcGFyYW0gY29uZmlnLmNvbnRpbnVlVXBsb2FkVFRMIHtOdW1iZXJ9IC0gW1NlcnZlcl0gVGltZSBpbiBzZWNvbmRzLCBkdXJpbmcgdXBsb2FkIG1heSBiZSBjb250aW51ZWQsIGRlZmF1bHQgMyBob3VycyAoMTA4MDAgc2Vjb25kcylcbiAqIEBwYXJhbSBjb25maWcub25CZWZvcmVVcGxvYWQge0Z1bmN0aW9ufS0gW0JvdGhdICAgRnVuY3Rpb24gd2hpY2ggZXhlY3V0ZXMgb24gc2VydmVyIGFmdGVyIHJlY2VpdmluZyBlYWNoIGNodW5rIGFuZCBvbiBjbGllbnQgcmlnaHQgYmVmb3JlIGJlZ2lubmluZyB1cGxvYWQuIEZ1bmN0aW9uIGNvbnRleHQgaXMgYEZpbGVgIC0gc28geW91IGFyZSBhYmxlIHRvIGNoZWNrIGZvciBleHRlbnNpb24sIG1pbWUtdHlwZSwgc2l6ZSBhbmQgZXRjLjpcbiAqICAtIHJldHVybiBgdHJ1ZWAgdG8gY29udGludWVcbiAqICAtIHJldHVybiBgZmFsc2VgIG9yIGBTdHJpbmdgIHRvIGFib3J0IHVwbG9hZFxuICogQHBhcmFtIGNvbmZpZy5vbkluaXRpYXRlVXBsb2FkIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBGdW5jdGlvbiB3aGljaCBleGVjdXRlcyBvbiBzZXJ2ZXIgcmlnaHQgYmVmb3JlIHVwbG9hZCBpcyBiZWdpbiBhbmQgcmlnaHQgYWZ0ZXIgYG9uQmVmb3JlVXBsb2FkYCBob29rLiBUaGlzIGhvb2sgaXMgZnVsbHkgYXN5bmNocm9ub3VzLlxuICogQHBhcmFtIGNvbmZpZy5vbkJlZm9yZVJlbW92ZSB7RnVuY3Rpb259IC0gW1NlcnZlcl0gRXhlY3V0ZXMgYmVmb3JlIHJlbW92aW5nIGZpbGUgb24gc2VydmVyLCBzbyB5b3UgY2FuIGNoZWNrIHBlcm1pc3Npb25zLiBSZXR1cm4gYHRydWVgIHRvIGFsbG93IGFjdGlvbiBhbmQgYGZhbHNlYCB0byBkZW55LlxuICogQHBhcmFtIGNvbmZpZy5hbGxvd0NsaWVudENvZGUgIHtCb29sZWFufSAgLSBbQm90aF0gICBBbGxvdyB0byBydW4gYHJlbW92ZWAgZnJvbSBjbGllbnRcbiAqIEBwYXJhbSBjb25maWcuZG93bmxvYWRDYWxsYmFjayB7RnVuY3Rpb259IC0gW1NlcnZlcl0gQ2FsbGJhY2sgdHJpZ2dlcmVkIGVhY2ggdGltZSBmaWxlIGlzIHJlcXVlc3RlZCwgcmV0dXJuIHRydXRoeSB2YWx1ZSB0byBjb250aW51ZSBkb3dubG9hZCwgb3IgZmFsc3kgdG8gYWJvcnRcbiAgKiBAcGFyYW0gY29uZmlnLmludGVyY2VwdFJlcXVlc3Qge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIEludGVyY2VwdCBpbmNvbWluZyBIVFRQIHJlcXVlc3QsIHNvIHlvdSBjYW4gd2hhdGV2ZXIgeW91IHdhbnQsIG5vIGNoZWNrcyBvciBwcmVwcm9jZXNzaW5nLCBhcmd1bWVudHMge2h0dHA6IHtyZXF1ZXN0OiB7Li4ufSwgcmVzcG9uc2U6IHsuLi59fSwgcGFyYW1zOiB7Li4ufX1cbiAqIEBwYXJhbSBjb25maWcuaW50ZXJjZXB0RG93bmxvYWQge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIEludGVyY2VwdCBkb3dubG9hZCByZXF1ZXN0LCBzbyB5b3UgY2FuIHNlcnZlIGZpbGUgZnJvbSB0aGlyZC1wYXJ0eSByZXNvdXJjZSwgYXJndW1lbnRzIHtodHRwOiB7cmVxdWVzdDogey4uLn0sIHJlc3BvbnNlOiB7Li4ufX0sIGZpbGVSZWY6IHsuLi59fVxuICogQHBhcmFtIGNvbmZpZy5kaXNhYmxlVXBsb2FkIHtCb29sZWFufSAtIERpc2FibGUgZmlsZSB1cGxvYWQsIHVzZWZ1bCBmb3Igc2VydmVyIG9ubHkgc29sdXRpb25zXG4gKiBAcGFyYW0gY29uZmlnLmRpc2FibGVEb3dubG9hZCB7Qm9vbGVhbn0gLSBEaXNhYmxlIGZpbGUgZG93bmxvYWQgKHNlcnZpbmcpLCB1c2VmdWwgZm9yIGZpbGUgbWFuYWdlbWVudCBvbmx5IHNvbHV0aW9uc1xuICogQHBhcmFtIGNvbmZpZy5hbGxvd2VkT3JpZ2lucyAge1JlZ2V4fEJvb2xlYW59ICAtIFtTZXJ2ZXJdICAgUmVnZXggb2YgT3JpZ2lucyB0aGF0IGFyZSBhbGxvd2VkIENPUlMgYWNjZXNzIG9yIGBmYWxzZWAgdG8gZGlzYWJsZSBjb21wbGV0ZWx5LiBEZWZhdWx0cyB0byBgL15odHRwOlxcL1xcL2xvY2FsaG9zdDoxMlswLTldezN9JC9gIGZvciBhbGxvd2luZyBNZXRlb3ItQ29yZG92YSBidWlsZHMgYWNjZXNzXG4gKiBAcGFyYW0gY29uZmlnLmFsbG93UXVlcnlTdHJpbmdDb29raWVzIHtCb29sZWFufSAtIEFsbG93IHBhc3NpbmcgQ29va2llcyBpbiBhIHF1ZXJ5IHN0cmluZyAoaW4gVVJMKS4gUHJpbWFyeSBzaG91bGQgYmUgdXNlZCBvbmx5IGluIENvcmRvdmEgZW52aXJvbm1lbnQuIE5vdGU6IHRoaXMgb3B0aW9uIHdpbGwgYmUgdXNlZCBvbmx5IG9uIENvcmRvdmEuIERlZmF1bHQ6IGBmYWxzZWBcbiAqIEBwYXJhbSBjb25maWcuX3ByZUNvbGxlY3Rpb24gIHtNb25nby5Db2xsZWN0aW9ufSAtIFtTZXJ2ZXJdIE1vbmdvIHByZUNvbGxlY3Rpb24gSW5zdGFuY2VcbiAqIEBwYXJhbSBjb25maWcuX3ByZUNvbGxlY3Rpb25OYW1lIHtTdHJpbmd9ICAtIFtTZXJ2ZXJdICBwcmVDb2xsZWN0aW9uIG5hbWVcbiAqIEBzdW1tYXJ5IENyZWF0ZSBuZXcgaW5zdGFuY2Ugb2YgRmlsZXNDb2xsZWN0aW9uXG4gKi9cbmV4cG9ydCBjbGFzcyBGaWxlc0NvbGxlY3Rpb24gZXh0ZW5kcyBGaWxlc0NvbGxlY3Rpb25Db3JlIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKTtcbiAgICBsZXQgc3RvcmFnZVBhdGg7XG4gICAgaWYgKGNvbmZpZykge1xuICAgICAgKHtcbiAgICAgICAgc3RvcmFnZVBhdGgsXG4gICAgICAgIGRlYnVnOiB0aGlzLmRlYnVnLFxuICAgICAgICBzY2hlbWE6IHRoaXMuc2NoZW1hLFxuICAgICAgICBwdWJsaWM6IHRoaXMucHVibGljLFxuICAgICAgICBzdHJpY3Q6IHRoaXMuc3RyaWN0LFxuICAgICAgICBjaHVua1NpemU6IHRoaXMuY2h1bmtTaXplLFxuICAgICAgICBwcm90ZWN0ZWQ6IHRoaXMucHJvdGVjdGVkLFxuICAgICAgICBjb2xsZWN0aW9uOiB0aGlzLmNvbGxlY3Rpb24sXG4gICAgICAgIHBlcm1pc3Npb25zOiB0aGlzLnBlcm1pc3Npb25zLFxuICAgICAgICBjYWNoZUNvbnRyb2w6IHRoaXMuY2FjaGVDb250cm9sLFxuICAgICAgICBkb3dubG9hZFJvdXRlOiB0aGlzLmRvd25sb2FkUm91dGUsXG4gICAgICAgIG9uQWZ0ZXJVcGxvYWQ6IHRoaXMub25BZnRlclVwbG9hZCxcbiAgICAgICAgb25BZnRlclJlbW92ZTogdGhpcy5vbkFmdGVyUmVtb3ZlLFxuICAgICAgICBkaXNhYmxlVXBsb2FkOiB0aGlzLmRpc2FibGVVcGxvYWQsXG4gICAgICAgIG9uQmVmb3JlUmVtb3ZlOiB0aGlzLm9uQmVmb3JlUmVtb3ZlLFxuICAgICAgICBpbnRlZ3JpdHlDaGVjazogdGhpcy5pbnRlZ3JpdHlDaGVjayxcbiAgICAgICAgY29sbGVjdGlvbk5hbWU6IHRoaXMuY29sbGVjdGlvbk5hbWUsXG4gICAgICAgIG9uQmVmb3JlVXBsb2FkOiB0aGlzLm9uQmVmb3JlVXBsb2FkLFxuICAgICAgICBuYW1pbmdGdW5jdGlvbjogdGhpcy5uYW1pbmdGdW5jdGlvbixcbiAgICAgICAgcmVzcG9uc2VIZWFkZXJzOiB0aGlzLnJlc3BvbnNlSGVhZGVycyxcbiAgICAgICAgZGlzYWJsZURvd25sb2FkOiB0aGlzLmRpc2FibGVEb3dubG9hZCxcbiAgICAgICAgYWxsb3dlZE9yaWdpbnM6IHRoaXMuYWxsb3dlZE9yaWdpbnMsXG4gICAgICAgIGFsbG93Q2xpZW50Q29kZTogdGhpcy5hbGxvd0NsaWVudENvZGUsXG4gICAgICAgIGRvd25sb2FkQ2FsbGJhY2s6IHRoaXMuZG93bmxvYWRDYWxsYmFjayxcbiAgICAgICAgb25Jbml0aWF0ZVVwbG9hZDogdGhpcy5vbkluaXRpYXRlVXBsb2FkLFxuICAgICAgICBpbnRlcmNlcHRSZXF1ZXN0OiB0aGlzLmludGVyY2VwdFJlcXVlc3QsXG4gICAgICAgIGludGVyY2VwdERvd25sb2FkOiB0aGlzLmludGVyY2VwdERvd25sb2FkLFxuICAgICAgICBjb250aW51ZVVwbG9hZFRUTDogdGhpcy5jb250aW51ZVVwbG9hZFRUTCxcbiAgICAgICAgcGFyZW50RGlyUGVybWlzc2lvbnM6IHRoaXMucGFyZW50RGlyUGVybWlzc2lvbnMsXG4gICAgICAgIGFsbG93UXVlcnlTdHJpbmdDb29raWVzOiB0aGlzLmFsbG93UXVlcnlTdHJpbmdDb29raWVzLFxuICAgICAgICBfcHJlQ29sbGVjdGlvbjogdGhpcy5fcHJlQ29sbGVjdGlvbixcbiAgICAgICAgX3ByZUNvbGxlY3Rpb25OYW1lOiB0aGlzLl9wcmVDb2xsZWN0aW9uTmFtZSxcbiAgICAgIH0gPSBjb25maWcpO1xuICAgIH1cblxuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbih0aGlzLmRlYnVnKSkge1xuICAgICAgdGhpcy5kZWJ1ZyA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5wdWJsaWMpKSB7XG4gICAgICB0aGlzLnB1YmxpYyA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghdGhpcy5wcm90ZWN0ZWQpIHtcbiAgICAgIHRoaXMucHJvdGVjdGVkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLmNodW5rU2l6ZSkge1xuICAgICAgdGhpcy5jaHVua1NpemUgPSAxMDI0ICogNTEyO1xuICAgIH1cblxuICAgIHRoaXMuY2h1bmtTaXplID0gTWF0aC5mbG9vcih0aGlzLmNodW5rU2l6ZSAvIDgpICogODtcblxuICAgIGlmICghaGVscGVycy5pc1N0cmluZyh0aGlzLmNvbGxlY3Rpb25OYW1lKSAmJiAhdGhpcy5jb2xsZWN0aW9uKSB7XG4gICAgICB0aGlzLmNvbGxlY3Rpb25OYW1lID0gJ01ldGVvclVwbG9hZEZpbGVzJztcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuY29sbGVjdGlvbikge1xuICAgICAgdGhpcy5jb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24odGhpcy5jb2xsZWN0aW9uTmFtZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29sbGVjdGlvbk5hbWUgPSB0aGlzLmNvbGxlY3Rpb24uX25hbWU7XG4gICAgfVxuXG4gICAgdGhpcy5jb2xsZWN0aW9uLmZpbGVzQ29sbGVjdGlvbiA9IHRoaXM7XG4gICAgY2hlY2sodGhpcy5jb2xsZWN0aW9uTmFtZSwgU3RyaW5nKTtcblxuICAgIGlmICh0aGlzLnB1YmxpYyAmJiAhdGhpcy5kb3dubG9hZFJvdXRlKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgYFtGaWxlc0NvbGxlY3Rpb24uJHt0aGlzLmNvbGxlY3Rpb25OYW1lfV06IFwiZG93bmxvYWRSb3V0ZVwiIG11c3QgYmUgcHJlY2lzZWx5IHByb3ZpZGVkIG9uIFwicHVibGljXCIgY29sbGVjdGlvbnMhIE5vdGU6IFwiZG93bmxvYWRSb3V0ZVwiIG11c3QgYmUgZXF1YWwgb3IgYmUgaW5zaWRlIG9mIHlvdXIgd2ViL3Byb3h5LXNlcnZlciAocmVsYXRpdmUpIHJvb3QuYCk7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKHRoaXMuZG93bmxvYWRSb3V0ZSkpIHtcbiAgICAgIHRoaXMuZG93bmxvYWRSb3V0ZSA9ICcvY2RuL3N0b3JhZ2UnO1xuICAgIH1cblxuICAgIHRoaXMuZG93bmxvYWRSb3V0ZSA9IHRoaXMuZG93bmxvYWRSb3V0ZS5yZXBsYWNlKC9cXC8kLywgJycpO1xuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5uYW1pbmdGdW5jdGlvbikpIHtcbiAgICAgIHRoaXMubmFtaW5nRnVuY3Rpb24gPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLm9uQmVmb3JlVXBsb2FkKSkge1xuICAgICAgdGhpcy5vbkJlZm9yZVVwbG9hZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5hbGxvd0NsaWVudENvZGUpKSB7XG4gICAgICB0aGlzLmFsbG93Q2xpZW50Q29kZSA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkluaXRpYXRlVXBsb2FkKSkge1xuICAgICAgdGhpcy5vbkluaXRpYXRlVXBsb2FkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5pbnRlcmNlcHRSZXF1ZXN0KSkge1xuICAgICAgdGhpcy5pbnRlcmNlcHRSZXF1ZXN0ID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5pbnRlcmNlcHREb3dubG9hZCkpIHtcbiAgICAgIHRoaXMuaW50ZXJjZXB0RG93bmxvYWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNCb29sZWFuKHRoaXMuc3RyaWN0KSkge1xuICAgICAgdGhpcy5zdHJpY3QgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcykpIHtcbiAgICAgIHRoaXMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNOdW1iZXIodGhpcy5wZXJtaXNzaW9ucykpIHtcbiAgICAgIHRoaXMucGVybWlzc2lvbnMgPSBwYXJzZUludCgnNjQ0JywgOCk7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzTnVtYmVyKHRoaXMucGFyZW50RGlyUGVybWlzc2lvbnMpKSB7XG4gICAgICB0aGlzLnBhcmVudERpclBlcm1pc3Npb25zID0gcGFyc2VJbnQoJzc1NScsIDgpO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc1N0cmluZyh0aGlzLmNhY2hlQ29udHJvbCkpIHtcbiAgICAgIHRoaXMuY2FjaGVDb250cm9sID0gJ3B1YmxpYywgbWF4LWFnZT0zMTUzNjAwMCwgcy1tYXhhZ2U9MzE1MzYwMDAnO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25BZnRlclVwbG9hZCkpIHtcbiAgICAgIHRoaXMub25BZnRlclVwbG9hZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5kaXNhYmxlVXBsb2FkKSkge1xuICAgICAgdGhpcy5kaXNhYmxlVXBsb2FkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkFmdGVyUmVtb3ZlKSkge1xuICAgICAgdGhpcy5vbkFmdGVyUmVtb3ZlID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkJlZm9yZVJlbW92ZSkpIHtcbiAgICAgIHRoaXMub25CZWZvcmVSZW1vdmUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNCb29sZWFuKHRoaXMuaW50ZWdyaXR5Q2hlY2spKSB7XG4gICAgICB0aGlzLmludGVncml0eUNoZWNrID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNCb29sZWFuKHRoaXMuZGlzYWJsZURvd25sb2FkKSkge1xuICAgICAgdGhpcy5kaXNhYmxlRG93bmxvYWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNCb29sZWFuKHRoaXMuYWxsb3dlZE9yaWdpbnMpIHx8IHRoaXMuYWxsb3dlZE9yaWdpbnMgPT09IHRydWUpIHtcbiAgICAgIHRoaXMuYWxsb3dlZE9yaWdpbnMgPSAvXmh0dHA6XFwvXFwvbG9jYWxob3N0OjEyWzAtOV17M30kLztcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNPYmplY3QodGhpcy5fY3VycmVudFVwbG9hZHMpKSB7XG4gICAgICB0aGlzLl9jdXJyZW50VXBsb2FkcyA9IHt9O1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMuZG93bmxvYWRDYWxsYmFjaykpIHtcbiAgICAgIHRoaXMuZG93bmxvYWRDYWxsYmFjayA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc051bWJlcih0aGlzLmNvbnRpbnVlVXBsb2FkVFRMKSkge1xuICAgICAgdGhpcy5jb250aW51ZVVwbG9hZFRUTCA9IDEwODAwO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMucmVzcG9uc2VIZWFkZXJzKSkge1xuICAgICAgdGhpcy5yZXNwb25zZUhlYWRlcnMgPSAocmVzcG9uc2VDb2RlLCBmaWxlUmVmLCB2ZXJzaW9uUmVmKSA9PiB7XG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7fTtcbiAgICAgICAgc3dpdGNoIChyZXNwb25zZUNvZGUpIHtcbiAgICAgICAgY2FzZSAnMjA2JzpcbiAgICAgICAgICBoZWFkZXJzLlByYWdtYSAgICAgICAgICAgICAgID0gJ3ByaXZhdGUnO1xuICAgICAgICAgIGhlYWRlcnNbJ1RyYW5zZmVyLUVuY29kaW5nJ10gPSAnY2h1bmtlZCc7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJzQwMCc6XG4gICAgICAgICAgaGVhZGVyc1snQ2FjaGUtQ29udHJvbCddICAgICA9ICduby1jYWNoZSc7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJzQxNic6XG4gICAgICAgICAgaGVhZGVyc1snQ29udGVudC1SYW5nZSddICAgICA9IGBieXRlcyAqLyR7dmVyc2lvblJlZi5zaXplfWA7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICBoZWFkZXJzLkNvbm5lY3Rpb24gICAgICAgPSAna2VlcC1hbGl2ZSc7XG4gICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtVHlwZSddICA9IHZlcnNpb25SZWYudHlwZSB8fCAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJztcbiAgICAgICAgaGVhZGVyc1snQWNjZXB0LVJhbmdlcyddID0gJ2J5dGVzJztcbiAgICAgICAgcmV0dXJuIGhlYWRlcnM7XG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmICh0aGlzLnB1YmxpYyAmJiAhc3RvcmFnZVBhdGgpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBgW0ZpbGVzQ29sbGVjdGlvbi4ke3RoaXMuY29sbGVjdGlvbk5hbWV9XSBcInN0b3JhZ2VQYXRoXCIgbXVzdCBiZSBzZXQgb24gXCJwdWJsaWNcIiBjb2xsZWN0aW9ucyEgTm90ZTogXCJzdG9yYWdlUGF0aFwiIG11c3QgYmUgZXF1YWwgb24gYmUgaW5zaWRlIG9mIHlvdXIgd2ViL3Byb3h5LXNlcnZlciAoYWJzb2x1dGUpIHJvb3QuYCk7XG4gICAgfVxuXG4gICAgaWYgKCFzdG9yYWdlUGF0aCkge1xuICAgICAgc3RvcmFnZVBhdGggPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBgYXNzZXRzJHtub2RlUGF0aC5zZXB9YXBwJHtub2RlUGF0aC5zZXB9dXBsb2FkcyR7bm9kZVBhdGguc2VwfSR7c2VsZi5jb2xsZWN0aW9uTmFtZX1gO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoaGVscGVycy5pc1N0cmluZyhzdG9yYWdlUGF0aCkpIHtcbiAgICAgIHRoaXMuc3RvcmFnZVBhdGggPSAoKSA9PiBzdG9yYWdlUGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdG9yYWdlUGF0aCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGV0IHNwID0gc3RvcmFnZVBhdGguYXBwbHkoc2VsZiwgYXJndW1lbnRzKTtcbiAgICAgICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKHNwKSkge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCBgW0ZpbGVzQ29sbGVjdGlvbi4ke3NlbGYuY29sbGVjdGlvbk5hbWV9XSBcInN0b3JhZ2VQYXRoXCIgZnVuY3Rpb24gbXVzdCByZXR1cm4gYSBTdHJpbmchYCk7XG4gICAgICAgIH1cbiAgICAgICAgc3AgPSBzcC5yZXBsYWNlKC9cXC8kLywgJycpO1xuICAgICAgICByZXR1cm4gbm9kZVBhdGgubm9ybWFsaXplKHNwKTtcbiAgICAgIH07XG4gICAgfVxuXG4gICAgdGhpcy5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb24uc3RvcmFnZVBhdGhdIFNldCB0bzonLCB0aGlzLnN0b3JhZ2VQYXRoKHt9KSk7XG5cbiAgICBmcy5ta2RpcnModGhpcy5zdG9yYWdlUGF0aCh7fSksIHsgbW9kZTogdGhpcy5wYXJlbnREaXJQZXJtaXNzaW9ucyB9LCAoZXJyb3IpID0+IHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMSwgYFtGaWxlc0NvbGxlY3Rpb24uJHtzZWxmLmNvbGxlY3Rpb25OYW1lfV0gUGF0aCBcIiR7dGhpcy5zdG9yYWdlUGF0aCh7fSl9XCIgaXMgbm90IHdyaXRhYmxlISAke2Vycm9yfWApO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgY2hlY2sodGhpcy5zdHJpY3QsIEJvb2xlYW4pO1xuICAgIGNoZWNrKHRoaXMucGVybWlzc2lvbnMsIE51bWJlcik7XG4gICAgY2hlY2sodGhpcy5zdG9yYWdlUGF0aCwgRnVuY3Rpb24pO1xuICAgIGNoZWNrKHRoaXMuY2FjaGVDb250cm9sLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRoaXMub25BZnRlclJlbW92ZSwgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5vbkFmdGVyVXBsb2FkLCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLmRpc2FibGVVcGxvYWQsIEJvb2xlYW4pO1xuICAgIGNoZWNrKHRoaXMuaW50ZWdyaXR5Q2hlY2ssIEJvb2xlYW4pO1xuICAgIGNoZWNrKHRoaXMub25CZWZvcmVSZW1vdmUsIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuZGlzYWJsZURvd25sb2FkLCBCb29sZWFuKTtcbiAgICBjaGVjayh0aGlzLmRvd25sb2FkQ2FsbGJhY2ssIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuaW50ZXJjZXB0UmVxdWVzdCwgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5pbnRlcmNlcHREb3dubG9hZCwgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5jb250aW51ZVVwbG9hZFRUTCwgTnVtYmVyKTtcbiAgICBjaGVjayh0aGlzLnJlc3BvbnNlSGVhZGVycywgTWF0Y2guT25lT2YoT2JqZWN0LCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMsIEJvb2xlYW4pO1xuXG4gICAgbmV3IENvb2tpZXMoe1xuICAgICAgYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXM6IHRoaXMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMsXG4gICAgICBhbGxvd2VkQ29yZG92YU9yaWdpbnM6IHRoaXMuYWxsb3dlZE9yaWdpbnNcbiAgICB9KTtcblxuICAgIGlmICghdGhpcy5kaXNhYmxlVXBsb2FkKSB7XG4gICAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcodGhpcy5fcHJlQ29sbGVjdGlvbk5hbWUpICYmICF0aGlzLl9wcmVDb2xsZWN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3ByZUNvbGxlY3Rpb25OYW1lID0gYF9fcHJlXyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXRoaXMuX3ByZUNvbGxlY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fcHJlQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKHRoaXMuX3ByZUNvbGxlY3Rpb25OYW1lKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3ByZUNvbGxlY3Rpb25OYW1lID0gdGhpcy5fcHJlQ29sbGVjdGlvbi5fbmFtZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKHRoaXMuX3ByZUNvbGxlY3Rpb25OYW1lLCBTdHJpbmcpO1xuXG4gICAgICB0aGlzLl9wcmVDb2xsZWN0aW9uLl9lbnN1cmVJbmRleCh7IGNyZWF0ZWRBdDogMSB9LCB7IGV4cGlyZUFmdGVyU2Vjb25kczogdGhpcy5jb250aW51ZVVwbG9hZFRUTCwgYmFja2dyb3VuZDogdHJ1ZSB9KTtcbiAgICAgIGNvbnN0IF9wcmVDb2xsZWN0aW9uQ3Vyc29yID0gdGhpcy5fcHJlQ29sbGVjdGlvbi5maW5kKHt9LCB7XG4gICAgICAgIGZpZWxkczoge1xuICAgICAgICAgIF9pZDogMSxcbiAgICAgICAgICBpc0ZpbmlzaGVkOiAxXG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBfcHJlQ29sbGVjdGlvbkN1cnNvci5vYnNlcnZlKHtcbiAgICAgICAgY2hhbmdlZChkb2MpIHtcbiAgICAgICAgICBpZiAoZG9jLmlzRmluaXNoZWQpIHtcbiAgICAgICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbX3ByZUNvbGxlY3Rpb25DdXJzb3Iub2JzZXJ2ZV0gW2NoYW5nZWRdOiAke2RvYy5faWR9YCk7XG4gICAgICAgICAgICBzZWxmLl9wcmVDb2xsZWN0aW9uLnJlbW92ZSh7X2lkOiBkb2MuX2lkfSwgTk9PUCk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICByZW1vdmVkKGRvYykge1xuICAgICAgICAgIC8vIEZyZWUgbWVtb3J5IGFmdGVyIHVwbG9hZCBpcyBkb25lXG4gICAgICAgICAgLy8gT3IgaWYgdXBsb2FkIGlzIHVuZmluaXNoZWRcbiAgICAgICAgICBzZWxmLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW19wcmVDb2xsZWN0aW9uQ3Vyc29yLm9ic2VydmVdIFtyZW1vdmVkXTogJHtkb2MuX2lkfWApO1xuICAgICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KHNlbGYuX2N1cnJlbnRVcGxvYWRzW2RvYy5faWRdKSkge1xuICAgICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbZG9jLl9pZF0uc3RvcCgpO1xuICAgICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbZG9jLl9pZF0uZW5kKCk7XG5cbiAgICAgICAgICAgIC8vIFdlIGNhbiBiZSB1bmx1Y2t5IHRvIHJ1biBpbnRvIGEgcmFjZSBjb25kaXRpb24gd2hlcmUgYW5vdGhlciBzZXJ2ZXIgcmVtb3ZlZCB0aGlzIGRvY3VtZW50IGJlZm9yZSB0aGUgY2hhbmdlIG9mIGBpc0ZpbmlzaGVkYCBpcyByZWdpc3RlcmVkIG9uIHRoaXMgc2VydmVyLlxuICAgICAgICAgICAgLy8gVGhlcmVmb3JlIGl0J3MgYmV0dGVyIHRvIGRvdWJsZS1jaGVjayB3aXRoIHRoZSBtYWluIGNvbGxlY3Rpb24gaWYgdGhlIGZpbGUgaXMgcmVmZXJlbmNlZCB0aGVyZS4gSXNzdWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvaXNzdWVzLzY3MlxuICAgICAgICAgICAgaWYgKCFkb2MuaXNGaW5pc2hlZCAmJiBzZWxmLmNvbGxlY3Rpb24uZmluZCh7IF9pZDogZG9jLl9pZCB9KS5jb3VudCgpID09PSAwKSB7XG4gICAgICAgICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbX3ByZUNvbGxlY3Rpb25DdXJzb3Iub2JzZXJ2ZV0gW3JlbW92ZVVuZmluaXNoZWRVcGxvYWRdOiAke2RvYy5faWR9YCk7XG4gICAgICAgICAgICAgIHNlbGYuX2N1cnJlbnRVcGxvYWRzW2RvYy5faWRdLmFib3J0KCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGRlbGV0ZSBzZWxmLl9jdXJyZW50VXBsb2Fkc1tkb2MuX2lkXTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLl9jcmVhdGVTdHJlYW0gPSAoX2lkLCBwYXRoLCBvcHRzKSA9PiB7XG4gICAgICAgIHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0gPSBuZXcgV3JpdGVTdHJlYW0ocGF0aCwgb3B0cy5maWxlTGVuZ3RoLCBvcHRzLCB0aGlzLnBlcm1pc3Npb25zKTtcbiAgICAgIH07XG5cbiAgICAgIC8vIFRoaXMgbGl0dGxlIGZ1bmN0aW9uIGFsbG93cyB0byBjb250aW51ZSB1cGxvYWRcbiAgICAgIC8vIGV2ZW4gYWZ0ZXIgc2VydmVyIGlzIHJlc3RhcnRlZCAoKm5vdCBvbiBkZXYtc3RhZ2UqKVxuICAgICAgdGhpcy5fY29udGludWVVcGxvYWQgPSAoX2lkKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdICYmIHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0uZmlsZSkge1xuICAgICAgICAgIGlmICghdGhpcy5fY3VycmVudFVwbG9hZHNbX2lkXS5hYm9ydGVkICYmICF0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmVuZGVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFVwbG9hZHNbX2lkXS5maWxlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLl9jcmVhdGVTdHJlYW0oX2lkLCB0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmZpbGUuZmlsZS5wYXRoLCB0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmZpbGUpO1xuICAgICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmZpbGU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY29udFVwbGQgPSB0aGlzLl9wcmVDb2xsZWN0aW9uLmZpbmRPbmUoe19pZH0pO1xuICAgICAgICBpZiAoY29udFVwbGQpIHtcbiAgICAgICAgICB0aGlzLl9jcmVhdGVTdHJlYW0oX2lkLCBjb250VXBsZC5maWxlLnBhdGgsIGNvbnRVcGxkKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFVwbG9hZHNbX2lkXS5maWxlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLnNjaGVtYSkge1xuICAgICAgdGhpcy5zY2hlbWEgPSBGaWxlc0NvbGxlY3Rpb25Db3JlLnNjaGVtYTtcbiAgICB9XG5cbiAgICBjaGVjayh0aGlzLmRlYnVnLCBCb29sZWFuKTtcbiAgICBjaGVjayh0aGlzLnNjaGVtYSwgT2JqZWN0KTtcbiAgICBjaGVjayh0aGlzLnB1YmxpYywgQm9vbGVhbik7XG4gICAgY2hlY2sodGhpcy5wcm90ZWN0ZWQsIE1hdGNoLk9uZU9mKEJvb2xlYW4sIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5jaHVua1NpemUsIE51bWJlcik7XG4gICAgY2hlY2sodGhpcy5kb3dubG9hZFJvdXRlLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRoaXMubmFtaW5nRnVuY3Rpb24sIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMub25CZWZvcmVVcGxvYWQsIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMub25Jbml0aWF0ZVVwbG9hZCwgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5hbGxvd0NsaWVudENvZGUsIEJvb2xlYW4pO1xuXG4gICAgaWYgKHRoaXMucHVibGljICYmIHRoaXMucHJvdGVjdGVkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgYFtGaWxlc0NvbGxlY3Rpb24uJHt0aGlzLmNvbGxlY3Rpb25OYW1lfV06IEZpbGVzIGNhbiBub3QgYmUgcHVibGljIGFuZCBwcm90ZWN0ZWQgYXQgdGhlIHNhbWUgdGltZSFgKTtcbiAgICB9XG5cbiAgICB0aGlzLl9jaGVja0FjY2VzcyA9IChodHRwKSA9PiB7XG4gICAgICBpZiAodGhpcy5wcm90ZWN0ZWQpIHtcbiAgICAgICAgbGV0IHJlc3VsdDtcbiAgICAgICAgY29uc3Qge3VzZXIsIHVzZXJJZH0gPSB0aGlzLl9nZXRVc2VyKGh0dHApO1xuXG4gICAgICAgIGlmIChoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5wcm90ZWN0ZWQpKSB7XG4gICAgICAgICAgbGV0IGZpbGVSZWY7XG4gICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QoaHR0cC5wYXJhbXMpICYmICBodHRwLnBhcmFtcy5faWQpIHtcbiAgICAgICAgICAgIGZpbGVSZWYgPSB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShodHRwLnBhcmFtcy5faWQpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJlc3VsdCA9IGh0dHAgPyB0aGlzLnByb3RlY3RlZC5jYWxsKE9iamVjdC5hc3NpZ24oaHR0cCwge3VzZXIsIHVzZXJJZH0pLCAoZmlsZVJlZiB8fCBudWxsKSkgOiB0aGlzLnByb3RlY3RlZC5jYWxsKHt1c2VyLCB1c2VySWR9LCAoZmlsZVJlZiB8fCBudWxsKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0ID0gISF1c2VySWQ7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoKGh0dHAgJiYgKHJlc3VsdCA9PT0gdHJ1ZSkpIHx8ICFodHRwKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByYyA9IGhlbHBlcnMuaXNOdW1iZXIocmVzdWx0KSA/IHJlc3VsdCA6IDQwMTtcbiAgICAgICAgdGhpcy5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb24uX2NoZWNrQWNjZXNzXSBXQVJOOiBBY2Nlc3MgZGVuaWVkIScpO1xuICAgICAgICBpZiAoaHR0cCkge1xuICAgICAgICAgIGNvbnN0IHRleHQgPSAnQWNjZXNzIGRlbmllZCEnO1xuICAgICAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgaHR0cC5yZXNwb25zZS53cml0ZUhlYWQocmMsIHtcbiAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3BsYWluJyxcbiAgICAgICAgICAgICAgJ0NvbnRlbnQtTGVuZ3RoJzogdGV4dC5sZW5ndGhcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghaHR0cC5yZXNwb25zZS5maW5pc2hlZCkge1xuICAgICAgICAgICAgaHR0cC5yZXNwb25zZS5lbmQodGV4dCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfTtcblxuICAgIHRoaXMuX21ldGhvZE5hbWVzID0ge1xuICAgICAgX0Fib3J0OiBgX0ZpbGVzQ29sbGVjdGlvbkFib3J0XyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLFxuICAgICAgX1dyaXRlOiBgX0ZpbGVzQ29sbGVjdGlvbldyaXRlXyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLFxuICAgICAgX1N0YXJ0OiBgX0ZpbGVzQ29sbGVjdGlvblN0YXJ0XyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLFxuICAgICAgX1JlbW92ZTogYF9GaWxlc0NvbGxlY3Rpb25SZW1vdmVfJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWBcbiAgICB9O1xuXG4gICAgdGhpcy5vbignX2hhbmRsZVVwbG9hZCcsIHRoaXMuX2hhbmRsZVVwbG9hZCk7XG4gICAgdGhpcy5vbignX2ZpbmlzaFVwbG9hZCcsIHRoaXMuX2ZpbmlzaFVwbG9hZCk7XG4gICAgdGhpcy5faGFuZGxlVXBsb2FkU3luYyA9IE1ldGVvci53cmFwQXN5bmModGhpcy5faGFuZGxlVXBsb2FkLmJpbmQodGhpcykpO1xuXG4gICAgaWYgKHRoaXMuZGlzYWJsZVVwbG9hZCAmJiB0aGlzLmRpc2FibGVEb3dubG9hZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgoaHR0cFJlcSwgaHR0cFJlc3AsIG5leHQpID0+IHtcbiAgICAgIGlmICh0aGlzLmFsbG93ZWRPcmlnaW5zICYmIGh0dHBSZXEuX3BhcnNlZFVybC5wYXRoLmluY2x1ZGVzKGAke3RoaXMuZG93bmxvYWRSb3V0ZX0vYCkgJiYgIWh0dHBSZXNwLmhlYWRlcnNTZW50KSB7XG4gICAgICAgIGlmICh0aGlzLmFsbG93ZWRPcmlnaW5zLnRlc3QoaHR0cFJlcS5oZWFkZXJzLm9yaWdpbikpIHtcbiAgICAgICAgICBodHRwUmVzcC5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUFsbG93LUNyZWRlbnRpYWxzJywgJ3RydWUnKTtcbiAgICAgICAgICBodHRwUmVzcC5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbicsIGh0dHBSZXEuaGVhZGVycy5vcmlnaW4pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGh0dHBSZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICAgICAgICBodHRwUmVzcC5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnLCAnR0VULCBQT1NULCBPUFRJT05TJyk7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJywgJ1JhbmdlLCBDb250ZW50LVR5cGUsIHgtbXRvaywgeC1zdGFydCwgeC1jaHVua2lkLCB4LWZpbGVpZCwgeC1lb2YnKTtcbiAgICAgICAgICBodHRwUmVzcC5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUV4cG9zZS1IZWFkZXJzJywgJ0FjY2VwdC1SYW5nZXMsIENvbnRlbnQtRW5jb2RpbmcsIENvbnRlbnQtTGVuZ3RoLCBDb250ZW50LVJhbmdlJyk7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBbGxvdycsICdHRVQsIFBPU1QsIE9QVElPTlMnKTtcbiAgICAgICAgICBodHRwUmVzcC53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICBodHRwUmVzcC5lbmQoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKCF0aGlzLmRpc2FibGVVcGxvYWQgJiYgaHR0cFJlcS5fcGFyc2VkVXJsLnBhdGguaW5jbHVkZXMoYCR7dGhpcy5kb3dubG9hZFJvdXRlfS8ke3RoaXMuY29sbGVjdGlvbk5hbWV9L19fdXBsb2FkYCkpIHtcbiAgICAgICAgaWYgKGh0dHBSZXEubWV0aG9kICE9PSAnUE9TVCcpIHtcbiAgICAgICAgICBuZXh0KCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaGFuZGxlRXJyb3IgPSAoX2Vycm9yKSA9PiB7XG4gICAgICAgICAgbGV0IGVycm9yID0gX2Vycm9yO1xuICAgICAgICAgIGNvbnNvbGUud2FybignW0ZpbGVzQ29sbGVjdGlvbl0gW1VwbG9hZF0gW0hUVFBdIEV4Y2VwdGlvbjonLCBlcnJvcik7XG4gICAgICAgICAgY29uc29sZS50cmFjZSgpO1xuXG4gICAgICAgICAgaWYgKCFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgaHR0cFJlc3Aud3JpdGVIZWFkKDUwMCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKCFodHRwUmVzcC5maW5pc2hlZCkge1xuICAgICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QoZXJyb3IpICYmIGhlbHBlcnMuaXNGdW5jdGlvbihlcnJvci50b1N0cmluZykpIHtcbiAgICAgICAgICAgICAgZXJyb3IgPSBlcnJvci50b1N0cmluZygpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcoZXJyb3IpKSB7XG4gICAgICAgICAgICAgIGVycm9yID0gJ1VuZXhwZWN0ZWQgZXJyb3IhJztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaHR0cFJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHsgZXJyb3IgfSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBsZXQgYm9keSA9ICcnO1xuICAgICAgICBjb25zdCBoYW5kbGVEYXRhID0gKCkgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgb3B0cztcbiAgICAgICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgICAgICBsZXQgdXNlcjtcblxuICAgICAgICAgICAgaWYgKGh0dHBSZXEuaGVhZGVyc1sneC1tdG9rJ10gJiYgdGhpcy5fZ2V0VXNlcklkKGh0dHBSZXEuaGVhZGVyc1sneC1tdG9rJ10pKSB7XG4gICAgICAgICAgICAgIHVzZXIgPSB7XG4gICAgICAgICAgICAgICAgdXNlcklkOiB0aGlzLl9nZXRVc2VySWQoaHR0cFJlcS5oZWFkZXJzWyd4LW10b2snXSlcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHVzZXIgPSB0aGlzLl9nZXRVc2VyKHtyZXF1ZXN0OiBodHRwUmVxLCByZXNwb25zZTogaHR0cFJlc3B9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGh0dHBSZXEuaGVhZGVyc1sneC1zdGFydCddICE9PSAnMScpIHtcbiAgICAgICAgICAgICAgb3B0cyA9IHtcbiAgICAgICAgICAgICAgICBmaWxlSWQ6IGh0dHBSZXEuaGVhZGVyc1sneC1maWxlaWQnXVxuICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgIGlmIChodHRwUmVxLmhlYWRlcnNbJ3gtZW9mJ10gPT09ICcxJykge1xuICAgICAgICAgICAgICAgIG9wdHMuZW9mID0gdHJ1ZTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBvcHRzLmJpbkRhdGEgPSBCdWZmZXIuZnJvbShib2R5LCAnYmFzZTY0Jyk7XG4gICAgICAgICAgICAgICAgb3B0cy5jaHVua0lkID0gcGFyc2VJbnQoaHR0cFJlcS5oZWFkZXJzWyd4LWNodW5raWQnXSk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBfY29udGludWVVcGxvYWQgPSB0aGlzLl9jb250aW51ZVVwbG9hZChvcHRzLmZpbGVJZCk7XG4gICAgICAgICAgICAgIGlmICghX2NvbnRpbnVlVXBsb2FkKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDgsICdDYW5cXCd0IGNvbnRpbnVlIHVwbG9hZCwgc2Vzc2lvbiBleHBpcmVkLiBTdGFydCB1cGxvYWQgYWdhaW4uJyk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAoe3Jlc3VsdCwgb3B0c30gID0gdGhpcy5fcHJlcGFyZVVwbG9hZChPYmplY3QuYXNzaWduKG9wdHMsIF9jb250aW51ZVVwbG9hZCksIHVzZXIudXNlcklkLCAnSFRUUCcpKTtcblxuICAgICAgICAgICAgICBpZiAob3B0cy5lb2YpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVVcGxvYWQocmVzdWx0LCBvcHRzLCAoX2Vycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSBfZXJyb3I7XG4gICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgICAgICAgICAgIGh0dHBSZXNwLndyaXRlSGVhZCg1MDApO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5maW5pc2hlZCkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGVycm9yKSAmJiBoZWxwZXJzLmlzRnVuY3Rpb24oZXJyb3IudG9TdHJpbmcpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvciA9IGVycm9yLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKGVycm9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgPSAnVW5leHBlY3RlZCBlcnJvciEnO1xuICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgIGh0dHBSZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7IGVycm9yIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmhlYWRlcnNTZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIGh0dHBSZXNwLndyaXRlSGVhZCgyMDApO1xuICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICBpZiAoaGVscGVycy5pc09iamVjdChyZXN1bHQuZmlsZSkgJiYgcmVzdWx0LmZpbGUubWV0YSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQuZmlsZS5tZXRhID0gZml4SlNPTlN0cmluZ2lmeShyZXN1bHQuZmlsZS5tZXRhKTtcbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5maW5pc2hlZCkge1xuICAgICAgICAgICAgICAgICAgICBodHRwUmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgdGhpcy5lbWl0KCdfaGFuZGxlVXBsb2FkJywgcmVzdWx0LCBvcHRzLCBOT09QKTtcblxuICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmhlYWRlcnNTZW50KSB7XG4gICAgICAgICAgICAgICAgaHR0cFJlc3Aud3JpdGVIZWFkKDIwNCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5maW5pc2hlZCkge1xuICAgICAgICAgICAgICAgIGh0dHBSZXNwLmVuZCgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIG9wdHMgPSBKU09OLnBhcnNlKGJvZHkpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChqc29uRXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ2FuXFwndCBwYXJzZSBpbmNvbWluZyBKU09OIGZyb20gQ2xpZW50IG9uIFsuaW5zZXJ0KCkgfCB1cGxvYWRdLCBzb21ldGhpbmcgd2VudCB3cm9uZyEnLCBqc29uRXJyKTtcbiAgICAgICAgICAgICAgICBvcHRzID0ge2ZpbGU6IHt9fTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzLmZpbGUpKSB7XG4gICAgICAgICAgICAgICAgb3B0cy5maWxlID0ge307XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBvcHRzLl9fX3MgPSB0cnVlO1xuICAgICAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGUgU3RhcnQgSFRUUF0gJHtvcHRzLmZpbGUubmFtZSB8fCAnW25vLW5hbWVdJ30gLSAke29wdHMuZmlsZUlkfWApO1xuICAgICAgICAgICAgICBpZiAoaGVscGVycy5pc09iamVjdChvcHRzLmZpbGUpICYmIG9wdHMuZmlsZS5tZXRhKSB7XG4gICAgICAgICAgICAgICAgb3B0cy5maWxlLm1ldGEgPSBmaXhKU09OUGFyc2Uob3B0cy5maWxlLm1ldGEpO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgKHtyZXN1bHR9ID0gdGhpcy5fcHJlcGFyZVVwbG9hZChoZWxwZXJzLmNsb25lKG9wdHMpLCB1c2VyLnVzZXJJZCwgJ0hUVFAgU3RhcnQgTWV0aG9kJykpO1xuXG4gICAgICAgICAgICAgIGlmICh0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShyZXN1bHQuX2lkKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAnQ2FuXFwndCBzdGFydCB1cGxvYWQsIGRhdGEgc3Vic3RpdHV0aW9uIGRldGVjdGVkIScpO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgb3B0cy5faWQgICAgICAgPSBvcHRzLmZpbGVJZDtcbiAgICAgICAgICAgICAgb3B0cy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICBvcHRzLm1heExlbmd0aCA9IG9wdHMuZmlsZUxlbmd0aDtcbiAgICAgICAgICAgICAgdGhpcy5fcHJlQ29sbGVjdGlvbi5pbnNlcnQoaGVscGVycy5vbWl0KG9wdHMsICdfX19zJykpO1xuICAgICAgICAgICAgICB0aGlzLl9jcmVhdGVTdHJlYW0ocmVzdWx0Ll9pZCwgcmVzdWx0LnBhdGgsIGhlbHBlcnMub21pdChvcHRzLCAnX19fcycpKTtcblxuICAgICAgICAgICAgICBpZiAob3B0cy5yZXR1cm5NZXRhKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgICAgICAgaHR0cFJlc3Aud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5maW5pc2hlZCkge1xuICAgICAgICAgICAgICAgICAgaHR0cFJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICAgICAgdXBsb2FkUm91dGU6IGAke3RoaXMuZG93bmxvYWRSb3V0ZX0vJHt0aGlzLmNvbGxlY3Rpb25OYW1lfS9fX3VwbG9hZGAsXG4gICAgICAgICAgICAgICAgICAgIGZpbGU6IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmhlYWRlcnNTZW50KSB7XG4gICAgICAgICAgICAgICAgICBodHRwUmVzcC53cml0ZUhlYWQoMjA0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmZpbmlzaGVkKSB7XG4gICAgICAgICAgICAgICAgICBodHRwUmVzcC5lbmQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChodHRwUmVzcEVycikge1xuICAgICAgICAgICAgaGFuZGxlRXJyb3IoaHR0cFJlc3BFcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBodHRwUmVxLnNldFRpbWVvdXQoMjAwMDAsIGhhbmRsZUVycm9yKTtcbiAgICAgICAgaWYgKHR5cGVvZiBodHRwUmVxLmJvZHkgPT09ICdvYmplY3QnICYmIE9iamVjdC5rZXlzKGh0dHBSZXEuYm9keSkubGVuZ3RoICE9PSAwKSB7XG4gICAgICAgICAgYm9keSA9IEpTT04uc3RyaW5naWZ5KGh0dHBSZXEuYm9keSk7XG4gICAgICAgICAgaGFuZGxlRGF0YSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGh0dHBSZXEub24oJ2RhdGEnLCAoZGF0YSkgPT4gYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgYm9keSArPSBkYXRhO1xuICAgICAgICAgIH0pKTtcblxuICAgICAgICAgIGh0dHBSZXEub24oJ2VuZCcsICgpID0+IGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgIGhhbmRsZURhdGEoKTtcbiAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXRoaXMuZGlzYWJsZURvd25sb2FkKSB7XG4gICAgICAgIGxldCB1cmk7XG5cbiAgICAgICAgaWYgKCF0aGlzLnB1YmxpYykge1xuICAgICAgICAgIGlmIChodHRwUmVxLl9wYXJzZWRVcmwucGF0aC5pbmNsdWRlcyhgJHt0aGlzLmRvd25sb2FkUm91dGV9LyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gKSkge1xuICAgICAgICAgICAgdXJpID0gaHR0cFJlcS5fcGFyc2VkVXJsLnBhdGgucmVwbGFjZShgJHt0aGlzLmRvd25sb2FkUm91dGV9LyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLCAnJyk7XG4gICAgICAgICAgICBpZiAodXJpLmluZGV4T2YoJy8nKSA9PT0gMCkge1xuICAgICAgICAgICAgICB1cmkgPSB1cmkuc3Vic3RyaW5nKDEpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCB1cmlzID0gdXJpLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICBpZiAodXJpcy5sZW5ndGggPT09IDMpIHtcbiAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIF9pZDogdXJpc1swXSxcbiAgICAgICAgICAgICAgICBxdWVyeTogaHR0cFJlcS5fcGFyc2VkVXJsLnF1ZXJ5ID8gbm9kZVFzLnBhcnNlKGh0dHBSZXEuX3BhcnNlZFVybC5xdWVyeSkgOiB7fSxcbiAgICAgICAgICAgICAgICBuYW1lOiB1cmlzWzJdLnNwbGl0KCc/JylbMF0sXG4gICAgICAgICAgICAgICAgdmVyc2lvbjogdXJpc1sxXVxuICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgIGNvbnN0IGh0dHAgPSB7cmVxdWVzdDogaHR0cFJlcSwgcmVzcG9uc2U6IGh0dHBSZXNwLCBwYXJhbXN9O1xuICAgICAgICAgICAgICBpZiAodGhpcy5pbnRlcmNlcHRSZXF1ZXN0ICYmIGhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLmludGVyY2VwdFJlcXVlc3QpICYmIHRoaXMuaW50ZXJjZXB0UmVxdWVzdChodHRwKSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0FjY2VzcyhodHRwKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuZG93bmxvYWQoaHR0cCwgdXJpc1sxXSwgdGhpcy5jb2xsZWN0aW9uLmZpbmRPbmUodXJpc1swXSkpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBuZXh0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGh0dHBSZXEuX3BhcnNlZFVybC5wYXRoLmluY2x1ZGVzKGAke3RoaXMuZG93bmxvYWRSb3V0ZX1gKSkge1xuICAgICAgICAgICAgdXJpID0gaHR0cFJlcS5fcGFyc2VkVXJsLnBhdGgucmVwbGFjZShgJHt0aGlzLmRvd25sb2FkUm91dGV9YCwgJycpO1xuICAgICAgICAgICAgaWYgKHVyaS5pbmRleE9mKCcvJykgPT09IDApIHtcbiAgICAgICAgICAgICAgdXJpID0gdXJpLnN1YnN0cmluZygxKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgdXJpcyA9IHVyaS5zcGxpdCgnLycpO1xuICAgICAgICAgICAgbGV0IF9maWxlID0gdXJpc1t1cmlzLmxlbmd0aCAtIDFdO1xuICAgICAgICAgICAgaWYgKF9maWxlKSB7XG4gICAgICAgICAgICAgIGxldCB2ZXJzaW9uO1xuICAgICAgICAgICAgICBpZiAoX2ZpbGUuaW5jbHVkZXMoJy0nKSkge1xuICAgICAgICAgICAgICAgIHZlcnNpb24gPSBfZmlsZS5zcGxpdCgnLScpWzBdO1xuICAgICAgICAgICAgICAgIF9maWxlICAgPSBfZmlsZS5zcGxpdCgnLScpWzFdLnNwbGl0KCc/JylbMF07XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdmVyc2lvbiA9ICdvcmlnaW5hbCc7XG4gICAgICAgICAgICAgICAgX2ZpbGUgICA9IF9maWxlLnNwbGl0KCc/JylbMF07XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgcXVlcnk6IGh0dHBSZXEuX3BhcnNlZFVybC5xdWVyeSA/IG5vZGVRcy5wYXJzZShodHRwUmVxLl9wYXJzZWRVcmwucXVlcnkpIDoge30sXG4gICAgICAgICAgICAgICAgZmlsZTogX2ZpbGUsXG4gICAgICAgICAgICAgICAgX2lkOiBfZmlsZS5zcGxpdCgnLicpWzBdLFxuICAgICAgICAgICAgICAgIHZlcnNpb24sXG4gICAgICAgICAgICAgICAgbmFtZTogX2ZpbGVcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgY29uc3QgaHR0cCA9IHtyZXF1ZXN0OiBodHRwUmVxLCByZXNwb25zZTogaHR0cFJlc3AsIHBhcmFtc307XG4gICAgICAgICAgICAgIGlmICh0aGlzLmludGVyY2VwdFJlcXVlc3QgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMuaW50ZXJjZXB0UmVxdWVzdCkgJiYgdGhpcy5pbnRlcmNlcHRSZXF1ZXN0KGh0dHApID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHRoaXMuZG93bmxvYWQoaHR0cCwgdmVyc2lvbiwgdGhpcy5jb2xsZWN0aW9uLmZpbmRPbmUocGFyYW1zLl9pZCkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgbmV4dCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXh0KCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIG5leHQoKTtcbiAgICB9KTtcblxuICAgIGlmICghdGhpcy5kaXNhYmxlVXBsb2FkKSB7XG4gICAgICBjb25zdCBfbWV0aG9kcyA9IHt9O1xuXG4gICAgICAvLyBNZXRob2QgdXNlZCB0byByZW1vdmUgZmlsZVxuICAgICAgLy8gZnJvbSBDbGllbnQgc2lkZVxuICAgICAgX21ldGhvZHNbdGhpcy5fbWV0aG9kTmFtZXMuX1JlbW92ZV0gPSBmdW5jdGlvbiAoc2VsZWN0b3IpIHtcbiAgICAgICAgY2hlY2soc2VsZWN0b3IsIE1hdGNoLk9uZU9mKFN0cmluZywgT2JqZWN0KSk7XG4gICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbVW5saW5rIE1ldGhvZF0gWy5yZW1vdmUoJHtzZWxlY3Rvcn0pXWApO1xuXG4gICAgICAgIGlmIChzZWxmLmFsbG93Q2xpZW50Q29kZSkge1xuICAgICAgICAgIGlmIChzZWxmLm9uQmVmb3JlUmVtb3ZlICYmIGhlbHBlcnMuaXNGdW5jdGlvbihzZWxmLm9uQmVmb3JlUmVtb3ZlKSkge1xuICAgICAgICAgICAgY29uc3QgdXNlcklkID0gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICBjb25zdCB1c2VyRnVuY3MgPSB7XG4gICAgICAgICAgICAgIHVzZXJJZDogdGhpcy51c2VySWQsXG4gICAgICAgICAgICAgIHVzZXIoKSB7XG4gICAgICAgICAgICAgICAgaWYgKE1ldGVvci51c2Vycykge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJJZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBpZiAoIXNlbGYub25CZWZvcmVSZW1vdmUuY2FsbCh1c2VyRnVuY3MsIChzZWxmLmZpbmQoc2VsZWN0b3IpIHx8IG51bGwpKSkge1xuICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgJ1tGaWxlc0NvbGxlY3Rpb25dIFtyZW1vdmVdIE5vdCBwZXJtaXR0ZWQhJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY29uc3QgY3Vyc29yID0gc2VsZi5maW5kKHNlbGVjdG9yKTtcbiAgICAgICAgICBpZiAoY3Vyc29yLmNvdW50KCkgPiAwKSB7XG4gICAgICAgICAgICBzZWxmLnJlbW92ZShzZWxlY3Rvcik7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDQsICdDdXJzb3IgaXMgZW1wdHksIG5vIGZpbGVzIGlzIHJlbW92ZWQnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMSwgJ1tGaWxlc0NvbGxlY3Rpb25dIFtyZW1vdmVdIFJ1biBjb2RlIGZyb20gY2xpZW50IGlzIG5vdCBhbGxvd2VkIScpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG5cbiAgICAgIC8vIE1ldGhvZCB1c2VkIHRvIHJlY2VpdmUgXCJmaXJzdCBieXRlXCIgb2YgdXBsb2FkXG4gICAgICAvLyBhbmQgYWxsIGZpbGUncyBtZXRhLWRhdGEsIHNvXG4gICAgICAvLyBpdCB3b24ndCBiZSB0cmFuc2ZlcnJlZCB3aXRoIGV2ZXJ5IGNodW5rXG4gICAgICAvLyBCYXNpY2FsbHkgaXQgcHJlcGFyZXMgZXZlcnl0aGluZ1xuICAgICAgLy8gU28gdXNlciBjYW4gcGF1c2UvZGlzY29ubmVjdCBhbmRcbiAgICAgIC8vIGNvbnRpbnVlIHVwbG9hZCBsYXRlciwgZHVyaW5nIGBjb250aW51ZVVwbG9hZFRUTGBcbiAgICAgIF9tZXRob2RzW3RoaXMuX21ldGhvZE5hbWVzLl9TdGFydF0gPSBmdW5jdGlvbiAob3B0cywgcmV0dXJuTWV0YSkge1xuICAgICAgICBjaGVjayhvcHRzLCB7XG4gICAgICAgICAgZmlsZTogT2JqZWN0LFxuICAgICAgICAgIGZpbGVJZDogU3RyaW5nLFxuICAgICAgICAgIEZTTmFtZTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICAgICAgICBjaHVua1NpemU6IE51bWJlcixcbiAgICAgICAgICBmaWxlTGVuZ3RoOiBOdW1iZXJcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY2hlY2socmV0dXJuTWV0YSwgTWF0Y2guT3B0aW9uYWwoQm9vbGVhbikpO1xuXG4gICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZSBTdGFydCBNZXRob2RdICR7b3B0cy5maWxlLm5hbWV9IC0gJHtvcHRzLmZpbGVJZH1gKTtcbiAgICAgICAgb3B0cy5fX19zID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgeyByZXN1bHQgfSA9IHNlbGYuX3ByZXBhcmVVcGxvYWQoaGVscGVycy5jbG9uZShvcHRzKSwgdGhpcy51c2VySWQsICdERFAgU3RhcnQgTWV0aG9kJyk7XG5cbiAgICAgICAgaWYgKHNlbGYuY29sbGVjdGlvbi5maW5kT25lKHJlc3VsdC5faWQpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICdDYW5cXCd0IHN0YXJ0IHVwbG9hZCwgZGF0YSBzdWJzdGl0dXRpb24gZGV0ZWN0ZWQhJyk7XG4gICAgICAgIH1cblxuICAgICAgICBvcHRzLl9pZCAgICAgICA9IG9wdHMuZmlsZUlkO1xuICAgICAgICBvcHRzLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgICAgIG9wdHMubWF4TGVuZ3RoID0gb3B0cy5maWxlTGVuZ3RoO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHNlbGYuX3ByZUNvbGxlY3Rpb24uaW5zZXJ0KGhlbHBlcnMub21pdChvcHRzLCAnX19fcycpKTtcbiAgICAgICAgICBzZWxmLl9jcmVhdGVTdHJlYW0ocmVzdWx0Ll9pZCwgcmVzdWx0LnBhdGgsIGhlbHBlcnMub21pdChvcHRzLCAnX19fcycpKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZSBTdGFydCBNZXRob2RdIFtFWENFUFRJT046XSAke29wdHMuZmlsZS5uYW1lfSAtICR7b3B0cy5maWxlSWR9YCwgZSk7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsICdDYW5cXCd0IHN0YXJ0Jyk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocmV0dXJuTWV0YSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB1cGxvYWRSb3V0ZTogYCR7c2VsZi5kb3dubG9hZFJvdXRlfS8ke3NlbGYuY29sbGVjdGlvbk5hbWV9L19fdXBsb2FkYCxcbiAgICAgICAgICAgIGZpbGU6IHJlc3VsdFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9O1xuXG5cbiAgICAgIC8vIE1ldGhvZCB1c2VkIHRvIHdyaXRlIGZpbGUgY2h1bmtzXG4gICAgICAvLyBpdCByZWNlaXZlcyB2ZXJ5IGxpbWl0ZWQgYW1vdW50IG9mIG1ldGEtZGF0YVxuICAgICAgLy8gVGhpcyBtZXRob2QgYWxzbyByZXNwb25zaWJsZSBmb3IgRU9GXG4gICAgICBfbWV0aG9kc1t0aGlzLl9tZXRob2ROYW1lcy5fV3JpdGVdID0gZnVuY3Rpb24gKF9vcHRzKSB7XG4gICAgICAgIGxldCBvcHRzID0gX29wdHM7XG4gICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgIGNoZWNrKG9wdHMsIHtcbiAgICAgICAgICBlb2Y6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgICAgICAgIGZpbGVJZDogU3RyaW5nLFxuICAgICAgICAgIGJpbkRhdGE6IE1hdGNoLk9wdGlvbmFsKFN0cmluZyksXG4gICAgICAgICAgY2h1bmtJZDogTWF0Y2guT3B0aW9uYWwoTnVtYmVyKVxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAob3B0cy5iaW5EYXRhKSB7XG4gICAgICAgICAgb3B0cy5iaW5EYXRhID0gQnVmZmVyLmZyb20ob3B0cy5iaW5EYXRhLCAnYmFzZTY0Jyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBfY29udGludWVVcGxvYWQgPSBzZWxmLl9jb250aW51ZVVwbG9hZChvcHRzLmZpbGVJZCk7XG4gICAgICAgIGlmICghX2NvbnRpbnVlVXBsb2FkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDgsICdDYW5cXCd0IGNvbnRpbnVlIHVwbG9hZCwgc2Vzc2lvbiBleHBpcmVkLiBTdGFydCB1cGxvYWQgYWdhaW4uJyk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgKHtyZXN1bHQsIG9wdHN9ID0gc2VsZi5fcHJlcGFyZVVwbG9hZChPYmplY3QuYXNzaWduKG9wdHMsIF9jb250aW51ZVVwbG9hZCksIHRoaXMudXNlcklkLCAnRERQJykpO1xuXG4gICAgICAgIGlmIChvcHRzLmVvZikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gc2VsZi5faGFuZGxlVXBsb2FkU3luYyhyZXN1bHQsIG9wdHMpO1xuICAgICAgICAgIH0gY2F0Y2ggKGhhbmRsZVVwbG9hZEVycikge1xuICAgICAgICAgICAgc2VsZi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtXcml0ZSBNZXRob2RdIFtERFBdIEV4Y2VwdGlvbjonLCBoYW5kbGVVcGxvYWRFcnIpO1xuICAgICAgICAgICAgdGhyb3cgaGFuZGxlVXBsb2FkRXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZWxmLmVtaXQoJ19oYW5kbGVVcGxvYWQnLCByZXN1bHQsIG9wdHMsIE5PT1ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfTtcblxuICAgICAgLy8gTWV0aG9kIHVzZWQgdG8gQWJvcnQgdXBsb2FkXG4gICAgICAvLyAtIEZlZWluZyBtZW1vcnkgYnkgLmVuZCgpaW5nIHdyaXRhYmxlU3RyZWFtc1xuICAgICAgLy8gLSBSZW1vdmluZyB0ZW1wb3JhcnkgcmVjb3JkIGZyb20gQF9wcmVDb2xsZWN0aW9uXG4gICAgICAvLyAtIFJlbW92aW5nIHJlY29yZCBmcm9tIEBjb2xsZWN0aW9uXG4gICAgICAvLyAtIC51bmxpbmsoKWluZyBjaHVua3MgZnJvbSBGU1xuICAgICAgX21ldGhvZHNbdGhpcy5fbWV0aG9kTmFtZXMuX0Fib3J0XSA9IGZ1bmN0aW9uIChfaWQpIHtcbiAgICAgICAgY2hlY2soX2lkLCBTdHJpbmcpO1xuXG4gICAgICAgIGNvbnN0IF9jb250aW51ZVVwbG9hZCA9IHNlbGYuX2NvbnRpbnVlVXBsb2FkKF9pZCk7XG4gICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbQWJvcnQgTWV0aG9kXTogJHtfaWR9IC0gJHsoaGVscGVycy5pc09iamVjdChfY29udGludWVVcGxvYWQuZmlsZSkgPyBfY29udGludWVVcGxvYWQuZmlsZS5wYXRoIDogJycpfWApO1xuXG4gICAgICAgIGlmIChzZWxmLl9jdXJyZW50VXBsb2FkcyAmJiBzZWxmLl9jdXJyZW50VXBsb2Fkc1tfaWRdKSB7XG4gICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbX2lkXS5zdG9wKCk7XG4gICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbX2lkXS5hYm9ydCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKF9jb250aW51ZVVwbG9hZCkge1xuICAgICAgICAgIHNlbGYuX3ByZUNvbGxlY3Rpb24ucmVtb3ZlKHtfaWR9KTtcbiAgICAgICAgICBzZWxmLnJlbW92ZSh7X2lkfSk7XG4gICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QoX2NvbnRpbnVlVXBsb2FkLmZpbGUpICYmIF9jb250aW51ZVVwbG9hZC5maWxlLnBhdGgpIHtcbiAgICAgICAgICAgIHNlbGYudW5saW5rKHtfaWQsIHBhdGg6IF9jb250aW51ZVVwbG9hZC5maWxlLnBhdGh9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9O1xuXG4gICAgICBNZXRlb3IubWV0aG9kcyhfbWV0aG9kcyk7XG4gICAgfVxuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9wcmVwYXJlVXBsb2FkXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gVXNlZCB0byBvcHRpbWl6ZSByZWNlaXZlZCBkYXRhIGFuZCBjaGVjayB1cGxvYWQgcGVybWlzc2lvblxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgX3ByZXBhcmVVcGxvYWQob3B0cyA9IHt9LCB1c2VySWQsIHRyYW5zcG9ydCkge1xuICAgIGxldCBjdHg7XG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbihvcHRzLmVvZikpIHtcbiAgICAgIG9wdHMuZW9mID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFvcHRzLmJpbkRhdGEpIHtcbiAgICAgIG9wdHMuYmluRGF0YSA9ICdFT0YnO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc051bWJlcihvcHRzLmNodW5rSWQpKSB7XG4gICAgICBvcHRzLmNodW5rSWQgPSAtMTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcob3B0cy5GU05hbWUpKSB7XG4gICAgICBvcHRzLkZTTmFtZSA9IG9wdHMuZmlsZUlkO1xuICAgIH1cblxuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbVXBsb2FkXSBbJHt0cmFuc3BvcnR9XSBHb3QgIyR7b3B0cy5jaHVua0lkfS8ke29wdHMuZmlsZUxlbmd0aH0gY2h1bmtzLCBkc3Q6ICR7b3B0cy5maWxlLm5hbWUgfHwgb3B0cy5maWxlLmZpbGVOYW1lfWApO1xuXG4gICAgY29uc3QgZmlsZU5hbWUgPSB0aGlzLl9nZXRGaWxlTmFtZShvcHRzLmZpbGUpO1xuICAgIGNvbnN0IHtleHRlbnNpb24sIGV4dGVuc2lvbldpdGhEb3R9ID0gdGhpcy5fZ2V0RXh0KGZpbGVOYW1lKTtcblxuICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzLmZpbGUubWV0YSkpIHtcbiAgICAgIG9wdHMuZmlsZS5tZXRhID0ge307XG4gICAgfVxuXG4gICAgbGV0IHJlc3VsdCAgICAgICA9IG9wdHMuZmlsZTtcbiAgICByZXN1bHQubmFtZSAgICAgID0gZmlsZU5hbWU7XG4gICAgcmVzdWx0Lm1ldGEgICAgICA9IG9wdHMuZmlsZS5tZXRhO1xuICAgIHJlc3VsdC5leHRlbnNpb24gPSBleHRlbnNpb247XG4gICAgcmVzdWx0LmV4dCAgICAgICA9IGV4dGVuc2lvbjtcbiAgICByZXN1bHQuX2lkICAgICAgID0gb3B0cy5maWxlSWQ7XG4gICAgcmVzdWx0LnVzZXJJZCAgICA9IHVzZXJJZCB8fCBudWxsO1xuICAgIG9wdHMuRlNOYW1lICAgICAgPSBvcHRzLkZTTmFtZS5yZXBsYWNlKC8oW15hLXowLTlcXC1cXF9dKykvZ2ksICctJyk7XG4gICAgcmVzdWx0LnBhdGggICAgICA9IGAke3RoaXMuc3RvcmFnZVBhdGgocmVzdWx0KX0ke25vZGVQYXRoLnNlcH0ke29wdHMuRlNOYW1lfSR7ZXh0ZW5zaW9uV2l0aERvdH1gO1xuICAgIHJlc3VsdCAgICAgICAgICAgPSBPYmplY3QuYXNzaWduKHJlc3VsdCwgdGhpcy5fZGF0YVRvU2NoZW1hKHJlc3VsdCkpO1xuXG4gICAgaWYgKHRoaXMub25CZWZvcmVVcGxvYWQgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25CZWZvcmVVcGxvYWQpKSB7XG4gICAgICBjdHggPSBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgZmlsZTogb3B0cy5maWxlXG4gICAgICB9LCB7XG4gICAgICAgIGNodW5rSWQ6IG9wdHMuY2h1bmtJZCxcbiAgICAgICAgdXNlcklkOiByZXN1bHQudXNlcklkLFxuICAgICAgICB1c2VyKCkge1xuICAgICAgICAgIGlmIChNZXRlb3IudXNlcnMgJiYgcmVzdWx0LnVzZXJJZCkge1xuICAgICAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHJlc3VsdC51c2VySWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfSxcbiAgICAgICAgZW9mOiBvcHRzLmVvZlxuICAgICAgfSk7XG4gICAgICBjb25zdCBpc1VwbG9hZEFsbG93ZWQgPSB0aGlzLm9uQmVmb3JlVXBsb2FkLmNhbGwoY3R4LCByZXN1bHQpO1xuXG4gICAgICBpZiAoaXNVcGxvYWRBbGxvd2VkICE9PSB0cnVlKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBoZWxwZXJzLmlzU3RyaW5nKGlzVXBsb2FkQWxsb3dlZCkgPyBpc1VwbG9hZEFsbG93ZWQgOiAnQG9uQmVmb3JlVXBsb2FkKCkgcmV0dXJuZWQgZmFsc2UnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICgob3B0cy5fX19zID09PSB0cnVlKSAmJiB0aGlzLm9uSW5pdGlhdGVVcGxvYWQgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25Jbml0aWF0ZVVwbG9hZCkpIHtcbiAgICAgICAgICB0aGlzLm9uSW5pdGlhdGVVcGxvYWQuY2FsbChjdHgsIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKChvcHRzLl9fX3MgPT09IHRydWUpICYmIHRoaXMub25Jbml0aWF0ZVVwbG9hZCAmJiBoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkluaXRpYXRlVXBsb2FkKSkge1xuICAgICAgY3R4ID0gT2JqZWN0LmFzc2lnbih7XG4gICAgICAgIGZpbGU6IG9wdHMuZmlsZVxuICAgICAgfSwge1xuICAgICAgICBjaHVua0lkOiBvcHRzLmNodW5rSWQsXG4gICAgICAgIHVzZXJJZDogcmVzdWx0LnVzZXJJZCxcbiAgICAgICAgdXNlcigpIHtcbiAgICAgICAgICBpZiAoTWV0ZW9yLnVzZXJzICYmIHJlc3VsdC51c2VySWQpIHtcbiAgICAgICAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZE9uZShyZXN1bHQudXNlcklkKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0sXG4gICAgICAgIGVvZjogb3B0cy5lb2ZcbiAgICAgIH0pO1xuICAgICAgdGhpcy5vbkluaXRpYXRlVXBsb2FkLmNhbGwoY3R4LCByZXN1bHQpO1xuICAgIH1cblxuICAgIHJldHVybiB7cmVzdWx0LCBvcHRzfTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBfZmluaXNoVXBsb2FkXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gRmluaXNoIHVwbG9hZCwgY2xvc2UgV3JpdGFibGUgc3RyZWFtLCBhZGQgcmVjb3JkIHRvIE1vbmdvREIgYW5kIGZsdXNoIHVzZWQgbWVtb3J5XG4gICAqIEByZXR1cm5zIHt1bmRlZmluZWR9XG4gICAqL1xuICBfZmluaXNoVXBsb2FkKHJlc3VsdCwgb3B0cywgY2IpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW1VwbG9hZF0gW2ZpbmlzaChpbmcpVXBsb2FkXSAtPiAke3Jlc3VsdC5wYXRofWApO1xuICAgIGZzLmNobW9kKHJlc3VsdC5wYXRoLCB0aGlzLnBlcm1pc3Npb25zLCBOT09QKTtcbiAgICByZXN1bHQudHlwZSAgID0gdGhpcy5fZ2V0TWltZVR5cGUob3B0cy5maWxlKTtcbiAgICByZXN1bHQucHVibGljID0gdGhpcy5wdWJsaWM7XG4gICAgdGhpcy5fdXBkYXRlRmlsZVR5cGVzKHJlc3VsdCk7XG5cbiAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KGhlbHBlcnMuY2xvbmUocmVzdWx0KSwgKGNvbEluc2VydCwgX2lkKSA9PiB7XG4gICAgICBpZiAoY29sSW5zZXJ0KSB7XG4gICAgICAgIGNiICYmIGNiKGNvbEluc2VydCk7XG4gICAgICAgIHRoaXMuX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbVXBsb2FkXSBbX2ZpbmlzaFVwbG9hZF0gW2luc2VydF0gRXJyb3I6JywgY29sSW5zZXJ0KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3ByZUNvbGxlY3Rpb24udXBkYXRlKHtfaWQ6IG9wdHMuZmlsZUlkfSwgeyRzZXQ6IHtpc0ZpbmlzaGVkOiB0cnVlfX0sIChwcmVVcGRhdGVFcnJvcikgPT4ge1xuICAgICAgICAgIGlmIChwcmVVcGRhdGVFcnJvcikge1xuICAgICAgICAgICAgY2IgJiYgY2IocHJlVXBkYXRlRXJyb3IpO1xuICAgICAgICAgICAgdGhpcy5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtVcGxvYWRdIFtfZmluaXNoVXBsb2FkXSBbdXBkYXRlXSBFcnJvcjonLCBwcmVVcGRhdGVFcnJvcik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc3VsdC5faWQgPSBfaWQ7XG4gICAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW1VwbG9hZF0gW2ZpbmlzaChlZClVcGxvYWRdIC0+ICR7cmVzdWx0LnBhdGh9YCk7XG4gICAgICAgICAgICB0aGlzLm9uQWZ0ZXJVcGxvYWQgJiYgdGhpcy5vbkFmdGVyVXBsb2FkLmNhbGwodGhpcywgcmVzdWx0KTtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnYWZ0ZXJVcGxvYWQnLCByZXN1bHQpO1xuICAgICAgICAgICAgY2IgJiYgY2IobnVsbCwgcmVzdWx0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9oYW5kbGVVcGxvYWRcbiAgICogQHN1bW1hcnkgSW50ZXJuYWwgbWV0aG9kIHRvIGhhbmRsZSB1cGxvYWQgcHJvY2VzcywgcGlwZSBpbmNvbWluZyBkYXRhIHRvIFdyaXRhYmxlIHN0cmVhbVxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgX2hhbmRsZVVwbG9hZChyZXN1bHQsIG9wdHMsIGNiKSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChvcHRzLmVvZikge1xuICAgICAgICB0aGlzLl9jdXJyZW50VXBsb2Fkc1tyZXN1bHQuX2lkXS5lbmQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMuZW1pdCgnX2ZpbmlzaFVwbG9hZCcsIHJlc3VsdCwgb3B0cywgY2IpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX2N1cnJlbnRVcGxvYWRzW3Jlc3VsdC5faWRdLndyaXRlKG9wdHMuY2h1bmtJZCwgb3B0cy5iaW5EYXRhLCBjYik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhpcy5fZGVidWcoJ1tfaGFuZGxlVXBsb2FkXSBbRVhDRVBUSU9OOl0nLCBlKTtcbiAgICAgIGNiICYmIGNiKGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9nZXRNaW1lVHlwZVxuICAgKiBAcGFyYW0ge09iamVjdH0gZmlsZURhdGEgLSBGaWxlIE9iamVjdFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGZpbGUncyBtaW1lLXR5cGVcbiAgICogQHJldHVybnMge1N0cmluZ31cbiAgICovXG4gIF9nZXRNaW1lVHlwZShmaWxlRGF0YSkge1xuICAgIGxldCBtaW1lO1xuICAgIGNoZWNrKGZpbGVEYXRhLCBPYmplY3QpO1xuICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGZpbGVEYXRhKSAmJiBmaWxlRGF0YS50eXBlKSB7XG4gICAgICBtaW1lID0gZmlsZURhdGEudHlwZTtcbiAgICB9XG5cbiAgICBpZiAoZmlsZURhdGEucGF0aCAmJiAoIW1pbWUgfHwgIWhlbHBlcnMuaXNTdHJpbmcobWltZSkpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBsZXQgYnVmICA9IEJ1ZmZlci5hbGxvYygyNjIpO1xuICAgICAgICBjb25zdCBmZCA9IGZzLm9wZW5TeW5jKGZpbGVEYXRhLnBhdGgsICdyJyk7XG4gICAgICAgIGNvbnN0IGJyID0gZnMucmVhZFN5bmMoZmQsIGJ1ZiwgMCwgMjYyLCAwKTtcbiAgICAgICAgZnMuY2xvc2UoZmQsIE5PT1ApO1xuICAgICAgICBpZiAoYnIgPCAyNjIpIHtcbiAgICAgICAgICBidWYgPSBidWYuc2xpY2UoMCwgYnIpO1xuICAgICAgICB9XG4gICAgICAgICh7bWltZX0gPSBmaWxlVHlwZShidWYpKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gV2UncmUgZ29vZFxuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghbWltZSB8fCAhaGVscGVycy5pc1N0cmluZyhtaW1lKSkge1xuICAgICAgbWltZSA9ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xuICAgIH1cbiAgICByZXR1cm4gbWltZTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9nZXRVc2VySWRcbiAgICogQHN1bW1hcnkgUmV0dXJucyBgdXNlcklkYCBtYXRjaGluZyB0aGUgeG10b2sgdG9rZW4gZGVyaXZlZCBmcm9tIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnNcbiAgICogQHJldHVybnMge1N0cmluZ31cbiAgICovXG4gIF9nZXRVc2VySWQoeG10b2spIHtcbiAgICBpZiAoIXhtdG9rKSByZXR1cm4gbnVsbDtcblxuICAgIC8vIHRocm93IGFuIGVycm9yIHVwb24gYW4gdW5leHBlY3RlZCB0eXBlIG9mIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMgaW4gb3JkZXIgdG8gaWRlbnRpZnkgYnJlYWtpbmcgY2hhbmdlc1xuICAgIGlmICghTWV0ZW9yLnNlcnZlci5zZXNzaW9ucyBpbnN0YW5jZW9mIE1hcCB8fCAhaGVscGVycy5pc09iamVjdChNZXRlb3Iuc2VydmVyLnNlc3Npb25zKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdSZWNlaXZlZCBpbmNvbXBhdGlibGUgdHlwZSBvZiBNZXRlb3Iuc2VydmVyLnNlc3Npb25zJyk7XG4gICAgfVxuXG4gICAgaWYgKE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMgaW5zdGFuY2VvZiBNYXAgJiYgTWV0ZW9yLnNlcnZlci5zZXNzaW9ucy5oYXMoeG10b2spICYmIGhlbHBlcnMuaXNPYmplY3QoTWV0ZW9yLnNlcnZlci5zZXNzaW9ucy5nZXQoeG10b2spKSkge1xuICAgICAgLy8gdG8gYmUgdXNlZCB3aXRoID49IE1ldGVvciAxLjguMSB3aGVyZSBNZXRlb3Iuc2VydmVyLnNlc3Npb25zIGlzIGEgTWFwXG4gICAgICByZXR1cm4gTWV0ZW9yLnNlcnZlci5zZXNzaW9ucy5nZXQoeG10b2spLnVzZXJJZDtcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNPYmplY3QoTWV0ZW9yLnNlcnZlci5zZXNzaW9ucykgJiYgeG10b2sgaW4gTWV0ZW9yLnNlcnZlci5zZXNzaW9ucyAmJiBoZWxwZXJzLmlzT2JqZWN0KE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnNbeG10b2tdKSkge1xuICAgICAgLy8gdG8gYmUgdXNlZCB3aXRoIDwgTWV0ZW9yIDEuOC4xIHdoZXJlIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMgaXMgYW4gT2JqZWN0XG4gICAgICByZXR1cm4gTWV0ZW9yLnNlcnZlci5zZXNzaW9uc1t4bXRva10udXNlcklkO1xuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgX2dldFVzZXJcbiAgICogQHN1bW1hcnkgUmV0dXJucyBvYmplY3Qgd2l0aCBgdXNlcklkYCBhbmQgYHVzZXIoKWAgbWV0aG9kIHdoaWNoIHJldHVybiB1c2VyJ3Mgb2JqZWN0XG4gICAqIEByZXR1cm5zIHtPYmplY3R9XG4gICAqL1xuICBfZ2V0VXNlcihodHRwKSB7XG4gICAgY29uc3QgcmVzdWx0ID0ge1xuICAgICAgdXNlcigpIHsgcmV0dXJuIG51bGw7IH0sXG4gICAgICB1c2VySWQ6IG51bGxcbiAgICB9O1xuXG4gICAgaWYgKGh0dHApIHtcbiAgICAgIGxldCBtdG9rID0gbnVsbDtcbiAgICAgIGlmIChodHRwLnJlcXVlc3QuaGVhZGVyc1sneC1tdG9rJ10pIHtcbiAgICAgICAgbXRvayA9IGh0dHAucmVxdWVzdC5oZWFkZXJzWyd4LW10b2snXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGNvb2tpZSA9IGh0dHAucmVxdWVzdC5Db29raWVzO1xuICAgICAgICBpZiAoY29va2llLmhhcygneF9tdG9rJykpIHtcbiAgICAgICAgICBtdG9rID0gY29va2llLmdldCgneF9tdG9rJyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKG10b2spIHtcbiAgICAgICAgY29uc3QgdXNlcklkID0gdGhpcy5fZ2V0VXNlcklkKG10b2spO1xuXG4gICAgICAgIGlmICh1c2VySWQpIHtcbiAgICAgICAgICByZXN1bHQudXNlciAgID0gKCkgPT4gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodXNlcklkKTtcbiAgICAgICAgICByZXN1bHQudXNlcklkID0gdXNlcklkO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSB3cml0ZVxuICAgKiBAcGFyYW0ge0J1ZmZlcn0gYnVmZmVyIC0gQmluYXJ5IEZpbGUncyBCdWZmZXJcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMgLSBPYmplY3Qgd2l0aCBmaWxlLWRhdGFcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMubmFtZSAtIEZpbGUgbmFtZSwgYWxpYXM6IGBmaWxlTmFtZWBcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMudHlwZSAtIEZpbGUgbWltZS10eXBlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzLm1ldGEgLSBGaWxlIGFkZGl0aW9uYWwgbWV0YS1kYXRhXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRzLnVzZXJJZCAtIFVzZXJJZCwgZGVmYXVsdCAqbnVsbCpcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMuZmlsZUlkIC0gX2lkLCBkZWZhdWx0ICpudWxsKlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIGZ1bmN0aW9uKGVycm9yLCBmaWxlT2JqKXsuLi59XG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gcHJvY2VlZEFmdGVyVXBsb2FkIC0gUHJvY2VlZCBvbkFmdGVyVXBsb2FkIGhvb2tcbiAgICogQHN1bW1hcnkgV3JpdGUgYnVmZmVyIHRvIEZTIGFuZCBhZGQgdG8gRmlsZXNDb2xsZWN0aW9uIENvbGxlY3Rpb25cbiAgICogQHJldHVybnMge0ZpbGVzQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIHdyaXRlKGJ1ZmZlciwgX29wdHMgPSB7fSwgX2NhbGxiYWNrLCBfcHJvY2VlZEFmdGVyVXBsb2FkKSB7XG4gICAgdGhpcy5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZSgpXScpO1xuICAgIGxldCBvcHRzID0gX29wdHM7XG4gICAgbGV0IGNhbGxiYWNrID0gX2NhbGxiYWNrO1xuICAgIGxldCBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBfcHJvY2VlZEFmdGVyVXBsb2FkO1xuXG4gICAgaWYgKGhlbHBlcnMuaXNGdW5jdGlvbihvcHRzKSkge1xuICAgICAgcHJvY2VlZEFmdGVyVXBsb2FkID0gY2FsbGJhY2s7XG4gICAgICBjYWxsYmFjayA9IG9wdHM7XG4gICAgICBvcHRzICAgICA9IHt9O1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4oY2FsbGJhY2spKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNCb29sZWFuKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBvcHRzO1xuICAgIH1cblxuICAgIGNoZWNrKG9wdHMsIE1hdGNoLk9wdGlvbmFsKE9iamVjdCkpO1xuICAgIGNoZWNrKGNhbGxiYWNrLCBNYXRjaC5PcHRpb25hbChGdW5jdGlvbikpO1xuICAgIGNoZWNrKHByb2NlZWRBZnRlclVwbG9hZCwgTWF0Y2guT3B0aW9uYWwoQm9vbGVhbikpO1xuXG4gICAgY29uc3QgZmlsZUlkICAgPSBvcHRzLmZpbGVJZCB8fCBSYW5kb20uaWQoKTtcbiAgICBjb25zdCBGU05hbWUgICA9IHRoaXMubmFtaW5nRnVuY3Rpb24gPyB0aGlzLm5hbWluZ0Z1bmN0aW9uKG9wdHMpIDogZmlsZUlkO1xuICAgIGNvbnN0IGZpbGVOYW1lID0gKG9wdHMubmFtZSB8fCBvcHRzLmZpbGVOYW1lKSA/IChvcHRzLm5hbWUgfHwgb3B0cy5maWxlTmFtZSkgOiBGU05hbWU7XG5cbiAgICBjb25zdCB7ZXh0ZW5zaW9uLCBleHRlbnNpb25XaXRoRG90fSA9IHRoaXMuX2dldEV4dChmaWxlTmFtZSk7XG5cbiAgICBvcHRzLnBhdGggPSBgJHt0aGlzLnN0b3JhZ2VQYXRoKG9wdHMpfSR7bm9kZVBhdGguc2VwfSR7RlNOYW1lfSR7ZXh0ZW5zaW9uV2l0aERvdH1gO1xuICAgIG9wdHMudHlwZSA9IHRoaXMuX2dldE1pbWVUeXBlKG9wdHMpO1xuICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzLm1ldGEpKSB7XG4gICAgICBvcHRzLm1ldGEgPSB7fTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNOdW1iZXIob3B0cy5zaXplKSkge1xuICAgICAgb3B0cy5zaXplID0gYnVmZmVyLmxlbmd0aDtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLl9kYXRhVG9TY2hlbWEoe1xuICAgICAgbmFtZTogZmlsZU5hbWUsXG4gICAgICBwYXRoOiBvcHRzLnBhdGgsXG4gICAgICBtZXRhOiBvcHRzLm1ldGEsXG4gICAgICB0eXBlOiBvcHRzLnR5cGUsXG4gICAgICBzaXplOiBvcHRzLnNpemUsXG4gICAgICB1c2VySWQ6IG9wdHMudXNlcklkLFxuICAgICAgZXh0ZW5zaW9uXG4gICAgfSk7XG5cbiAgICByZXN1bHQuX2lkID0gZmlsZUlkO1xuXG4gICAgZnMuZW5zdXJlRmlsZShvcHRzLnBhdGgsIChlZkVycm9yKSA9PiB7XG4gICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgIGlmIChlZkVycm9yKSB7XG4gICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZWZFcnJvcik7XG4gICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZV0gW2Vuc3VyZUZpbGVdIFtFcnJvcjpdICR7ZmlsZU5hbWV9IC0+ICR7b3B0cy5wYXRofWAsIGVmRXJyb3IpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IHN0cmVhbSA9IGZzLmNyZWF0ZVdyaXRlU3RyZWFtKG9wdHMucGF0aCwge2ZsYWdzOiAndycsIG1vZGU6IHRoaXMucGVybWlzc2lvbnN9KTtcbiAgICAgICAgICBzdHJlYW0uZW5kKGJ1ZmZlciwgKHN0cmVhbUVycikgPT4ge1xuICAgICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoc3RyZWFtRXJyKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soc3RyZWFtRXJyKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KHJlc3VsdCwgKGluc2VydEVyciwgX2lkKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoaW5zZXJ0RXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKGluc2VydEVycik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbd3JpdGVdIFtpbnNlcnRdIEVycm9yOiAke2ZpbGVOYW1lfSAtPiAke3RoaXMuY29sbGVjdGlvbk5hbWV9YCwgaW5zZXJ0RXJyKTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGVSZWYgPSB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShfaWQpO1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhudWxsLCBmaWxlUmVmKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2NlZWRBZnRlclVwbG9hZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHRoaXMub25BZnRlclVwbG9hZCAmJiB0aGlzLm9uQWZ0ZXJVcGxvYWQuY2FsbCh0aGlzLCBmaWxlUmVmKTtcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ2FmdGVyVXBsb2FkJywgZmlsZVJlZik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZV06ICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIGxvYWRcbiAgICogQHBhcmFtIHtTdHJpbmd9IHVybCAtIFVSTCB0byBmaWxlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzIC0gT2JqZWN0IHdpdGggZmlsZS1kYXRhXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzLmhlYWRlcnMgLSBIVFRQIGhlYWRlcnMgdG8gdXNlIHdoZW4gcmVxdWVzdGluZyB0aGUgZmlsZVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy5uYW1lIC0gRmlsZSBuYW1lLCBhbGlhczogYGZpbGVOYW1lYFxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy50eXBlIC0gRmlsZSBtaW1lLXR5cGVcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMubWV0YSAtIEZpbGUgYWRkaXRpb25hbCBtZXRhLWRhdGFcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMudXNlcklkIC0gVXNlcklkLCBkZWZhdWx0ICpudWxsKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy5maWxlSWQgLSBfaWQsIGRlZmF1bHQgKm51bGwqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gZnVuY3Rpb24oZXJyb3IsIGZpbGVPYmopey4uLn1cbiAgICogQHBhcmFtIHtCb29sZWFufSBwcm9jZWVkQWZ0ZXJVcGxvYWQgLSBQcm9jZWVkIG9uQWZ0ZXJVcGxvYWQgaG9va1xuICAgKiBAc3VtbWFyeSBEb3dubG9hZCBmaWxlLCB3cml0ZSBzdHJlYW0gdG8gRlMgYW5kIGFkZCB0byBGaWxlc0NvbGxlY3Rpb24gQ29sbGVjdGlvblxuICAgKiBAcmV0dXJucyB7RmlsZXNDb2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgbG9hZCh1cmwsIF9vcHRzID0ge30sIF9jYWxsYmFjaywgX3Byb2NlZWRBZnRlclVwbG9hZCkge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZCgke3VybH0sICR7SlNPTi5zdHJpbmdpZnkoX29wdHMpfSwgY2FsbGJhY2spXWApO1xuICAgIGxldCBvcHRzID0gX29wdHM7XG4gICAgbGV0IGNhbGxiYWNrID0gX2NhbGxiYWNrO1xuICAgIGxldCBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBfcHJvY2VlZEFmdGVyVXBsb2FkO1xuXG4gICAgaWYgKGhlbHBlcnMuaXNGdW5jdGlvbihvcHRzKSkge1xuICAgICAgcHJvY2VlZEFmdGVyVXBsb2FkID0gY2FsbGJhY2s7XG4gICAgICBjYWxsYmFjayA9IG9wdHM7XG4gICAgICBvcHRzICAgICA9IHt9O1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4oY2FsbGJhY2spKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNCb29sZWFuKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBvcHRzO1xuICAgIH1cblxuICAgIGNoZWNrKHVybCwgU3RyaW5nKTtcbiAgICBjaGVjayhvcHRzLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcbiAgICBjaGVjayhjYWxsYmFjaywgTWF0Y2guT3B0aW9uYWwoRnVuY3Rpb24pKTtcbiAgICBjaGVjayhwcm9jZWVkQWZ0ZXJVcGxvYWQsIE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pKTtcblxuICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzKSkge1xuICAgICAgb3B0cyA9IHt9O1xuICAgIH1cblxuICAgIGNvbnN0IGZpbGVJZCAgICA9IG9wdHMuZmlsZUlkIHx8IFJhbmRvbS5pZCgpO1xuICAgIGNvbnN0IEZTTmFtZSAgICA9IHRoaXMubmFtaW5nRnVuY3Rpb24gPyB0aGlzLm5hbWluZ0Z1bmN0aW9uKG9wdHMpIDogZmlsZUlkO1xuICAgIGNvbnN0IHBhdGhQYXJ0cyA9IHVybC5zcGxpdCgnLycpO1xuICAgIGNvbnN0IGZpbGVOYW1lICA9IChvcHRzLm5hbWUgfHwgb3B0cy5maWxlTmFtZSkgPyAob3B0cy5uYW1lIHx8IG9wdHMuZmlsZU5hbWUpIDogcGF0aFBhcnRzW3BhdGhQYXJ0cy5sZW5ndGggLSAxXSB8fCBGU05hbWU7XG5cbiAgICBjb25zdCB7ZXh0ZW5zaW9uLCBleHRlbnNpb25XaXRoRG90fSA9IHRoaXMuX2dldEV4dChmaWxlTmFtZSk7XG4gICAgb3B0cy5wYXRoICA9IGAke3RoaXMuc3RvcmFnZVBhdGgob3B0cyl9JHtub2RlUGF0aC5zZXB9JHtGU05hbWV9JHtleHRlbnNpb25XaXRoRG90fWA7XG5cbiAgICBjb25zdCBzdG9yZVJlc3VsdCA9IChyZXN1bHQsIGNiKSA9PiB7XG4gICAgICByZXN1bHQuX2lkID0gZmlsZUlkO1xuXG4gICAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KHJlc3VsdCwgKGVycm9yLCBfaWQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgY2IgJiYgY2IoZXJyb3IpO1xuICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2luc2VydF0gRXJyb3I6ICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLCBlcnJvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgZmlsZVJlZiA9IHRoaXMuY29sbGVjdGlvbi5maW5kT25lKF9pZCk7XG4gICAgICAgICAgY2IgJiYgY2IobnVsbCwgZmlsZVJlZik7XG4gICAgICAgICAgaWYgKHByb2NlZWRBZnRlclVwbG9hZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgdGhpcy5vbkFmdGVyVXBsb2FkICYmIHRoaXMub25BZnRlclVwbG9hZC5jYWxsKHRoaXMsIGZpbGVSZWYpO1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdhZnRlclVwbG9hZCcsIGZpbGVSZWYpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2xvYWRdIFtpbnNlcnRdICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIGZzLmVuc3VyZUZpbGUob3B0cy5wYXRoLCAoZWZFcnJvcikgPT4ge1xuICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICBpZiAoZWZFcnJvcikge1xuICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKGVmRXJyb3IpO1xuICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2Vuc3VyZUZpbGVdIFtFcnJvcjpdICR7ZmlsZU5hbWV9IC0+ICR7b3B0cy5wYXRofWAsIGVmRXJyb3IpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlcXVlc3Qoe1xuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgaGVhZGVyczogb3B0cy5oZWFkZXJzIHx8IHt9LFxuICAgICAgICAgICAgd2FpdDogdHJ1ZVxuICAgICAgICAgIH0sIChyZXFFcnJvciwgcmVzcG9uc2UpID0+IGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXFFcnJvcikge1xuICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhyZXFFcnJvcik7XG4gICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW3JlcXVlc3QuZ2V0KCR7dXJsfSldIEVycm9yOmAsIHJlcUVycm9yKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gUmVjZWl2ZWQ6ICR7dXJsfWApO1xuICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLl9kYXRhVG9TY2hlbWEoe1xuICAgICAgICAgICAgICAgIG5hbWU6IGZpbGVOYW1lLFxuICAgICAgICAgICAgICAgIHBhdGg6IG9wdHMucGF0aCxcbiAgICAgICAgICAgICAgICBtZXRhOiBvcHRzLm1ldGEsXG4gICAgICAgICAgICAgICAgdHlwZTogb3B0cy50eXBlIHx8IHJlc3BvbnNlLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddIHx8IHRoaXMuX2dldE1pbWVUeXBlKHtwYXRoOiBvcHRzLnBhdGh9KSxcbiAgICAgICAgICAgICAgICBzaXplOiBvcHRzLnNpemUgfHwgcGFyc2VJbnQocmVzcG9uc2UuaGVhZGVyc1snY29udGVudC1sZW5ndGgnXSB8fCAwKSxcbiAgICAgICAgICAgICAgICB1c2VySWQ6IG9wdHMudXNlcklkLFxuICAgICAgICAgICAgICAgIGV4dGVuc2lvblxuICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICBpZiAoIXJlc3VsdC5zaXplKSB7XG4gICAgICAgICAgICAgICAgZnMuc3RhdChvcHRzLnBhdGgsIChlcnJvciwgc3RhdHMpID0+IGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhlcnJvcik7XG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQudmVyc2lvbnMub3JpZ2luYWwuc2l6ZSA9IChyZXN1bHQuc2l6ZSA9IHN0YXRzLnNpemUpO1xuICAgICAgICAgICAgICAgICAgICBzdG9yZVJlc3VsdChyZXN1bHQsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc3RvcmVSZXN1bHQocmVzdWx0LCBjYWxsYmFjayk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KSkucGlwZShmcy5jcmVhdGVXcml0ZVN0cmVhbShvcHRzLnBhdGgsIHtmbGFnczogJ3cnLCBtb2RlOiB0aGlzLnBlcm1pc3Npb25zfSkpLnNlbmQoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG5cblxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIGFkZEZpbGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IHBhdGggICAgICAgICAgLSBQYXRoIHRvIGZpbGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMgICAgICAgICAgLSBbT3B0aW9uYWxdIE9iamVjdCB3aXRoIGZpbGUtZGF0YVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy50eXBlICAgICAtIFtPcHRpb25hbF0gRmlsZSBtaW1lLXR5cGVcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMubWV0YSAgICAgLSBbT3B0aW9uYWxdIEZpbGUgYWRkaXRpb25hbCBtZXRhLWRhdGFcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMuZmlsZUlkICAgLSBfaWQsIGRlZmF1bHQgKm51bGwqXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzLmZpbGVOYW1lIC0gW09wdGlvbmFsXSBGaWxlIG5hbWUsIGlmIG5vdCBzcGVjaWZpZWQgZmlsZSBuYW1lIGFuZCBleHRlbnNpb24gd2lsbCBiZSB0YWtlbiBmcm9tIHBhdGhcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMudXNlcklkICAgLSBbT3B0aW9uYWxdIFVzZXJJZCwgZGVmYXVsdCAqbnVsbCpcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgICAgLSBbT3B0aW9uYWxdIGZ1bmN0aW9uKGVycm9yLCBmaWxlT2JqKXsuLi59XG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gcHJvY2VlZEFmdGVyVXBsb2FkIC0gUHJvY2VlZCBvbkFmdGVyVXBsb2FkIGhvb2tcbiAgICogQHN1bW1hcnkgQWRkIGZpbGUgZnJvbSBGUyB0byBGaWxlc0NvbGxlY3Rpb25cbiAgICogQHJldHVybnMge0ZpbGVzQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIGFkZEZpbGUocGF0aCwgX29wdHMgPSB7fSwgX2NhbGxiYWNrLCBfcHJvY2VlZEFmdGVyVXBsb2FkKSB7XG4gICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFthZGRGaWxlKCR7cGF0aH0pXWApO1xuICAgIGxldCBvcHRzID0gX29wdHM7XG4gICAgbGV0IGNhbGxiYWNrID0gX2NhbGxiYWNrO1xuICAgIGxldCBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBfcHJvY2VlZEFmdGVyVXBsb2FkO1xuXG4gICAgaWYgKGhlbHBlcnMuaXNGdW5jdGlvbihvcHRzKSkge1xuICAgICAgcHJvY2VlZEFmdGVyVXBsb2FkID0gY2FsbGJhY2s7XG4gICAgICBjYWxsYmFjayA9IG9wdHM7XG4gICAgICBvcHRzICAgICA9IHt9O1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4oY2FsbGJhY2spKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNCb29sZWFuKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBvcHRzO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnB1YmxpYykge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsICdDYW4gbm90IHJ1biBbYWRkRmlsZV0gb24gcHVibGljIGNvbGxlY3Rpb24hIEp1c3QgTW92ZSBmaWxlIHRvIHJvb3Qgb2YgeW91ciBzZXJ2ZXIsIHRoZW4gYWRkIHJlY29yZCB0byBDb2xsZWN0aW9uJyk7XG4gICAgfVxuXG4gICAgY2hlY2socGF0aCwgU3RyaW5nKTtcbiAgICBjaGVjayhvcHRzLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcbiAgICBjaGVjayhjYWxsYmFjaywgTWF0Y2guT3B0aW9uYWwoRnVuY3Rpb24pKTtcbiAgICBjaGVjayhwcm9jZWVkQWZ0ZXJVcGxvYWQsIE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pKTtcblxuICAgIGZzLnN0YXQocGF0aCwgKHN0YXRFcnIsIHN0YXRzKSA9PiBib3VuZCgoKSA9PiB7XG4gICAgICBpZiAoc3RhdEVycikge1xuICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhzdGF0RXJyKTtcbiAgICAgIH0gZWxzZSBpZiAoc3RhdHMuaXNGaWxlKCkpIHtcbiAgICAgICAgaWYgKCFoZWxwZXJzLmlzT2JqZWN0KG9wdHMpKSB7XG4gICAgICAgICAgb3B0cyA9IHt9O1xuICAgICAgICB9XG4gICAgICAgIG9wdHMucGF0aCAgPSBwYXRoO1xuXG4gICAgICAgIGlmICghb3B0cy5maWxlTmFtZSkge1xuICAgICAgICAgIGNvbnN0IHBhdGhQYXJ0cyA9IHBhdGguc3BsaXQobm9kZVBhdGguc2VwKTtcbiAgICAgICAgICBvcHRzLmZpbGVOYW1lICAgPSBwYXRoLnNwbGl0KG5vZGVQYXRoLnNlcClbcGF0aFBhcnRzLmxlbmd0aCAtIDFdO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qge2V4dGVuc2lvbn0gPSB0aGlzLl9nZXRFeHQob3B0cy5maWxlTmFtZSk7XG5cbiAgICAgICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKG9wdHMudHlwZSkpIHtcbiAgICAgICAgICBvcHRzLnR5cGUgPSB0aGlzLl9nZXRNaW1lVHlwZShvcHRzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzLm1ldGEpKSB7XG4gICAgICAgICAgb3B0cy5tZXRhID0ge307XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIWhlbHBlcnMuaXNOdW1iZXIob3B0cy5zaXplKSkge1xuICAgICAgICAgIG9wdHMuc2l6ZSA9IHN0YXRzLnNpemU7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLl9kYXRhVG9TY2hlbWEoe1xuICAgICAgICAgIG5hbWU6IG9wdHMuZmlsZU5hbWUsXG4gICAgICAgICAgcGF0aCxcbiAgICAgICAgICBtZXRhOiBvcHRzLm1ldGEsXG4gICAgICAgICAgdHlwZTogb3B0cy50eXBlLFxuICAgICAgICAgIHNpemU6IG9wdHMuc2l6ZSxcbiAgICAgICAgICB1c2VySWQ6IG9wdHMudXNlcklkLFxuICAgICAgICAgIGV4dGVuc2lvbixcbiAgICAgICAgICBfc3RvcmFnZVBhdGg6IHBhdGgucmVwbGFjZShgJHtub2RlUGF0aC5zZXB9JHtvcHRzLmZpbGVOYW1lfWAsICcnKSxcbiAgICAgICAgICBmaWxlSWQ6IG9wdHMuZmlsZUlkIHx8IG51bGxcbiAgICAgICAgfSk7XG5cblxuICAgICAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KHJlc3VsdCwgKGluc2VydEVyciwgX2lkKSA9PiB7XG4gICAgICAgICAgaWYgKGluc2VydEVycikge1xuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soaW5zZXJ0RXJyKTtcbiAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbYWRkRmlsZV0gW2luc2VydF0gRXJyb3I6ICR7cmVzdWx0Lm5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLCBpbnNlcnRFcnIpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBmaWxlUmVmID0gdGhpcy5jb2xsZWN0aW9uLmZpbmRPbmUoX2lkKTtcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG51bGwsIGZpbGVSZWYpO1xuICAgICAgICAgICAgaWYgKHByb2NlZWRBZnRlclVwbG9hZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICB0aGlzLm9uQWZ0ZXJVcGxvYWQgJiYgdGhpcy5vbkFmdGVyVXBsb2FkLmNhbGwodGhpcywgZmlsZVJlZik7XG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnYWZ0ZXJVcGxvYWQnLCBmaWxlUmVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbYWRkRmlsZV06ICR7cmVzdWx0Lm5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2sobmV3IE1ldGVvci5FcnJvcig0MDAsIGBbRmlsZXNDb2xsZWN0aW9uXSBbYWRkRmlsZSgke3BhdGh9KV06IEZpbGUgZG9lcyBub3QgZXhpc3RgKSk7XG4gICAgICB9XG4gICAgfSkpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgcmVtb3ZlXG4gICAqIEBwYXJhbSB7U3RyaW5nfE9iamVjdH0gc2VsZWN0b3IgLSBNb25nby1TdHlsZSBzZWxlY3RvciAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzZWxlY3RvcnMpXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gQ2FsbGJhY2sgd2l0aCBvbmUgYGVycm9yYCBhcmd1bWVudFxuICAgKiBAc3VtbWFyeSBSZW1vdmUgZG9jdW1lbnRzIGZyb20gdGhlIGNvbGxlY3Rpb25cbiAgICogQHJldHVybnMge0ZpbGVzQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIHJlbW92ZShzZWxlY3RvciwgY2FsbGJhY2spIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3JlbW92ZSgke0pTT04uc3RyaW5naWZ5KHNlbGVjdG9yKX0pXWApO1xuICAgIGlmIChzZWxlY3RvciA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgY2hlY2soY2FsbGJhY2ssIE1hdGNoLk9wdGlvbmFsKEZ1bmN0aW9uKSk7XG5cbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuY29sbGVjdGlvbi5maW5kKHNlbGVjdG9yKTtcbiAgICBpZiAoZmlsZXMuY291bnQoKSA+IDApIHtcbiAgICAgIGZpbGVzLmZvckVhY2goKGZpbGUpID0+IHtcbiAgICAgICAgdGhpcy51bmxpbmsoZmlsZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2sobmV3IE1ldGVvci5FcnJvcig0MDQsICdDdXJzb3IgaXMgZW1wdHksIG5vIGZpbGVzIGlzIHJlbW92ZWQnKSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vbkFmdGVyUmVtb3ZlKSB7XG4gICAgICBjb25zdCBkb2NzID0gZmlsZXMuZmV0Y2goKTtcbiAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgICAgdGhpcy5jb2xsZWN0aW9uLnJlbW92ZShzZWxlY3RvciwgZnVuY3Rpb24gKCkge1xuICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjay5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICBzZWxmLm9uQWZ0ZXJSZW1vdmUoZG9jcyk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb2xsZWN0aW9uLnJlbW92ZShzZWxlY3RvciwgKGNhbGxiYWNrIHx8IE5PT1ApKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgZGVueVxuICAgKiBAcGFyYW0ge09iamVjdH0gcnVsZXNcbiAgICogQHNlZSAgaHR0cHM6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjTW9uZ28tQ29sbGVjdGlvbi1kZW55XG4gICAqIEBzdW1tYXJ5IGxpbmsgTW9uZ28uQ29sbGVjdGlvbiBkZW55IG1ldGhvZHNcbiAgICogQHJldHVybnMge01vbmdvLkNvbGxlY3Rpb259IEluc3RhbmNlXG4gICAqL1xuICBkZW55KHJ1bGVzKSB7XG4gICAgdGhpcy5jb2xsZWN0aW9uLmRlbnkocnVsZXMpO1xuICAgIHJldHVybiB0aGlzLmNvbGxlY3Rpb247XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgYWxsb3dcbiAgICogQHBhcmFtIHtPYmplY3R9IHJ1bGVzXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjTW9uZ28tQ29sbGVjdGlvbi1hbGxvd1xuICAgKiBAc3VtbWFyeSBsaW5rIE1vbmdvLkNvbGxlY3Rpb24gYWxsb3cgbWV0aG9kc1xuICAgKiBAcmV0dXJucyB7TW9uZ28uQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIGFsbG93KHJ1bGVzKSB7XG4gICAgdGhpcy5jb2xsZWN0aW9uLmFsbG93KHJ1bGVzKTtcbiAgICByZXR1cm4gdGhpcy5jb2xsZWN0aW9uO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIGRlbnlDbGllbnRcbiAgICogQHNlZSBodHRwczovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNNb25nby1Db2xsZWN0aW9uLWRlbnlcbiAgICogQHN1bW1hcnkgU2hvcnRoYW5kcyBmb3IgTW9uZ28uQ29sbGVjdGlvbiBkZW55IG1ldGhvZFxuICAgKiBAcmV0dXJucyB7TW9uZ28uQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIGRlbnlDbGllbnQoKSB7XG4gICAgdGhpcy5jb2xsZWN0aW9uLmRlbnkoe1xuICAgICAgaW5zZXJ0KCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgICAgIHVwZGF0ZSgpIHsgcmV0dXJuIHRydWU7IH0sXG4gICAgICByZW1vdmUoKSB7IHJldHVybiB0cnVlOyB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMuY29sbGVjdGlvbjtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBhbGxvd0NsaWVudFxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI01vbmdvLUNvbGxlY3Rpb24tYWxsb3dcbiAgICogQHN1bW1hcnkgU2hvcnRoYW5kcyBmb3IgTW9uZ28uQ29sbGVjdGlvbiBhbGxvdyBtZXRob2RcbiAgICogQHJldHVybnMge01vbmdvLkNvbGxlY3Rpb259IEluc3RhbmNlXG4gICAqL1xuICBhbGxvd0NsaWVudCgpIHtcbiAgICB0aGlzLmNvbGxlY3Rpb24uYWxsb3coe1xuICAgICAgaW5zZXJ0KCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgICAgIHVwZGF0ZSgpIHsgcmV0dXJuIHRydWU7IH0sXG4gICAgICByZW1vdmUoKSB7IHJldHVybiB0cnVlOyB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMuY29sbGVjdGlvbjtcbiAgfVxuXG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIHVubGlua1xuICAgKiBAcGFyYW0ge09iamVjdH0gZmlsZVJlZiAtIGZpbGVPYmpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHZlcnNpb24gLSBbT3B0aW9uYWxdIGZpbGUncyB2ZXJzaW9uXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gW09wdGlvbmFsXSBjYWxsYmFjayBmdW5jdGlvblxuICAgKiBAc3VtbWFyeSBVbmxpbmsgZmlsZXMgYW5kIGl0J3MgdmVyc2lvbnMgZnJvbSBGU1xuICAgKiBAcmV0dXJucyB7RmlsZXNDb2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgdW5saW5rKGZpbGVSZWYsIHZlcnNpb24sIGNhbGxiYWNrKSB7XG4gICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFt1bmxpbmsoJHtmaWxlUmVmLl9pZH0sICR7dmVyc2lvbn0pXWApO1xuICAgIGlmICh2ZXJzaW9uKSB7XG4gICAgICBpZiAoaGVscGVycy5pc09iamVjdChmaWxlUmVmLnZlcnNpb25zKSAmJiBoZWxwZXJzLmlzT2JqZWN0KGZpbGVSZWYudmVyc2lvbnNbdmVyc2lvbl0pICYmIGZpbGVSZWYudmVyc2lvbnNbdmVyc2lvbl0ucGF0aCkge1xuICAgICAgICBmcy51bmxpbmsoZmlsZVJlZi52ZXJzaW9uc1t2ZXJzaW9uXS5wYXRoLCAoY2FsbGJhY2sgfHwgTk9PUCkpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoaGVscGVycy5pc09iamVjdChmaWxlUmVmLnZlcnNpb25zKSkge1xuICAgICAgICBmb3IobGV0IHZLZXkgaW4gZmlsZVJlZi52ZXJzaW9ucykge1xuICAgICAgICAgIGlmIChmaWxlUmVmLnZlcnNpb25zW3ZLZXldICYmIGZpbGVSZWYudmVyc2lvbnNbdktleV0ucGF0aCkge1xuICAgICAgICAgICAgZnMudW5saW5rKGZpbGVSZWYudmVyc2lvbnNbdktleV0ucGF0aCwgKGNhbGxiYWNrIHx8IE5PT1ApKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZzLnVubGluayhmaWxlUmVmLnBhdGgsIChjYWxsYmFjayB8fCBOT09QKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF80MDRcbiAgICogQHN1bW1hcnkgSW50ZXJuYWwgbWV0aG9kLCB1c2VkIHRvIHJldHVybiA0MDQgZXJyb3JcbiAgICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAgICovXG4gIF80MDQoaHR0cCkge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbZG93bmxvYWQoJHtodHRwLnJlcXVlc3Qub3JpZ2luYWxVcmx9KV0gW180MDRdIEZpbGUgbm90IGZvdW5kYCk7XG4gICAgY29uc3QgdGV4dCA9ICdGaWxlIE5vdCBGb3VuZCA6KCc7XG5cbiAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgIGh0dHAucmVzcG9uc2Uud3JpdGVIZWFkKDQwNCwge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvcGxhaW4nLFxuICAgICAgICAnQ29udGVudC1MZW5ndGgnOiB0ZXh0Lmxlbmd0aFxuICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCFodHRwLnJlc3BvbnNlLmZpbmlzaGVkKSB7XG4gICAgICBodHRwLnJlc3BvbnNlLmVuZCh0ZXh0KTtcbiAgICB9XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgZG93bmxvYWRcbiAgICogQHBhcmFtIHtPYmplY3R9IGh0dHAgICAgLSBTZXJ2ZXIgSFRUUCBvYmplY3RcbiAgICogQHBhcmFtIHtTdHJpbmd9IHZlcnNpb24gLSBSZXF1ZXN0ZWQgZmlsZSB2ZXJzaW9uXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBmaWxlUmVmIC0gUmVxdWVzdGVkIGZpbGUgT2JqZWN0XG4gICAqIEBzdW1tYXJ5IEluaXRpYXRlcyB0aGUgSFRUUCByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgZG93bmxvYWQoaHR0cCwgdmVyc2lvbiA9ICdvcmlnaW5hbCcsIGZpbGVSZWYpIHtcbiAgICBsZXQgdlJlZjtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2Rvd25sb2FkKCR7aHR0cC5yZXF1ZXN0Lm9yaWdpbmFsVXJsfSwgJHt2ZXJzaW9ufSldYCk7XG5cbiAgICBpZiAoZmlsZVJlZikge1xuICAgICAgaWYgKGhlbHBlcnMuaGFzKGZpbGVSZWYsICd2ZXJzaW9ucycpICYmIGhlbHBlcnMuaGFzKGZpbGVSZWYudmVyc2lvbnMsIHZlcnNpb24pKSB7XG4gICAgICAgIHZSZWYgPSBmaWxlUmVmLnZlcnNpb25zW3ZlcnNpb25dO1xuICAgICAgICB2UmVmLl9pZCA9IGZpbGVSZWYuX2lkO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdlJlZiA9IGZpbGVSZWY7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHZSZWYgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIXZSZWYgfHwgIWhlbHBlcnMuaXNPYmplY3QodlJlZikpIHtcbiAgICAgIHJldHVybiB0aGlzLl80MDQoaHR0cCk7XG4gICAgfSBlbHNlIGlmIChmaWxlUmVmKSB7XG4gICAgICBpZiAodGhpcy5kb3dubG9hZENhbGxiYWNrKSB7XG4gICAgICAgIGlmICghdGhpcy5kb3dubG9hZENhbGxiYWNrLmNhbGwoT2JqZWN0LmFzc2lnbihodHRwLCB0aGlzLl9nZXRVc2VyKGh0dHApKSwgZmlsZVJlZikpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fNDA0KGh0dHApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLmludGVyY2VwdERvd25sb2FkICYmIGhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLmludGVyY2VwdERvd25sb2FkKSAmJiB0aGlzLmludGVyY2VwdERvd25sb2FkKGh0dHAsIGZpbGVSZWYsIHZlcnNpb24pID09PSB0cnVlKSB7XG4gICAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgICB9XG5cbiAgICAgIGZzLnN0YXQodlJlZi5wYXRoLCAoc3RhdEVyciwgc3RhdHMpID0+IGJvdW5kKCgpID0+IHtcbiAgICAgICAgbGV0IHJlc3BvbnNlVHlwZTtcbiAgICAgICAgaWYgKHN0YXRFcnIgfHwgIXN0YXRzLmlzRmlsZSgpKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuXzQwNChodHRwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICgoc3RhdHMuc2l6ZSAhPT0gdlJlZi5zaXplKSAmJiAhdGhpcy5pbnRlZ3JpdHlDaGVjaykge1xuICAgICAgICAgIHZSZWYuc2l6ZSA9IHN0YXRzLnNpemU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoKHN0YXRzLnNpemUgIT09IHZSZWYuc2l6ZSkgJiYgdGhpcy5pbnRlZ3JpdHlDaGVjaykge1xuICAgICAgICAgIHJlc3BvbnNlVHlwZSA9ICc0MDAnO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuc2VydmUoaHR0cCwgZmlsZVJlZiwgdlJlZiwgdmVyc2lvbiwgbnVsbCwgKHJlc3BvbnNlVHlwZSB8fCAnMjAwJykpO1xuICAgICAgfSkpO1xuICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuXzQwNChodHRwKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBzZXJ2ZVxuICAgKiBAcGFyYW0ge09iamVjdH0gaHR0cCAgICAtIFNlcnZlciBIVFRQIG9iamVjdFxuICAgKiBAcGFyYW0ge09iamVjdH0gZmlsZVJlZiAtIFJlcXVlc3RlZCBmaWxlIE9iamVjdFxuICAgKiBAcGFyYW0ge09iamVjdH0gdlJlZiAgICAtIFJlcXVlc3RlZCBmaWxlIHZlcnNpb24gT2JqZWN0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSB2ZXJzaW9uIC0gUmVxdWVzdGVkIGZpbGUgdmVyc2lvblxuICAgKiBAcGFyYW0ge3N0cmVhbS5SZWFkYWJsZXxudWxsfSByZWFkYWJsZVN0cmVhbSAtIFJlYWRhYmxlIHN0cmVhbSwgd2hpY2ggc2VydmVzIGJpbmFyeSBmaWxlIGRhdGFcbiAgICogQHBhcmFtIHtTdHJpbmd9IHJlc3BvbnNlVHlwZSAtIFJlc3BvbnNlIGNvZGVcbiAgICogQHBhcmFtIHtCb29sZWFufSBmb3JjZTIwMCAtIEZvcmNlIDIwMCByZXNwb25zZSBjb2RlIG92ZXIgMjA2XG4gICAqIEBzdW1tYXJ5IEhhbmRsZSBhbmQgcmVwbHkgdG8gaW5jb21pbmcgcmVxdWVzdFxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgc2VydmUoaHR0cCwgZmlsZVJlZiwgdlJlZiwgdmVyc2lvbiA9ICdvcmlnaW5hbCcsIHJlYWRhYmxlU3RyZWFtID0gbnVsbCwgX3Jlc3BvbnNlVHlwZSA9ICcyMDAnLCBmb3JjZTIwMCA9IGZhbHNlKSB7XG4gICAgbGV0IHBhcnRpcmFsID0gZmFsc2U7XG4gICAgbGV0IHJlcVJhbmdlID0gZmFsc2U7XG4gICAgbGV0IGRpc3Bvc2l0aW9uVHlwZSA9ICcnO1xuICAgIGxldCBzdGFydDtcbiAgICBsZXQgZW5kO1xuICAgIGxldCB0YWtlO1xuICAgIGxldCByZXNwb25zZVR5cGUgPSBfcmVzcG9uc2VUeXBlO1xuXG4gICAgaWYgKGh0dHAucGFyYW1zLnF1ZXJ5LmRvd25sb2FkICYmIChodHRwLnBhcmFtcy5xdWVyeS5kb3dubG9hZCA9PT0gJ3RydWUnKSkge1xuICAgICAgZGlzcG9zaXRpb25UeXBlID0gJ2F0dGFjaG1lbnQ7ICc7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRpc3Bvc2l0aW9uVHlwZSA9ICdpbmxpbmU7ICc7XG4gICAgfVxuXG4gICAgY29uc3QgZGlzcG9zaXRpb25OYW1lID0gYGZpbGVuYW1lPVxcXCIke2VuY29kZVVSSSh2UmVmLm5hbWUgfHwgZmlsZVJlZi5uYW1lKS5yZXBsYWNlKC9cXCwvZywgJyUyQycpfVxcXCI7IGZpbGVuYW1lKj1VVEYtOCcnJHtlbmNvZGVVUklDb21wb25lbnQodlJlZi5uYW1lIHx8IGZpbGVSZWYubmFtZSl9OyBgO1xuICAgIGNvbnN0IGRpc3Bvc2l0aW9uRW5jb2RpbmcgPSAnY2hhcnNldD1VVEYtOCc7XG5cbiAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgIGh0dHAucmVzcG9uc2Uuc2V0SGVhZGVyKCdDb250ZW50LURpc3Bvc2l0aW9uJywgZGlzcG9zaXRpb25UeXBlICsgZGlzcG9zaXRpb25OYW1lICsgZGlzcG9zaXRpb25FbmNvZGluZyk7XG4gICAgfVxuXG4gICAgaWYgKGh0dHAucmVxdWVzdC5oZWFkZXJzLnJhbmdlICYmICFmb3JjZTIwMCkge1xuICAgICAgcGFydGlyYWwgPSB0cnVlO1xuICAgICAgY29uc3QgYXJyYXkgPSBodHRwLnJlcXVlc3QuaGVhZGVycy5yYW5nZS5zcGxpdCgvYnl0ZXM9KFswLTldKiktKFswLTldKikvKTtcbiAgICAgIHN0YXJ0ID0gcGFyc2VJbnQoYXJyYXlbMV0pO1xuICAgICAgZW5kID0gcGFyc2VJbnQoYXJyYXlbMl0pO1xuICAgICAgaWYgKGlzTmFOKGVuZCkpIHtcbiAgICAgICAgZW5kID0gdlJlZi5zaXplIC0gMTtcbiAgICAgIH1cbiAgICAgIHRha2UgPSBlbmQgLSBzdGFydDtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RhcnQgPSAwO1xuICAgICAgZW5kID0gdlJlZi5zaXplIC0gMTtcbiAgICAgIHRha2UgPSB2UmVmLnNpemU7XG4gICAgfVxuXG4gICAgaWYgKHBhcnRpcmFsIHx8IChodHRwLnBhcmFtcy5xdWVyeS5wbGF5ICYmIChodHRwLnBhcmFtcy5xdWVyeS5wbGF5ID09PSAndHJ1ZScpKSkge1xuICAgICAgcmVxUmFuZ2UgPSB7c3RhcnQsIGVuZH07XG4gICAgICBpZiAoaXNOYU4oc3RhcnQpICYmICFpc05hTihlbmQpKSB7XG4gICAgICAgIHJlcVJhbmdlLnN0YXJ0ID0gZW5kIC0gdGFrZTtcbiAgICAgICAgcmVxUmFuZ2UuZW5kICAgPSBlbmQ7XG4gICAgICB9XG4gICAgICBpZiAoIWlzTmFOKHN0YXJ0KSAmJiBpc05hTihlbmQpKSB7XG4gICAgICAgIHJlcVJhbmdlLnN0YXJ0ID0gc3RhcnQ7XG4gICAgICAgIHJlcVJhbmdlLmVuZCAgID0gc3RhcnQgKyB0YWtlO1xuICAgICAgfVxuXG4gICAgICBpZiAoKHN0YXJ0ICsgdGFrZSkgPj0gdlJlZi5zaXplKSB7XG4gICAgICAgIHJlcVJhbmdlLmVuZCA9IHZSZWYuc2l6ZSAtIDE7XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLnN0cmljdCAmJiAoKHJlcVJhbmdlLnN0YXJ0ID49ICh2UmVmLnNpemUgLSAxKSkgfHwgKHJlcVJhbmdlLmVuZCA+ICh2UmVmLnNpemUgLSAxKSkpKSB7XG4gICAgICAgIHJlc3BvbnNlVHlwZSA9ICc0MTYnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzcG9uc2VUeXBlID0gJzIwNic7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3BvbnNlVHlwZSA9ICcyMDAnO1xuICAgIH1cblxuICAgIGNvbnN0IHN0cmVhbUVycm9ySGFuZGxlciA9IChlcnJvcikgPT4ge1xuICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtzZXJ2ZSgke3ZSZWYucGF0aH0sICR7dmVyc2lvbn0pXSBbNTAwXWAsIGVycm9yKTtcbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5maW5pc2hlZCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLmVuZChlcnJvci50b1N0cmluZygpKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGVhZGVycyA9IGhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLnJlc3BvbnNlSGVhZGVycykgPyB0aGlzLnJlc3BvbnNlSGVhZGVycyhyZXNwb25zZVR5cGUsIGZpbGVSZWYsIHZSZWYsIHZlcnNpb24sIGh0dHApIDogdGhpcy5yZXNwb25zZUhlYWRlcnM7XG5cbiAgICBpZiAoIWhlYWRlcnNbJ0NhY2hlLUNvbnRyb2wnXSkge1xuICAgICAgaWYgKCFodHRwLnJlc3BvbnNlLmhlYWRlcnNTZW50KSB7XG4gICAgICAgIGh0dHAucmVzcG9uc2Uuc2V0SGVhZGVyKCdDYWNoZS1Db250cm9sJywgdGhpcy5jYWNoZUNvbnRyb2wpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGZvciAobGV0IGtleSBpbiBoZWFkZXJzKSB7XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5zZXRIZWFkZXIoa2V5LCBoZWFkZXJzW2tleV0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHJlc3BvbmQgPSAoc3RyZWFtLCBjb2RlKSA9PiB7XG4gICAgICBzdHJlYW0uX2lzRW5kZWQgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGNsb3NlU3RyZWFtQ2IgPSAoY2xvc2VFcnJvcikgPT4ge1xuICAgICAgICBpZiAoIWNsb3NlRXJyb3IpIHtcbiAgICAgICAgICBzdHJlYW0uX2lzRW5kZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbc2VydmUoJHt2UmVmLnBhdGh9LCAke3ZlcnNpb259KV0gW3Jlc3BvbmRdIFtjbG9zZVN0cmVhbUNiXSBFcnJvcjpgLCBjbG9zZUVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgY29uc3QgY2xvc2VTdHJlYW0gPSAoKSA9PiB7XG4gICAgICAgIGlmICghc3RyZWFtLl9pc0VuZGVkKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBzdHJlYW0uY2xvc2UgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHN0cmVhbS5jbG9zZShjbG9zZVN0cmVhbUNiKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBzdHJlYW0uZW5kID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBzdHJlYW0uZW5kKGNsb3NlU3RyZWFtQ2IpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHN0cmVhbS5kZXN0cm95ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBzdHJlYW0uZGVzdHJveSgnR290IHRvIGNsb3NlIHRoaXMgc3RyZWFtJywgY2xvc2VTdHJlYW1DYik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQgJiYgcmVhZGFibGVTdHJlYW0pIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS53cml0ZUhlYWQoY29kZSk7XG4gICAgICB9XG5cbiAgICAgIGh0dHAucmVzcG9uc2Uub24oJ2Nsb3NlJywgY2xvc2VTdHJlYW0pO1xuICAgICAgaHR0cC5yZXF1ZXN0Lm9uKCdhYm9ydGVkJywgKCkgPT4ge1xuICAgICAgICBodHRwLnJlcXVlc3QuYWJvcnRlZCA9IHRydWU7XG4gICAgICAgIGNsb3NlU3RyZWFtKCk7XG4gICAgICB9KTtcblxuICAgICAgc3RyZWFtLm9uKCdvcGVuJywgKCkgPT4ge1xuICAgICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgICBodHRwLnJlc3BvbnNlLndyaXRlSGVhZChjb2RlKTtcbiAgICAgICAgfVxuICAgICAgfSkub24oJ2Fib3J0JywgKCkgPT4ge1xuICAgICAgICBjbG9zZVN0cmVhbSgpO1xuICAgICAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgICAgICBodHRwLnJlc3BvbnNlLmVuZCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaHR0cC5yZXF1ZXN0LmFib3J0ZWQpIHtcbiAgICAgICAgICBodHRwLnJlcXVlc3QuZGVzdHJveSgpO1xuICAgICAgICB9XG4gICAgICB9KS5vbignZXJyb3InLCAoZXJyKSA9PiB7XG4gICAgICAgIGNsb3NlU3RyZWFtKCk7XG4gICAgICAgIHN0cmVhbUVycm9ySGFuZGxlcihlcnIpO1xuICAgICAgfSkub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgY2xvc2VTdHJlYW0oKTtcbiAgICAgICAgaWYgKCFodHRwLnJlc3BvbnNlLmZpbmlzaGVkKSB7XG4gICAgICAgICAgaHR0cC5yZXNwb25zZS5lbmQoKTtcbiAgICAgICAgfVxuICAgICAgfSkucGlwZShodHRwLnJlc3BvbnNlKTtcbiAgICB9O1xuXG4gICAgc3dpdGNoIChyZXNwb25zZVR5cGUpIHtcbiAgICBjYXNlICc0MDAnOlxuICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtzZXJ2ZSgke3ZSZWYucGF0aH0sICR7dmVyc2lvbn0pXSBbNDAwXSBDb250ZW50LUxlbmd0aCBtaXNtYXRjaCFgKTtcbiAgICAgIHZhciB0ZXh0ID0gJ0NvbnRlbnQtTGVuZ3RoIG1pc21hdGNoISc7XG5cbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLndyaXRlSGVhZCg0MDAsIHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvcGxhaW4nLFxuICAgICAgICAgICdDb250ZW50LUxlbmd0aCc6IHRleHQubGVuZ3RoXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5lbmQodGV4dCk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICc0MDQnOlxuICAgICAgdGhpcy5fNDA0KGh0dHApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnNDE2JzpcbiAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbc2VydmUoJHt2UmVmLnBhdGh9LCAke3ZlcnNpb259KV0gWzQxNl0gQ29udGVudC1SYW5nZSBpcyBub3Qgc3BlY2lmaWVkIWApO1xuICAgICAgaWYgKCFodHRwLnJlc3BvbnNlLmhlYWRlcnNTZW50KSB7XG4gICAgICAgIGh0dHAucmVzcG9uc2Uud3JpdGVIZWFkKDQxNik7XG4gICAgICB9XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5lbmQoKTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJzIwNic6XG4gICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3NlcnZlKCR7dlJlZi5wYXRofSwgJHt2ZXJzaW9ufSldIFsyMDZdYCk7XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5zZXRIZWFkZXIoJ0NvbnRlbnQtUmFuZ2UnLCBgYnl0ZXMgJHtyZXFSYW5nZS5zdGFydH0tJHtyZXFSYW5nZS5lbmR9LyR7dlJlZi5zaXplfWApO1xuICAgICAgfVxuICAgICAgcmVzcG9uZChyZWFkYWJsZVN0cmVhbSB8fCBmcy5jcmVhdGVSZWFkU3RyZWFtKHZSZWYucGF0aCwge3N0YXJ0OiByZXFSYW5nZS5zdGFydCwgZW5kOiByZXFSYW5nZS5lbmR9KSwgMjA2KTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5zZXRIZWFkZXIoJ0NvbnRlbnQtTGVuZ3RoJywgYCR7dlJlZi5zaXplfWApO1xuICAgICAgfVxuICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtzZXJ2ZSgke3ZSZWYucGF0aH0sICR7dmVyc2lvbn0pXSBbMjAwXWApO1xuICAgICAgcmVzcG9uZChyZWFkYWJsZVN0cmVhbSB8fCBmcy5jcmVhdGVSZWFkU3RyZWFtKHZSZWYucGF0aCksIDIwMCk7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbn1cbiIsImltcG9ydCB7IEV2ZW50RW1pdHRlciB9ICAgICAgICAgICAgZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSAgICAgICAgICAgIGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBmb3JtYXRGbGVVUkwsIGhlbHBlcnMgfSAgIGZyb20gJy4vbGliLmpzJztcbmltcG9ydCB7IEZpbGVzQ3Vyc29yLCBGaWxlQ3Vyc29yIH0gZnJvbSAnLi9jdXJzb3IuanMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBGaWxlc0NvbGxlY3Rpb25Db3JlIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHN0YXRpYyBfX2hlbHBlcnMgPSBoZWxwZXJzO1xuXG4gIHN0YXRpYyBzY2hlbWEgPSB7XG4gICAgX2lkOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIHNpemU6IHtcbiAgICAgIHR5cGU6IE51bWJlclxuICAgIH0sXG4gICAgbmFtZToge1xuICAgICAgdHlwZTogU3RyaW5nXG4gICAgfSxcbiAgICB0eXBlOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIHBhdGg6IHtcbiAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgaXNWaWRlbzoge1xuICAgICAgdHlwZTogQm9vbGVhblxuICAgIH0sXG4gICAgaXNBdWRpbzoge1xuICAgICAgdHlwZTogQm9vbGVhblxuICAgIH0sXG4gICAgaXNJbWFnZToge1xuICAgICAgdHlwZTogQm9vbGVhblxuICAgIH0sXG4gICAgaXNUZXh0OiB7XG4gICAgICB0eXBlOiBCb29sZWFuXG4gICAgfSxcbiAgICBpc0pTT046IHtcbiAgICAgIHR5cGU6IEJvb2xlYW5cbiAgICB9LFxuICAgIGlzUERGOiB7XG4gICAgICB0eXBlOiBCb29sZWFuXG4gICAgfSxcbiAgICBleHRlbnNpb246IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBleHQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBleHRlbnNpb25XaXRoRG90OiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgbWltZToge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgICdtaW1lLXR5cGUnOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgX3N0b3JhZ2VQYXRoOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIF9kb3dubG9hZFJvdXRlOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIF9jb2xsZWN0aW9uTmFtZToge1xuICAgICAgdHlwZTogU3RyaW5nXG4gICAgfSxcbiAgICBwdWJsaWM6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgbWV0YToge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgYmxhY2tib3g6IHRydWUsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgdXNlcklkOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgdXBkYXRlZEF0OiB7XG4gICAgICB0eXBlOiBEYXRlLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIHZlcnNpb25zOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBibGFja2JveDogdHJ1ZVxuICAgIH1cbiAgfTtcblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgX2RlYnVnXG4gICAqIEBzdW1tYXJ5IFByaW50IGxvZ3MgaW4gZGVidWcgbW9kZVxuICAgKiBAcmV0dXJucyB7dm9pZH1cbiAgICovXG4gIF9kZWJ1ZygpIHtcbiAgICBpZiAodGhpcy5kZWJ1Zykge1xuICAgICAgKGNvbnNvbGUuaW5mbyB8fCBjb25zb2xlLmxvZyB8fCBmdW5jdGlvbiAoKSB7IH0pLmFwcGx5KHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgICB9XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgX2dldEZpbGVOYW1lXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBmaWxlRGF0YSAtIEZpbGUgT2JqZWN0XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgZmlsZSdzIG5hbWVcbiAgICogQHJldHVybnMge1N0cmluZ31cbiAgICovXG4gIF9nZXRGaWxlTmFtZShmaWxlRGF0YSkge1xuICAgIGNvbnN0IGZpbGVOYW1lID0gZmlsZURhdGEubmFtZSB8fCBmaWxlRGF0YS5maWxlTmFtZTtcbiAgICBpZiAoaGVscGVycy5pc1N0cmluZyhmaWxlTmFtZSkgJiYgKGZpbGVOYW1lLmxlbmd0aCA+IDApKSB7XG4gICAgICByZXR1cm4gKGZpbGVEYXRhLm5hbWUgfHwgZmlsZURhdGEuZmlsZU5hbWUpLnJlcGxhY2UoL15cXC5cXC4rLywgJycpLnJlcGxhY2UoL1xcLnsyLH0vZywgJy4nKS5yZXBsYWNlKC9cXC8vZywgJycpO1xuICAgIH1cbiAgICByZXR1cm4gJyc7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgX2dldEV4dFxuICAgKiBAcGFyYW0ge1N0cmluZ30gRmlsZU5hbWUgLSBGaWxlIG5hbWVcbiAgICogQHN1bW1hcnkgR2V0IGV4dGVuc2lvbiBmcm9tIEZpbGVOYW1lXG4gICAqIEByZXR1cm5zIHtPYmplY3R9XG4gICAqL1xuICBfZ2V0RXh0KGZpbGVOYW1lKSB7XG4gICAgaWYgKGZpbGVOYW1lLmluY2x1ZGVzKCcuJykpIHtcbiAgICAgIGNvbnN0IGV4dGVuc2lvbiA9IChmaWxlTmFtZS5zcGxpdCgnLicpLnBvcCgpLnNwbGl0KCc/JylbMF0gfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gICAgICByZXR1cm4geyBleHQ6IGV4dGVuc2lvbiwgZXh0ZW5zaW9uLCBleHRlbnNpb25XaXRoRG90OiBgLiR7ZXh0ZW5zaW9ufWAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHsgZXh0OiAnJywgZXh0ZW5zaW9uOiAnJywgZXh0ZW5zaW9uV2l0aERvdDogJycgfTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBfdXBkYXRlRmlsZVR5cGVzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIC0gRmlsZSBkYXRhXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gQ2xhc3NpZnkgZmlsZSBiYXNlZCBvbiAndHlwZScgZmllbGRcbiAgICovXG4gIF91cGRhdGVGaWxlVHlwZXMoZGF0YSkge1xuICAgIGRhdGEuaXNWaWRlbyAgPSAvXnZpZGVvXFwvL2kudGVzdChkYXRhLnR5cGUpO1xuICAgIGRhdGEuaXNBdWRpbyAgPSAvXmF1ZGlvXFwvL2kudGVzdChkYXRhLnR5cGUpO1xuICAgIGRhdGEuaXNJbWFnZSAgPSAvXmltYWdlXFwvL2kudGVzdChkYXRhLnR5cGUpO1xuICAgIGRhdGEuaXNUZXh0ICAgPSAvXnRleHRcXC8vaS50ZXN0KGRhdGEudHlwZSk7XG4gICAgZGF0YS5pc0pTT04gICA9IC9eYXBwbGljYXRpb25cXC9qc29uJC9pLnRlc3QoZGF0YS50eXBlKTtcbiAgICBkYXRhLmlzUERGICAgID0gL15hcHBsaWNhdGlvblxcLyh4LSk/cGRmJC9pLnRlc3QoZGF0YS50eXBlKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBfZGF0YVRvU2NoZW1hXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIC0gRmlsZSBkYXRhXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gQnVpbGQgb2JqZWN0IGluIGFjY29yZGFuY2Ugd2l0aCBkZWZhdWx0IHNjaGVtYSBmcm9tIEZpbGUgZGF0YVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgX2RhdGFUb1NjaGVtYShkYXRhKSB7XG4gICAgY29uc3QgZHMgPSB7XG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICBleHRlbnNpb246IGRhdGEuZXh0ZW5zaW9uLFxuICAgICAgZXh0OiBkYXRhLmV4dGVuc2lvbixcbiAgICAgIGV4dGVuc2lvbldpdGhEb3Q6ICcuJyArIGRhdGEuZXh0ZW5zaW9uLFxuICAgICAgcGF0aDogZGF0YS5wYXRoLFxuICAgICAgbWV0YTogZGF0YS5tZXRhLFxuICAgICAgdHlwZTogZGF0YS50eXBlLFxuICAgICAgbWltZTogZGF0YS50eXBlLFxuICAgICAgJ21pbWUtdHlwZSc6IGRhdGEudHlwZSxcbiAgICAgIHNpemU6IGRhdGEuc2l6ZSxcbiAgICAgIHVzZXJJZDogZGF0YS51c2VySWQgfHwgbnVsbCxcbiAgICAgIHZlcnNpb25zOiB7XG4gICAgICAgIG9yaWdpbmFsOiB7XG4gICAgICAgICAgcGF0aDogZGF0YS5wYXRoLFxuICAgICAgICAgIHNpemU6IGRhdGEuc2l6ZSxcbiAgICAgICAgICB0eXBlOiBkYXRhLnR5cGUsXG4gICAgICAgICAgZXh0ZW5zaW9uOiBkYXRhLmV4dGVuc2lvblxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgX2Rvd25sb2FkUm91dGU6IGRhdGEuX2Rvd25sb2FkUm91dGUgfHwgdGhpcy5kb3dubG9hZFJvdXRlLFxuICAgICAgX2NvbGxlY3Rpb25OYW1lOiBkYXRhLl9jb2xsZWN0aW9uTmFtZSB8fCB0aGlzLmNvbGxlY3Rpb25OYW1lXG4gICAgfTtcblxuICAgIC8vT3B0aW9uYWwgZmlsZUlkXG4gICAgaWYgKGRhdGEuZmlsZUlkKSB7XG4gICAgICBkcy5faWQgPSBkYXRhLmZpbGVJZDtcbiAgICB9XG5cbiAgICB0aGlzLl91cGRhdGVGaWxlVHlwZXMoZHMpO1xuICAgIGRzLl9zdG9yYWdlUGF0aCA9IGRhdGEuX3N0b3JhZ2VQYXRoIHx8IHRoaXMuc3RvcmFnZVBhdGgoT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgZHMpKTtcbiAgICByZXR1cm4gZHM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgZmluZE9uZVxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IHNlbGVjdG9yIC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgKGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjc2VsZWN0b3JzKVxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE1vbmdvLVN0eWxlIHNlbGVjdG9yIE9wdGlvbnMgKGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjc29ydHNwZWNpZmllcnMpXG4gICAqIEBzdW1tYXJ5IEZpbmQgYW5kIHJldHVybiBDdXJzb3IgZm9yIG1hdGNoaW5nIGRvY3VtZW50IE9iamVjdFxuICAgKiBAcmV0dXJucyB7RmlsZUN1cnNvcn0gSW5zdGFuY2VcbiAgICovXG4gIGZpbmRPbmUoc2VsZWN0b3IgPSB7fSwgb3B0aW9ucykge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbZmluZE9uZSgke0pTT04uc3RyaW5naWZ5KHNlbGVjdG9yKX0sICR7SlNPTi5zdHJpbmdpZnkob3B0aW9ucyl9KV1gKTtcbiAgICBjaGVjayhzZWxlY3RvciwgTWF0Y2guT3B0aW9uYWwoTWF0Y2guT25lT2YoT2JqZWN0LCBTdHJpbmcsIEJvb2xlYW4sIE51bWJlciwgbnVsbCkpKTtcbiAgICBjaGVjayhvcHRpb25zLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcblxuICAgIGNvbnN0IGRvYyA9IHRoaXMuY29sbGVjdGlvbi5maW5kT25lKHNlbGVjdG9yLCBvcHRpb25zKTtcbiAgICBpZiAoZG9jKSB7XG4gICAgICByZXR1cm4gbmV3IEZpbGVDdXJzb3IoZG9jLCB0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIGRvYztcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBmaW5kXG4gICAqIEBwYXJhbSB7U3RyaW5nfE9iamVjdH0gc2VsZWN0b3IgLSBNb25nby1TdHlsZSBzZWxlY3RvciAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzZWxlY3RvcnMpXG4gICAqIEBwYXJhbSB7T2JqZWN0fSAgICAgICAgb3B0aW9ucyAgLSBNb25nby1TdHlsZSBzZWxlY3RvciBPcHRpb25zIChodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI3NvcnRzcGVjaWZpZXJzKVxuICAgKiBAc3VtbWFyeSBGaW5kIGFuZCByZXR1cm4gQ3Vyc29yIGZvciBtYXRjaGluZyBkb2N1bWVudHNcbiAgICogQHJldHVybnMge0ZpbGVzQ3Vyc29yfSBJbnN0YW5jZVxuICAgKi9cbiAgZmluZChzZWxlY3RvciA9IHt9LCBvcHRpb25zKSB7XG4gICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtmaW5kKCR7SlNPTi5zdHJpbmdpZnkoc2VsZWN0b3IpfSwgJHtKU09OLnN0cmluZ2lmeShvcHRpb25zKX0pXWApO1xuICAgIGNoZWNrKHNlbGVjdG9yLCBNYXRjaC5PcHRpb25hbChNYXRjaC5PbmVPZihPYmplY3QsIFN0cmluZywgQm9vbGVhbiwgTnVtYmVyLCBudWxsKSkpO1xuICAgIGNoZWNrKG9wdGlvbnMsIE1hdGNoLk9wdGlvbmFsKE9iamVjdCkpO1xuXG4gICAgcmV0dXJuIG5ldyBGaWxlc0N1cnNvcihzZWxlY3Rvciwgb3B0aW9ucywgdGhpcyk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgdXBkYXRlXG4gICAqIEBzZWUgaHR0cDovL2RvY3MubWV0ZW9yLmNvbS8jL2Z1bGwvdXBkYXRlXG4gICAqIEBzdW1tYXJ5IGxpbmsgTW9uZ28uQ29sbGVjdGlvbiB1cGRhdGUgbWV0aG9kXG4gICAqIEByZXR1cm5zIHtNb25nby5Db2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgdXBkYXRlKCkge1xuICAgIHRoaXMuY29sbGVjdGlvbi51cGRhdGUuYXBwbHkodGhpcy5jb2xsZWN0aW9uLCBhcmd1bWVudHMpO1xuICAgIHJldHVybiB0aGlzLmNvbGxlY3Rpb247XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgbGlua1xuICAgKiBAcGFyYW0ge09iamVjdH0gZmlsZVJlZiAtIEZpbGUgcmVmZXJlbmNlIG9iamVjdFxuICAgKiBAcGFyYW0ge1N0cmluZ30gdmVyc2lvbiAtIFZlcnNpb24gb2YgZmlsZSB5b3Ugd291bGQgbGlrZSB0byByZXF1ZXN0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBVUklCYXNlIC0gW09wdGlvbmFsXSBVUkkgYmFzZSwgc2VlIC0gaHR0cHM6Ly9naXRodWIuY29tL1ZlbGlvdkdyb3VwL01ldGVvci1GaWxlcy9pc3N1ZXMvNjI2XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgZG93bmxvYWRhYmxlIFVSTFxuICAgKiBAcmV0dXJucyB7U3RyaW5nfSBFbXB0eSBzdHJpbmcgcmV0dXJuZWQgaW4gY2FzZSBpZiBmaWxlIG5vdCBmb3VuZCBpbiBEQlxuICAgKi9cbiAgbGluayhmaWxlUmVmLCB2ZXJzaW9uID0gJ29yaWdpbmFsJywgVVJJQmFzZSkge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbGluaygkeyhoZWxwZXJzLmlzT2JqZWN0KGZpbGVSZWYpID8gZmlsZVJlZi5faWQgOiB2b2lkIDApfSwgJHt2ZXJzaW9ufSldYCk7XG4gICAgY2hlY2soZmlsZVJlZiwgT2JqZWN0KTtcblxuICAgIGlmICghZmlsZVJlZikge1xuICAgICAgcmV0dXJuICcnO1xuICAgIH1cbiAgICByZXR1cm4gZm9ybWF0RmxlVVJMKGZpbGVSZWYsIHZlcnNpb24sIFVSSUJhc2UpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuLypcbiAqIEBwcml2YXRlXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBjbGFzcyBGaWxlQ3Vyc29yXG4gKiBAcGFyYW0gX2ZpbGVSZWYgICAge09iamVjdH0gLSBNb25nby1TdHlsZSBzZWxlY3RvciAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzZWxlY3RvcnMpXG4gKiBAcGFyYW0gX2NvbGxlY3Rpb24ge0ZpbGVzQ29sbGVjdGlvbn0gLSBGaWxlc0NvbGxlY3Rpb24gSW5zdGFuY2VcbiAqIEBzdW1tYXJ5IEludGVybmFsIGNsYXNzLCByZXByZXNlbnRzIGVhY2ggcmVjb3JkIGluIGBGaWxlc0N1cnNvci5lYWNoKClgIG9yIGRvY3VtZW50IHJldHVybmVkIGZyb20gYC5maW5kT25lKClgIG1ldGhvZFxuICovXG5leHBvcnQgY2xhc3MgRmlsZUN1cnNvciB7XG4gIGNvbnN0cnVjdG9yKF9maWxlUmVmLCBfY29sbGVjdGlvbikge1xuICAgIHRoaXMuX2ZpbGVSZWYgICAgPSBfZmlsZVJlZjtcbiAgICB0aGlzLl9jb2xsZWN0aW9uID0gX2NvbGxlY3Rpb247XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLCBfZmlsZVJlZik7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVDdXJzb3JcbiAgICogQG5hbWUgcmVtb3ZlXG4gICAqIEBwYXJhbSBjYWxsYmFjayB7RnVuY3Rpb259IC0gVHJpZ2dlcmVkIGFzeW5jaHJvbm91c2x5IGFmdGVyIGl0ZW0gaXMgcmVtb3ZlZCBvciBmYWlsZWQgdG8gYmUgcmVtb3ZlZFxuICAgKiBAc3VtbWFyeSBSZW1vdmUgZG9jdW1lbnRcbiAgICogQHJldHVybnMge0ZpbGVDdXJzb3J9XG4gICAqL1xuICByZW1vdmUoY2FsbGJhY2spIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVDdXJzb3JdIFtyZW1vdmUoKV0nKTtcbiAgICBpZiAodGhpcy5fZmlsZVJlZikge1xuICAgICAgdGhpcy5fY29sbGVjdGlvbi5yZW1vdmUodGhpcy5fZmlsZVJlZi5faWQsIGNhbGxiYWNrKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2sobmV3IE1ldGVvci5FcnJvcig0MDQsICdObyBzdWNoIGZpbGUnKSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlQ3Vyc29yXG4gICAqIEBuYW1lIGxpbmtcbiAgICogQHBhcmFtIHZlcnNpb24ge1N0cmluZ30gLSBOYW1lIG9mIGZpbGUncyBzdWJ2ZXJzaW9uXG4gICAqIEBwYXJhbSBVUklCYXNlIHtTdHJpbmd9IC0gW09wdGlvbmFsXSBVUkkgYmFzZSwgc2VlIC0gaHR0cHM6Ly9naXRodWIuY29tL1ZlbGlvdkdyb3VwL01ldGVvci1GaWxlcy9pc3N1ZXMvNjI2XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgZG93bmxvYWRhYmxlIFVSTCB0byBGaWxlXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9XG4gICAqL1xuICBsaW5rKHZlcnNpb24gPSAnb3JpZ2luYWwnLCBVUklCYXNlKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtGaWxlQ3Vyc29yXSBbbGluaygke3ZlcnNpb259KV1gKTtcbiAgICBpZiAodGhpcy5fZmlsZVJlZikge1xuICAgICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24ubGluayh0aGlzLl9maWxlUmVmLCB2ZXJzaW9uLCBVUklCYXNlKTtcbiAgICB9XG4gICAgcmV0dXJuICcnO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlQ3Vyc29yXG4gICAqIEBuYW1lIGdldFxuICAgKiBAcGFyYW0gcHJvcGVydHkge1N0cmluZ30gLSBOYW1lIG9mIHN1Yi1vYmplY3QgcHJvcGVydHlcbiAgICogQHN1bW1hcnkgUmV0dXJucyBjdXJyZW50IGRvY3VtZW50IGFzIGEgcGxhaW4gT2JqZWN0LCBpZiBgcHJvcGVydHlgIGlzIHNwZWNpZmllZCAtIHJldHVybnMgdmFsdWUgb2Ygc3ViLW9iamVjdCBwcm9wZXJ0eVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fG1peH1cbiAgICovXG4gIGdldChwcm9wZXJ0eSkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZUN1cnNvcl0gW2dldCgke3Byb3BlcnR5fSldYCk7XG4gICAgaWYgKHByb3BlcnR5KSB7XG4gICAgICByZXR1cm4gdGhpcy5fZmlsZVJlZltwcm9wZXJ0eV07XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9maWxlUmVmO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlQ3Vyc29yXG4gICAqIEBuYW1lIGZldGNoXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgZG9jdW1lbnQgYXMgcGxhaW4gT2JqZWN0IGluIEFycmF5XG4gICAqIEByZXR1cm5zIHtbT2JqZWN0XX1cbiAgICovXG4gIGZldGNoKCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZUN1cnNvcl0gW2ZldGNoKCldJyk7XG4gICAgcmV0dXJuIFt0aGlzLl9maWxlUmVmXTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZUN1cnNvclxuICAgKiBAbmFtZSB3aXRoXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgcmVhY3RpdmUgdmVyc2lvbiBvZiBjdXJyZW50IEZpbGVDdXJzb3IsIHVzZWZ1bCB0byB1c2Ugd2l0aCBge3sjd2l0aH19Li4ue3svd2l0aH19YCBibG9jayB0ZW1wbGF0ZSBoZWxwZXJcbiAgICogQHJldHVybnMge1tPYmplY3RdfVxuICAgKi9cbiAgd2l0aCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVDdXJzb3JdIFt3aXRoKCldJyk7XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24odGhpcywgdGhpcy5fY29sbGVjdGlvbi5jb2xsZWN0aW9uLmZpbmRPbmUodGhpcy5fZmlsZVJlZi5faWQpKTtcbiAgfVxufVxuXG4vKlxuICogQHByaXZhdGVcbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGNsYXNzIEZpbGVzQ3Vyc29yXG4gKiBAcGFyYW0gX3NlbGVjdG9yICAge1N0cmluZ3xPYmplY3R9ICAgLSBNb25nby1TdHlsZSBzZWxlY3RvciAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzZWxlY3RvcnMpXG4gKiBAcGFyYW0gb3B0aW9ucyAgICAge09iamVjdH0gICAgICAgICAgLSBNb25nby1TdHlsZSBzZWxlY3RvciBPcHRpb25zIChodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI3NlbGVjdG9ycylcbiAqIEBwYXJhbSBfY29sbGVjdGlvbiB7RmlsZXNDb2xsZWN0aW9ufSAtIEZpbGVzQ29sbGVjdGlvbiBJbnN0YW5jZVxuICogQHN1bW1hcnkgSW1wbGVtZW50YXRpb24gb2YgQ3Vyc29yIGZvciBGaWxlc0NvbGxlY3Rpb25cbiAqL1xuZXhwb3J0IGNsYXNzIEZpbGVzQ3Vyc29yIHtcbiAgY29uc3RydWN0b3IoX3NlbGVjdG9yID0ge30sIG9wdGlvbnMsIF9jb2xsZWN0aW9uKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbiA9IF9jb2xsZWN0aW9uO1xuICAgIHRoaXMuX3NlbGVjdG9yICAgPSBfc2VsZWN0b3I7XG4gICAgdGhpcy5fY3VycmVudCAgICA9IC0xO1xuICAgIHRoaXMuY3Vyc29yICAgICAgPSB0aGlzLl9jb2xsZWN0aW9uLmNvbGxlY3Rpb24uZmluZCh0aGlzLl9zZWxlY3Rvciwgb3B0aW9ucyk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGdldFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGFsbCBtYXRjaGluZyBkb2N1bWVudChzKSBhcyBhbiBBcnJheS4gQWxpYXMgb2YgYC5mZXRjaCgpYFxuICAgKiBAcmV0dXJucyB7W09iamVjdF19XG4gICAqL1xuICBnZXQoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW2dldCgpXScpO1xuICAgIHJldHVybiB0aGlzLmN1cnNvci5mZXRjaCgpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBoYXNOZXh0XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgYHRydWVgIGlmIHRoZXJlIGlzIG5leHQgaXRlbSBhdmFpbGFibGUgb24gQ3Vyc29yXG4gICAqIEByZXR1cm5zIHtCb29sZWFufVxuICAgKi9cbiAgaGFzTmV4dCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbaGFzTmV4dCgpXScpO1xuICAgIHJldHVybiB0aGlzLl9jdXJyZW50IDwgKHRoaXMuY3Vyc29yLmNvdW50KCkgLSAxKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgbmV4dFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIG5leHQgaXRlbSBvbiBDdXJzb3IsIGlmIGF2YWlsYWJsZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fHVuZGVmaW5lZH1cbiAgICovXG4gIG5leHQoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW25leHQoKV0nKTtcbiAgICB0aGlzLmN1cnNvci5mZXRjaCgpWysrdGhpcy5fY3VycmVudF07XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGhhc1ByZXZpb3VzXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgYHRydWVgIGlmIHRoZXJlIGlzIHByZXZpb3VzIGl0ZW0gYXZhaWxhYmxlIG9uIEN1cnNvclxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn1cbiAgICovXG4gIGhhc1ByZXZpb3VzKCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtoYXNQcmV2aW91cygpXScpO1xuICAgIHJldHVybiB0aGlzLl9jdXJyZW50ICE9PSAtMTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgcHJldmlvdXNcbiAgICogQHN1bW1hcnkgUmV0dXJucyBwcmV2aW91cyBpdGVtIG9uIEN1cnNvciwgaWYgYXZhaWxhYmxlXG4gICAqIEByZXR1cm5zIHtPYmplY3R8dW5kZWZpbmVkfVxuICAgKi9cbiAgcHJldmlvdXMoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW3ByZXZpb3VzKCldJyk7XG4gICAgdGhpcy5jdXJzb3IuZmV0Y2goKVstLXRoaXMuX2N1cnJlbnRdO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBmZXRjaFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGFsbCBtYXRjaGluZyBkb2N1bWVudChzKSBhcyBhbiBBcnJheS5cbiAgICogQHJldHVybnMge1tPYmplY3RdfVxuICAgKi9cbiAgZmV0Y2goKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW2ZldGNoKCldJyk7XG4gICAgcmV0dXJuIHRoaXMuY3Vyc29yLmZldGNoKCkgfHwgW107XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGZpcnN0XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgZmlyc3QgaXRlbSBvbiBDdXJzb3IsIGlmIGF2YWlsYWJsZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fHVuZGVmaW5lZH1cbiAgICovXG4gIGZpcnN0KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtmaXJzdCgpXScpO1xuICAgIHRoaXMuX2N1cnJlbnQgPSAwO1xuICAgIHJldHVybiB0aGlzLmZldGNoKClbdGhpcy5fY3VycmVudF07XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGxhc3RcbiAgICogQHN1bW1hcnkgUmV0dXJucyBsYXN0IGl0ZW0gb24gQ3Vyc29yLCBpZiBhdmFpbGFibGVcbiAgICogQHJldHVybnMge09iamVjdHx1bmRlZmluZWR9XG4gICAqL1xuICBsYXN0KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtsYXN0KCldJyk7XG4gICAgdGhpcy5fY3VycmVudCA9IHRoaXMuY291bnQoKSAtIDE7XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2goKVt0aGlzLl9jdXJyZW50XTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgY291bnRcbiAgICogQHN1bW1hcnkgUmV0dXJucyB0aGUgbnVtYmVyIG9mIGRvY3VtZW50cyB0aGF0IG1hdGNoIGEgcXVlcnlcbiAgICogQHJldHVybnMge051bWJlcn1cbiAgICovXG4gIGNvdW50KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtjb3VudCgpXScpO1xuICAgIHJldHVybiB0aGlzLmN1cnNvci5jb3VudCgpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSByZW1vdmVcbiAgICogQHBhcmFtIGNhbGxiYWNrIHtGdW5jdGlvbn0gLSBUcmlnZ2VyZWQgYXN5bmNocm9ub3VzbHkgYWZ0ZXIgaXRlbSBpcyByZW1vdmVkIG9yIGZhaWxlZCB0byBiZSByZW1vdmVkXG4gICAqIEBzdW1tYXJ5IFJlbW92ZXMgYWxsIGRvY3VtZW50cyB0aGF0IG1hdGNoIGEgcXVlcnlcbiAgICogQHJldHVybnMge0ZpbGVzQ3Vyc29yfVxuICAgKi9cbiAgcmVtb3ZlKGNhbGxiYWNrKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW3JlbW92ZSgpXScpO1xuICAgIHRoaXMuX2NvbGxlY3Rpb24ucmVtb3ZlKHRoaXMuX3NlbGVjdG9yLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGZvckVhY2hcbiAgICogQHBhcmFtIGNhbGxiYWNrIHtGdW5jdGlvbn0gLSBGdW5jdGlvbiB0byBjYWxsLiBJdCB3aWxsIGJlIGNhbGxlZCB3aXRoIHRocmVlIGFyZ3VtZW50czogdGhlIGBmaWxlYCwgYSAwLWJhc2VkIGluZGV4LCBhbmQgY3Vyc29yIGl0c2VsZlxuICAgKiBAcGFyYW0gY29udGV4dCB7T2JqZWN0fSAtIEFuIG9iamVjdCB3aGljaCB3aWxsIGJlIHRoZSB2YWx1ZSBvZiBgdGhpc2AgaW5zaWRlIGBjYWxsYmFja2BcbiAgICogQHN1bW1hcnkgQ2FsbCBgY2FsbGJhY2tgIG9uY2UgZm9yIGVhY2ggbWF0Y2hpbmcgZG9jdW1lbnQsIHNlcXVlbnRpYWxseSBhbmQgc3luY2hyb25vdXNseS5cbiAgICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAgICovXG4gIGZvckVhY2goY2FsbGJhY2ssIGNvbnRleHQgPSB7fSkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtmb3JFYWNoKCldJyk7XG4gICAgdGhpcy5jdXJzb3IuZm9yRWFjaChjYWxsYmFjaywgY29udGV4dCk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGVhY2hcbiAgICogQHN1bW1hcnkgUmV0dXJucyBhbiBBcnJheSBvZiBGaWxlQ3Vyc29yIG1hZGUgZm9yIGVhY2ggZG9jdW1lbnQgb24gY3VycmVudCBjdXJzb3JcbiAgICogICAgICAgICAgVXNlZnVsIHdoZW4gdXNpbmcgaW4ge3sjZWFjaCBGaWxlc0N1cnNvciNlYWNofX0uLi57ey9lYWNofX0gYmxvY2sgdGVtcGxhdGUgaGVscGVyXG4gICAqIEByZXR1cm5zIHtbRmlsZUN1cnNvcl19XG4gICAqL1xuICBlYWNoKCkge1xuICAgIHJldHVybiB0aGlzLm1hcCgoZmlsZSkgPT4ge1xuICAgICAgcmV0dXJuIG5ldyBGaWxlQ3Vyc29yKGZpbGUsIHRoaXMuX2NvbGxlY3Rpb24pO1xuICAgIH0pO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBtYXBcbiAgICogQHBhcmFtIGNhbGxiYWNrIHtGdW5jdGlvbn0gLSBGdW5jdGlvbiB0byBjYWxsLiBJdCB3aWxsIGJlIGNhbGxlZCB3aXRoIHRocmVlIGFyZ3VtZW50czogdGhlIGBmaWxlYCwgYSAwLWJhc2VkIGluZGV4LCBhbmQgY3Vyc29yIGl0c2VsZlxuICAgKiBAcGFyYW0gY29udGV4dCB7T2JqZWN0fSAtIEFuIG9iamVjdCB3aGljaCB3aWxsIGJlIHRoZSB2YWx1ZSBvZiBgdGhpc2AgaW5zaWRlIGBjYWxsYmFja2BcbiAgICogQHN1bW1hcnkgTWFwIGBjYWxsYmFja2Agb3ZlciBhbGwgbWF0Y2hpbmcgZG9jdW1lbnRzLiBSZXR1cm5zIGFuIEFycmF5LlxuICAgKiBAcmV0dXJucyB7QXJyYXl9XG4gICAqL1xuICBtYXAoY2FsbGJhY2ssIGNvbnRleHQgPSB7fSkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFttYXAoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5jdXJzb3IubWFwKGNhbGxiYWNrLCBjb250ZXh0KTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgY3VycmVudFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGN1cnJlbnQgaXRlbSBvbiBDdXJzb3IsIGlmIGF2YWlsYWJsZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fHVuZGVmaW5lZH1cbiAgICovXG4gIGN1cnJlbnQoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW2N1cnJlbnQoKV0nKTtcbiAgICBpZiAodGhpcy5fY3VycmVudCA8IDApIHtcbiAgICAgIHRoaXMuX2N1cnJlbnQgPSAwO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5mZXRjaCgpW3RoaXMuX2N1cnJlbnRdO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBvYnNlcnZlXG4gICAqIEBwYXJhbSBjYWxsYmFja3Mge09iamVjdH0gLSBGdW5jdGlvbnMgdG8gY2FsbCB0byBkZWxpdmVyIHRoZSByZXN1bHQgc2V0IGFzIGl0IGNoYW5nZXNcbiAgICogQHN1bW1hcnkgV2F0Y2ggYSBxdWVyeS4gUmVjZWl2ZSBjYWxsYmFja3MgYXMgdGhlIHJlc3VsdCBzZXQgY2hhbmdlcy5cbiAgICogQHVybCBodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI01vbmdvLUN1cnNvci1vYnNlcnZlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IC0gbGl2ZSBxdWVyeSBoYW5kbGVcbiAgICovXG4gIG9ic2VydmUoY2FsbGJhY2tzKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW29ic2VydmUoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5jdXJzb3Iub2JzZXJ2ZShjYWxsYmFja3MpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBvYnNlcnZlQ2hhbmdlc1xuICAgKiBAcGFyYW0gY2FsbGJhY2tzIHtPYmplY3R9IC0gRnVuY3Rpb25zIHRvIGNhbGwgdG8gZGVsaXZlciB0aGUgcmVzdWx0IHNldCBhcyBpdCBjaGFuZ2VzXG4gICAqIEBzdW1tYXJ5IFdhdGNoIGEgcXVlcnkuIFJlY2VpdmUgY2FsbGJhY2tzIGFzIHRoZSByZXN1bHQgc2V0IGNoYW5nZXMuIE9ubHkgdGhlIGRpZmZlcmVuY2VzIGJldHdlZW4gdGhlIG9sZCBhbmQgbmV3IGRvY3VtZW50cyBhcmUgcGFzc2VkIHRvIHRoZSBjYWxsYmFja3MuXG4gICAqIEB1cmwgaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNNb25nby1DdXJzb3Itb2JzZXJ2ZUNoYW5nZXNcbiAgICogQHJldHVybnMge09iamVjdH0gLSBsaXZlIHF1ZXJ5IGhhbmRsZVxuICAgKi9cbiAgb2JzZXJ2ZUNoYW5nZXMoY2FsbGJhY2tzKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW29ic2VydmVDaGFuZ2VzKCldJyk7XG4gICAgcmV0dXJuIHRoaXMuY3Vyc29yLm9ic2VydmVDaGFuZ2VzKGNhbGxiYWNrcyk7XG4gIH1cbn1cbiIsImltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcblxuY29uc3QgaGVscGVycyA9IHtcbiAgaXNVbmRlZmluZWQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiA9PT0gdm9pZCAwO1xuICB9LFxuICBpc09iamVjdChvYmopIHtcbiAgICBpZiAodGhpcy5pc0FycmF5KG9iaikgfHwgdGhpcy5pc0Z1bmN0aW9uKG9iaikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIG9iaiA9PT0gT2JqZWN0KG9iaik7XG4gIH0sXG4gIGlzQXJyYXkob2JqKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkob2JqKTtcbiAgfSxcbiAgaXNCb29sZWFuKG9iaikge1xuICAgIHJldHVybiBvYmogPT09IHRydWUgfHwgb2JqID09PSBmYWxzZSB8fCBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqKSA9PT0gJ1tvYmplY3QgQm9vbGVhbl0nO1xuICB9LFxuICBpc0Z1bmN0aW9uKG9iaikge1xuICAgIHJldHVybiB0eXBlb2Ygb2JqID09PSAnZnVuY3Rpb24nIHx8IGZhbHNlO1xuICB9LFxuICBpc0VtcHR5KG9iaikge1xuICAgIGlmICh0aGlzLmlzRGF0ZShvYmopKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0aGlzLmlzT2JqZWN0KG9iaikpIHtcbiAgICAgIHJldHVybiAhT2JqZWN0LmtleXMob2JqKS5sZW5ndGg7XG4gICAgfVxuICAgIGlmICh0aGlzLmlzQXJyYXkob2JqKSB8fCB0aGlzLmlzU3RyaW5nKG9iaikpIHtcbiAgICAgIHJldHVybiAhb2JqLmxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuICBjbG9uZShvYmopIHtcbiAgICBpZiAoIXRoaXMuaXNPYmplY3Qob2JqKSkgcmV0dXJuIG9iajtcbiAgICByZXR1cm4gdGhpcy5pc0FycmF5KG9iaikgPyBvYmouc2xpY2UoKSA6IE9iamVjdC5hc3NpZ24oe30sIG9iaik7XG4gIH0sXG4gIGhhcyhfb2JqLCBwYXRoKSB7XG4gICAgbGV0IG9iaiA9IF9vYmo7XG4gICAgaWYgKCF0aGlzLmlzT2JqZWN0KG9iaikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmlzQXJyYXkocGF0aCkpIHtcbiAgICAgIHJldHVybiB0aGlzLmlzT2JqZWN0KG9iaikgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcGF0aCk7XG4gICAgfVxuXG4gICAgY29uc3QgbGVuZ3RoID0gcGF0aC5sZW5ndGg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwYXRoW2ldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBvYmogPSBvYmpbcGF0aFtpXV07XG4gICAgfVxuICAgIHJldHVybiAhIWxlbmd0aDtcbiAgfSxcbiAgb21pdChvYmosIC4uLmtleXMpIHtcbiAgICBjb25zdCBjbGVhciA9IE9iamVjdC5hc3NpZ24oe30sIG9iaik7XG4gICAgZm9yIChsZXQgaSA9IGtleXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGRlbGV0ZSBjbGVhcltrZXlzW2ldXTtcbiAgICB9XG5cbiAgICByZXR1cm4gY2xlYXI7XG4gIH0sXG4gIG5vdzogRGF0ZS5ub3csXG4gIHRocm90dGxlKGZ1bmMsIHdhaXQsIG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCBwcmV2aW91cyA9IDA7XG4gICAgbGV0IHRpbWVvdXQgPSBudWxsO1xuICAgIGxldCByZXN1bHQ7XG4gICAgY29uc3QgdGhhdCA9IHRoaXM7XG4gICAgbGV0IHNlbGY7XG4gICAgbGV0IGFyZ3M7XG5cbiAgICBjb25zdCBsYXRlciA9ICgpID0+IHtcbiAgICAgIHByZXZpb3VzID0gb3B0aW9ucy5sZWFkaW5nID09PSBmYWxzZSA/IDAgOiB0aGF0Lm5vdygpO1xuICAgICAgdGltZW91dCA9IG51bGw7XG4gICAgICByZXN1bHQgPSBmdW5jLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgICAgaWYgKCF0aW1lb3V0KSB7XG4gICAgICAgIHNlbGYgPSBhcmdzID0gbnVsbDtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgdGhyb3R0bGVkID0gZnVuY3Rpb24gKCkge1xuICAgICAgY29uc3Qgbm93ID0gdGhhdC5ub3coKTtcbiAgICAgIGlmICghcHJldmlvdXMgJiYgb3B0aW9ucy5sZWFkaW5nID09PSBmYWxzZSkgcHJldmlvdXMgPSBub3c7XG4gICAgICBjb25zdCByZW1haW5pbmcgPSB3YWl0IC0gKG5vdyAtIHByZXZpb3VzKTtcbiAgICAgIHNlbGYgPSB0aGlzO1xuICAgICAgYXJncyA9IGFyZ3VtZW50cztcbiAgICAgIGlmIChyZW1haW5pbmcgPD0gMCB8fCByZW1haW5pbmcgPiB3YWl0KSB7XG4gICAgICAgIGlmICh0aW1lb3V0KSB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgICAgICAgIHRpbWVvdXQgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHByZXZpb3VzID0gbm93O1xuICAgICAgICByZXN1bHQgPSBmdW5jLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgICAgICBpZiAoIXRpbWVvdXQpIHtcbiAgICAgICAgICBzZWxmID0gYXJncyA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoIXRpbWVvdXQgJiYgb3B0aW9ucy50cmFpbGluZyAhPT0gZmFsc2UpIHtcbiAgICAgICAgdGltZW91dCA9IHNldFRpbWVvdXQobGF0ZXIsIHJlbWFpbmluZyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG5cbiAgICB0aHJvdHRsZWQuY2FuY2VsID0gKCkgPT4ge1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgICAgcHJldmlvdXMgPSAwO1xuICAgICAgdGltZW91dCA9IHNlbGYgPSBhcmdzID0gbnVsbDtcbiAgICB9O1xuXG4gICAgcmV0dXJuIHRocm90dGxlZDtcbiAgfVxufTtcblxuY29uc3QgX2hlbHBlcnMgPSBbJ1N0cmluZycsICdOdW1iZXInLCAnRGF0ZSddO1xuZm9yIChsZXQgaSA9IDA7IGkgPCBfaGVscGVycy5sZW5ndGg7IGkrKykge1xuICBoZWxwZXJzWydpcycgKyBfaGVscGVyc1tpXV0gPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopID09PSAnW29iamVjdCAnICsgX2hlbHBlcnNbaV0gKyAnXSc7XG4gIH07XG59XG5cbi8qXG4gKiBAY29uc3Qge0Z1bmN0aW9ufSBmaXhKU09OUGFyc2UgLSBGaXggaXNzdWUgd2l0aCBEYXRlIHBhcnNlXG4gKi9cbmNvbnN0IGZpeEpTT05QYXJzZSA9IGZ1bmN0aW9uKG9iaikge1xuICBmb3IgKGxldCBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKGhlbHBlcnMuaXNTdHJpbmcob2JqW2tleV0pICYmIG9ialtrZXldLmluY2x1ZGVzKCc9LS1KU09OLURBVEUtLT0nKSkge1xuICAgICAgb2JqW2tleV0gPSBvYmpba2V5XS5yZXBsYWNlKCc9LS1KU09OLURBVEUtLT0nLCAnJyk7XG4gICAgICBvYmpba2V5XSA9IG5ldyBEYXRlKHBhcnNlSW50KG9ialtrZXldKSk7XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzT2JqZWN0KG9ialtrZXldKSkge1xuICAgICAgb2JqW2tleV0gPSBmaXhKU09OUGFyc2Uob2JqW2tleV0pO1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0FycmF5KG9ialtrZXldKSkge1xuICAgICAgbGV0IHY7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9ialtrZXldLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHYgPSBvYmpba2V5XVtpXTtcbiAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QodikpIHtcbiAgICAgICAgICBvYmpba2V5XVtpXSA9IGZpeEpTT05QYXJzZSh2KTtcbiAgICAgICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzU3RyaW5nKHYpICYmIHYuaW5jbHVkZXMoJz0tLUpTT04tREFURS0tPScpKSB7XG4gICAgICAgICAgdiA9IHYucmVwbGFjZSgnPS0tSlNPTi1EQVRFLS09JywgJycpO1xuICAgICAgICAgIG9ialtrZXldW2ldID0gbmV3IERhdGUocGFyc2VJbnQodikpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBvYmo7XG59O1xuXG4vKlxuICogQGNvbnN0IHtGdW5jdGlvbn0gZml4SlNPTlN0cmluZ2lmeSAtIEZpeCBpc3N1ZSB3aXRoIERhdGUgc3RyaW5naWZ5XG4gKi9cbmNvbnN0IGZpeEpTT05TdHJpbmdpZnkgPSBmdW5jdGlvbihvYmopIHtcbiAgZm9yIChsZXQga2V5IGluIG9iaikge1xuICAgIGlmIChoZWxwZXJzLmlzRGF0ZShvYmpba2V5XSkpIHtcbiAgICAgIG9ialtrZXldID0gYD0tLUpTT04tREFURS0tPSR7K29ialtrZXldfWA7XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzT2JqZWN0KG9ialtrZXldKSkge1xuICAgICAgb2JqW2tleV0gPSBmaXhKU09OU3RyaW5naWZ5KG9ialtrZXldKTtcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNBcnJheShvYmpba2V5XSkpIHtcbiAgICAgIGxldCB2O1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvYmpba2V5XS5sZW5ndGg7IGkrKykge1xuICAgICAgICB2ID0gb2JqW2tleV1baV07XG4gICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KHYpKSB7XG4gICAgICAgICAgb2JqW2tleV1baV0gPSBmaXhKU09OU3RyaW5naWZ5KHYpO1xuICAgICAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNEYXRlKHYpKSB7XG4gICAgICAgICAgb2JqW2tleV1baV0gPSBgPS0tSlNPTi1EQVRFLS09JHsrdn1gO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBvYmo7XG59O1xuXG4vKlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAcHJpdmF0ZVxuICogQG5hbWUgZm9ybWF0RmxlVVJMXG4gKiBAcGFyYW0ge09iamVjdH0gZmlsZVJlZiAtIEZpbGUgcmVmZXJlbmNlIG9iamVjdFxuICogQHBhcmFtIHtTdHJpbmd9IHZlcnNpb24gLSBbT3B0aW9uYWxdIFZlcnNpb24gb2YgZmlsZSB5b3Ugd291bGQgbGlrZSBidWlsZCBVUkwgZm9yXG4gKiBAcGFyYW0ge1N0cmluZ30gVVJJQmFzZSAtIFtPcHRpb25hbF0gVVJJIGJhc2UsIHNlZSAtIGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvaXNzdWVzLzYyNlxuICogQHN1bW1hcnkgUmV0dXJucyBmb3JtYXR0ZWQgVVJMIGZvciBmaWxlXG4gKiBAcmV0dXJucyB7U3RyaW5nfSBEb3dubG9hZGFibGUgbGlua1xuICovXG5jb25zdCBmb3JtYXRGbGVVUkwgPSAoZmlsZVJlZiwgdmVyc2lvbiA9ICdvcmlnaW5hbCcsIF9VUklCYXNlID0gKF9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18gfHwge30pLlJPT1RfVVJMKSA9PiB7XG4gIGNoZWNrKGZpbGVSZWYsIE9iamVjdCk7XG4gIGNoZWNrKHZlcnNpb24sIFN0cmluZyk7XG4gIGxldCBVUklCYXNlID0gX1VSSUJhc2U7XG5cbiAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKFVSSUJhc2UpKSB7XG4gICAgVVJJQmFzZSA9IChfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fIHx8IHt9KS5ST09UX1VSTCB8fCAnLyc7XG4gIH1cblxuICBjb25zdCBfcm9vdCA9IFVSSUJhc2UucmVwbGFjZSgvXFwvKyQvLCAnJyk7XG4gIGNvbnN0IHZSZWYgPSAoZmlsZVJlZi52ZXJzaW9ucyAmJiBmaWxlUmVmLnZlcnNpb25zW3ZlcnNpb25dKSB8fCBmaWxlUmVmIHx8IHt9O1xuXG4gIGxldCBleHQ7XG4gIGlmIChoZWxwZXJzLmlzU3RyaW5nKHZSZWYuZXh0ZW5zaW9uKSkge1xuICAgIGV4dCA9IGAuJHt2UmVmLmV4dGVuc2lvbi5yZXBsYWNlKC9eXFwuLywgJycpfWA7XG4gIH0gZWxzZSB7XG4gICAgZXh0ID0gJyc7XG4gIH1cblxuICBpZiAoZmlsZVJlZi5wdWJsaWMgPT09IHRydWUpIHtcbiAgICByZXR1cm4gX3Jvb3QgKyAodmVyc2lvbiA9PT0gJ29yaWdpbmFsJyA/IGAke2ZpbGVSZWYuX2Rvd25sb2FkUm91dGV9LyR7ZmlsZVJlZi5faWR9JHtleHR9YCA6IGAke2ZpbGVSZWYuX2Rvd25sb2FkUm91dGV9LyR7dmVyc2lvbn0tJHtmaWxlUmVmLl9pZH0ke2V4dH1gKTtcbiAgfVxuICByZXR1cm4gX3Jvb3QgKyBgJHtmaWxlUmVmLl9kb3dubG9hZFJvdXRlfS8ke2ZpbGVSZWYuX2NvbGxlY3Rpb25OYW1lfS8ke2ZpbGVSZWYuX2lkfS8ke3ZlcnNpb259LyR7ZmlsZVJlZi5faWR9JHtleHR9YDtcbn07XG5cbmV4cG9ydCB7IGZpeEpTT05QYXJzZSwgZml4SlNPTlN0cmluZ2lmeSwgZm9ybWF0RmxlVVJMLCBoZWxwZXJzIH07XG4iLCJpbXBvcnQgZnMgICAgICAgICAgZnJvbSAnZnMtZXh0cmEnO1xuaW1wb3J0IHsgTWV0ZW9yIH0gIGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgaGVscGVycyB9IGZyb20gJy4vbGliLmpzJztcbmNvbnN0IE5PT1AgPSAoKSA9PiB7fTtcblxuLypcbiAqIEBjb25zdCB7T2JqZWN0fSBib3VuZCAgIC0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCAoRmliZXIgd3JhcHBlcilcbiAqIEBjb25zdCB7T2JqZWN0fSBmZENhY2hlIC0gRmlsZSBEZXNjcmlwdG9ycyBDYWNoZVxuICovXG5jb25zdCBib3VuZCAgID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChjYWxsYmFjayA9PiBjYWxsYmFjaygpKTtcbmNvbnN0IGZkQ2FjaGUgPSB7fTtcblxuLypcbiAqIEBwcml2YXRlXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAY2xhc3MgV3JpdGVTdHJlYW1cbiAqIEBwYXJhbSBwYXRoICAgICAgICB7U3RyaW5nfSAtIFBhdGggdG8gZmlsZSBvbiBGU1xuICogQHBhcmFtIG1heExlbmd0aCAgIHtOdW1iZXJ9IC0gTWF4IGFtb3VudCBvZiBjaHVua3MgaW4gc3RyZWFtXG4gKiBAcGFyYW0gZmlsZSAgICAgICAge09iamVjdH0gLSBmaWxlUmVmIE9iamVjdFxuICogQHBhcmFtIHBlcm1pc3Npb25zIHtTdHJpbmd9IC0gUGVybWlzc2lvbnMgd2hpY2ggd2lsbCBiZSBzZXQgdG8gb3BlbiBkZXNjcmlwdG9yIChvY3RhbCksIGxpa2U6IGA2MTFgIG9yIGAwbzc3N2AuIERlZmF1bHQ6IDA3NTVcbiAqIEBzdW1tYXJ5IHdyaXRhYmxlU3RyZWFtIHdyYXBwZXIgY2xhc3MsIG1ha2VzIHN1cmUgY2h1bmtzIGlzIHdyaXR0ZW4gaW4gZ2l2ZW4gb3JkZXIuIEltcGxlbWVudGF0aW9uIG9mIHF1ZXVlIHN0cmVhbS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgV3JpdGVTdHJlYW0ge1xuICBjb25zdHJ1Y3RvcihwYXRoLCBtYXhMZW5ndGgsIGZpbGUsIHBlcm1pc3Npb25zKSB7XG4gICAgdGhpcy5wYXRoID0gcGF0aDtcbiAgICB0aGlzLm1heExlbmd0aCA9IG1heExlbmd0aDtcbiAgICB0aGlzLmZpbGUgPSBmaWxlO1xuICAgIHRoaXMucGVybWlzc2lvbnMgPSBwZXJtaXNzaW9ucztcbiAgICBpZiAoIXRoaXMucGF0aCB8fCAhaGVscGVycy5pc1N0cmluZyh0aGlzLnBhdGgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5mZCAgICAgICAgICAgID0gbnVsbDtcbiAgICB0aGlzLndyaXR0ZW5DaHVua3MgPSAwO1xuICAgIHRoaXMuZW5kZWQgICAgICAgICA9IGZhbHNlO1xuICAgIHRoaXMuYWJvcnRlZCAgICAgICA9IGZhbHNlO1xuXG4gICAgaWYgKGZkQ2FjaGVbdGhpcy5wYXRoXSAmJiAhZmRDYWNoZVt0aGlzLnBhdGhdLmVuZGVkICYmICFmZENhY2hlW3RoaXMucGF0aF0uYWJvcnRlZCkge1xuICAgICAgdGhpcy5mZCA9IGZkQ2FjaGVbdGhpcy5wYXRoXS5mZDtcbiAgICAgIHRoaXMud3JpdHRlbkNodW5rcyA9IGZkQ2FjaGVbdGhpcy5wYXRoXS53cml0dGVuQ2h1bmtzO1xuICAgIH0gZWxzZSB7XG4gICAgICBmcy5lbnN1cmVGaWxlKHRoaXMucGF0aCwgKGVmRXJyb3IpID0+IHtcbiAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgIGlmIChlZkVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmFib3J0KCk7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJ1tGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZVN0cmVhbV0gW2Vuc3VyZUZpbGVdIFtFcnJvcjpdICcgKyBlZkVycm9yKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZnMub3Blbih0aGlzLnBhdGgsICdyKycsIHRoaXMucGVybWlzc2lvbnMsIChvRXJyb3IsIGZkKSA9PiB7XG4gICAgICAgICAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAob0Vycm9yKSB7XG4gICAgICAgICAgICAgICAgICB0aGlzLmFib3J0KCk7XG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJ1tGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZVN0cmVhbV0gW2Vuc3VyZUZpbGVdIFtvcGVuXSBbRXJyb3I6XSAnICsgb0Vycm9yKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgdGhpcy5mZCA9IGZkO1xuICAgICAgICAgICAgICAgICAgZmRDYWNoZVt0aGlzLnBhdGhdID0gdGhpcztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBtZW1iZXJPZiB3cml0ZVN0cmVhbVxuICAgKiBAbmFtZSB3cml0ZVxuICAgKiBAcGFyYW0ge051bWJlcn0gbnVtIC0gQ2h1bmsgcG9zaXRpb24gaW4gYSBzdHJlYW1cbiAgICogQHBhcmFtIHtCdWZmZXJ9IGNodW5rIC0gQnVmZmVyIChjaHVuayBiaW5hcnkgZGF0YSlcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBDYWxsYmFja1xuICAgKiBAc3VtbWFyeSBXcml0ZSBjaHVuayBpbiBnaXZlbiBvcmRlclxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gLSBUcnVlIGlmIGNodW5rIGlzIHNlbnQgdG8gc3RyZWFtLCBmYWxzZSBpZiBjaHVuayBpcyBzZXQgaW50byBxdWV1ZVxuICAgKi9cbiAgd3JpdGUobnVtLCBjaHVuaywgY2FsbGJhY2spIHtcbiAgICBpZiAoIXRoaXMuYWJvcnRlZCAmJiAhdGhpcy5lbmRlZCkge1xuICAgICAgaWYgKHRoaXMuZmQpIHtcbiAgICAgICAgZnMud3JpdGUodGhpcy5mZCwgY2h1bmssIDAsIGNodW5rLmxlbmd0aCwgKG51bSAtIDEpICogdGhpcy5maWxlLmNodW5rU2l6ZSwgKGVycm9yLCB3cml0dGVuLCBidWZmZXIpID0+IHtcbiAgICAgICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhlcnJvciwgd3JpdHRlbiwgYnVmZmVyKTtcbiAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ1tGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZVN0cmVhbV0gW3dyaXRlXSBbRXJyb3I6XScsIGVycm9yKTtcbiAgICAgICAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgKyt0aGlzLndyaXR0ZW5DaHVua3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgTWV0ZW9yLnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMud3JpdGUobnVtLCBjaHVuaywgY2FsbGJhY2spO1xuICAgICAgICB9LCAyNSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qXG4gICAqIEBtZW1iZXJPZiB3cml0ZVN0cmVhbVxuICAgKiBAbmFtZSBlbmRcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBDYWxsYmFja1xuICAgKiBAc3VtbWFyeSBGaW5pc2hlcyB3cml0aW5nIHRvIHdyaXRhYmxlU3RyZWFtLCBvbmx5IGFmdGVyIGFsbCBjaHVua3MgaW4gcXVldWUgaXMgd3JpdHRlblxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gLSBUcnVlIGlmIHN0cmVhbSBpcyBmdWxmaWxsZWQsIGZhbHNlIGlmIHF1ZXVlIGlzIGluIHByb2dyZXNzXG4gICAqL1xuICBlbmQoY2FsbGJhY2spIHtcbiAgICBpZiAoIXRoaXMuYWJvcnRlZCAmJiAhdGhpcy5lbmRlZCkge1xuICAgICAgaWYgKHRoaXMud3JpdHRlbkNodW5rcyA9PT0gdGhpcy5tYXhMZW5ndGgpIHtcbiAgICAgICAgZnMuY2xvc2UodGhpcy5mZCwgKCkgPT4ge1xuICAgICAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgIGRlbGV0ZSBmZENhY2hlW3RoaXMucGF0aF07XG4gICAgICAgICAgICB0aGlzLmVuZGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHZvaWQgMCwgdHJ1ZSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cblxuICAgICAgZnMuc3RhdCh0aGlzLnBhdGgsIChlcnJvciwgc3RhdCkgPT4ge1xuICAgICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgaWYgKCFlcnJvciAmJiBzdGF0KSB7XG4gICAgICAgICAgICB0aGlzLndyaXR0ZW5DaHVua3MgPSBNYXRoLmNlaWwoc3RhdC5zaXplIC8gdGhpcy5maWxlLmNodW5rU2l6ZSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIE1ldGVvci5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuZW5kKGNhbGxiYWNrKTtcbiAgICAgICAgICB9LCAyNSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHZvaWQgMCwgdGhpcy5lbmRlZCk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qXG4gICAqIEBtZW1iZXJPZiB3cml0ZVN0cmVhbVxuICAgKiBAbmFtZSBhYm9ydFxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIENhbGxiYWNrXG4gICAqIEBzdW1tYXJ5IEFib3J0cyB3cml0aW5nIHRvIHdyaXRhYmxlU3RyZWFtLCByZW1vdmVzIGNyZWF0ZWQgZmlsZVxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gLSBUcnVlXG4gICAqL1xuICBhYm9ydChjYWxsYmFjaykge1xuICAgIHRoaXMuYWJvcnRlZCA9IHRydWU7XG4gICAgZGVsZXRlIGZkQ2FjaGVbdGhpcy5wYXRoXTtcbiAgICBmcy51bmxpbmsodGhpcy5wYXRoLCAoY2FsbGJhY2sgfHwgTk9PUCkpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgLypcbiAgICogQG1lbWJlck9mIHdyaXRlU3RyZWFtXG4gICAqIEBuYW1lIHN0b3BcbiAgICogQHN1bW1hcnkgU3RvcCB3cml0aW5nIHRvIHdyaXRhYmxlU3RyZWFtXG4gICAqIEByZXR1cm5zIHtCb29sZWFufSAtIFRydWVcbiAgICovXG4gIHN0b3AoKSB7XG4gICAgdGhpcy5hYm9ydGVkID0gdHJ1ZTtcbiAgICBkZWxldGUgZmRDYWNoZVt0aGlzLnBhdGhdO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG4iXX0=
