(function () {



/* Exports */
Package._define("ostrio:uiblocker");

})();
