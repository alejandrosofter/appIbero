(function () {



/* Exports */
Package._define("aldeed:collection2");

})();
