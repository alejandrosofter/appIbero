(function () {



/* Exports */
Package._define("peppelg:bootstrap-3-modal");

})();
