(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Random;

var require = meteorInstall({"node_modules":{"meteor":{"random":{"random.js":function module(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/random/random.js                                                                                     //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// We use cryptographically strong PRNGs (crypto.getRandomBytes() on the server,
// window.crypto.getRandomValues() in the browser) when available. If these
// PRNGs fail, we fall back to the Alea PRNG, which is not cryptographically
// strong, and we seed it with various sources such as the date, Math.random,
// and window size on the client.  When using crypto.getRandomValues(), our
// primitive is hexString(), from which we construct fraction(). When using
// window.crypto.getRandomValues() or alea, the primitive is fraction and we use
// that to construct hex string.
if (Meteor.isServer) var nodeCrypto = Npm.require('crypto'); // see http://baagoe.org/en/wiki/Better_random_numbers_for_javascript
// for a full discussion and Alea implementation.

var Alea = function () {
  function Mash() {
    var n = 0xefc8249d;

    var mash = function (data) {
      data = data.toString();

      for (var i = 0; i < data.length; i++) {
        n += data.charCodeAt(i);
        var h = 0.02519603282416938 * n;
        n = h >>> 0;
        h -= n;
        h *= n;
        n = h >>> 0;
        h -= n;
        n += h * 0x100000000; // 2^32
      }

      return (n >>> 0) * 2.3283064365386963e-10; // 2^-32
    };

    mash.version = 'Mash 0.9';
    return mash;
  }

  return function (args) {
    var s0 = 0;
    var s1 = 0;
    var s2 = 0;
    var c = 1;

    if (args.length == 0) {
      args = [+new Date()];
    }

    var mash = Mash();
    s0 = mash(' ');
    s1 = mash(' ');
    s2 = mash(' ');

    for (var i = 0; i < args.length; i++) {
      s0 -= mash(args[i]);

      if (s0 < 0) {
        s0 += 1;
      }

      s1 -= mash(args[i]);

      if (s1 < 0) {
        s1 += 1;
      }

      s2 -= mash(args[i]);

      if (s2 < 0) {
        s2 += 1;
      }
    }

    mash = null;

    var random = function () {
      var t = 2091639 * s0 + c * 2.3283064365386963e-10; // 2^-32

      s0 = s1;
      s1 = s2;
      return s2 = t - (c = t | 0);
    };

    random.uint32 = function () {
      return random() * 0x100000000; // 2^32
    };

    random.fract53 = function () {
      return random() + (random() * 0x200000 | 0) * 1.1102230246251565e-16; // 2^-53
    };

    random.version = 'Alea 0.9';
    random.args = args;
    return random;
  }(Array.prototype.slice.call(arguments));
};

var UNMISTAKABLE_CHARS = "23456789ABCDEFGHJKLMNPQRSTWXYZabcdefghijkmnopqrstuvwxyz";
var BASE64_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789-_"; // `type` is one of `RandomGenerator.Type` as defined below.
//
// options:
// - seeds: (required, only for RandomGenerator.Type.ALEA) an array
//   whose items will be `toString`ed and used as the seed to the Alea
//   algorithm

var RandomGenerator = function (type, options) {
  var self = this;
  self.type = type;

  if (!RandomGenerator.Type[type]) {
    throw new Error("Unknown random generator type: " + type);
  }

  if (type === RandomGenerator.Type.ALEA) {
    if (!options.seeds) {
      throw new Error("No seeds were provided for Alea PRNG");
    }

    self.alea = Alea.apply(null, options.seeds);
  }
}; // Types of PRNGs supported by the `RandomGenerator` class


RandomGenerator.Type = {
  // Use Node's built-in `crypto.getRandomBytes` (cryptographically
  // secure but not seedable, runs only on the server). Reverts to
  // `crypto.getPseudoRandomBytes` in the extremely uncommon case that
  // there isn't enough entropy yet
  NODE_CRYPTO: "NODE_CRYPTO",
  // Use non-IE browser's built-in `window.crypto.getRandomValues`
  // (cryptographically secure but not seedable, runs only in the
  // browser).
  BROWSER_CRYPTO: "BROWSER_CRYPTO",
  // Use the *fast*, seedaable and not cryptographically secure
  // Alea algorithm
  ALEA: "ALEA"
};
/**
 * @name Random.fraction
 * @summary Return a number between 0 and 1, like `Math.random`.
 * @locus Anywhere
 */

RandomGenerator.prototype.fraction = function () {
  var self = this;

  if (self.type === RandomGenerator.Type.ALEA) {
    return self.alea();
  } else if (self.type === RandomGenerator.Type.NODE_CRYPTO) {
    var numerator = parseInt(self.hexString(8), 16);
    return numerator * 2.3283064365386963e-10; // 2^-32
  } else if (self.type === RandomGenerator.Type.BROWSER_CRYPTO) {
    var array = new Uint32Array(1);
    window.crypto.getRandomValues(array);
    return array[0] * 2.3283064365386963e-10; // 2^-32
  } else {
    throw new Error('Unknown random generator type: ' + self.type);
  }
};
/**
 * @name Random.hexString
 * @summary Return a random string of `n` hexadecimal digits.
 * @locus Anywhere
 * @param {Number} n Length of the string
 */


RandomGenerator.prototype.hexString = function (digits) {
  var self = this;

  if (self.type === RandomGenerator.Type.NODE_CRYPTO) {
    var numBytes = Math.ceil(digits / 2);
    var bytes; // Try to get cryptographically strong randomness. Fall back to
    // non-cryptographically strong if not available.

    try {
      bytes = nodeCrypto.randomBytes(numBytes);
    } catch (e) {
      // XXX should re-throw any error except insufficient entropy
      bytes = nodeCrypto.pseudoRandomBytes(numBytes);
    }

    var result = bytes.toString("hex"); // If the number of digits is odd, we'll have generated an extra 4 bits
    // of randomness, so we need to trim the last digit.

    return result.substring(0, digits);
  } else {
    return this._randomString(digits, "0123456789abcdef");
  }
};

RandomGenerator.prototype._randomString = function (charsCount, alphabet) {
  var self = this;
  var digits = [];

  for (var i = 0; i < charsCount; i++) {
    digits[i] = self.choice(alphabet);
  }

  return digits.join("");
};
/**
 * @name Random.id
 * @summary Return a unique identifier, such as `"Jjwjg6gouWLXhMGKW"`, that is
 * likely to be unique in the whole world.
 * @locus Anywhere
 * @param {Number} [n] Optional length of the identifier in characters
 *   (defaults to 17)
 */


RandomGenerator.prototype.id = function (charsCount) {
  var self = this; // 17 characters is around 96 bits of entropy, which is the amount of
  // state in the Alea PRNG.

  if (charsCount === undefined) charsCount = 17;
  return self._randomString(charsCount, UNMISTAKABLE_CHARS);
};
/**
 * @name Random.secret
 * @summary Return a random string of printable characters with 6 bits of
 * entropy per character. Use `Random.secret` for security-critical secrets
 * that are intended for machine, rather than human, consumption.
 * @locus Anywhere
 * @param {Number} [n] Optional length of the secret string (defaults to 43
 *   characters, or 256 bits of entropy)
 */


RandomGenerator.prototype.secret = function (charsCount) {
  var self = this; // Default to 256 bits of entropy, or 43 characters at 6 bits per
  // character.

  if (charsCount === undefined) charsCount = 43;
  return self._randomString(charsCount, BASE64_CHARS);
};
/**
 * @name Random.choice
 * @summary Return a random element of the given array or string.
 * @locus Anywhere
 * @param {Array|String} arrayOrString Array or string to choose from
 */


RandomGenerator.prototype.choice = function (arrayOrString) {
  var index = Math.floor(this.fraction() * arrayOrString.length);
  if (typeof arrayOrString === "string") return arrayOrString.substr(index, 1);else return arrayOrString[index];
}; // instantiate RNG.  Heuristically collect entropy from various sources when a
// cryptographic PRNG isn't available.
// client sources


var height = typeof window !== 'undefined' && window.innerHeight || typeof document !== 'undefined' && document.documentElement && document.documentElement.clientHeight || typeof document !== 'undefined' && document.body && document.body.clientHeight || 1;
var width = typeof window !== 'undefined' && window.innerWidth || typeof document !== 'undefined' && document.documentElement && document.documentElement.clientWidth || typeof document !== 'undefined' && document.body && document.body.clientWidth || 1;
var agent = typeof navigator !== 'undefined' && navigator.userAgent || "";

function createAleaGeneratorWithGeneratedSeed() {
  return new RandomGenerator(RandomGenerator.Type.ALEA, {
    seeds: [new Date(), height, width, agent, Math.random()]
  });
}

;

if (Meteor.isServer) {
  Random = new RandomGenerator(RandomGenerator.Type.NODE_CRYPTO);
} else {
  if (typeof window !== "undefined" && window.crypto && window.crypto.getRandomValues) {
    Random = new RandomGenerator(RandomGenerator.Type.BROWSER_CRYPTO);
  } else {
    // On IE 10 and below, there's no browser crypto API
    // available. Fall back to Alea
    //
    // XXX looks like at the moment, we use Alea in IE 11 as well,
    // which has `window.msCrypto` instead of `window.crypto`.
    Random = createAleaGeneratorWithGeneratedSeed();
  }
} // Create a non-cryptographically secure PRNG with a given seed (using
// the Alea algorithm)


Random.createWithSeeds = function () {
  for (var _len = arguments.length, seeds = new Array(_len), _key = 0; _key < _len; _key++) {
    seeds[_key] = arguments[_key];
  }

  if (seeds.length === 0) {
    throw new Error("No seeds were provided");
  }

  return new RandomGenerator(RandomGenerator.Type.ALEA, {
    seeds: seeds
  });
}; // Used like `Random`, but much faster and not cryptographically
// secure


Random.insecure = createAleaGeneratorWithGeneratedSeed();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/random/random.js");

/* Exports */
Package._define("random", {
  Random: Random
});

})();

//# sourceURL=meteor://💻app/packages/random.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcmFuZG9tL3JhbmRvbS5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJpc1NlcnZlciIsIm5vZGVDcnlwdG8iLCJOcG0iLCJyZXF1aXJlIiwiQWxlYSIsIk1hc2giLCJuIiwibWFzaCIsImRhdGEiLCJ0b1N0cmluZyIsImkiLCJsZW5ndGgiLCJjaGFyQ29kZUF0IiwiaCIsInZlcnNpb24iLCJhcmdzIiwiczAiLCJzMSIsInMyIiwiYyIsIkRhdGUiLCJyYW5kb20iLCJ0IiwidWludDMyIiwiZnJhY3Q1MyIsIkFycmF5IiwicHJvdG90eXBlIiwic2xpY2UiLCJjYWxsIiwiYXJndW1lbnRzIiwiVU5NSVNUQUtBQkxFX0NIQVJTIiwiQkFTRTY0X0NIQVJTIiwiUmFuZG9tR2VuZXJhdG9yIiwidHlwZSIsIm9wdGlvbnMiLCJzZWxmIiwiVHlwZSIsIkVycm9yIiwiQUxFQSIsInNlZWRzIiwiYWxlYSIsImFwcGx5IiwiTk9ERV9DUllQVE8iLCJCUk9XU0VSX0NSWVBUTyIsImZyYWN0aW9uIiwibnVtZXJhdG9yIiwicGFyc2VJbnQiLCJoZXhTdHJpbmciLCJhcnJheSIsIlVpbnQzMkFycmF5Iiwid2luZG93IiwiY3J5cHRvIiwiZ2V0UmFuZG9tVmFsdWVzIiwiZGlnaXRzIiwibnVtQnl0ZXMiLCJNYXRoIiwiY2VpbCIsImJ5dGVzIiwicmFuZG9tQnl0ZXMiLCJlIiwicHNldWRvUmFuZG9tQnl0ZXMiLCJyZXN1bHQiLCJzdWJzdHJpbmciLCJfcmFuZG9tU3RyaW5nIiwiY2hhcnNDb3VudCIsImFscGhhYmV0IiwiY2hvaWNlIiwiam9pbiIsImlkIiwidW5kZWZpbmVkIiwic2VjcmV0IiwiYXJyYXlPclN0cmluZyIsImluZGV4IiwiZmxvb3IiLCJzdWJzdHIiLCJoZWlnaHQiLCJpbm5lckhlaWdodCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xpZW50SGVpZ2h0IiwiYm9keSIsIndpZHRoIiwiaW5uZXJXaWR0aCIsImNsaWVudFdpZHRoIiwiYWdlbnQiLCJuYXZpZ2F0b3IiLCJ1c2VyQWdlbnQiLCJjcmVhdGVBbGVhR2VuZXJhdG9yV2l0aEdlbmVyYXRlZFNlZWQiLCJSYW5kb20iLCJjcmVhdGVXaXRoU2VlZHMiLCJpbnNlY3VyZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLElBQUlBLE1BQU0sQ0FBQ0MsUUFBWCxFQUNFLElBQUlDLFVBQVUsR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksUUFBWixDQUFqQixDLENBRUY7QUFDQTs7QUFDQSxJQUFJQyxJQUFJLEdBQUcsWUFBWTtBQUNyQixXQUFTQyxJQUFULEdBQWdCO0FBQ2QsUUFBSUMsQ0FBQyxHQUFHLFVBQVI7O0FBRUEsUUFBSUMsSUFBSSxHQUFHLFVBQVNDLElBQVQsRUFBZTtBQUN4QkEsVUFBSSxHQUFHQSxJQUFJLENBQUNDLFFBQUwsRUFBUDs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdGLElBQUksQ0FBQ0csTUFBekIsRUFBaUNELENBQUMsRUFBbEMsRUFBc0M7QUFDcENKLFNBQUMsSUFBSUUsSUFBSSxDQUFDSSxVQUFMLENBQWdCRixDQUFoQixDQUFMO0FBQ0EsWUFBSUcsQ0FBQyxHQUFHLHNCQUFzQlAsQ0FBOUI7QUFDQUEsU0FBQyxHQUFHTyxDQUFDLEtBQUssQ0FBVjtBQUNBQSxTQUFDLElBQUlQLENBQUw7QUFDQU8sU0FBQyxJQUFJUCxDQUFMO0FBQ0FBLFNBQUMsR0FBR08sQ0FBQyxLQUFLLENBQVY7QUFDQUEsU0FBQyxJQUFJUCxDQUFMO0FBQ0FBLFNBQUMsSUFBSU8sQ0FBQyxHQUFHLFdBQVQsQ0FSb0MsQ0FRZDtBQUN2Qjs7QUFDRCxhQUFPLENBQUNQLENBQUMsS0FBSyxDQUFQLElBQVksc0JBQW5CLENBWndCLENBWW1CO0FBQzVDLEtBYkQ7O0FBZUFDLFFBQUksQ0FBQ08sT0FBTCxHQUFlLFVBQWY7QUFDQSxXQUFPUCxJQUFQO0FBQ0Q7O0FBRUQsU0FBUSxVQUFVUSxJQUFWLEVBQWdCO0FBQ3RCLFFBQUlDLEVBQUUsR0FBRyxDQUFUO0FBQ0EsUUFBSUMsRUFBRSxHQUFHLENBQVQ7QUFDQSxRQUFJQyxFQUFFLEdBQUcsQ0FBVDtBQUNBLFFBQUlDLENBQUMsR0FBRyxDQUFSOztBQUVBLFFBQUlKLElBQUksQ0FBQ0osTUFBTCxJQUFlLENBQW5CLEVBQXNCO0FBQ3BCSSxVQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUlLLElBQUosRUFBRixDQUFQO0FBQ0Q7O0FBQ0QsUUFBSWIsSUFBSSxHQUFHRixJQUFJLEVBQWY7QUFDQVcsTUFBRSxHQUFHVCxJQUFJLENBQUMsR0FBRCxDQUFUO0FBQ0FVLE1BQUUsR0FBR1YsSUFBSSxDQUFDLEdBQUQsQ0FBVDtBQUNBVyxNQUFFLEdBQUdYLElBQUksQ0FBQyxHQUFELENBQVQ7O0FBRUEsU0FBSyxJQUFJRyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSyxJQUFJLENBQUNKLE1BQXpCLEVBQWlDRCxDQUFDLEVBQWxDLEVBQXNDO0FBQ3BDTSxRQUFFLElBQUlULElBQUksQ0FBQ1EsSUFBSSxDQUFDTCxDQUFELENBQUwsQ0FBVjs7QUFDQSxVQUFJTSxFQUFFLEdBQUcsQ0FBVCxFQUFZO0FBQ1ZBLFVBQUUsSUFBSSxDQUFOO0FBQ0Q7O0FBQ0RDLFFBQUUsSUFBSVYsSUFBSSxDQUFDUSxJQUFJLENBQUNMLENBQUQsQ0FBTCxDQUFWOztBQUNBLFVBQUlPLEVBQUUsR0FBRyxDQUFULEVBQVk7QUFDVkEsVUFBRSxJQUFJLENBQU47QUFDRDs7QUFDREMsUUFBRSxJQUFJWCxJQUFJLENBQUNRLElBQUksQ0FBQ0wsQ0FBRCxDQUFMLENBQVY7O0FBQ0EsVUFBSVEsRUFBRSxHQUFHLENBQVQsRUFBWTtBQUNWQSxVQUFFLElBQUksQ0FBTjtBQUNEO0FBQ0Y7O0FBQ0RYLFFBQUksR0FBRyxJQUFQOztBQUVBLFFBQUljLE1BQU0sR0FBRyxZQUFXO0FBQ3RCLFVBQUlDLENBQUMsR0FBRyxVQUFVTixFQUFWLEdBQWVHLENBQUMsR0FBRyxzQkFBM0IsQ0FEc0IsQ0FDNkI7O0FBQ25ESCxRQUFFLEdBQUdDLEVBQUw7QUFDQUEsUUFBRSxHQUFHQyxFQUFMO0FBQ0EsYUFBT0EsRUFBRSxHQUFHSSxDQUFDLElBQUlILENBQUMsR0FBR0csQ0FBQyxHQUFHLENBQVosQ0FBYjtBQUNELEtBTEQ7O0FBTUFELFVBQU0sQ0FBQ0UsTUFBUCxHQUFnQixZQUFXO0FBQ3pCLGFBQU9GLE1BQU0sS0FBSyxXQUFsQixDQUR5QixDQUNNO0FBQ2hDLEtBRkQ7O0FBR0FBLFVBQU0sQ0FBQ0csT0FBUCxHQUFpQixZQUFXO0FBQzFCLGFBQU9ILE1BQU0sS0FDWCxDQUFDQSxNQUFNLEtBQUssUUFBWCxHQUFzQixDQUF2QixJQUE0QixzQkFEOUIsQ0FEMEIsQ0FFNEI7QUFDdkQsS0FIRDs7QUFJQUEsVUFBTSxDQUFDUCxPQUFQLEdBQWlCLFVBQWpCO0FBQ0FPLFVBQU0sQ0FBQ04sSUFBUCxHQUFjQSxJQUFkO0FBQ0EsV0FBT00sTUFBUDtBQUVELEdBL0NPLENBK0NMSSxLQUFLLENBQUNDLFNBQU4sQ0FBZ0JDLEtBQWhCLENBQXNCQyxJQUF0QixDQUEyQkMsU0FBM0IsQ0EvQ0ssQ0FBUjtBQWdERCxDQXZFRDs7QUF5RUEsSUFBSUMsa0JBQWtCLEdBQUcseURBQXpCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHLHlEQUNqQixjQURGLEMsQ0FHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsSUFBSUMsZUFBZSxHQUFHLFVBQVVDLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCO0FBQzdDLE1BQUlDLElBQUksR0FBRyxJQUFYO0FBQ0FBLE1BQUksQ0FBQ0YsSUFBTCxHQUFZQSxJQUFaOztBQUVBLE1BQUksQ0FBQ0QsZUFBZSxDQUFDSSxJQUFoQixDQUFxQkgsSUFBckIsQ0FBTCxFQUFpQztBQUMvQixVQUFNLElBQUlJLEtBQUosQ0FBVSxvQ0FBb0NKLElBQTlDLENBQU47QUFDRDs7QUFFRCxNQUFJQSxJQUFJLEtBQUtELGVBQWUsQ0FBQ0ksSUFBaEIsQ0FBcUJFLElBQWxDLEVBQXdDO0FBQ3RDLFFBQUksQ0FBQ0osT0FBTyxDQUFDSyxLQUFiLEVBQW9CO0FBQ2xCLFlBQU0sSUFBSUYsS0FBSixDQUFVLHNDQUFWLENBQU47QUFDRDs7QUFDREYsUUFBSSxDQUFDSyxJQUFMLEdBQVlwQyxJQUFJLENBQUNxQyxLQUFMLENBQVcsSUFBWCxFQUFpQlAsT0FBTyxDQUFDSyxLQUF6QixDQUFaO0FBQ0Q7QUFDRixDQWRELEMsQ0FnQkE7OztBQUNBUCxlQUFlLENBQUNJLElBQWhCLEdBQXVCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0FNLGFBQVcsRUFBRSxhQUxRO0FBT3JCO0FBQ0E7QUFDQTtBQUNBQyxnQkFBYyxFQUFFLGdCQVZLO0FBWXJCO0FBQ0E7QUFDQUwsTUFBSSxFQUFFO0FBZGUsQ0FBdkI7QUFpQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQU4sZUFBZSxDQUFDTixTQUFoQixDQUEwQmtCLFFBQTFCLEdBQXFDLFlBQVk7QUFDL0MsTUFBSVQsSUFBSSxHQUFHLElBQVg7O0FBQ0EsTUFBSUEsSUFBSSxDQUFDRixJQUFMLEtBQWNELGVBQWUsQ0FBQ0ksSUFBaEIsQ0FBcUJFLElBQXZDLEVBQTZDO0FBQzNDLFdBQU9ILElBQUksQ0FBQ0ssSUFBTCxFQUFQO0FBQ0QsR0FGRCxNQUVPLElBQUlMLElBQUksQ0FBQ0YsSUFBTCxLQUFjRCxlQUFlLENBQUNJLElBQWhCLENBQXFCTSxXQUF2QyxFQUFvRDtBQUN6RCxRQUFJRyxTQUFTLEdBQUdDLFFBQVEsQ0FBQ1gsSUFBSSxDQUFDWSxTQUFMLENBQWUsQ0FBZixDQUFELEVBQW9CLEVBQXBCLENBQXhCO0FBQ0EsV0FBT0YsU0FBUyxHQUFHLHNCQUFuQixDQUZ5RCxDQUVkO0FBQzVDLEdBSE0sTUFHQSxJQUFJVixJQUFJLENBQUNGLElBQUwsS0FBY0QsZUFBZSxDQUFDSSxJQUFoQixDQUFxQk8sY0FBdkMsRUFBdUQ7QUFDNUQsUUFBSUssS0FBSyxHQUFHLElBQUlDLFdBQUosQ0FBZ0IsQ0FBaEIsQ0FBWjtBQUNBQyxVQUFNLENBQUNDLE1BQVAsQ0FBY0MsZUFBZCxDQUE4QkosS0FBOUI7QUFDQSxXQUFPQSxLQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsc0JBQWxCLENBSDRELENBR2xCO0FBQzNDLEdBSk0sTUFJQTtBQUNMLFVBQU0sSUFBSVgsS0FBSixDQUFVLG9DQUFvQ0YsSUFBSSxDQUFDRixJQUFuRCxDQUFOO0FBQ0Q7QUFDRixDQWREO0FBZ0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FELGVBQWUsQ0FBQ04sU0FBaEIsQ0FBMEJxQixTQUExQixHQUFzQyxVQUFVTSxNQUFWLEVBQWtCO0FBQ3RELE1BQUlsQixJQUFJLEdBQUcsSUFBWDs7QUFDQSxNQUFJQSxJQUFJLENBQUNGLElBQUwsS0FBY0QsZUFBZSxDQUFDSSxJQUFoQixDQUFxQk0sV0FBdkMsRUFBb0Q7QUFDbEQsUUFBSVksUUFBUSxHQUFHQyxJQUFJLENBQUNDLElBQUwsQ0FBVUgsTUFBTSxHQUFHLENBQW5CLENBQWY7QUFDQSxRQUFJSSxLQUFKLENBRmtELENBR2xEO0FBQ0E7O0FBQ0EsUUFBSTtBQUNGQSxXQUFLLEdBQUd4RCxVQUFVLENBQUN5RCxXQUFYLENBQXVCSixRQUF2QixDQUFSO0FBQ0QsS0FGRCxDQUVFLE9BQU9LLENBQVAsRUFBVTtBQUNWO0FBQ0FGLFdBQUssR0FBR3hELFVBQVUsQ0FBQzJELGlCQUFYLENBQTZCTixRQUE3QixDQUFSO0FBQ0Q7O0FBQ0QsUUFBSU8sTUFBTSxHQUFHSixLQUFLLENBQUNoRCxRQUFOLENBQWUsS0FBZixDQUFiLENBWGtELENBWWxEO0FBQ0E7O0FBQ0EsV0FBT29ELE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQixDQUFqQixFQUFvQlQsTUFBcEIsQ0FBUDtBQUNELEdBZkQsTUFlTztBQUNMLFdBQU8sS0FBS1UsYUFBTCxDQUFtQlYsTUFBbkIsRUFBMkIsa0JBQTNCLENBQVA7QUFDRDtBQUNGLENBcEJEOztBQXNCQXJCLGVBQWUsQ0FBQ04sU0FBaEIsQ0FBMEJxQyxhQUExQixHQUEwQyxVQUFVQyxVQUFWLEVBQ1VDLFFBRFYsRUFDb0I7QUFDNUQsTUFBSTlCLElBQUksR0FBRyxJQUFYO0FBQ0EsTUFBSWtCLE1BQU0sR0FBRyxFQUFiOztBQUNBLE9BQUssSUFBSTNDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdzRCxVQUFwQixFQUFnQ3RELENBQUMsRUFBakMsRUFBcUM7QUFDbkMyQyxVQUFNLENBQUMzQyxDQUFELENBQU4sR0FBWXlCLElBQUksQ0FBQytCLE1BQUwsQ0FBWUQsUUFBWixDQUFaO0FBQ0Q7O0FBQ0QsU0FBT1osTUFBTSxDQUFDYyxJQUFQLENBQVksRUFBWixDQUFQO0FBQ0QsQ0FSRDtBQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBbkMsZUFBZSxDQUFDTixTQUFoQixDQUEwQjBDLEVBQTFCLEdBQStCLFVBQVVKLFVBQVYsRUFBc0I7QUFDbkQsTUFBSTdCLElBQUksR0FBRyxJQUFYLENBRG1ELENBRW5EO0FBQ0E7O0FBQ0EsTUFBSTZCLFVBQVUsS0FBS0ssU0FBbkIsRUFDRUwsVUFBVSxHQUFHLEVBQWI7QUFFRixTQUFPN0IsSUFBSSxDQUFDNEIsYUFBTCxDQUFtQkMsVUFBbkIsRUFBK0JsQyxrQkFBL0IsQ0FBUDtBQUNELENBUkQ7QUFVQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBRSxlQUFlLENBQUNOLFNBQWhCLENBQTBCNEMsTUFBMUIsR0FBbUMsVUFBVU4sVUFBVixFQUFzQjtBQUN2RCxNQUFJN0IsSUFBSSxHQUFHLElBQVgsQ0FEdUQsQ0FFdkQ7QUFDQTs7QUFDQSxNQUFJNkIsVUFBVSxLQUFLSyxTQUFuQixFQUNFTCxVQUFVLEdBQUcsRUFBYjtBQUNGLFNBQU83QixJQUFJLENBQUM0QixhQUFMLENBQW1CQyxVQUFuQixFQUErQmpDLFlBQS9CLENBQVA7QUFDRCxDQVBEO0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQUMsZUFBZSxDQUFDTixTQUFoQixDQUEwQndDLE1BQTFCLEdBQW1DLFVBQVVLLGFBQVYsRUFBeUI7QUFDMUQsTUFBSUMsS0FBSyxHQUFHakIsSUFBSSxDQUFDa0IsS0FBTCxDQUFXLEtBQUs3QixRQUFMLEtBQWtCMkIsYUFBYSxDQUFDNUQsTUFBM0MsQ0FBWjtBQUNBLE1BQUksT0FBTzRELGFBQVAsS0FBeUIsUUFBN0IsRUFDRSxPQUFPQSxhQUFhLENBQUNHLE1BQWQsQ0FBcUJGLEtBQXJCLEVBQTRCLENBQTVCLENBQVAsQ0FERixLQUdFLE9BQU9ELGFBQWEsQ0FBQ0MsS0FBRCxDQUFwQjtBQUNILENBTkQsQyxDQVFBO0FBQ0E7QUFFQTs7O0FBQ0EsSUFBSUcsTUFBTSxHQUFJLE9BQU96QixNQUFQLEtBQWtCLFdBQWxCLElBQWlDQSxNQUFNLENBQUMwQixXQUF6QyxJQUNOLE9BQU9DLFFBQVAsS0FBb0IsV0FBcEIsSUFDR0EsUUFBUSxDQUFDQyxlQURaLElBRUdELFFBQVEsQ0FBQ0MsZUFBVCxDQUF5QkMsWUFIdEIsSUFJTixPQUFPRixRQUFQLEtBQW9CLFdBQXBCLElBQ0dBLFFBQVEsQ0FBQ0csSUFEWixJQUVHSCxRQUFRLENBQUNHLElBQVQsQ0FBY0QsWUFOWCxJQU9QLENBUE47QUFTQSxJQUFJRSxLQUFLLEdBQUksT0FBTy9CLE1BQVAsS0FBa0IsV0FBbEIsSUFBaUNBLE1BQU0sQ0FBQ2dDLFVBQXpDLElBQ0wsT0FBT0wsUUFBUCxLQUFvQixXQUFwQixJQUNHQSxRQUFRLENBQUNDLGVBRFosSUFFR0QsUUFBUSxDQUFDQyxlQUFULENBQXlCSyxXQUh2QixJQUlMLE9BQU9OLFFBQVAsS0FBb0IsV0FBcEIsSUFDR0EsUUFBUSxDQUFDRyxJQURaLElBRUdILFFBQVEsQ0FBQ0csSUFBVCxDQUFjRyxXQU5aLElBT04sQ0FQTjtBQVNBLElBQUlDLEtBQUssR0FBSSxPQUFPQyxTQUFQLEtBQXFCLFdBQXJCLElBQW9DQSxTQUFTLENBQUNDLFNBQS9DLElBQTZELEVBQXpFOztBQUVBLFNBQVNDLG9DQUFULEdBQWdEO0FBQzlDLFNBQU8sSUFBSXZELGVBQUosQ0FDTEEsZUFBZSxDQUFDSSxJQUFoQixDQUFxQkUsSUFEaEIsRUFFTDtBQUFDQyxTQUFLLEVBQUUsQ0FBQyxJQUFJbkIsSUFBSixFQUFELEVBQVd1RCxNQUFYLEVBQW1CTSxLQUFuQixFQUEwQkcsS0FBMUIsRUFBaUM3QixJQUFJLENBQUNsQyxNQUFMLEVBQWpDO0FBQVIsR0FGSyxDQUFQO0FBR0Q7O0FBQUE7O0FBRUQsSUFBSXRCLE1BQU0sQ0FBQ0MsUUFBWCxFQUFxQjtBQUNuQndGLFFBQU0sR0FBRyxJQUFJeEQsZUFBSixDQUFvQkEsZUFBZSxDQUFDSSxJQUFoQixDQUFxQk0sV0FBekMsQ0FBVDtBQUNELENBRkQsTUFFTztBQUNMLE1BQUksT0FBT1EsTUFBUCxLQUFrQixXQUFsQixJQUFpQ0EsTUFBTSxDQUFDQyxNQUF4QyxJQUNBRCxNQUFNLENBQUNDLE1BQVAsQ0FBY0MsZUFEbEIsRUFDbUM7QUFDakNvQyxVQUFNLEdBQUcsSUFBSXhELGVBQUosQ0FBb0JBLGVBQWUsQ0FBQ0ksSUFBaEIsQ0FBcUJPLGNBQXpDLENBQVQ7QUFDRCxHQUhELE1BR087QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E2QyxVQUFNLEdBQUdELG9DQUFvQyxFQUE3QztBQUNEO0FBQ0YsQyxDQUVEO0FBQ0E7OztBQUNBQyxNQUFNLENBQUNDLGVBQVAsR0FBeUIsWUFBb0I7QUFBQSxvQ0FBUGxELEtBQU87QUFBUEEsU0FBTztBQUFBOztBQUMzQyxNQUFJQSxLQUFLLENBQUM1QixNQUFOLEtBQWlCLENBQXJCLEVBQXdCO0FBQ3RCLFVBQU0sSUFBSTBCLEtBQUosQ0FBVSx3QkFBVixDQUFOO0FBQ0Q7O0FBQ0QsU0FBTyxJQUFJTCxlQUFKLENBQW9CQSxlQUFlLENBQUNJLElBQWhCLENBQXFCRSxJQUF6QyxFQUErQztBQUFDQyxTQUFLLEVBQUVBO0FBQVIsR0FBL0MsQ0FBUDtBQUNELENBTEQsQyxDQU9BO0FBQ0E7OztBQUNBaUQsTUFBTSxDQUFDRSxRQUFQLEdBQWtCSCxvQ0FBb0MsRUFBdEQsQyIsImZpbGUiOiIvcGFja2FnZXMvcmFuZG9tLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2UgdXNlIGNyeXB0b2dyYXBoaWNhbGx5IHN0cm9uZyBQUk5HcyAoY3J5cHRvLmdldFJhbmRvbUJ5dGVzKCkgb24gdGhlIHNlcnZlcixcbi8vIHdpbmRvdy5jcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKCkgaW4gdGhlIGJyb3dzZXIpIHdoZW4gYXZhaWxhYmxlLiBJZiB0aGVzZVxuLy8gUFJOR3MgZmFpbCwgd2UgZmFsbCBiYWNrIHRvIHRoZSBBbGVhIFBSTkcsIHdoaWNoIGlzIG5vdCBjcnlwdG9ncmFwaGljYWxseVxuLy8gc3Ryb25nLCBhbmQgd2Ugc2VlZCBpdCB3aXRoIHZhcmlvdXMgc291cmNlcyBzdWNoIGFzIHRoZSBkYXRlLCBNYXRoLnJhbmRvbSxcbi8vIGFuZCB3aW5kb3cgc2l6ZSBvbiB0aGUgY2xpZW50LiAgV2hlbiB1c2luZyBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKCksIG91clxuLy8gcHJpbWl0aXZlIGlzIGhleFN0cmluZygpLCBmcm9tIHdoaWNoIHdlIGNvbnN0cnVjdCBmcmFjdGlvbigpLiBXaGVuIHVzaW5nXG4vLyB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcygpIG9yIGFsZWEsIHRoZSBwcmltaXRpdmUgaXMgZnJhY3Rpb24gYW5kIHdlIHVzZVxuLy8gdGhhdCB0byBjb25zdHJ1Y3QgaGV4IHN0cmluZy5cblxuaWYgKE1ldGVvci5pc1NlcnZlcilcbiAgdmFyIG5vZGVDcnlwdG8gPSBOcG0ucmVxdWlyZSgnY3J5cHRvJyk7XG5cbi8vIHNlZSBodHRwOi8vYmFhZ29lLm9yZy9lbi93aWtpL0JldHRlcl9yYW5kb21fbnVtYmVyc19mb3JfamF2YXNjcmlwdFxuLy8gZm9yIGEgZnVsbCBkaXNjdXNzaW9uIGFuZCBBbGVhIGltcGxlbWVudGF0aW9uLlxudmFyIEFsZWEgPSBmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIE1hc2goKSB7XG4gICAgdmFyIG4gPSAweGVmYzgyNDlkO1xuXG4gICAgdmFyIG1hc2ggPSBmdW5jdGlvbihkYXRhKSB7XG4gICAgICBkYXRhID0gZGF0YS50b1N0cmluZygpO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIG4gKz0gZGF0YS5jaGFyQ29kZUF0KGkpO1xuICAgICAgICB2YXIgaCA9IDAuMDI1MTk2MDMyODI0MTY5MzggKiBuO1xuICAgICAgICBuID0gaCA+Pj4gMDtcbiAgICAgICAgaCAtPSBuO1xuICAgICAgICBoICo9IG47XG4gICAgICAgIG4gPSBoID4+PiAwO1xuICAgICAgICBoIC09IG47XG4gICAgICAgIG4gKz0gaCAqIDB4MTAwMDAwMDAwOyAvLyAyXjMyXG4gICAgICB9XG4gICAgICByZXR1cm4gKG4gPj4+IDApICogMi4zMjgzMDY0MzY1Mzg2OTYzZS0xMDsgLy8gMl4tMzJcbiAgICB9O1xuXG4gICAgbWFzaC52ZXJzaW9uID0gJ01hc2ggMC45JztcbiAgICByZXR1cm4gbWFzaDtcbiAgfVxuXG4gIHJldHVybiAoZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICB2YXIgczAgPSAwO1xuICAgIHZhciBzMSA9IDA7XG4gICAgdmFyIHMyID0gMDtcbiAgICB2YXIgYyA9IDE7XG5cbiAgICBpZiAoYXJncy5sZW5ndGggPT0gMCkge1xuICAgICAgYXJncyA9IFsrbmV3IERhdGVdO1xuICAgIH1cbiAgICB2YXIgbWFzaCA9IE1hc2goKTtcbiAgICBzMCA9IG1hc2goJyAnKTtcbiAgICBzMSA9IG1hc2goJyAnKTtcbiAgICBzMiA9IG1hc2goJyAnKTtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJncy5sZW5ndGg7IGkrKykge1xuICAgICAgczAgLT0gbWFzaChhcmdzW2ldKTtcbiAgICAgIGlmIChzMCA8IDApIHtcbiAgICAgICAgczAgKz0gMTtcbiAgICAgIH1cbiAgICAgIHMxIC09IG1hc2goYXJnc1tpXSk7XG4gICAgICBpZiAoczEgPCAwKSB7XG4gICAgICAgIHMxICs9IDE7XG4gICAgICB9XG4gICAgICBzMiAtPSBtYXNoKGFyZ3NbaV0pO1xuICAgICAgaWYgKHMyIDwgMCkge1xuICAgICAgICBzMiArPSAxO1xuICAgICAgfVxuICAgIH1cbiAgICBtYXNoID0gbnVsbDtcblxuICAgIHZhciByYW5kb20gPSBmdW5jdGlvbigpIHtcbiAgICAgIHZhciB0ID0gMjA5MTYzOSAqIHMwICsgYyAqIDIuMzI4MzA2NDM2NTM4Njk2M2UtMTA7IC8vIDJeLTMyXG4gICAgICBzMCA9IHMxO1xuICAgICAgczEgPSBzMjtcbiAgICAgIHJldHVybiBzMiA9IHQgLSAoYyA9IHQgfCAwKTtcbiAgICB9O1xuICAgIHJhbmRvbS51aW50MzIgPSBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiByYW5kb20oKSAqIDB4MTAwMDAwMDAwOyAvLyAyXjMyXG4gICAgfTtcbiAgICByYW5kb20uZnJhY3Q1MyA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHJhbmRvbSgpICtcbiAgICAgICAgKHJhbmRvbSgpICogMHgyMDAwMDAgfCAwKSAqIDEuMTEwMjIzMDI0NjI1MTU2NWUtMTY7IC8vIDJeLTUzXG4gICAgfTtcbiAgICByYW5kb20udmVyc2lvbiA9ICdBbGVhIDAuOSc7XG4gICAgcmFuZG9tLmFyZ3MgPSBhcmdzO1xuICAgIHJldHVybiByYW5kb207XG5cbiAgfSAoQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xufTtcblxudmFyIFVOTUlTVEFLQUJMRV9DSEFSUyA9IFwiMjM0NTY3ODlBQkNERUZHSEpLTE1OUFFSU1RXWFlaYWJjZGVmZ2hpamttbm9wcXJzdHV2d3h5elwiO1xudmFyIEJBU0U2NF9DSEFSUyA9IFwiYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXpBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWlwiICtcbiAgXCIwMTIzNDU2Nzg5LV9cIjtcblxuLy8gYHR5cGVgIGlzIG9uZSBvZiBgUmFuZG9tR2VuZXJhdG9yLlR5cGVgIGFzIGRlZmluZWQgYmVsb3cuXG4vL1xuLy8gb3B0aW9uczpcbi8vIC0gc2VlZHM6IChyZXF1aXJlZCwgb25seSBmb3IgUmFuZG9tR2VuZXJhdG9yLlR5cGUuQUxFQSkgYW4gYXJyYXlcbi8vICAgd2hvc2UgaXRlbXMgd2lsbCBiZSBgdG9TdHJpbmdgZWQgYW5kIHVzZWQgYXMgdGhlIHNlZWQgdG8gdGhlIEFsZWFcbi8vICAgYWxnb3JpdGhtXG52YXIgUmFuZG9tR2VuZXJhdG9yID0gZnVuY3Rpb24gKHR5cGUsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBzZWxmLnR5cGUgPSB0eXBlO1xuXG4gIGlmICghUmFuZG9tR2VuZXJhdG9yLlR5cGVbdHlwZV0pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmtub3duIHJhbmRvbSBnZW5lcmF0b3IgdHlwZTogXCIgKyB0eXBlKTtcbiAgfVxuXG4gIGlmICh0eXBlID09PSBSYW5kb21HZW5lcmF0b3IuVHlwZS5BTEVBKSB7XG4gICAgaWYgKCFvcHRpb25zLnNlZWRzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzZWVkcyB3ZXJlIHByb3ZpZGVkIGZvciBBbGVhIFBSTkdcIik7XG4gICAgfVxuICAgIHNlbGYuYWxlYSA9IEFsZWEuYXBwbHkobnVsbCwgb3B0aW9ucy5zZWVkcyk7XG4gIH1cbn07XG5cbi8vIFR5cGVzIG9mIFBSTkdzIHN1cHBvcnRlZCBieSB0aGUgYFJhbmRvbUdlbmVyYXRvcmAgY2xhc3NcblJhbmRvbUdlbmVyYXRvci5UeXBlID0ge1xuICAvLyBVc2UgTm9kZSdzIGJ1aWx0LWluIGBjcnlwdG8uZ2V0UmFuZG9tQnl0ZXNgIChjcnlwdG9ncmFwaGljYWxseVxuICAvLyBzZWN1cmUgYnV0IG5vdCBzZWVkYWJsZSwgcnVucyBvbmx5IG9uIHRoZSBzZXJ2ZXIpLiBSZXZlcnRzIHRvXG4gIC8vIGBjcnlwdG8uZ2V0UHNldWRvUmFuZG9tQnl0ZXNgIGluIHRoZSBleHRyZW1lbHkgdW5jb21tb24gY2FzZSB0aGF0XG4gIC8vIHRoZXJlIGlzbid0IGVub3VnaCBlbnRyb3B5IHlldFxuICBOT0RFX0NSWVBUTzogXCJOT0RFX0NSWVBUT1wiLFxuXG4gIC8vIFVzZSBub24tSUUgYnJvd3NlcidzIGJ1aWx0LWluIGB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlc2BcbiAgLy8gKGNyeXB0b2dyYXBoaWNhbGx5IHNlY3VyZSBidXQgbm90IHNlZWRhYmxlLCBydW5zIG9ubHkgaW4gdGhlXG4gIC8vIGJyb3dzZXIpLlxuICBCUk9XU0VSX0NSWVBUTzogXCJCUk9XU0VSX0NSWVBUT1wiLFxuXG4gIC8vIFVzZSB0aGUgKmZhc3QqLCBzZWVkYWFibGUgYW5kIG5vdCBjcnlwdG9ncmFwaGljYWxseSBzZWN1cmVcbiAgLy8gQWxlYSBhbGdvcml0aG1cbiAgQUxFQTogXCJBTEVBXCIsXG59O1xuXG4vKipcbiAqIEBuYW1lIFJhbmRvbS5mcmFjdGlvblxuICogQHN1bW1hcnkgUmV0dXJuIGEgbnVtYmVyIGJldHdlZW4gMCBhbmQgMSwgbGlrZSBgTWF0aC5yYW5kb21gLlxuICogQGxvY3VzIEFueXdoZXJlXG4gKi9cblJhbmRvbUdlbmVyYXRvci5wcm90b3R5cGUuZnJhY3Rpb24gPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgaWYgKHNlbGYudHlwZSA9PT0gUmFuZG9tR2VuZXJhdG9yLlR5cGUuQUxFQSkge1xuICAgIHJldHVybiBzZWxmLmFsZWEoKTtcbiAgfSBlbHNlIGlmIChzZWxmLnR5cGUgPT09IFJhbmRvbUdlbmVyYXRvci5UeXBlLk5PREVfQ1JZUFRPKSB7XG4gICAgdmFyIG51bWVyYXRvciA9IHBhcnNlSW50KHNlbGYuaGV4U3RyaW5nKDgpLCAxNik7XG4gICAgcmV0dXJuIG51bWVyYXRvciAqIDIuMzI4MzA2NDM2NTM4Njk2M2UtMTA7IC8vIDJeLTMyXG4gIH0gZWxzZSBpZiAoc2VsZi50eXBlID09PSBSYW5kb21HZW5lcmF0b3IuVHlwZS5CUk9XU0VSX0NSWVBUTykge1xuICAgIHZhciBhcnJheSA9IG5ldyBVaW50MzJBcnJheSgxKTtcbiAgICB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhhcnJheSk7XG4gICAgcmV0dXJuIGFycmF5WzBdICogMi4zMjgzMDY0MzY1Mzg2OTYzZS0xMDsgLy8gMl4tMzJcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gcmFuZG9tIGdlbmVyYXRvciB0eXBlOiAnICsgc2VsZi50eXBlKTtcbiAgfVxufTtcblxuLyoqXG4gKiBAbmFtZSBSYW5kb20uaGV4U3RyaW5nXG4gKiBAc3VtbWFyeSBSZXR1cm4gYSByYW5kb20gc3RyaW5nIG9mIGBuYCBoZXhhZGVjaW1hbCBkaWdpdHMuXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBwYXJhbSB7TnVtYmVyfSBuIExlbmd0aCBvZiB0aGUgc3RyaW5nXG4gKi9cblJhbmRvbUdlbmVyYXRvci5wcm90b3R5cGUuaGV4U3RyaW5nID0gZnVuY3Rpb24gKGRpZ2l0cykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGlmIChzZWxmLnR5cGUgPT09IFJhbmRvbUdlbmVyYXRvci5UeXBlLk5PREVfQ1JZUFRPKSB7XG4gICAgdmFyIG51bUJ5dGVzID0gTWF0aC5jZWlsKGRpZ2l0cyAvIDIpO1xuICAgIHZhciBieXRlcztcbiAgICAvLyBUcnkgdG8gZ2V0IGNyeXB0b2dyYXBoaWNhbGx5IHN0cm9uZyByYW5kb21uZXNzLiBGYWxsIGJhY2sgdG9cbiAgICAvLyBub24tY3J5cHRvZ3JhcGhpY2FsbHkgc3Ryb25nIGlmIG5vdCBhdmFpbGFibGUuXG4gICAgdHJ5IHtcbiAgICAgIGJ5dGVzID0gbm9kZUNyeXB0by5yYW5kb21CeXRlcyhudW1CeXRlcyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gWFhYIHNob3VsZCByZS10aHJvdyBhbnkgZXJyb3IgZXhjZXB0IGluc3VmZmljaWVudCBlbnRyb3B5XG4gICAgICBieXRlcyA9IG5vZGVDcnlwdG8ucHNldWRvUmFuZG9tQnl0ZXMobnVtQnl0ZXMpO1xuICAgIH1cbiAgICB2YXIgcmVzdWx0ID0gYnl0ZXMudG9TdHJpbmcoXCJoZXhcIik7XG4gICAgLy8gSWYgdGhlIG51bWJlciBvZiBkaWdpdHMgaXMgb2RkLCB3ZSdsbCBoYXZlIGdlbmVyYXRlZCBhbiBleHRyYSA0IGJpdHNcbiAgICAvLyBvZiByYW5kb21uZXNzLCBzbyB3ZSBuZWVkIHRvIHRyaW0gdGhlIGxhc3QgZGlnaXQuXG4gICAgcmV0dXJuIHJlc3VsdC5zdWJzdHJpbmcoMCwgZGlnaXRzKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdGhpcy5fcmFuZG9tU3RyaW5nKGRpZ2l0cywgXCIwMTIzNDU2Nzg5YWJjZGVmXCIpO1xuICB9XG59O1xuXG5SYW5kb21HZW5lcmF0b3IucHJvdG90eXBlLl9yYW5kb21TdHJpbmcgPSBmdW5jdGlvbiAoY2hhcnNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHBoYWJldCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBkaWdpdHMgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGFyc0NvdW50OyBpKyspIHtcbiAgICBkaWdpdHNbaV0gPSBzZWxmLmNob2ljZShhbHBoYWJldCk7XG4gIH1cbiAgcmV0dXJuIGRpZ2l0cy5qb2luKFwiXCIpO1xufTtcblxuLyoqXG4gKiBAbmFtZSBSYW5kb20uaWRcbiAqIEBzdW1tYXJ5IFJldHVybiBhIHVuaXF1ZSBpZGVudGlmaWVyLCBzdWNoIGFzIGBcIkpqd2pnNmdvdVdMWGhNR0tXXCJgLCB0aGF0IGlzXG4gKiBsaWtlbHkgdG8gYmUgdW5pcXVlIGluIHRoZSB3aG9sZSB3b3JsZC5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQHBhcmFtIHtOdW1iZXJ9IFtuXSBPcHRpb25hbCBsZW5ndGggb2YgdGhlIGlkZW50aWZpZXIgaW4gY2hhcmFjdGVyc1xuICogICAoZGVmYXVsdHMgdG8gMTcpXG4gKi9cblJhbmRvbUdlbmVyYXRvci5wcm90b3R5cGUuaWQgPSBmdW5jdGlvbiAoY2hhcnNDb3VudCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIC8vIDE3IGNoYXJhY3RlcnMgaXMgYXJvdW5kIDk2IGJpdHMgb2YgZW50cm9weSwgd2hpY2ggaXMgdGhlIGFtb3VudCBvZlxuICAvLyBzdGF0ZSBpbiB0aGUgQWxlYSBQUk5HLlxuICBpZiAoY2hhcnNDb3VudCA9PT0gdW5kZWZpbmVkKVxuICAgIGNoYXJzQ291bnQgPSAxNztcblxuICByZXR1cm4gc2VsZi5fcmFuZG9tU3RyaW5nKGNoYXJzQ291bnQsIFVOTUlTVEFLQUJMRV9DSEFSUyk7XG59O1xuXG4vKipcbiAqIEBuYW1lIFJhbmRvbS5zZWNyZXRcbiAqIEBzdW1tYXJ5IFJldHVybiBhIHJhbmRvbSBzdHJpbmcgb2YgcHJpbnRhYmxlIGNoYXJhY3RlcnMgd2l0aCA2IGJpdHMgb2ZcbiAqIGVudHJvcHkgcGVyIGNoYXJhY3Rlci4gVXNlIGBSYW5kb20uc2VjcmV0YCBmb3Igc2VjdXJpdHktY3JpdGljYWwgc2VjcmV0c1xuICogdGhhdCBhcmUgaW50ZW5kZWQgZm9yIG1hY2hpbmUsIHJhdGhlciB0aGFuIGh1bWFuLCBjb25zdW1wdGlvbi5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQHBhcmFtIHtOdW1iZXJ9IFtuXSBPcHRpb25hbCBsZW5ndGggb2YgdGhlIHNlY3JldCBzdHJpbmcgKGRlZmF1bHRzIHRvIDQzXG4gKiAgIGNoYXJhY3RlcnMsIG9yIDI1NiBiaXRzIG9mIGVudHJvcHkpXG4gKi9cblJhbmRvbUdlbmVyYXRvci5wcm90b3R5cGUuc2VjcmV0ID0gZnVuY3Rpb24gKGNoYXJzQ291bnQpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICAvLyBEZWZhdWx0IHRvIDI1NiBiaXRzIG9mIGVudHJvcHksIG9yIDQzIGNoYXJhY3RlcnMgYXQgNiBiaXRzIHBlclxuICAvLyBjaGFyYWN0ZXIuXG4gIGlmIChjaGFyc0NvdW50ID09PSB1bmRlZmluZWQpXG4gICAgY2hhcnNDb3VudCA9IDQzO1xuICByZXR1cm4gc2VsZi5fcmFuZG9tU3RyaW5nKGNoYXJzQ291bnQsIEJBU0U2NF9DSEFSUyk7XG59O1xuXG4vKipcbiAqIEBuYW1lIFJhbmRvbS5jaG9pY2VcbiAqIEBzdW1tYXJ5IFJldHVybiBhIHJhbmRvbSBlbGVtZW50IG9mIHRoZSBnaXZlbiBhcnJheSBvciBzdHJpbmcuXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBwYXJhbSB7QXJyYXl8U3RyaW5nfSBhcnJheU9yU3RyaW5nIEFycmF5IG9yIHN0cmluZyB0byBjaG9vc2UgZnJvbVxuICovXG5SYW5kb21HZW5lcmF0b3IucHJvdG90eXBlLmNob2ljZSA9IGZ1bmN0aW9uIChhcnJheU9yU3RyaW5nKSB7XG4gIHZhciBpbmRleCA9IE1hdGguZmxvb3IodGhpcy5mcmFjdGlvbigpICogYXJyYXlPclN0cmluZy5sZW5ndGgpO1xuICBpZiAodHlwZW9mIGFycmF5T3JTdHJpbmcgPT09IFwic3RyaW5nXCIpXG4gICAgcmV0dXJuIGFycmF5T3JTdHJpbmcuc3Vic3RyKGluZGV4LCAxKTtcbiAgZWxzZVxuICAgIHJldHVybiBhcnJheU9yU3RyaW5nW2luZGV4XTtcbn07XG5cbi8vIGluc3RhbnRpYXRlIFJORy4gIEhldXJpc3RpY2FsbHkgY29sbGVjdCBlbnRyb3B5IGZyb20gdmFyaW91cyBzb3VyY2VzIHdoZW4gYVxuLy8gY3J5cHRvZ3JhcGhpYyBQUk5HIGlzbid0IGF2YWlsYWJsZS5cblxuLy8gY2xpZW50IHNvdXJjZXNcbnZhciBoZWlnaHQgPSAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmlubmVySGVpZ2h0KSB8fFxuICAgICAgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAmJiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcbiAgICAgICAmJiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0KSB8fFxuICAgICAgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAmJiBkb2N1bWVudC5ib2R5XG4gICAgICAgJiYgZG9jdW1lbnQuYm9keS5jbGllbnRIZWlnaHQpIHx8XG4gICAgICAxO1xuXG52YXIgd2lkdGggPSAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmlubmVyV2lkdGgpIHx8XG4gICAgICAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJ1xuICAgICAgICYmIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxuICAgICAgICYmIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aCkgfHxcbiAgICAgICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnXG4gICAgICAgJiYgZG9jdW1lbnQuYm9keVxuICAgICAgICYmIGRvY3VtZW50LmJvZHkuY2xpZW50V2lkdGgpIHx8XG4gICAgICAxO1xuXG52YXIgYWdlbnQgPSAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudCkgfHwgXCJcIjtcblxuZnVuY3Rpb24gY3JlYXRlQWxlYUdlbmVyYXRvcldpdGhHZW5lcmF0ZWRTZWVkKCkge1xuICByZXR1cm4gbmV3IFJhbmRvbUdlbmVyYXRvcihcbiAgICBSYW5kb21HZW5lcmF0b3IuVHlwZS5BTEVBLFxuICAgIHtzZWVkczogW25ldyBEYXRlLCBoZWlnaHQsIHdpZHRoLCBhZ2VudCwgTWF0aC5yYW5kb20oKV19KTtcbn07XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgUmFuZG9tID0gbmV3IFJhbmRvbUdlbmVyYXRvcihSYW5kb21HZW5lcmF0b3IuVHlwZS5OT0RFX0NSWVBUTyk7XG59IGVsc2Uge1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuY3J5cHRvICYmXG4gICAgICB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcykge1xuICAgIFJhbmRvbSA9IG5ldyBSYW5kb21HZW5lcmF0b3IoUmFuZG9tR2VuZXJhdG9yLlR5cGUuQlJPV1NFUl9DUllQVE8pO1xuICB9IGVsc2Uge1xuICAgIC8vIE9uIElFIDEwIGFuZCBiZWxvdywgdGhlcmUncyBubyBicm93c2VyIGNyeXB0byBBUElcbiAgICAvLyBhdmFpbGFibGUuIEZhbGwgYmFjayB0byBBbGVhXG4gICAgLy9cbiAgICAvLyBYWFggbG9va3MgbGlrZSBhdCB0aGUgbW9tZW50LCB3ZSB1c2UgQWxlYSBpbiBJRSAxMSBhcyB3ZWxsLFxuICAgIC8vIHdoaWNoIGhhcyBgd2luZG93Lm1zQ3J5cHRvYCBpbnN0ZWFkIG9mIGB3aW5kb3cuY3J5cHRvYC5cbiAgICBSYW5kb20gPSBjcmVhdGVBbGVhR2VuZXJhdG9yV2l0aEdlbmVyYXRlZFNlZWQoKTtcbiAgfVxufVxuXG4vLyBDcmVhdGUgYSBub24tY3J5cHRvZ3JhcGhpY2FsbHkgc2VjdXJlIFBSTkcgd2l0aCBhIGdpdmVuIHNlZWQgKHVzaW5nXG4vLyB0aGUgQWxlYSBhbGdvcml0aG0pXG5SYW5kb20uY3JlYXRlV2l0aFNlZWRzID0gZnVuY3Rpb24gKC4uLnNlZWRzKSB7XG4gIGlmIChzZWVkcy5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzZWVkcyB3ZXJlIHByb3ZpZGVkXCIpO1xuICB9XG4gIHJldHVybiBuZXcgUmFuZG9tR2VuZXJhdG9yKFJhbmRvbUdlbmVyYXRvci5UeXBlLkFMRUEsIHtzZWVkczogc2VlZHN9KTtcbn07XG5cbi8vIFVzZWQgbGlrZSBgUmFuZG9tYCwgYnV0IG11Y2ggZmFzdGVyIGFuZCBub3QgY3J5cHRvZ3JhcGhpY2FsbHlcbi8vIHNlY3VyZVxuUmFuZG9tLmluc2VjdXJlID0gY3JlYXRlQWxlYUdlbmVyYXRvcldpdGhHZW5lcmF0ZWRTZWVkKCk7XG4iXX0=
